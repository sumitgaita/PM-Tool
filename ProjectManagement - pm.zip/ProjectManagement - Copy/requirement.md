# Deployment & IIS Hosting Requirement

## 112. IIS Hosting — API and Web (pmapi / pmtool)

1. The root-folder `publish` output is the deployment source of truth:
   - `publish/api` contains the backend (ASP.NET Core 9 Web API) publish output.
   - `publish/web` contains the frontend (Angular 21 production build) output.
2. When built and hosted on the local IIS server, the application URLs must be:
   - Backend API: `http://localhost/pmapi` (example API health/endpoint: `http://localhost/pmapi/api/project`)
   - Frontend Web: `http://localhost/pmtool`
3. The application must be independently built, deployed, hosted, and runnable on the local IIS server:
   - Backend: `dotnet publish` (Release) → deploy to `publish/api` → host as IIS application `pmapi` (No Managed Code, `AspNetCoreModuleV2`, HTTP port 80, `DisableHttpsRedirection=true` in Production).
   - Frontend: `ng build --configuration production --base-href /pmtool/` → deploy `browser` output to `publish/web` → host as IIS application `pmtool` with SPA fallback to `index.html`.
   - Frontend production build must call the IIS-hosted API (`http://localhost/pmapi/api`), not a dev-only Kestrel URL, while local `ng serve` development keeps using `https://localhost:7284/api`.
   - Backend CORS must allow the IIS-hosted frontend origin (`http://localhost`, `https://localhost`) in addition to `http://localhost:4200`.
4. Any IIS hosting, configuration, deployment, routing, API connectivity, or other hosting-related errors must be identified and fixed independently, including but not limited to:
   - Missing/corrupt `publish/api` or `publish/web` output.
   - Wrong frontend `base-href` (must be `/pmtool/` for sub-application hosting).
   - Wrong frontend `apiUrl` pointing to a dev-only port instead of `/pmapi/api`.
   - Backend CORS rejecting the IIS origin.
   - Missing frontend `web.config` SPA rewrite (deep links / refresh under `/pmtool` must serve `index.html`).
   - Missing IIS prerequisites (ASP.NET Core Hosting Bundle / `AspNetCoreModuleV2`, URL Rewrite module), wrong App Pool (`No Managed Code`), missing `logs` folder permissions, or App-Pool-identity SQL Server login failures under Windows Authentication.
5. Verification on local IIS (Default Web Site, port 80):
   - `http://localhost/pmapi/api/project` (or equivalent health endpoint) responds after login/API call succeeds.
   - `http://localhost/pmtool` loads the login page, login with `admin/admin123` succeeds, and dashboard/lists load data from `pmapi` with no CORS/mixed-content/404 errors.

# Database Backup Requirement

## 113. Database Backup Page (Super Admin Only)

1. Create a new **`Database Backup`** folder in the project root directory.
2. The application must automatically create and store a **database backup on a daily basis** in this folder.
3. The **Super Admin** is the only user who can access the **Database Backup** page (new page under **Administration** with the page name **Database Backup**).
4. The Database Backup page must provide a UI to:
   * View the available database backup files.
   * Download a selected backup file.
   * Restore the database from a selected backup file.
   * Create a new database from a selected backup file (clone under a new name; the live database is not touched).
5. Only the **Super Admin** can download or restore database backup files.
6. Before restoring a database, display a confirmation dialog clearly warning that the existing database will be overwritten/replaced.
7. Implement the required frontend, backend API, database backup, restore, validation, authorization, and error-handling functionality.
8. Ensure that unauthorized users cannot access the page or invoke the backup download/restore APIs directly.
9. Configure the daily automatic backup process so that it continues to work when the application is hosted on the local IIS server.
10. Handle backup and restore failures gracefully and display appropriate success or error messages in the UI.
11. Follow the application's existing authentication, authorization, and **Super Admin permission logic**.

# Document Section – Project Document Requirement

## 114. Project Document Page

1. Create a **`Document`** folder in the project root directory.
2. Under the `Document` folder, create separate subfolders based on the **project name**.
   * Example: `Document/Project A/`
   * Example: `Document/Project B/`
3. Store all project-related documents in the corresponding project-name folder.
4. The system should support the following document/file types:
   * PDF (`.pdf`)
   * Word (`.doc`, `.docx`)
   * Excel (`.xls`, `.xlsx`)
   * Images (`.jpg`, `.jpeg`, `.png`, etc.)
5. The **Project Document** page should allow users to view and manage documents according to their assigned project permissions.
6. Apply the existing **Document page permission rules** for:
   * **View** – View/download project documents.
   * **Add** – Upload/add documents to the appropriate project folder (mapped to the existing Edit permission).
   * **Delete** – Delete documents from the appropriate project folder.
7. Permission checks must be applied both on the **frontend UI** and **backend APIs**. Users must not be able to bypass permissions by directly calling the APIs.
8. The **Super Admin** is exempt from the normal document permission restrictions and must have full access to all project documents, including **view, add, and delete**.
9. Users without the required project/document permission must not be able to perform the corresponding action.
10. Documents must always be stored under the correct project-name folder and should not be mixed between projects.
11. Implement appropriate file validation, error handling, and security checks for document upload, viewing/downloading, and deletion.
12. Follow the application's existing **user, project, role, and permission logic**.

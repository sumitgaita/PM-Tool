# Project Management, Budget, Resource & Expense Tracking Application

Production-ready full-stack app: Angular 21 + ASP.NET Core 9 Web API + SQL Server Express.

## Prerequisites

- Node.js 24+ (`node --version`), npm 10+
- Angular CLI 21 (`npm i -g @angular/cli`)
- .NET SDK 9 (`dotnet --list-sdks`)
- SQL Server Express instance `DESKTOP-J3F0UP4\SQLEXPRESS` running
- SSMS (optional)

## SQL Server verification

```powershell
sqlcmd -S "DESKTOP-J3F0UP4\SQLEXPRESS" -E -Q "SELECT @@VERSION"
Get-Service | Where-Object { $_.Name -like "*SQL*" }
```

Expected: `MSSQL$SQLEXPRESS Running`.

Connection string (Windows Auth, no password in source):

```
Server=DESKTOP-J3F0UP4\SQLEXPRESS;Database=ProjectManagementDB;Integrated Security=True;TrustServerCertificate=True;
```

## Database installation (idempotent, in order)

```powershell
sqlcmd -S "DESKTOP-J3F0UP4\SQLEXPRESS" -E -i database/001_CreateDatabase.sql
sqlcmd -S "DESKTOP-J3F0UP4\SQLEXPRESS" -E -i database/002_CreateTables.sql
sqlcmd -S "DESKTOP-J3F0UP4\SQLEXPRESS" -E -i database/003_CreateIndexes.sql
sqlcmd -S "DESKTOP-J3F0UP4\SQLEXPRESS" -E -i database/004_CreateViews.sql
sqlcmd -S "DESKTOP-J3F0UP4\SQLEXPRESS" -E -i database/005_CreateFunctions.sql
sqlcmd -S "DESKTOP-J3F0UP4\SQLEXPRESS" -E -i database/006_CreateStoredProcedures.sql
sqlcmd -S "DESKTOP-J3F0UP4\SQLEXPRESS" -E -i database/007_CreateSeedData.sql
sqlcmd -S "DESKTOP-J3F0UP4\SQLEXPRESS" -E -i database/008_CreateAdmin.sql
```

Plus manually applied: `usp_Pages_GetAll` (permission pages list). Re-run safe (`IF NOT EXISTS`).

Verify:

```sql
SELECT name FROM sys.databases WHERE name='ProjectManagementDB';
SELECT COUNT(*) FROM Projects; -- 3
SELECT COUNT(*) FROM ProjectBudgets; -- 6
SELECT COUNT(*) FROM Expenses; -- 6
```

## Backend (ASP.NET Core 9)

Canonical project:

```
backend/ProjectManagement.Api/ProjectManagement.Api/ProjectManagement.Api.csproj
```

(The outer `backend/ProjectManagement.Api/` mirrors sources for reference.)

```powershell
dotnet restore backend/ProjectManagement.Api/ProjectManagement.Api/ProjectManagement.Api.csproj
dotnet build backend/ProjectManagement.Api/ProjectManagement.Api/ProjectManagement.Api.csproj
dotnet run --project backend/ProjectManagement.Api/ProjectManagement.Api/ProjectManagement.Api.csproj --launch-profile https
```

- HTTP: http://localhost:5104, HTTPS: https://localhost:7284
- Swagger: https://localhost:7284/swagger
- Auth: JWT Bearer. Controllers: auth, project, budgetcode, resource, projectbudget, projectresource, expense, dashboard, report, user, permission.
- Permission enforcement: `Authorization/RequirePermissionAttribute.cs` (Admin bypass, else `UserPermissions` check → 403). Global errors: `Middleware/GlobalExceptionMiddleware.cs`. DB access: ADO.NET + stored procedures only (`Services/DatabaseService.cs` with nullable-safe mapping fix).

## Frontend (Angular 21 standalone)

```
frontend/project-management-frontend
```

```powershell
npm install --legacy-peer-deps
ng serve --open
# prod build:
ng build --configuration production
```

- URL: http://localhost:4200
- `src/environments/environment*.ts` → `apiUrl: 'https://localhost:7284/api'`
- Routes (`src/app/app.routes.ts`): login + Layout children (dashboard, projects, budget-codes, resources, project-budgets, expenses/expense-history, cost-vs-budget, reports, users, permissions) guarded by AuthGuard + PermissionGuard.
- All feature components are `standalone:true` with Material imports; charts via ng2-charts, Excel via xlsx, currency INR (en-IN).

## Login / Admin setup

Seed admin:

- Username: `admin`
- Password: `admin123` (SHA256 `240be518...` in `008_CreateAdmin.sql`; comment says Admin@123 but actual is admin123)
- Role: Admin (full View/Edit/Delete all pages, no per-page rows needed)

Reset:

```sql
-- SHA256('NewPass123') via PowerShell, then:
UPDATE Users SET PasswordHash='<hex>', IsActive=1 WHERE Username='admin';
```

Create Normal User: login as admin → Users → Create (Role=User) → Permissions → bulk save View/Edit/Delete per page (`POST /api/permission/user/bulk`, admin-only).

## URLs

- Angular: http://localhost:4200
- API HTTP: http://localhost:5104/api
- API HTTPS: https://localhost:7284/api
- Swagger: https://localhost:7284/swagger

## Notes / fixes applied 2026-10-02

- Fixed `007_CreateSeedData.sql` hardcoded IDs (1,2,3) → code-based lookups (PRJ001, BC001, RES001); keyed expenses by ReferenceNo. Repopulated 6 budgets, 5 assignments, 6 expenses.
- Merged orphaned outer backend sources into inner csproj; added JwtBearer/Swashbuckle/SqlClient packages; added `ProjectBudgetController`, `ProjectResourceController`, `PermissionController`, `RequirePermissionAttribute`, `GlobalExceptionMiddleware`; created missing `usp_Pages_GetAll`.
- Fixed `DatabaseService` nullable mapping (`Invalid cast DateTime → DateTime?` broke all LISTS).
- Fixed frontend: installed `@angular/animations@21`, converted 11 components to standalone, created `project-budgets` component, implemented full `app.routes.ts`, fixed interceptor DI (`withInterceptorsFromDi`), raised bundle budgets.
- Verified: login OK, `/api/project` 3 rows, `/api/projectbudget` 6 rows, `/api/dashboard/summary` totals (budget 140000, expense 35500).

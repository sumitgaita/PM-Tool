import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, forkJoin, of } from 'rxjs';
import { switchMap, map } from 'rxjs/operators';
import { resolveApiUrl } from '../core/api-base';
import { Auth } from './auth';
import {
  User, Project, BudgetCode, Resource, ProjectBudget, ProjectResource,
  Expense, DashboardSummary, PagePermission, Page, ApiResponse, ProjectBudgetQuery, UserProject,
  Pond, FishType, FishStocking, FishFeed, FishTreatment, FishMortality, FishGrowth,
  FishHarvest, FishSale, PoultryShed, PoultryBatch, ChickPurchase, PoultryFeed,
  PoultryTreatment, PoultryMortality, PoultryGrowth, EggProduction, PoultrySale,
  Revenue, FarmDashboardSummary, FishDashboardKpis, PoultryDashboardKpis, DatabaseBackupFile,
  DocumentProject, ProjectDocumentFile
} from '../models/models';

@Injectable({
  providedIn: 'root',
})
export class Api {
  private apiUrl = resolveApiUrl();

  constructor(private http: HttpClient, private auth: Auth) {}

  // Users
  getUsers(): Observable<ApiResponse<User[]>> {
    return this.http.get<ApiResponse<User[]>>(`${this.apiUrl}/user`);
  }

  getUsersPaged(searchText?: string, roleName?: string, query?: { pageNumber?: number; pageSize?: number; sortBy?: string; sortDir?: string }): Observable<ApiResponse<User[]>> {
    let params = new HttpParams();
    if (searchText) params = params.set('searchText', searchText);
    if (roleName) params = params.set('roleName', roleName);
    if (query?.pageNumber) params = params.set('pageNumber', query.pageNumber.toString());
    if (query?.pageSize) params = params.set('pageSize', query.pageSize.toString());
    if (query?.sortBy) params = params.set('sortBy', query.sortBy);
    if (query?.sortDir) params = params.set('sortDir', query.sortDir);
    return this.http.get<ApiResponse<User[]>>(`${this.apiUrl}/user/paged`, { params });
  }

  getUser(id: number): Observable<ApiResponse<User>> {
    return this.http.get<ApiResponse<User>>(`${this.apiUrl}/user/${id}`);
  }

  createUser(user: Partial<User>): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/user`, user);
  }

  updateUser(id: number, user: Partial<User>): Observable<ApiResponse<any>> {
    return this.http.put<ApiResponse<any>>(`${this.apiUrl}/user/${id}`, user);
  }

  resetUserPassword(id: number, newPassword: string): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/user/${id}/reset-password`, { newPassword });
  }

  activateUser(id: number): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/user/${id}/activate`, {});
  }

  deactivateUser(id: number): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/user/${id}/deactivate`, {});
  }

  deleteUser(id: number): Observable<ApiResponse<any>> {
    return this.http.delete<ApiResponse<any>>(`${this.apiUrl}/user/${id}`);
  }

  getUserPermissions(userId: number): Observable<ApiResponse<PagePermission[]>> {
    return this.http.get<ApiResponse<PagePermission[]>>(`${this.apiUrl}/user/${userId}/permissions`);
  }

  saveUserPermission(permission: any): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/user/permissions`, permission);
  }

  saveUserPermissionsBulk(userId: number, permissions: any[]): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/permission/user/bulk`, { userId, permissions });
  }

  getPages(): Observable<ApiResponse<Page[]>> {
    return this.http.get<ApiResponse<Page[]>>(`${this.apiUrl}/permission/pages`);
  }

  getMyPermissions(): Observable<ApiResponse<PagePermission[]>> {
    return this.http.get<ApiResponse<PagePermission[]>>(`${this.apiUrl}/permission/my-permissions`);
  }

  // Project Permissions (Super Admin only, except my-projects)
  getUserProjects(userId: number): Observable<ApiResponse<UserProject[]> & { isSuperAdmin?: boolean }> {
    return this.http.get<ApiResponse<UserProject[]> & { isSuperAdmin?: boolean }>(`${this.apiUrl}/projectpermission/user/${userId}`);
  }

  saveUserProjectsBulk(userId: number, projectIds: number[]): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/projectpermission/user/bulk`, { userId, projectIds });
  }

  getMyProjects(): Observable<ApiResponse<Project[]>> {
    return this.http.get<ApiResponse<Project[]>>(`${this.apiUrl}/project/mine`);
  }

  // Projects (scoped: Admin/Normal users only receive assigned projects)
  getProjects(): Observable<ApiResponse<Project[]>> {
    if (this.auth.isSuperAdmin()) {
      return this.http.get<ApiResponse<Project[]>>(`${this.apiUrl}/project`);
    }
    return this.getMyProjects();
  }

  getProjectsPaged(searchText?: string, status?: string, farmType?: string, query?: { pageNumber?: number; pageSize?: number; sortBy?: string; sortDir?: string }): Observable<ApiResponse<Project[]>> {
    let params = new HttpParams();
    if (searchText) params = params.set('searchText', searchText);
    if (status) params = params.set('status', status);
    if (farmType) params = params.set('farmType', farmType);
    if (query?.pageNumber) params = params.set('pageNumber', query.pageNumber.toString());
    if (query?.pageSize) params = params.set('pageSize', query.pageSize.toString());
    if (query?.sortBy) params = params.set('sortBy', query.sortBy);
    if (query?.sortDir) params = params.set('sortDir', query.sortDir);
    return this.http.get<ApiResponse<Project[]>>(`${this.apiUrl}/project/paged`, { params });
  }

  getProject(id: number): Observable<ApiResponse<Project>> {
    return this.http.get<ApiResponse<Project>>(`${this.apiUrl}/project/${id}`);
  }

  getInactiveProjectsPaged(searchText?: string, status?: string, farmType?: string, query?: { pageNumber?: number; pageSize?: number; sortBy?: string; sortDir?: string }): Observable<ApiResponse<Project[]>> {
    let params = new HttpParams();
    if (searchText) params = params.set('searchText', searchText);
    if (status) params = params.set('status', status);
    if (farmType) params = params.set('farmType', farmType);
    if (query?.pageNumber) params = params.set('pageNumber', query.pageNumber.toString());
    if (query?.pageSize) params = params.set('pageSize', query.pageSize.toString());
    if (query?.sortBy) params = params.set('sortBy', query.sortBy);
    if (query?.sortDir) params = params.set('sortDir', query.sortDir);
    return this.http.get<ApiResponse<Project[]>>(`${this.apiUrl}/project/paged/inactive`, { params });
  }

  createProject(project: Partial<Project>): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/project`, project);
  }

  updateProject(id: number, project: Partial<Project>): Observable<ApiResponse<any>> {
    return this.http.put<ApiResponse<any>>(`${this.apiUrl}/project/${id}`, project);
  }

  activateProject(id: number): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/project/${id}/activate`, {});
  }

  deactivateProject(id: number): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/project/${id}/deactivate`, {});
  }

  deleteProject(id: number): Observable<ApiResponse<any>> {
    return this.http.delete<ApiResponse<any>>(`${this.apiUrl}/project/${id}`);
  }

  // Budget Codes
  getBudgetCodes(): Observable<ApiResponse<BudgetCode[]>> {
    return this.http.get<ApiResponse<BudgetCode[]>>(`${this.apiUrl}/budgetcode`);
  }

  getBudgetCodesPaged(searchText?: string, query?: { pageNumber?: number; pageSize?: number; sortBy?: string; sortDir?: string }): Observable<ApiResponse<BudgetCode[]>> {
    let params = new HttpParams();
    if (searchText) params = params.set('searchText', searchText);
    if (query?.pageNumber) params = params.set('pageNumber', query.pageNumber.toString());
    if (query?.pageSize) params = params.set('pageSize', query.pageSize.toString());
    if (query?.sortBy) params = params.set('sortBy', query.sortBy);
    if (query?.sortDir) params = params.set('sortDir', query.sortDir);
    return this.http.get<ApiResponse<BudgetCode[]>>(`${this.apiUrl}/budgetcode/paged`, { params });
  }

  createBudgetCode(budgetCode: Partial<BudgetCode>): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/budgetcode`, budgetCode);
  }

  updateBudgetCode(id: number, budgetCode: Partial<BudgetCode>): Observable<ApiResponse<any>> {
    return this.http.put<ApiResponse<any>>(`${this.apiUrl}/budgetcode/${id}`, budgetCode);
  }

  activateBudgetCode(id: number): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/budgetcode/${id}/activate`, {});
  }

  deactivateBudgetCode(id: number): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/budgetcode/${id}/deactivate`, {});
  }

  deleteBudgetCode(id: number): Observable<ApiResponse<any>> {
    return this.http.delete<ApiResponse<any>>(`${this.apiUrl}/budgetcode/${id}`);
  }

  // Resources
  getResources(): Observable<ApiResponse<Resource[]>> {
    return this.http.get<ApiResponse<Resource[]>>(`${this.apiUrl}/resource`);
  }

  getResourcesPaged(searchText?: string, query?: { pageNumber?: number; pageSize?: number; sortBy?: string; sortDir?: string }): Observable<ApiResponse<Resource[]>> {
    let params = new HttpParams();
    if (searchText) params = params.set('searchText', searchText);
    if (query?.pageNumber) params = params.set('pageNumber', query.pageNumber.toString());
    if (query?.pageSize) params = params.set('pageSize', query.pageSize.toString());
    if (query?.sortBy) params = params.set('sortBy', query.sortBy);
    if (query?.sortDir) params = params.set('sortDir', query.sortDir);
    return this.http.get<ApiResponse<Resource[]>>(`${this.apiUrl}/resource/paged`, { params });
  }

  createResource(resource: Partial<Resource>): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/resource`, resource);
  }

  updateResource(id: number, resource: Partial<Resource>): Observable<ApiResponse<any>> {
    return this.http.put<ApiResponse<any>>(`${this.apiUrl}/resource/${id}`, resource);
  }

  activateResource(id: number): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/resource/${id}/activate`, {});
  }

  deactivateResource(id: number): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/resource/${id}/deactivate`, {});
  }

  deleteResource(id: number): Observable<ApiResponse<any>> {
    return this.http.delete<ApiResponse<any>>(`${this.apiUrl}/resource/${id}`);
  }

  // Project Budgets
  getProjectBudgets(projectId?: number, budgetCodeId?: number, query?: ProjectBudgetQuery): Observable<ApiResponse<ProjectBudget[]>> {
    const q: ProjectBudgetQuery = { projectId, budgetCodeId, ...query };
    let params = new HttpParams();
    if (q.projectId) params = params.set('projectId', q.projectId.toString());
    if (q.budgetCodeId) params = params.set('budgetCodeId', q.budgetCodeId.toString());
    if (q.searchText && q.searchText.trim()) params = params.set('searchText', q.searchText.trim());
    if (q.pageNumber) params = params.set('pageNumber', q.pageNumber.toString());
    if (q.pageSize) params = params.set('pageSize', q.pageSize.toString());
    if (q.sortBy) params = params.set('sortBy', q.sortBy);
    if (q.sortDir) params = params.set('sortDir', q.sortDir);
    return this.http.get<ApiResponse<ProjectBudget[]>>(`${this.apiUrl}/projectbudget`, { params });
  }

  createProjectBudget(budget: Partial<ProjectBudget>): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/projectbudget`, budget);
  }

  updateProjectBudget(id: number, budget: Partial<ProjectBudget>): Observable<ApiResponse<any>> {
    return this.http.put<ApiResponse<any>>(`${this.apiUrl}/projectbudget/${id}`, budget);
  }

  deleteProjectBudget(id: number): Observable<ApiResponse<any>> {
    return this.http.delete<ApiResponse<any>>(`${this.apiUrl}/projectbudget/${id}`);
  }

  // Project Resources
  getProjectResources(projectId?: number, resourceId?: number): Observable<ApiResponse<ProjectResource[]>> {
    let params = new HttpParams();
    if (projectId) params = params.set('projectId', projectId.toString());
    if (resourceId) params = params.set('resourceId', resourceId.toString());
    return this.http.get<ApiResponse<ProjectResource[]>>(`${this.apiUrl}/projectresource`, { params });
  }

  createProjectResource(resource: Partial<ProjectResource>): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/projectresource`, resource);
  }

  updateProjectResource(id: number, resource: Partial<ProjectResource>): Observable<ApiResponse<any>> {
    return this.http.put<ApiResponse<any>>(`${this.apiUrl}/projectresource/${id}`, resource);
  }

  deleteProjectResource(id: number): Observable<ApiResponse<any>> {
    return this.http.delete<ApiResponse<any>>(`${this.apiUrl}/projectresource/${id}`);
  }

  // Expenses
  getExpense(id: number): Observable<ApiResponse<Expense>> {
    return this.http.get<ApiResponse<Expense>>(`${this.apiUrl}/expense/${id}`);
  }

  getExpensesByDate(date: string): Observable<ApiResponse<Expense[]>> {
    return this.http.get<ApiResponse<Expense[]>>(`${this.apiUrl}/expense/by-date/${date}`);
  }

  getExpensesByDateRange(fromDate: string, toDate: string, projectId?: number, budgetCodeId?: number, resourceId?: number, query?: { pageNumber?: number; pageSize?: number; sortBy?: string; sortDir?: string }): Observable<ApiResponse<Expense[]>> {
    let params = new HttpParams()
      .set('fromDate', fromDate)
      .set('toDate', toDate);
    if (projectId) params = params.set('projectId', projectId.toString());
    if (budgetCodeId) params = params.set('budgetCodeId', budgetCodeId.toString());
    if (resourceId) params = params.set('resourceId', resourceId.toString());
    if (query?.pageNumber) params = params.set('pageNumber', query.pageNumber.toString());
    if (query?.pageSize) params = params.set('pageSize', query.pageSize.toString());
    if (query?.sortBy) params = params.set('sortBy', query.sortBy);
    if (query?.sortDir) params = params.set('sortDir', query.sortDir);
    return this.http.get<ApiResponse<Expense[]>>(`${this.apiUrl}/expense/by-date-range`, { params });
  }

  createExpense(expense: Partial<Expense>): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/expense`, expense);
  }

  updateExpense(id: number, expense: Partial<Expense>): Observable<ApiResponse<any>> {
    return this.http.put<ApiResponse<any>>(`${this.apiUrl}/expense/${id}`, expense);
  }

  deleteExpense(id: number): Observable<ApiResponse<any>> {
    return this.http.delete<ApiResponse<any>>(`${this.apiUrl}/expense/${id}`);
  }

  copyExpenses(fromDate: string, toDate: string, projectId?: number, resourceId?: number): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/expense/copy-from-date`, { fromDate, toDate, projectId, resourceId });
  }

  // Dashboard
  getDashboardSummary(projectId?: number, budgetCodeId?: number, fromDate?: string, toDate?: string): Observable<ApiResponse<DashboardSummary>> {
    let params = new HttpParams();
    if (projectId) params = params.set('projectId', projectId.toString());
    if (budgetCodeId) params = params.set('budgetCodeId', budgetCodeId.toString());
    if (fromDate) params = params.set('fromDate', fromDate);
    if (toDate) params = params.set('toDate', toDate);
    return this.http.get<ApiResponse<DashboardSummary>>(`${this.apiUrl}/dashboard/summary`, { params });
  }

  getDashboardProjectWise(fromDate?: string, toDate?: string): Observable<ApiResponse<any[]>> {
    let params = new HttpParams();
    if (fromDate) params = params.set('fromDate', fromDate);
    if (toDate) params = params.set('toDate', toDate);
    return this.http.get<ApiResponse<any[]>>(`${this.apiUrl}/dashboard/project-wise`, { params });
  }

  getDashboardBudgetCodeWise(fromDate?: string, toDate?: string): Observable<ApiResponse<any[]>> {
    let params = new HttpParams();
    if (fromDate) params = params.set('fromDate', fromDate);
    if (toDate) params = params.set('toDate', toDate);
    return this.http.get<ApiResponse<any[]>>(`${this.apiUrl}/dashboard/budget-code-wise`, { params });
  }

  getDashboardMonthly(fromDate?: string, toDate?: string): Observable<ApiResponse<any[]>> {
    let params = new HttpParams();
    if (fromDate) params = params.set('fromDate', fromDate);
    if (toDate) params = params.set('toDate', toDate);
    return this.http.get<ApiResponse<any[]>>(`${this.apiUrl}/dashboard/monthly`, { params });
  }

  getDashboardYearWise(year?: number): Observable<ApiResponse<any[]>> {
    let params = new HttpParams();
    if (year) params = params.set('year', year.toString());
    return this.http.get<ApiResponse<any[]>>(`${this.apiUrl}/dashboard/year-wise`, { params });
  }

  getDashboardResourceWise(fromDate?: string, toDate?: string): Observable<ApiResponse<any[]>> {
    let params = new HttpParams();
    if (fromDate) params = params.set('fromDate', fromDate);
    if (toDate) params = params.set('toDate', toDate);
    return this.http.get<ApiResponse<any[]>>(`${this.apiUrl}/dashboard/resource-wise`, { params });
  }

  // Reports
  getProjectWiseReport(projectId?: number, fromDate?: string, toDate?: string, budgetCodeId?: number, resourceId?: number): Observable<ApiResponse<any[]>> {
    let params = new HttpParams();
    if (projectId) params = params.set('projectId', projectId.toString());
    if (fromDate) params = params.set('fromDate', fromDate);
    if (toDate) params = params.set('toDate', toDate);
    if (budgetCodeId) params = params.set('budgetCodeId', budgetCodeId.toString());
    if (resourceId) params = params.set('resourceId', resourceId.toString());
    return this.http.get<ApiResponse<any[]>>(`${this.apiUrl}/report/project-wise`, { params });
  }

  getDateWiseReport(date: string): Observable<ApiResponse<any[]>> {
    return this.http.get<ApiResponse<any[]>>(`${this.apiUrl}/report/date-wise/${date}`);
  }

  getDateRangeReport(fromDate: string, toDate: string, projectId?: number, budgetCodeId?: number, resourceId?: number): Observable<ApiResponse<any[]>> {
    let params = new HttpParams()
      .set('fromDate', fromDate)
      .set('toDate', toDate);
    if (projectId) params = params.set('projectId', projectId.toString());
    if (budgetCodeId) params = params.set('budgetCodeId', budgetCodeId.toString());
    if (resourceId) params = params.set('resourceId', resourceId.toString());
    return this.http.get<ApiResponse<any[]>>(`${this.apiUrl}/report/date-range`, { params });
  }

  getCostVsBudgetReport(projectId?: number, budgetCodeId?: number, fromDate?: string, toDate?: string): Observable<ApiResponse<any[]>> {
    let params = new HttpParams();
    if (projectId) params = params.set('projectId', projectId.toString());
    if (budgetCodeId) params = params.set('budgetCodeId', budgetCodeId.toString());
    if (fromDate) params = params.set('fromDate', fromDate);
    if (toDate) params = params.set('toDate', toDate);
    return this.http.get<ApiResponse<any[]>>(`${this.apiUrl}/report/cost-vs-budget`, { params });
  }

  // ---- Farming (§68+) ----
  // Fetch all pages of a paged endpoint (100/page) for full filtered export.
  fetchAll<T>(fetch: (page: number) => Observable<ApiResponse<T[]>>): Observable<T[]> {
    return fetch(1).pipe(
      switchMap(first => {
        if (!first.success) return of([]);
        const total = first.totalRecords ?? first.data.length;
        const pages = Math.ceil(total / 100);
        if (pages <= 1) return of(first.data);
        const rest = [];
        for (let p = 2; p <= pages; p++) rest.push(fetch(p));
        return forkJoin(rest).pipe(
          map(results => [...first.data, ...results.flatMap(r => r.success ? r.data : [])]));
      })
    );
  }

  private pagedParams(query?: { pageNumber?: number; pageSize?: number; sortBy?: string; sortDir?: string }): HttpParams {
    let params = new HttpParams();
    if (query?.pageNumber) params = params.set('pageNumber', query.pageNumber.toString());
    if (query?.pageSize) params = params.set('pageSize', query.pageSize.toString());
    if (query?.sortBy) params = params.set('sortBy', query.sortBy);
    if (query?.sortDir) params = params.set('sortDir', query.sortDir);
    return params;
  }

  // Ponds
  getPonds(projectId?: number, searchText?: string, query?: { pageNumber?: number; pageSize?: number }): Observable<ApiResponse<Pond[]>> {
    let params = this.pagedParams(query);
    if (projectId) params = params.set('projectId', projectId.toString());
    if (searchText) params = params.set('searchText', searchText);
    return this.http.get<ApiResponse<Pond[]>>(`${this.apiUrl}/pond/paged`, { params });
  }
  createPond(data: Partial<Pond>): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/pond`, data);
  }
  updatePond(id: number, data: Partial<Pond>): Observable<ApiResponse<any>> {
    return this.http.put<ApiResponse<any>>(`${this.apiUrl}/pond/${id}`, data);
  }
  deletePond(id: number): Observable<ApiResponse<any>> {
    return this.http.delete<ApiResponse<any>>(`${this.apiUrl}/pond/${id}`);
  }
  activatePond(id: number): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/pond/${id}/activate`, {});
  }
  deactivatePond(id: number): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/pond/${id}/deactivate`, {});
  }

  // Fish types
  getFishTypes(): Observable<ApiResponse<FishType[]>> {
    return this.http.get<ApiResponse<FishType[]>>(`${this.apiUrl}/fishtype`);
  }
  createFishType(data: Partial<FishType>): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/fishtype`, data);
  }
  updateFishType(id: number, data: Partial<FishType>): Observable<ApiResponse<any>> {
    return this.http.put<ApiResponse<any>>(`${this.apiUrl}/fishtype/${id}`, data);
  }
  deleteFishType(id: number): Observable<ApiResponse<any>> {
    return this.http.delete<ApiResponse<any>>(`${this.apiUrl}/fishtype/${id}`);
  }
  activateFishType(id: number): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/fishtype/${id}/activate`, {});
  }
  deactivateFishType(id: number): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/fishtype/${id}/deactivate`, {});
  }

  // Fish stocking
  getFishStocking(projectId?: number, pondId?: number, fishTypeId?: number, searchText?: string, fromDate?: string, toDate?: string, query?: { pageNumber?: number; pageSize?: number }): Observable<ApiResponse<FishStocking[]>> {
    let params = this.pagedParams(query);
    if (projectId) params = params.set('projectId', projectId.toString());
    if (pondId) params = params.set('pondId', pondId.toString());
    if (fishTypeId) params = params.set('fishTypeId', fishTypeId.toString());
    if (searchText) params = params.set('searchText', searchText);
    if (fromDate) params = params.set('fromDate', fromDate);
    if (toDate) params = params.set('toDate', toDate);
    return this.http.get<ApiResponse<FishStocking[]>>(`${this.apiUrl}/fishstocking/paged`, { params });
  }
  createFishStocking(data: any): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/fishstocking`, data);
  }
  updateFishStocking(id: number, data: any): Observable<ApiResponse<any>> {
    return this.http.put<ApiResponse<any>>(`${this.apiUrl}/fishstocking/${id}`, data);
  }
  deleteFishStocking(id: number): Observable<ApiResponse<any>> {
    return this.http.delete<ApiResponse<any>>(`${this.apiUrl}/fishstocking/${id}`);
  }

  // Fish feed
  getFishFeed(projectId?: number, pondId?: number, searchText?: string, fromDate?: string, toDate?: string, query?: { pageNumber?: number; pageSize?: number }): Observable<ApiResponse<FishFeed[]>> {
    let params = this.pagedParams(query);
    if (projectId) params = params.set('projectId', projectId.toString());
    if (pondId) params = params.set('pondId', pondId.toString());
    if (searchText) params = params.set('searchText', searchText);
    if (fromDate) params = params.set('fromDate', fromDate);
    if (toDate) params = params.set('toDate', toDate);
    return this.http.get<ApiResponse<FishFeed[]>>(`${this.apiUrl}/fishfeed/paged`, { params });
  }
  createFishFeed(data: any): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/fishfeed`, data);
  }
  updateFishFeed(id: number, data: any): Observable<ApiResponse<any>> {
    return this.http.put<ApiResponse<any>>(`${this.apiUrl}/fishfeed/${id}`, data);
  }
  deleteFishFeed(id: number): Observable<ApiResponse<any>> {
    return this.http.delete<ApiResponse<any>>(`${this.apiUrl}/fishfeed/${id}`);
  }

  // Fish treatment
  getFishTreatment(projectId?: number, pondId?: number, searchText?: string, fromDate?: string, toDate?: string, query?: { pageNumber?: number; pageSize?: number }): Observable<ApiResponse<FishTreatment[]>> {
    let params = this.pagedParams(query);
    if (projectId) params = params.set('projectId', projectId.toString());
    if (pondId) params = params.set('pondId', pondId.toString());
    if (searchText) params = params.set('searchText', searchText);
    if (fromDate) params = params.set('fromDate', fromDate);
    if (toDate) params = params.set('toDate', toDate);
    return this.http.get<ApiResponse<FishTreatment[]>>(`${this.apiUrl}/fishtreatment/paged`, { params });
  }
  createFishTreatment(data: any): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/fishtreatment`, data);
  }
  updateFishTreatment(id: number, data: any): Observable<ApiResponse<any>> {
    return this.http.put<ApiResponse<any>>(`${this.apiUrl}/fishtreatment/${id}`, data);
  }
  deleteFishTreatment(id: number): Observable<ApiResponse<any>> {
    return this.http.delete<ApiResponse<any>>(`${this.apiUrl}/fishtreatment/${id}`);
  }

  // Fish mortality
  getFishMortality(projectId?: number, pondId?: number, fishTypeId?: number, fromDate?: string, toDate?: string, query?: { pageNumber?: number; pageSize?: number }): Observable<ApiResponse<FishMortality[]>> {
    let params = this.pagedParams(query);
    if (projectId) params = params.set('projectId', projectId.toString());
    if (pondId) params = params.set('pondId', pondId.toString());
    if (fishTypeId) params = params.set('fishTypeId', fishTypeId.toString());
    if (fromDate) params = params.set('fromDate', fromDate);
    if (toDate) params = params.set('toDate', toDate);
    return this.http.get<ApiResponse<FishMortality[]>>(`${this.apiUrl}/fishmortality/paged`, { params });
  }
  createFishMortality(data: any): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/fishmortality`, data);
  }
  updateFishMortality(id: number, data: any): Observable<ApiResponse<any>> {
    return this.http.put<ApiResponse<any>>(`${this.apiUrl}/fishmortality/${id}`, data);
  }
  deleteFishMortality(id: number): Observable<ApiResponse<any>> {
    return this.http.delete<ApiResponse<any>>(`${this.apiUrl}/fishmortality/${id}`);
  }

  // Fish growth
  getFishGrowth(projectId?: number, pondId?: number, fishTypeId?: number, fromDate?: string, toDate?: string, query?: { pageNumber?: number; pageSize?: number }): Observable<ApiResponse<FishGrowth[]>> {
    let params = this.pagedParams(query);
    if (projectId) params = params.set('projectId', projectId.toString());
    if (pondId) params = params.set('pondId', pondId.toString());
    if (fishTypeId) params = params.set('fishTypeId', fishTypeId.toString());
    if (fromDate) params = params.set('fromDate', fromDate);
    if (toDate) params = params.set('toDate', toDate);
    return this.http.get<ApiResponse<FishGrowth[]>>(`${this.apiUrl}/fishgrowth/paged`, { params });
  }
  createFishGrowth(data: any): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/fishgrowth`, data);
  }
  updateFishGrowth(id: number, data: any): Observable<ApiResponse<any>> {
    return this.http.put<ApiResponse<any>>(`${this.apiUrl}/fishgrowth/${id}`, data);
  }
  deleteFishGrowth(id: number): Observable<ApiResponse<any>> {
    return this.http.delete<ApiResponse<any>>(`${this.apiUrl}/fishgrowth/${id}`);
  }

  // Fish harvest
  getFishHarvest(projectId?: number, pondId?: number, fishTypeId?: number, fromDate?: string, toDate?: string, query?: { pageNumber?: number; pageSize?: number }): Observable<ApiResponse<FishHarvest[]>> {
    let params = this.pagedParams(query);
    if (projectId) params = params.set('projectId', projectId.toString());
    if (pondId) params = params.set('pondId', pondId.toString());
    if (fishTypeId) params = params.set('fishTypeId', fishTypeId.toString());
    if (fromDate) params = params.set('fromDate', fromDate);
    if (toDate) params = params.set('toDate', toDate);
    return this.http.get<ApiResponse<FishHarvest[]>>(`${this.apiUrl}/fishharvest/paged`, { params });
  }
  createFishHarvest(data: any): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/fishharvest`, data);
  }
  updateFishHarvest(id: number, data: any): Observable<ApiResponse<any>> {
    return this.http.put<ApiResponse<any>>(`${this.apiUrl}/fishharvest/${id}`, data);
  }
  deleteFishHarvest(id: number): Observable<ApiResponse<any>> {
    return this.http.delete<ApiResponse<any>>(`${this.apiUrl}/fishharvest/${id}`);
  }

  // Fish sales
  getFishSales(projectId?: number, fishTypeId?: number, paymentStatus?: string, fromDate?: string, toDate?: string, query?: { pageNumber?: number; pageSize?: number }): Observable<ApiResponse<FishSale[]>> {
    let params = this.pagedParams(query);
    if (projectId) params = params.set('projectId', projectId.toString());
    if (fishTypeId) params = params.set('fishTypeId', fishTypeId.toString());
    if (paymentStatus) params = params.set('paymentStatus', paymentStatus);
    if (fromDate) params = params.set('fromDate', fromDate);
    if (toDate) params = params.set('toDate', toDate);
    return this.http.get<ApiResponse<FishSale[]>>(`${this.apiUrl}/fishsales/paged`, { params });
  }
  createFishSale(data: any): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/fishsales`, data);
  }
  updateFishSale(id: number, data: any): Observable<ApiResponse<any>> {
    return this.http.put<ApiResponse<any>>(`${this.apiUrl}/fishsales/${id}`, data);
  }
  deleteFishSale(id: number): Observable<ApiResponse<any>> {
    return this.http.delete<ApiResponse<any>>(`${this.apiUrl}/fishsales/${id}`);
  }

  // Poultry sheds
  getPoultrySheds(projectId?: number, searchText?: string, query?: { pageNumber?: number; pageSize?: number }): Observable<ApiResponse<PoultryShed[]>> {
    let params = this.pagedParams(query);
    if (projectId) params = params.set('projectId', projectId.toString());
    if (searchText) params = params.set('searchText', searchText);
    return this.http.get<ApiResponse<PoultryShed[]>>(`${this.apiUrl}/poultryshed/paged`, { params });
  }
  createPoultryShed(data: Partial<PoultryShed>): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/poultryshed`, data);
  }
  updatePoultryShed(id: number, data: Partial<PoultryShed>): Observable<ApiResponse<any>> {
    return this.http.put<ApiResponse<any>>(`${this.apiUrl}/poultryshed/${id}`, data);
  }
  deletePoultryShed(id: number): Observable<ApiResponse<any>> {
    return this.http.delete<ApiResponse<any>>(`${this.apiUrl}/poultryshed/${id}`);
  }
  activatePoultryShed(id: number): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/poultryshed/${id}/activate`, {});
  }
  deactivatePoultryShed(id: number): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/poultryshed/${id}/deactivate`, {});
  }

  // Poultry batches
  getPoultryBatches(projectId?: number, shedId?: number, searchText?: string, status?: string, query?: { pageNumber?: number; pageSize?: number }): Observable<ApiResponse<PoultryBatch[]>> {
    let params = this.pagedParams(query);
    if (projectId) params = params.set('projectId', projectId.toString());
    if (shedId) params = params.set('shedId', shedId.toString());
    if (searchText) params = params.set('searchText', searchText);
    if (status) params = params.set('status', status);
    return this.http.get<ApiResponse<PoultryBatch[]>>(`${this.apiUrl}/poultrybatch/paged`, { params });
  }
  createPoultryBatch(data: any): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/poultrybatch`, data);
  }
  updatePoultryBatch(id: number, data: any): Observable<ApiResponse<any>> {
    return this.http.put<ApiResponse<any>>(`${this.apiUrl}/poultrybatch/${id}`, data);
  }
  deletePoultryBatch(id: number): Observable<ApiResponse<any>> {
    return this.http.delete<ApiResponse<any>>(`${this.apiUrl}/poultrybatch/${id}`);
  }
  activatePoultryBatch(id: number): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/poultrybatch/${id}/activate`, {});
  }
  deactivatePoultryBatch(id: number): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/poultrybatch/${id}/deactivate`, {});
  }

  // Chick purchase
  getChickPurchases(projectId?: number, batchId?: number, fromDate?: string, toDate?: string, query?: { pageNumber?: number; pageSize?: number }): Observable<ApiResponse<ChickPurchase[]>> {
    let params = this.pagedParams(query);
    if (projectId) params = params.set('projectId', projectId.toString());
    if (batchId) params = params.set('batchId', batchId.toString());
    if (fromDate) params = params.set('fromDate', fromDate);
    if (toDate) params = params.set('toDate', toDate);
    return this.http.get<ApiResponse<ChickPurchase[]>>(`${this.apiUrl}/chickpurchase/paged`, { params });
  }
  createChickPurchase(data: any): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/chickpurchase`, data);
  }
  updateChickPurchase(id: number, data: any): Observable<ApiResponse<any>> {
    return this.http.put<ApiResponse<any>>(`${this.apiUrl}/chickpurchase/${id}`, data);
  }
  deleteChickPurchase(id: number): Observable<ApiResponse<any>> {
    return this.http.delete<ApiResponse<any>>(`${this.apiUrl}/chickpurchase/${id}`);
  }

  // Poultry feed
  getPoultryFeed(projectId?: number, batchId?: number, searchText?: string, fromDate?: string, toDate?: string, query?: { pageNumber?: number; pageSize?: number }): Observable<ApiResponse<PoultryFeed[]>> {
    let params = this.pagedParams(query);
    if (projectId) params = params.set('projectId', projectId.toString());
    if (batchId) params = params.set('batchId', batchId.toString());
    if (searchText) params = params.set('searchText', searchText);
    if (fromDate) params = params.set('fromDate', fromDate);
    if (toDate) params = params.set('toDate', toDate);
    return this.http.get<ApiResponse<PoultryFeed[]>>(`${this.apiUrl}/poultryfeed/paged`, { params });
  }
  createPoultryFeed(data: any): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/poultryfeed`, data);
  }
  updatePoultryFeed(id: number, data: any): Observable<ApiResponse<any>> {
    return this.http.put<ApiResponse<any>>(`${this.apiUrl}/poultryfeed/${id}`, data);
  }
  deletePoultryFeed(id: number): Observable<ApiResponse<any>> {
    return this.http.delete<ApiResponse<any>>(`${this.apiUrl}/poultryfeed/${id}`);
  }

  // Poultry treatment
  getPoultryTreatment(projectId?: number, batchId?: number, searchText?: string, fromDate?: string, toDate?: string, query?: { pageNumber?: number; pageSize?: number }): Observable<ApiResponse<PoultryTreatment[]>> {
    let params = this.pagedParams(query);
    if (projectId) params = params.set('projectId', projectId.toString());
    if (batchId) params = params.set('batchId', batchId.toString());
    if (searchText) params = params.set('searchText', searchText);
    if (fromDate) params = params.set('fromDate', fromDate);
    if (toDate) params = params.set('toDate', toDate);
    return this.http.get<ApiResponse<PoultryTreatment[]>>(`${this.apiUrl}/poultrytreatment/paged`, { params });
  }
  createPoultryTreatment(data: any): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/poultrytreatment`, data);
  }
  updatePoultryTreatment(id: number, data: any): Observable<ApiResponse<any>> {
    return this.http.put<ApiResponse<any>>(`${this.apiUrl}/poultrytreatment/${id}`, data);
  }
  deletePoultryTreatment(id: number): Observable<ApiResponse<any>> {
    return this.http.delete<ApiResponse<any>>(`${this.apiUrl}/poultrytreatment/${id}`);
  }

  // Poultry mortality
  getPoultryMortality(projectId?: number, batchId?: number, fromDate?: string, toDate?: string, query?: { pageNumber?: number; pageSize?: number }): Observable<ApiResponse<PoultryMortality[]>> {
    let params = this.pagedParams(query);
    if (projectId) params = params.set('projectId', projectId.toString());
    if (batchId) params = params.set('batchId', batchId.toString());
    if (fromDate) params = params.set('fromDate', fromDate);
    if (toDate) params = params.set('toDate', toDate);
    return this.http.get<ApiResponse<PoultryMortality[]>>(`${this.apiUrl}/poultrymortality/paged`, { params });
  }
  createPoultryMortality(data: any): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/poultrymortality`, data);
  }
  updatePoultryMortality(id: number, data: any): Observable<ApiResponse<any>> {
    return this.http.put<ApiResponse<any>>(`${this.apiUrl}/poultrymortality/${id}`, data);
  }
  deletePoultryMortality(id: number): Observable<ApiResponse<any>> {
    return this.http.delete<ApiResponse<any>>(`${this.apiUrl}/poultrymortality/${id}`);
  }

  // Poultry growth
  getPoultryGrowth(projectId?: number, batchId?: number, fromDate?: string, toDate?: string, query?: { pageNumber?: number; pageSize?: number }): Observable<ApiResponse<PoultryGrowth[]>> {
    let params = this.pagedParams(query);
    if (projectId) params = params.set('projectId', projectId.toString());
    if (batchId) params = params.set('batchId', batchId.toString());
    if (fromDate) params = params.set('fromDate', fromDate);
    if (toDate) params = params.set('toDate', toDate);
    return this.http.get<ApiResponse<PoultryGrowth[]>>(`${this.apiUrl}/poultrygrowth/paged`, { params });
  }
  createPoultryGrowth(data: any): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/poultrygrowth`, data);
  }
  updatePoultryGrowth(id: number, data: any): Observable<ApiResponse<any>> {
    return this.http.put<ApiResponse<any>>(`${this.apiUrl}/poultrygrowth/${id}`, data);
  }
  deletePoultryGrowth(id: number): Observable<ApiResponse<any>> {
    return this.http.delete<ApiResponse<any>>(`${this.apiUrl}/poultrygrowth/${id}`);
  }

  // Egg production
  getEggProduction(projectId?: number, batchId?: number, fromDate?: string, toDate?: string, query?: { pageNumber?: number; pageSize?: number }): Observable<ApiResponse<EggProduction[]>> {
    let params = this.pagedParams(query);
    if (projectId) params = params.set('projectId', projectId.toString());
    if (batchId) params = params.set('batchId', batchId.toString());
    if (fromDate) params = params.set('fromDate', fromDate);
    if (toDate) params = params.set('toDate', toDate);
    return this.http.get<ApiResponse<EggProduction[]>>(`${this.apiUrl}/eggproduction/paged`, { params });
  }
  createEggProduction(data: any): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/eggproduction`, data);
  }
  updateEggProduction(id: number, data: any): Observable<ApiResponse<any>> {
    return this.http.put<ApiResponse<any>>(`${this.apiUrl}/eggproduction/${id}`, data);
  }
  deleteEggProduction(id: number): Observable<ApiResponse<any>> {
    return this.http.delete<ApiResponse<any>>(`${this.apiUrl}/eggproduction/${id}`);
  }

  // Poultry sales
  getPoultrySales(projectId?: number, batchId?: number, paymentStatus?: string, fromDate?: string, toDate?: string, query?: { pageNumber?: number; pageSize?: number }): Observable<ApiResponse<PoultrySale[]>> {
    let params = this.pagedParams(query);
    if (projectId) params = params.set('projectId', projectId.toString());
    if (batchId) params = params.set('batchId', batchId.toString());
    if (paymentStatus) params = params.set('paymentStatus', paymentStatus);
    if (fromDate) params = params.set('fromDate', fromDate);
    if (toDate) params = params.set('toDate', toDate);
    return this.http.get<ApiResponse<PoultrySale[]>>(`${this.apiUrl}/poultrysales/paged`, { params });
  }
  createPoultrySale(data: any): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/poultrysales`, data);
  }
  updatePoultrySale(id: number, data: any): Observable<ApiResponse<any>> {
    return this.http.put<ApiResponse<any>>(`${this.apiUrl}/poultrysales/${id}`, data);
  }
  deletePoultrySale(id: number): Observable<ApiResponse<any>> {
    return this.http.delete<ApiResponse<any>>(`${this.apiUrl}/poultrysales/${id}`);
  }

  // Revenue
  getRevenue(projectId?: number, farmType?: string, revenueType?: string, fromDate?: string, toDate?: string, query?: { pageNumber?: number; pageSize?: number }): Observable<ApiResponse<Revenue[]>> {
    let params = this.pagedParams(query);
    if (projectId) params = params.set('projectId', projectId.toString());
    if (farmType) params = params.set('farmType', farmType);
    if (revenueType) params = params.set('revenueType', revenueType);
    if (fromDate) params = params.set('fromDate', fromDate);
    if (toDate) params = params.set('toDate', toDate);
    return this.http.get<ApiResponse<Revenue[]>>(`${this.apiUrl}/revenue/paged`, { params });
  }
  createRevenue(data: any): Observable<ApiResponse<any>> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/revenue`, data);
  }
  updateRevenue(id: number, data: any): Observable<ApiResponse<any>> {
    return this.http.put<ApiResponse<any>>(`${this.apiUrl}/revenue/${id}`, data);
  }
  deleteRevenue(id: number): Observable<ApiResponse<any>> {
    return this.http.delete<ApiResponse<any>>(`${this.apiUrl}/revenue/${id}`);
  }

  // Farm dashboards
  getFarmDashboardSummary(projectId?: number, farmType?: string, fromDate?: string, toDate?: string): Observable<ApiResponse<FarmDashboardSummary>> {
    let params = new HttpParams();
    if (projectId) params = params.set('projectId', projectId.toString());
    if (farmType) params = params.set('farmType', farmType);
    if (fromDate) params = params.set('fromDate', fromDate);
    if (toDate) params = params.set('toDate', toDate);
    return this.http.get<ApiResponse<FarmDashboardSummary>>(`${this.apiUrl}/farmdashboard/summary`, { params });
  }
  getFishDashboardKpis(projectId?: number, fromDate?: string, toDate?: string): Observable<ApiResponse<FishDashboardKpis>> {
    let params = new HttpParams();
    if (projectId) params = params.set('projectId', projectId.toString());
    if (fromDate) params = params.set('fromDate', fromDate);
    if (toDate) params = params.set('toDate', toDate);
    return this.http.get<ApiResponse<FishDashboardKpis>>(`${this.apiUrl}/farmdashboard/fish-kpis`, { params });
  }
  getPoultryDashboardKpis(projectId?: number, fromDate?: string, toDate?: string): Observable<ApiResponse<PoultryDashboardKpis>> {
    let params = new HttpParams();
    if (projectId) params = params.set('projectId', projectId.toString());
    if (fromDate) params = params.set('fromDate', fromDate);
    if (toDate) params = params.set('toDate', toDate);
    return this.http.get<ApiResponse<PoultryDashboardKpis>>(`${this.apiUrl}/farmdashboard/poultry-kpis`, { params });
  }
  getFarmDashboardMonthly(projectId?: number, farmType?: string, fromDate?: string, toDate?: string): Observable<ApiResponse<any[]>> {
    let params = new HttpParams();
    if (projectId) params = params.set('projectId', projectId.toString());
    if (farmType) params = params.set('farmType', farmType);
    if (fromDate) params = params.set('fromDate', fromDate);
    if (toDate) params = params.set('toDate', toDate);
    return this.http.get<ApiResponse<any[]>>(`${this.apiUrl}/farmdashboard/monthly`, { params });
  }
  getFishTypeWise(projectId?: number): Observable<ApiResponse<any[]>> {
    let params = new HttpParams();
    if (projectId) params = params.set('projectId', projectId.toString());
    return this.http.get<ApiResponse<any[]>>(`${this.apiUrl}/farmdashboard/typewise`, { params });
  }
  getFishPondWise(projectId?: number): Observable<ApiResponse<any[]>> {
    let params = new HttpParams();
    if (projectId) params = params.set('projectId', projectId.toString());
    return this.http.get<ApiResponse<any[]>>(`${this.apiUrl}/farmdashboard/pondwise`, { params });
  }
  getPoultryBatchWise(projectId?: number): Observable<ApiResponse<any[]>> {
    let params = new HttpParams();
    if (projectId) params = params.set('projectId', projectId.toString());
    return this.http.get<ApiResponse<any[]>>(`${this.apiUrl}/farmdashboard/batchwise`, { params });
  }
  getEggSeries(projectId?: number, fromDate?: string, toDate?: string): Observable<ApiResponse<any[]>> {
    let params = new HttpParams();
    if (projectId) params = params.set('projectId', projectId.toString());
    if (fromDate) params = params.set('fromDate', fromDate);
    if (toDate) params = params.set('toDate', toDate);
    return this.http.get<ApiResponse<any[]>>(`${this.apiUrl}/farmdashboard/eggs`, { params });
  }

  // Farm reports
  getFarmWiseReport(farmType?: string, projectId?: number, query?: { pageNumber?: number; pageSize?: number }): Observable<ApiResponse<any[]>> {
    let params = this.pagedParams(query);
    if (farmType) params = params.set('farmType', farmType);
    if (projectId) params = params.set('projectId', projectId.toString());
    return this.http.get<ApiResponse<any[]>>(`${this.apiUrl}/farmreport/farmwise`, { params });
  }
  getFishReport(projectId?: number, pondId?: number, fishTypeId?: number, query?: { pageNumber?: number; pageSize?: number }): Observable<ApiResponse<any[]>> {
    let params = this.pagedParams(query);
    if (projectId) params = params.set('projectId', projectId.toString());
    if (pondId) params = params.set('pondId', pondId.toString());
    if (fishTypeId) params = params.set('fishTypeId', fishTypeId.toString());
    return this.http.get<ApiResponse<any[]>>(`${this.apiUrl}/farmreport/fish`, { params });
  }
  getPoultryReport(projectId?: number, shedId?: number, batchId?: number, query?: { pageNumber?: number; pageSize?: number }): Observable<ApiResponse<any[]>> {
    let params = this.pagedParams(query);
    if (projectId) params = params.set('projectId', projectId.toString());
    if (shedId) params = params.set('shedId', shedId.toString());
    if (batchId) params = params.set('batchId', batchId.toString());
    return this.http.get<ApiResponse<any[]>>(`${this.apiUrl}/farmreport/poultry`, { params });
  }
  getFeedReport(farmType?: string, projectId?: number, pondId?: number, batchId?: number, feedType?: string, fromDate?: string, toDate?: string): Observable<ApiResponse<any[]>> {
    let params = new HttpParams();
    if (farmType) params = params.set('farmType', farmType);
    if (projectId) params = params.set('projectId', projectId.toString());
    if (pondId) params = params.set('pondId', pondId.toString());
    if (batchId) params = params.set('batchId', batchId.toString());
    if (feedType) params = params.set('feedType', feedType);
    if (fromDate) params = params.set('fromDate', fromDate);
    if (toDate) params = params.set('toDate', toDate);
    return this.http.get<ApiResponse<any[]>>(`${this.apiUrl}/farmreport/feed`, { params });
  }
  getMortalityReport(farmType?: string, projectId?: number, pondId?: number, batchId?: number, fromDate?: string, toDate?: string): Observable<ApiResponse<any[]>> {
    let params = new HttpParams();
    if (farmType) params = params.set('farmType', farmType);
    if (projectId) params = params.set('projectId', projectId.toString());
    if (batchId) params = params.set('batchId', batchId.toString());
    if (pondId) params = params.set('pondId', pondId.toString());
    if (fromDate) params = params.set('fromDate', fromDate);
    if (toDate) params = params.set('toDate', toDate);
    return this.http.get<ApiResponse<any[]>>(`${this.apiUrl}/farmreport/mortality`, { params });
  }
  getProfitability(projectId?: number, farmType?: string, fromDate?: string, toDate?: string): Observable<ApiResponse<any>> {
    let params = new HttpParams();
    if (projectId) params = params.set('projectId', projectId.toString());
    if (farmType) params = params.set('farmType', farmType);
    if (fromDate) params = params.set('fromDate', fromDate);
    if (toDate) params = params.set('toDate', toDate);
    return this.http.get<ApiResponse<any>>(`${this.apiUrl}/farmreport/profitability`, { params });
  }
  getFarmCostVsBudget(projectId?: number, farmType?: string, pondId?: number, batchId?: number, fromDate?: string, toDate?: string): Observable<ApiResponse<any[]>> {
    let params = new HttpParams();
    if (projectId) params = params.set('projectId', projectId.toString());
    if (farmType) params = params.set('farmType', farmType);
    if (pondId) params = params.set('pondId', pondId.toString());
    if (batchId) params = params.set('batchId', batchId.toString());
    if (fromDate) params = params.set('fromDate', fromDate);
    if (toDate) params = params.set('toDate', toDate);
    return this.http.get<ApiResponse<any[]>>(`${this.apiUrl}/farmreport/farm-costvsbudget`, { params });
  }

  // Database Backup (Super Admin only)
  getDatabaseBackups(): Observable<ApiResponse<DatabaseBackupFile[]>> {
    return this.http.get<ApiResponse<DatabaseBackupFile[]>>(`${this.apiUrl}/databasebackup`);
  }

  downloadDatabaseBackup(fileName: string): Observable<Blob> {
    return this.http.get(`${this.apiUrl}/databasebackup/download/${encodeURIComponent(fileName)}`, { responseType: 'blob' });
  }

  restoreDatabaseBackup(fileName: string): Observable<ApiResponse<unknown>> {
    return this.http.post<ApiResponse<unknown>>(`${this.apiUrl}/databasebackup/restore`, { fileName });
  }

  createDatabaseFromBackup(fileName: string, newDatabaseName: string): Observable<ApiResponse<unknown>> {
    return this.http.post<ApiResponse<unknown>>(`${this.apiUrl}/databasebackup/create-database`, { fileName, newDatabaseName });
  }

  // Project Documents (page permission: View = view/download, Edit = upload, Delete = delete)
  getDocumentProjects(): Observable<ApiResponse<DocumentProject[]>> {
    return this.http.get<ApiResponse<DocumentProject[]>>(`${this.apiUrl}/projectdocument/projects`);
  }

  getProjectDocuments(projectId: number): Observable<ApiResponse<ProjectDocumentFile[]>> {
    return this.http.get<ApiResponse<ProjectDocumentFile[]>>(`${this.apiUrl}/projectdocument`, { params: new HttpParams().set('projectId', projectId.toString()) });
  }

  downloadProjectDocument(projectId: number, fileName: string): Observable<Blob> {
    const params = new HttpParams().set('projectId', projectId.toString()).set('fileName', fileName);
    return this.http.get(`${this.apiUrl}/projectdocument/download`, { params, responseType: 'blob' });
  }

  uploadProjectDocument(projectId: number, file: File): Observable<ApiResponse<ProjectDocumentFile>> {
    const form = new FormData();
    form.append('projectId', projectId.toString());
    form.append('file', file, file.name);
    return this.http.post<ApiResponse<ProjectDocumentFile>>(`${this.apiUrl}/projectdocument/upload`, form);
  }

  deleteProjectDocument(projectId: number, fileName: string): Observable<ApiResponse<unknown>> {
    const params = new HttpParams().set('projectId', projectId.toString()).set('fileName', fileName);
    return this.http.delete<ApiResponse<unknown>>(`${this.apiUrl}/projectdocument`, { params });
  }
}

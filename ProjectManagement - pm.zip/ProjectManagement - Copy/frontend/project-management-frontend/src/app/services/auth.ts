import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, of, tap, shareReplay, finalize } from 'rxjs';
import { Router } from '@angular/router';
import { resolveApiUrl } from '../core/api-base';
import { LoginRequest, LoginResponse, PagePermission, ApiResponse, User, SecurityQuestion, VerifySecurityAnswersRequest, SuperAdminChangePassRequest } from '../models/models';

export type PermissionAction = 'view' | 'edit' | 'delete' | 'export';

@Injectable({
  providedIn: 'root',
})
export class Auth {
  private apiUrl = `${resolveApiUrl()}/auth`;
  private currentUserSubject = new BehaviorSubject<User | null>(null);
  public currentUser$ = this.currentUserSubject.asObservable();
  private permissionsSubject = new BehaviorSubject<PagePermission[]>([]);
  public permissions$ = this.permissionsSubject.asObservable();
  public permissionsLoaded = false;
  private permissionsRequest$: Observable<ApiResponse<PagePermission[]>> | null = null;

  constructor(private http: HttpClient, private router: Router) {
    const storedUser = localStorage.getItem('currentUser');
    if (storedUser) {
      this.currentUserSubject.next(JSON.parse(storedUser));
    }
    // NOTE: no HTTP here. Session preload on bootstrap is owned by the
    // APP_INITIALIZER in app.config.ts (it awaits the shared
    // loadMyPermissions()). Firing a request from the constructor as well
    // would only duplicate it.
  }

  login(credentials: LoginRequest): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(`${this.apiUrl}/login`, credentials).pipe(
      tap(response => {
        if (response.success && response.token) {
          localStorage.setItem('token', response.token);
          localStorage.setItem('currentUser', JSON.stringify(response.user));
          this.currentUserSubject.next(response.user);
        }
      })
    );
  }

  getChangePassQuestions(): Observable<ApiResponse<SecurityQuestion[]>> {
    return this.http.get<ApiResponse<SecurityQuestion[]>>(`${resolveApiUrl()}/changepass/questions`);
  }

  verifyChangePassAnswers(payload: VerifySecurityAnswersRequest): Observable<ApiResponse<unknown>> {
    return this.http.post<ApiResponse<unknown>>(`${resolveApiUrl()}/changepass/verify`, payload);
  }

  resetSuperAdminPassword(payload: SuperAdminChangePassRequest): Observable<ApiResponse<unknown>> {
    return this.http.post<ApiResponse<unknown>>(`${resolveApiUrl()}/changepass/reset`, payload);
  }

  logout(): void {
    localStorage.removeItem('token');
    localStorage.removeItem('currentUser');
    this.currentUserSubject.next(null);
    this.permissionsSubject.next([]);
    this.permissionsLoaded = false;
    this.router.navigate(['/login']);
  }

  loadMyPermissions(): Observable<ApiResponse<PagePermission[]>> {
    if (this.permissionsLoaded) {
      return of({ success: true, message: '', data: this.permissionsSubject.value });
    }
    // Share a single in-flight request so a browser refresh (guard + layout +
    // constructor calling at once) does not fire duplicate requests.
    if (!this.permissionsRequest$) {
      this.permissionsRequest$ = this.http.get<ApiResponse<PagePermission[]>>(`${resolveApiUrl()}/permission/my-permissions`).pipe(
        tap(response => {
          if (response.success) {
            this.permissionsSubject.next(response.data ?? []);
            this.permissionsLoaded = true;
          }
        }),
        shareReplay(1),
        finalize(() => { this.permissionsRequest$ = null; })
      );
    }
    return this.permissionsRequest$;
  }

  can(page: string, action: PermissionAction): boolean {
    if (this.isAdmin()) return true;
    const perm = this.permissionsSubject.value.find(p => p.pageName === page);
    if (!perm) return false;
    switch (action) {
      case 'view': return perm.canView;
      case 'edit': return perm.canEdit;
      case 'delete': return perm.canDelete;
      case 'export': return perm.canExport;
      default: return false;
    }
  }

  canView(page: string): boolean {
    return this.can(page, 'view');
  }

  hasAnyViewPermission(): boolean {
    if (this.isAdmin()) return true;
    return this.permissionsSubject.value.some(p => p.canView);
  }

  isLoggedIn(): boolean {
    const token = localStorage.getItem('token');
    if (!token) {
      return false;
    }
    if (this.isTokenExpired(token)) {
      this.logout();
      return false;
    }
    return true;
  }

  isTokenExpired(token?: string | null): boolean {
    try {
      const value = token ?? localStorage.getItem('token');
      if (!value) {
        return true;
      }
      const payload = this.decodeJwtPayload(value);
      const exp = Number(payload.exp);
      if (!exp) {
        return false;
      }
      return Date.now() >= exp * 1000;
    } catch {
      return true;
    }
  }

  // JWT payloads are base64url-encoded (-/_ instead of +/), which atob()
  // cannot decode directly. A decode failure here was treating valid tokens
  // as expired on every browser refresh and wiping the session via logout().
  private decodeJwtPayload(token: string): any {
    const part = (token.split('.')[1] ?? '').replace(/-/g, '+').replace(/_/g, '/');
    const padded = part + '='.repeat((4 - (part.length % 4)) % 4);
    return JSON.parse(atob(padded));
  }

  getToken(): string | null {
    return localStorage.getItem('token');
  }

  getCurrentUser(): User | null {
    return this.currentUserSubject.value;
  }

  hasRole(role: string): boolean {
    const user = this.getCurrentUser();
    return user?.roleName === role;
  }

  isAdmin(): boolean {
    return this.hasRole('Admin') || this.hasRole('Super Admin');
  }

  isSuperAdmin(): boolean {
    return this.hasRole('Super Admin');
  }
}

import { environment } from '../../environments/environment';

/**
 * Resolve the backend API base URL.
 *
 * - Local dev (`ng serve` on :4200, Kestrel :7284/:5104): use environment.apiUrl
 *   (kept as https://localhost:7284/api per project convention).
 * - IIS hosting (frontend at http://localhost/pmtool, backend at
 *   http://localhost/pmapi): same host, port 80/443, not a dev port, so call
 *   the IIS-hosted API on the same origin to avoid CORS/mixed-content errors.
 */
export function resolveApiUrl(): string {
  try {
    const loc = typeof window !== 'undefined' ? window.location : undefined;
    if (loc) {
      const devPorts = new Set(['4200', '5104', '7284']);
      if (!devPorts.has(loc.port)) {
        return `${loc.protocol}//${loc.host}/pmapi/api`;
      }
    }
  } catch {
    // fall through to environment default
  }
  return environment.apiUrl;
}

import { Injectable } from '@angular/core';
import { CanActivate, Router, UrlTree, ActivatedRouteSnapshot } from '@angular/router';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { Auth } from '../../services/auth';

@Injectable({
  providedIn: 'root',
})
export class PermissionGuard implements CanActivate {
  constructor(private auth: Auth, private router: Router) {}

  canActivate(route: ActivatedRouteSnapshot):
    | Observable<boolean | UrlTree>
    | Promise<boolean | UrlTree>
    | boolean
    | UrlTree {
    if (!this.auth.isLoggedIn()) {
      this.router.navigate(['/login']);
      return false;
    }

    if (route.data['superAdminOnly']) {
      if (this.auth.isSuperAdmin()) {
        return true;
      }
      this.router.navigate(['/dashboard']);
      return false;
    }

    if (this.auth.isAdmin()) {
      return true;
    }

    if (route.data['adminOnly']) {
      this.router.navigate(['/dashboard']);
      return false;
    }

    const requiredPermission = route.data['permission'] as string | undefined;
    if (!requiredPermission) {
      return true;
    }
    if (this.auth.permissionsLoaded) {
      return this.checkView(requiredPermission);
    }
    return this.auth.loadMyPermissions().pipe(
      map(() => this.checkView(requiredPermission)),
      catchError(() => {
        this.router.navigate(['/no-access']);
        return of(false);
      })
    );
  }

  private checkView(requiredPermission: string): boolean {
    if (this.auth.canView(requiredPermission)) {
      return true;
    }
    this.router.navigate(['/no-access']);
    return false;
  }
}

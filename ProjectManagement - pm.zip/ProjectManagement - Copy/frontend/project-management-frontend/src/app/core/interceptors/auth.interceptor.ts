import { Injectable, Injector } from '@angular/core';
import {
  HttpInterceptor,
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpErrorResponse
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Router } from '@angular/router';
import { Auth } from '../../services/auth';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  // NOTE: Auth is resolved lazily via Injector (not constructor injection).
  // Auth -> HttpClient -> HTTP_INTERCEPTORS -> AuthInterceptor -> Auth is a
  // DI cycle (NG0200) once anything (e.g. APP_INITIALIZER) resolves Auth
  // eagerly at bootstrap. Lazy lookup breaks the cycle: by request time Auth
  // is fully constructed.
  constructor(private injector: Injector, private router: Router) {}

  private get auth(): Auth {
    return this.injector.get(Auth);
  }

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    const token = this.auth.getToken();

    if (token) {
      request = request.clone({
        setHeaders: {
          Authorization: `Bearer ${token}`
        }
      });
    }

    return next.handle(request).pipe(
      catchError((error: HttpErrorResponse) => {
        // A 401 from the login endpoint itself (wrong credentials) must not
        // wipe the session or fight the login form's own error handling.
        const isLoginRequest = request.url.includes('/auth/login');
        if (error.status === 401 && !isLoginRequest) {
          this.auth.logout();
          this.router.navigate(['/login']);
        }
        return throwError(() => error);
      })
    );
  }
}

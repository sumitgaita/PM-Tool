import { Routes } from '@angular/router';
import { LoginComponent } from './components/login/login';
import { ChangePassComponent } from './components/changepass/changepass';
import { LayoutComponent } from './components/layout/layout';
import { DashboardComponent } from './components/dashboard/dashboard';
import { ProjectsComponent } from './components/projects/projects';
import { BudgetCodesComponent } from './components/budget-codes/budget-codes';
import { ResourcesComponent } from './components/resources/resources';
import { ExpensesComponent } from './components/expenses/expenses';
import { CostVsBudgetComponent } from './components/cost-vs-budget/cost-vs-budget';
import { ReportsComponent } from './components/reports/reports';
import { UsersComponent } from './components/users/users';
import { PermissionsComponent } from './components/permissions/permissions';
import { ProjectPermissionsComponent } from './components/project-permissions/project-permissions';
import { NoAccessComponent } from './components/no-access/no-access';
import { ProjectBudgetsComponent } from './components/project-budgets/project-budgets';
import { AuthGuard } from './core/guards/auth.guard';
import { PermissionGuard } from './core/guards/permission.guard';
import { PondsComponent } from './components/farming/ponds/ponds';
import { FishTypesComponent } from './components/farming/fish-types/fish-types';
import { FishStockingComponent } from './components/farming/fish-stocking/fish-stocking';
import { FishFeedComponent } from './components/farming/fish-feed/fish-feed';
import { FishTreatmentComponent } from './components/farming/fish-treatment/fish-treatment';
import { FishMortalityComponent } from './components/farming/fish-mortality/fish-mortality';
import { FishGrowthComponent } from './components/farming/fish-growth/fish-growth';
import { FishHarvestComponent } from './components/farming/fish-harvest/fish-harvest';
import { FishSalesComponent } from './components/farming/fish-sales/fish-sales';
import { PoultryShedsComponent } from './components/farming/poultry-sheds/poultry-sheds';
import { PoultryBatchesComponent } from './components/farming/poultry-batches/poultry-batches';
import { ChickPurchaseComponent } from './components/farming/chick-purchase/chick-purchase';
import { PoultryFeedComponent } from './components/farming/poultry-feed/poultry-feed';
import { PoultryTreatmentComponent } from './components/farming/poultry-treatment/poultry-treatment';
import { PoultryMortalityComponent } from './components/farming/poultry-mortality/poultry-mortality';
import { PoultryGrowthComponent } from './components/farming/poultry-growth/poultry-growth';
import { EggProductionComponent } from './components/farming/egg-production/egg-production';
import { PoultrySalesComponent } from './components/farming/poultry-sales/poultry-sales';
import { RevenueComponent } from './components/farming/revenue/revenue';
import { DatabaseBackupComponent } from './components/database-backup/database-backup';
import { ProjectDocumentComponent } from './components/project-document/project-document';import { ProfitabilityComponent } from './components/farming/profitability/profitability';
import { FarmReportsComponent } from './components/farming/farm-reports/farm-reports';

export const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'changepass', component: ChangePassComponent },
  {
    path: '',
    component: LayoutComponent,
    canActivate: [AuthGuard],
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      { path: 'dashboard', component: DashboardComponent, canActivate: [PermissionGuard], data: { permission: 'Dashboard' } },
      { path: 'projects', component: ProjectsComponent, canActivate: [PermissionGuard], data: { permission: 'Projects', title: 'Projects' } },
      { path: 'completed-projects', component: ProjectsComponent, canActivate: [PermissionGuard], data: { permission: 'Projects', title: 'Completed Projects', inactiveOnly: true } },
      { path: 'budget-codes', component: BudgetCodesComponent, canActivate: [PermissionGuard], data: { permission: 'Budget Codes' } },
      { path: 'resources', component: ResourcesComponent, canActivate: [PermissionGuard], data: { permission: 'Resources' } },
      { path: 'project-budgets', component: ProjectBudgetsComponent, canActivate: [PermissionGuard], data: { permission: 'Project Budgets' } },
      { path: 'expenses', component: ExpensesComponent, canActivate: [PermissionGuard], data: { permission: 'Expenses', title: 'Daily Expenses', showCopy: true, showAdd: true, showSearch: false } },
      { path: 'expense-history', component: ExpensesComponent, canActivate: [PermissionGuard], data: { permission: 'Expenses', title: 'Expense History', showCopy: false, showAdd: false, showSearch: true } },
      { path: 'cost-vs-budget', component: CostVsBudgetComponent, canActivate: [PermissionGuard], data: { permission: 'Cost Vs Budget' } },
      { path: 'reports/project', component: ReportsComponent, canActivate: [PermissionGuard], data: { permission: 'Reports' } },
      { path: 'reports/date-wise', component: ReportsComponent, canActivate: [PermissionGuard], data: { permission: 'Reports' } },
      { path: 'reports/date-range', component: ReportsComponent, canActivate: [PermissionGuard], data: { permission: 'Reports' } },
      { path: 'reports', component: ReportsComponent, canActivate: [PermissionGuard], data: { permission: 'Reports' } },
      { path: 'users', component: UsersComponent, canActivate: [PermissionGuard], data: { permission: 'Users' } },
      { path: 'permissions', component: PermissionsComponent, canActivate: [PermissionGuard], data: { permission: 'Permissions', adminOnly: true } },
      { path: 'project-permissions', component: ProjectPermissionsComponent, canActivate: [PermissionGuard], data: { permission: 'Project Permissions', superAdminOnly: true } },
      { path: 'database-backup', component: DatabaseBackupComponent, canActivate: [PermissionGuard], data: { permission: 'Database Backup', superAdminOnly: true } },
      { path: 'project-document', component: ProjectDocumentComponent, canActivate: [PermissionGuard], data: { permission: 'Project Document' } },
      { path: 'fish-ponds', component: PondsComponent, canActivate: [PermissionGuard], data: { permission: 'Fish Ponds' } },
      { path: 'fish-types', component: FishTypesComponent, canActivate: [PermissionGuard], data: { permission: 'Fish Types' } },
      { path: 'fish-stocking', component: FishStockingComponent, canActivate: [PermissionGuard], data: { permission: 'Fish Stocking' } },
      { path: 'fish-feed', component: FishFeedComponent, canActivate: [PermissionGuard], data: { permission: 'Fish Feed' } },
      { path: 'fish-treatment', component: FishTreatmentComponent, canActivate: [PermissionGuard], data: { permission: 'Fish Treatment' } },
      { path: 'fish-mortality', component: FishMortalityComponent, canActivate: [PermissionGuard], data: { permission: 'Fish Mortality' } },
      { path: 'fish-growth', component: FishGrowthComponent, canActivate: [PermissionGuard], data: { permission: 'Fish Growth' } },
      { path: 'fish-harvest', component: FishHarvestComponent, canActivate: [PermissionGuard], data: { permission: 'Fish Harvest' } },
      { path: 'fish-sales', component: FishSalesComponent, canActivate: [PermissionGuard], data: { permission: 'Fish Sales' } },
      { path: 'poultry-sheds', component: PoultryShedsComponent, canActivate: [PermissionGuard], data: { permission: 'Poultry Sheds' } },
      { path: 'poultry-batches', component: PoultryBatchesComponent, canActivate: [PermissionGuard], data: { permission: 'Poultry Batches' } },
      { path: 'chick-purchase', component: ChickPurchaseComponent, canActivate: [PermissionGuard], data: { permission: 'Chick Purchase' } },
      { path: 'poultry-feed', component: PoultryFeedComponent, canActivate: [PermissionGuard], data: { permission: 'Poultry Feed' } },
      { path: 'poultry-treatment', component: PoultryTreatmentComponent, canActivate: [PermissionGuard], data: { permission: 'Poultry Treatment' } },
      { path: 'poultry-mortality', component: PoultryMortalityComponent, canActivate: [PermissionGuard], data: { permission: 'Poultry Mortality' } },
      { path: 'poultry-growth', component: PoultryGrowthComponent, canActivate: [PermissionGuard], data: { permission: 'Poultry Growth' } },
      { path: 'egg-production', component: EggProductionComponent, canActivate: [PermissionGuard], data: { permission: 'Egg Production' } },
      { path: 'poultry-sales', component: PoultrySalesComponent, canActivate: [PermissionGuard], data: { permission: 'Poultry Sales' } },
      { path: 'revenue', component: RevenueComponent, canActivate: [PermissionGuard], data: { permission: 'Revenue' } },
      { path: 'profitability', component: ProfitabilityComponent, canActivate: [PermissionGuard], data: { permission: 'Profitability' } },
      { path: 'reports/farm', component: FarmReportsComponent, canActivate: [PermissionGuard], data: { permission: 'Farm Reports' } },
      { path: 'no-access', component: NoAccessComponent },
    ]
  },
  { path: '**', redirectTo: 'dashboard' }
];

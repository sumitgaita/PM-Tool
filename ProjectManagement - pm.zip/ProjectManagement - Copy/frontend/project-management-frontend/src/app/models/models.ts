export interface User {
  userId: number;
  username: string;
  fullName: string;
  email: string;
  mobileNumber?: string | null;
  roleId: number;
  roleName: string;
  isActive: boolean;
  createdDate: string;
  createdBy?: number;
  modifiedDate?: string;
  modifiedBy?: number;
  passwordHash?: string;
  password?: string;
}

export interface LoginRequest {
  username: string;
  password: string;
}

export interface LoginResponse {
  success: boolean;
  message: string;
  token: string;
  user: User;
}

export interface SecurityQuestion {
  questionId: number;
  questionCode: string;
  questionText: string;
}

export interface SecurityAnswer {
  questionId: number;
  answer: string;
}

export interface VerifySecurityAnswersRequest {
  answers: SecurityAnswer[];
}

export interface SuperAdminChangePassRequest {
  answers: SecurityAnswer[];
  newPassword: string;
  confirmPassword: string;
}

export interface DatabaseBackupFile {
  fileName: string;
  sizeBytes: number;
  createdDate: string;
}

export interface DocumentProject {
  projectId: number;
  projectCode: string;
  projectName: string;
}

export interface ProjectDocumentFile {
  fileName: string;
  sizeBytes: number;
  createdDate: string;
}

export interface Project {
  projectId: number;
  projectCode: string;
  projectName: string;
  description?: string;
  clientName?: string;
  startDate?: string;
  endDate?: string;
  totalBudget: number;
  status: string;
  farmType?: string;
  isActive: boolean;
  createdBy?: number;
  createdDate: string;
  modifiedBy?: number;
  modifiedDate?: string;
}

export interface BudgetCode {
  budgetCodeId: number;
  budgetCode: string;
  budgetCodeName: string;
  description?: string;
  isActive: boolean;
  createdBy?: number;
  createdDate: string;
  modifiedBy?: number;
  modifiedDate?: string;
}

export interface Resource {
  resourceId: number;
  resourceCode: string;
  resourceName: string;
  resourceType: string;
  email?: string;
  phone?: string;
  department?: string;
  isActive: boolean;
  createdBy?: number;
  createdDate: string;
  modifiedBy?: number;
  modifiedDate?: string;
}

export interface ProjectBudget {
  projectBudgetId: number;
  projectId: number;
  projectCode: string;
  projectName: string;
  budgetCodeId: number;
  budgetCode: string;
  budgetCodeName: string;
  budgetAmount: number;
  effectiveFrom: string;
  effectiveTo?: string;
  isActive: boolean;
  createdBy?: number;
  createdDate: string;
  modifiedBy?: number;
  modifiedDate?: string;
}

export interface ProjectResource {
  projectResourceId: number;
  projectId: number;
  projectCode: string;
  projectName: string;
  resourceId: number;
  resourceCode: string;
  resourceName: string;
  resourceType: string;
  assignedFrom: string;
  assignedTo?: string;
  isActive: boolean;
  createdBy?: number;
  createdDate: string;
  modifiedBy?: number;
  modifiedDate?: string;
}

export interface Expense {
  expenseId: number;
  expenseDate: string;
  projectId: number;
  projectCode: string;
  projectName: string;
  budgetCodeId: number;
  budgetCode: string;
  budgetCodeName: string;
  resourceId: number;
  resourceCode: string;
  resourceName: string;
  amount: number;
  description?: string;
  referenceNo?: string;
  remarks?: string;
  farmType?: string;
  farmEntityType?: string;
  farmEntityId?: number;
  isDeleted: boolean;
  createdBy?: number;
  createdDate: string;
  modifiedBy?: number;
  modifiedDate?: string;
}

export interface DashboardSummary {
  totalProjects: number;
  activeProjects: number;
  totalBudget: number;
  totalExpense: number;
  activeResources: number;
}

export interface PagePermission {
  pageId: number;
  pageName: string;
  canView: boolean;
  canEdit: boolean;
  canDelete: boolean;
  canExport: boolean;
}

export interface Page {
  pageId: number;
  pageName: string;
  pageDescription?: string;
}

export interface UserProject {
  projectId: number;
  projectCode: string;
  projectName: string;
  status: string;
  farmType?: string;
  isActive: boolean;
  isAssigned: boolean;
  assignedDate?: string;
}

export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data: T;
  pageNumber?: number;
  pageSize?: number;
  totalRecords?: number;
  totalPages?: number;
}

export interface ProjectBudgetQuery {
  projectId?: number;
  budgetCodeId?: number;
  searchText?: string;
  pageNumber?: number;
  pageSize?: number;
  sortBy?: string;
  sortDir?: string;
}

// ---- Farming (§68-§94) ----
export interface Pond {
  pondId: number;
  projectId: number;
  projectCode: string;
  projectName: string;
  pondCode: string;
  pondName: string;
  area?: number;
  areaUnit?: string;
  depth?: string;
  waterCapacity?: number;
  pondType?: string;
  status: string;
  isActive: boolean;
  createdDate: string;
}

export interface FishType {
  fishTypeId: number;
  fishCode: string;
  fishName: string;
  scientificName?: string;
  description?: string;
  isActive: boolean;
  createdDate: string;
}

export interface FishStocking {
  stockingId: number;
  pondId: number;
  pondCode: string;
  pondName: string;
  projectId: number;
  fishTypeId: number;
  fishCode: string;
  fishName: string;
  stockingDate: string;
  quantity: number;
  averageWeight?: number;
  purchaseRate: number;
  totalCost: number;
  supplier?: string;
  referenceNo?: string;
  remarks?: string;
  createdDate: string;
}

export interface FishFeed {
  fishFeedId: number;
  pondId: number;
  pondCode: string;
  pondName: string;
  projectId: number;
  feedDate: string;
  feedType: string;
  quantity: number;
  unit?: string;
  rate: number;
  totalCost: number;
  remarks?: string;
  createdDate: string;
}

export interface FishTreatment {
  treatmentId: number;
  pondId: number;
  pondCode: string;
  pondName: string;
  projectId: number;
  treatmentDate: string;
  treatmentType: string;
  medicine?: string;
  quantity: number;
  unit?: string;
  cost: number;
  reason?: string;
  remarks?: string;
  createdDate: string;
}

export interface FishMortality {
  mortalityId: number;
  pondId: number;
  pondCode: string;
  pondName: string;
  projectId: number;
  fishTypeId: number;
  fishCode: string;
  fishName: string;
  mortalityDate: string;
  quantity: number;
  reason?: string;
  remarks?: string;
  createdDate: string;
}

export interface FishGrowth {
  growthId: number;
  pondId: number;
  pondCode: string;
  pondName: string;
  projectId: number;
  fishTypeId: number;
  fishCode: string;
  fishName: string;
  samplingDate: string;
  sampleQuantity: number;
  averageWeight: number;
  remarks?: string;
  createdDate: string;
}

export interface FishHarvest {
  harvestId: number;
  pondId: number;
  pondCode: string;
  pondName: string;
  projectId: number;
  fishTypeId: number;
  fishCode: string;
  fishName: string;
  harvestDate: string;
  quantity: number;
  totalWeight: number;
  averageWeight?: number;
  harvestCost: number;
  remarks?: string;
  createdDate: string;
}

export interface FishSale {
  saleId: number;
  projectId: number;
  projectCode: string;
  projectName: string;
  harvestId?: number;
  fishTypeId: number;
  fishCode: string;
  fishName: string;
  saleDate: string;
  customerName: string;
  quantity: number;
  totalWeight: number;
  rate: number;
  totalAmount: number;
  paymentStatus: string;
  referenceNo?: string;
  remarks?: string;
  createdDate: string;
}

export interface PoultryShed {
  shedId: number;
  projectId: number;
  projectCode: string;
  projectName: string;
  shedCode: string;
  shedName: string;
  capacity: number;
  capacityUnit?: string;
  shedType?: string;
  status: string;
  isActive: boolean;
  createdDate: string;
}

export interface PoultryBatch {
  batchId: number;
  projectId: number;
  projectCode: string;
  projectName: string;
  shedId: number;
  shedCode: string;
  shedName: string;
  batchCode: string;
  birdType: string;
  startDate: string;
  expectedSaleDate?: string;
  initialQuantity: number;
  purchaseCost: number;
  status: string;
  remarks?: string;
  createdDate: string;
}

export interface ChickPurchase {
  purchaseId: number;
  batchId: number;
  batchCode: string;
  projectId: number;
  purchaseDate: string;
  supplier?: string;
  quantity: number;
  rate: number;
  totalAmount: number;
  referenceNo?: string;
  remarks?: string;
  createdDate: string;
}

export interface PoultryFeed {
  feedId: number;
  batchId: number;
  batchCode: string;
  projectId: number;
  feedDate: string;
  feedType: string;
  quantity: number;
  unit?: string;
  rate: number;
  totalCost: number;
  remarks?: string;
  createdDate: string;
}

export interface PoultryTreatment {
  treatmentId: number;
  batchId: number;
  batchCode: string;
  projectId: number;
  treatmentDate: string;
  treatmentType: string;
  medicine?: string;
  quantity: number;
  cost: number;
  reason?: string;
  remarks?: string;
  createdDate: string;
}

export interface PoultryMortality {
  mortalityId: number;
  batchId: number;
  batchCode: string;
  projectId: number;
  mortalityDate: string;
  quantity: number;
  reason?: string;
  remarks?: string;
  createdDate: string;
}

export interface PoultryGrowth {
  growthId: number;
  batchId: number;
  batchCode: string;
  projectId: number;
  sampleDate: string;
  sampleQuantity: number;
  averageWeight: number;
  remarks?: string;
  createdDate: string;
}

export interface EggProduction {
  productionId: number;
  batchId: number;
  batchCode: string;
  projectId: number;
  productionDate: string;
  goodEggs: number;
  brokenEggs: number;
  totalEggs: number;
  remarks?: string;
  createdDate: string;
}

export interface PoultrySale {
  saleId: number;
  projectId: number;
  projectCode: string;
  projectName: string;
  batchId?: number;
  batchCode?: string;
  saleDate: string;
  customerName: string;
  birdQuantity: number;
  totalWeight: number;
  rate: number;
  totalAmount: number;
  paymentStatus: string;
  referenceNo?: string;
  remarks?: string;
  createdDate: string;
}

export interface Revenue {
  revenueId: number;
  revenueDate: string;
  projectId: number;
  projectCode: string;
  projectName: string;
  farmType?: string;
  revenueType: string;
  referenceId?: number;
  customerName?: string;
  quantity: number;
  weight: number;
  rate: number;
  amount: number;
  paymentStatus: string;
  remarks?: string;
  createdDate: string;
}

export interface FarmDashboardSummary {
  totalRevenue: number;
  totalExpense: number;
  totalPonds: number;
  activePonds: number;
  totalSheds: number;
  activeBatches: number;
}

export interface FishDashboardKpis {
  activePonds: number;
  totalStocked: number;
  currentStock: number;
  totalMortality: number;
  totalHarvest: number;
  totalHarvestWeight: number;
  feedCost: number;
  treatmentCost: number;
  fishRevenue: number;
}

export interface PoultryDashboardKpis {
  activeSheds: number;
  activeBatches: number;
  totalBirds: number;
  currentBirds: number;
  totalMortality: number;
  totalFeed: number;
  feedCost: number;
  totalEggs: number;
  goodEggs: number;
  brokenEggs: number;
  birdSales: number;
  poultryRevenue: number;
}

import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { Api } from '../../services/api';
import { Auth } from '../../services/auth';
import { DocumentProject, ProjectDocumentFile } from '../../models/models';

@Component({
  selector: 'app-project-document',
  templateUrl: './project-document.html',
  styleUrls: ['./project-document.scss'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, RouterModule, MatCardModule, MatTableModule, MatFormFieldModule, MatSelectModule, MatButtonModule, MatIconModule, MatTooltipModule, MatProgressSpinnerModule, MatSnackBarModule]
})
export class ProjectDocumentComponent implements OnInit {
  projects: DocumentProject[] = [];
  selectedProjectId: number | null = null;
  documentsDataSource = new MatTableDataSource<ProjectDocumentFile>([]);
  displayedColumns: string[] = ['fileName', 'sizeBytes', 'createdDate', 'actions'];
  isLoadingProjects = false;
  isLoadingDocuments = false;
  isUploading = false;
  errorMessage = '';
  successMessage = '';

  constructor(
    private api: Api,
    public auth: Auth,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    this.loadProjects();
  }

  loadProjects(): void {
    this.isLoadingProjects = true;
    this.errorMessage = '';
    this.api.getDocumentProjects().subscribe({
      next: (response) => {
        this.isLoadingProjects = false;
        if (response.success) {
          this.projects = response.data ?? [];
          if (this.projects.length === 1) {
            this.selectedProjectId = this.projects[0].projectId;
            this.loadDocuments();
          }
        } else {
          this.errorMessage = response.message || 'Unable to load projects.';
        }
      },
      error: (error) => {
        this.isLoadingProjects = false;
        this.errorMessage = error.error?.message || 'Unable to load projects. Please try again.';
      }
    });
  }

  onProjectChange(): void {
    this.successMessage = '';
    this.errorMessage = '';
    this.documentsDataSource.data = [];
    if (this.selectedProjectId) {
      this.loadDocuments();
    }
  }

  loadDocuments(): void {
    if (!this.selectedProjectId) return;
    this.isLoadingDocuments = true;
    this.api.getProjectDocuments(this.selectedProjectId).subscribe({
      next: (response) => {
        this.isLoadingDocuments = false;
        if (response.success) {
          this.documentsDataSource.data = response.data ?? [];
        } else {
          this.errorMessage = response.message || 'Unable to load documents.';
        }
      },
      error: (error) => {
        this.isLoadingDocuments = false;
        this.errorMessage = error.error?.message || 'Unable to load documents. Please try again.';
      }
    });
  }

  formatSize(bytes: number): string {
    if (!bytes || bytes <= 0) return '0 B';
    const units = ['B', 'KB', 'MB', 'GB'];
    let size = bytes;
    let unit = 0;
    while (size >= 1024 && unit < units.length - 1) {
      size /= 1024;
      unit++;
    }
    return `${size.toFixed(unit === 0 ? 0 : 2)} ${units[unit]}`;
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (!input.files || input.files.length === 0 || !this.selectedProjectId) return;
    const file = input.files[0];
    input.value = '';
    this.errorMessage = '';
    this.successMessage = '';
    this.isUploading = true;
    this.api.uploadProjectDocument(this.selectedProjectId, file).subscribe({
      next: (response) => {
        this.isUploading = false;
        this.successMessage = response.message || 'Document uploaded.';
        this.snackBar.open(this.successMessage, 'Close', { duration: 4000 });
        this.loadDocuments();
      },
      error: (error) => {
        this.isUploading = false;
        this.errorMessage = error.error?.message || 'Upload failed. Please try again.';
      }
    });
  }

  downloadDocument(file: ProjectDocumentFile): void {
    if (!this.selectedProjectId) return;
    this.errorMessage = '';
    this.api.downloadProjectDocument(this.selectedProjectId, file.fileName).subscribe({
      next: (blob) => {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = file.fileName;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
      },
      error: (error) => {
        this.errorMessage = error.error?.message || 'Unable to download the document. Please try again.';
      }
    });
  }

  deleteDocument(file: ProjectDocumentFile): void {
    if (!this.selectedProjectId) return;
    const ok = window.confirm(`Delete document '${file.fileName}'?\n\nThis cannot be undone.`);
    if (!ok) return;
    this.errorMessage = '';
    this.successMessage = '';
    this.api.deleteProjectDocument(this.selectedProjectId, file.fileName).subscribe({
      next: (response) => {
        this.successMessage = response.message || 'Document deleted successfully.';
        this.snackBar.open(this.successMessage, 'Close', { duration: 4000 });
        this.loadDocuments();
      },
      error: (error) => {
        this.errorMessage = error.error?.message || 'Unable to delete the document. Please try again.';
      }
    });
  }
}

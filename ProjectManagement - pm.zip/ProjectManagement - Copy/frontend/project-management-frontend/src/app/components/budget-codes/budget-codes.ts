import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { forkJoin, of } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { Api } from '../../services/api';
import { Auth } from '../../services/auth';
import { BudgetCode } from '../../models/models';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialogModule, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatChipsModule } from '@angular/material/chips';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@Component({
  selector: 'app-budget-codes',
  templateUrl: './budget-codes.html',
  styleUrls: ['./budget-codes.scss'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, RouterModule, MatCardModule, MatTableModule, MatFormFieldModule, MatInputModule, MatSelectModule, MatButtonModule, MatIconModule, MatToolbarModule, MatSidenavModule, MatListModule, MatExpansionModule, MatDatepickerModule, MatNativeDateModule, MatSlideToggleModule, MatSnackBarModule, MatDialogModule, MatPaginatorModule, MatSortModule, MatChipsModule, MatTooltipModule, MatProgressSpinnerModule]
})
export class BudgetCodesComponent implements OnInit {
  @ViewChild('dialogContent') dialogContent!: TemplateRef<unknown>;
  private dialogRef: MatDialogRef<unknown> | null = null;
  budgetCodes: BudgetCode[] = [];
  budgetCodesDataSource = new MatTableDataSource<BudgetCode>([]);
  budgetCodeForm: FormGroup;
  searchForm: FormGroup;
  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;
  isEditing = false;
  selectedBudgetCode: BudgetCode | null = null;
  isLoading = false;
  displayedColumns: string[] = ['budgetCode', 'budgetCodeName', 'description', 'isActive', 'actions'];

  constructor(
    private fb: FormBuilder,
    private api: Api,
    private dialog: MatDialog,
    private snackBar: MatSnackBar,
    public auth: Auth
  ) {
    this.budgetCodeForm = this.fb.group({
      budgetCode: ['', [Validators.required]],
      budgetCodeName: ['', [Validators.required]],
      description: ['']
    });
    this.searchForm = this.fb.group({
      searchText: ['']
    });
  }

  ngOnInit(): void {
    this.loadBudgetCodes();
  }

  loadBudgetCodes(): void {
    this.isLoading = true;
    const searchText = ((this.searchForm.get('searchText')?.value ?? '') as string).trim();
    this.api.getBudgetCodesPaged(
      searchText || undefined,
      { pageNumber: this.pageIndex + 1, pageSize: this.pageSize }
    ).subscribe({
      next: response => {
        if (response.success) {
          this.budgetCodes = response.data;
          this.budgetCodesDataSource.data = response.data;
          this.totalRecords = response.totalRecords ?? response.data.length;
        }
        this.isLoading = false;
      },
      error: () => {
        this.isLoading = false;
      }
    });
  }

  applySearch(): void {
    this.pageIndex = 0;
    this.loadBudgetCodes();
  }

  resetSearch(): void {
    this.searchForm.reset({ searchText: '' });
    this.pageIndex = 0;
    this.loadBudgetCodes();
  }

  onPage(event: { pageIndex: number; pageSize: number }): void {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.loadBudgetCodes();
  }

  openDialog(budgetCode?: BudgetCode): void {
    this.isEditing = !!budgetCode;
    this.selectedBudgetCode = budgetCode || null;

    if (budgetCode) {
      this.budgetCodeForm.patchValue(budgetCode);
    } else {
      this.budgetCodeForm.reset();
    }

    this.dialogRef = this.dialog.open(this.dialogContent, {
      width: '600px',
      maxHeight: '90vh'
    });
  }

  saveBudgetCode(): void {
    if (this.budgetCodeForm.invalid) {
      return;
    }

    const budgetCodeData = this.budgetCodeForm.value;

    if (this.isEditing && this.selectedBudgetCode) {
      this.api.updateBudgetCode(this.selectedBudgetCode.budgetCodeId, budgetCodeData).subscribe(response => {
        if (response.success) {
          this.loadBudgetCodes();
          this.closeDialog();
        }
      });
    } else {
      this.api.createBudgetCode(budgetCodeData).subscribe(response => {
        if (response.success) {
          this.loadBudgetCodes();
          this.closeDialog();
        }
      });
    }
  }

  closeDialog(): void {
    this.dialogRef?.close();
    this.dialogRef = null;
    this.budgetCodeForm.reset();
    this.isEditing = false;
    this.selectedBudgetCode = null;
  }

  exportToExcel(): void {
    // Export all rows matching the current search (server-side paging
    // returns max 100 per call, so fetch remaining pages when needed).
    const searchText = ((this.searchForm.get('searchText')?.value ?? '') as string).trim();
    const fetch = (page: number) => this.api.getBudgetCodesPaged(
      searchText || undefined, { pageNumber: page, pageSize: 100 });
    fetch(1).pipe(
      switchMap(first => {
        if (!first.success) return of<BudgetCode[]>([]);
        const total = first.totalRecords ?? first.data.length;
        const pages = Math.ceil(total / 100);
        if (pages <= 1) return of(first.data);
        const rest = [];
        for (let p = 2; p <= pages; p++) rest.push(fetch(p));
        return forkJoin(rest).pipe(
          switchMap(results => of([...first.data, ...results.flatMap(r => r.success ? r.data : [])]))
        );
      })
    ).subscribe(all => {
      if (all.length === 0) return;
      this.writeExcel(all);
    });
  }

  private writeExcel(rows: BudgetCode[]): void {
    import('xlsx').then(xlsx => {
      const sheet = rows.map(b => ({
        'Budget Code': b.budgetCode,
        'Budget Code Name': b.budgetCodeName,
        'Description': b.description ?? '',
        'Active': b.isActive ? 'Yes' : 'No'
      }));
      const ws = xlsx.utils.json_to_sheet(sheet);
      const wb = xlsx.utils.book_new();
      xlsx.utils.book_append_sheet(wb, ws, 'Budget Codes');
      xlsx.writeFile(wb, `Budget_Codes_${new Date().toISOString().split('T')[0]}.xlsx`);
    });
  }

  toggleStatus(budgetCode: BudgetCode): void {
    if (budgetCode.isActive) {
      this.api.deactivateBudgetCode(budgetCode.budgetCodeId).subscribe(response => {
        if (response.success) {
          this.loadBudgetCodes();
        }
      });
    } else {
      this.api.activateBudgetCode(budgetCode.budgetCodeId).subscribe(response => {
        if (response.success) {
          this.loadBudgetCodes();
        }
      });
    }
  }

  deleteBudgetCode(budgetCode: BudgetCode): void {
    const ok = window.confirm(
      `Delete budget code '${budgetCode.budgetCode} - ${budgetCode.budgetCodeName}'?\n\nCodes already used in budgets or expenses cannot be deleted.`);
    if (!ok) return;
    this.api.deleteBudgetCode(budgetCode.budgetCodeId).subscribe({
      next: response => {
        this.snackBar.open(response.message || 'Budget code deleted successfully.', 'Close', { duration: 3000 });
        if (response.success) {
          this.loadBudgetCodes();
        }
      },
      error: (err: { status?: number; error?: { message?: string } }) => {
        this.snackBar.open(
          err?.error?.message || 'Budget code is in use and cannot be deleted.', 'Close', { duration: 4000 });
      }
    });
  }
}

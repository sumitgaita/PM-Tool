﻿import { Component, ChangeDetectorRef, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Api } from '../../../services/api';
import { Auth } from '../../../services/auth';
import { Revenue, Project } from '../../../models/models';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatChipsModule } from '@angular/material/chips';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialogModule } from '@angular/material/dialog';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@Component({
  selector: 'app-revenue',
  templateUrl: './revenue.html',
  styleUrls: ['../shared/farming.scss'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, RouterModule, MatCardModule, MatTableModule, MatFormFieldModule, MatInputModule, MatSelectModule, MatButtonModule, MatIconModule, MatChipsModule, MatDatepickerModule, MatNativeDateModule, MatSnackBarModule, MatDialogModule, MatPaginatorModule, MatTooltipModule, MatProgressSpinnerModule]
})
export class RevenueComponent implements OnInit {
  @ViewChild('dialogContent') dialogContent!: TemplateRef<unknown>;
  private dialogRef: MatDialogRef<unknown> | null = null;
  rows: Revenue[] = [];
  dataSource = new MatTableDataSource<Revenue>([]);
  projects: Project[] = [];
  farmTypes = ['Fish Farming', 'Poultry Farming'];
  revenueTypes = ['Fish Sale', 'Poultry Sale', 'Egg Sale', 'Other Farm Revenue'];
  paymentStatuses = ['Paid', 'Partially Paid', 'Pending'];
  form: FormGroup;
  searchForm: FormGroup;
  isEditing = false;
  selected: Revenue | null = null;
  isLoading = false;
  isSaving = false;
  saveError = '';
  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;
  displayedColumns = ['revenueDate', 'projectName', 'revenueType', 'customerName', 'amount', 'paymentStatus', 'actions'];

  constructor(
    private fb: FormBuilder, private api: Api, private dialog: MatDialog,
    private snackBar: MatSnackBar, private cdr: ChangeDetectorRef, public auth: Auth
  ) {
    this.form = this.fb.group({
      projectId: ['', Validators.required],
      revenueDate: ['', Validators.required],
      farmType: [''],
      revenueType: ['', Validators.required],
      customerName: [''],
      quantity: [0],
      weight: [0],
      rate: [0],
      amount: [null, [Validators.required, Validators.min(0)]],
      paymentStatus: ['Pending'],
      remarks: ['']
    });
    this.searchForm = this.fb.group({ projectId: [''], farmType: [''], revenueType: [''] });
  }

  ngOnInit(): void {
    this.api.getProjects().subscribe(r => { if (r.success) this.projects = r.data.filter((p: Project) => p.isActive); this.cdr.markForCheck(); });
    this.load();
  }

  load(): void {
    this.isLoading = true;
    const s = this.searchForm.value;
    this.api.getRevenue(s.projectId || undefined, s.farmType || undefined, s.revenueType || undefined,
      undefined, undefined, { pageNumber: this.pageIndex + 1, pageSize: this.pageSize }).subscribe({
      next: r => {
        if (r.success) { this.rows = r.data; this.dataSource.data = r.data; this.totalRecords = r.totalRecords ?? r.data.length; }
        this.isLoading = false; this.cdr.markForCheck();
      },
      error: () => { this.isLoading = false; this.cdr.markForCheck(); }
    });
  }

  applySearch(): void { this.pageIndex = 0; this.load(); }
  resetSearch(): void { this.searchForm.reset({ projectId: '', farmType: '', revenueType: '' }); this.pageIndex = 0; this.load(); }
  onPage(e: { pageIndex: number; pageSize: number }): void { this.pageIndex = e.pageIndex; this.pageSize = e.pageSize; this.load(); }
  isLinked(row: Revenue): boolean { return row.referenceId != null; }

  openDialog(row?: Revenue): void {
    this.isEditing = !!row;
    this.selected = row || null;
    this.isSaving = false;
    this.saveError = '';
    if (row) this.form.patchValue({ ...row, revenueDate: this.toDateObject(row.revenueDate) });
    else { this.form.reset(); this.form.patchValue({ revenueDate: new Date(), paymentStatus: 'Pending' }); }
    this.dialogRef = this.dialog.open(this.dialogContent, { width: '700px', maxHeight: '90vh' });
  }

  save(): void {
    if (this.form.invalid) return;
    if (this.isEditing && this.selected && this.isLinked(this.selected)) {
      this.saveError = 'Sale-linked revenue must be edited through its sale record.';
      return;
    }
    this.isSaving = true;
    this.saveError = '';
    const v = this.form.value;
    const payload: any = {
      projectId: Number(v.projectId), revenueDate: this.toApiDate(v.revenueDate),
      farmType: v.farmType || null, revenueType: v.revenueType,
      customerName: v.customerName || null, quantity: v.quantity ?? 0,
      weight: v.weight ?? 0, rate: v.rate ?? 0, amount: Number(v.amount),
      paymentStatus: v.paymentStatus || 'Pending', remarks: v.remarks || null
    };
    const call = this.isEditing && this.selected
      ? this.api.updateRevenue(this.selected.revenueId, payload)
      : this.api.createRevenue(payload);
    call.subscribe({
      next: r => {
        this.isSaving = false;
        if (r.success) { this.snackBar.open(r.message || 'Saved.', 'Close', { duration: 3000 }); this.load(); this.closeDialog(); }
        else this.saveError = r.message || 'Failed to save.';
        this.cdr.markForCheck();
      },
      error: err => {
        this.isSaving = false;
        this.saveError = err?.status === 403 ? 'Access denied.' : (err?.error?.message || 'Failed to save.');
        this.cdr.markForCheck();
      }
    });
  }

  closeDialog(): void {
    this.dialogRef?.close(); this.dialogRef = null; this.form.reset();
    this.isEditing = false; this.selected = null; this.isSaving = false; this.saveError = '';
  }

  remove(row: Revenue): void {
    if (this.isLinked(row)) {
      this.snackBar.open('Sale-linked revenue must be deleted through its sale record.', 'Close', { duration: 4000 });
      return;
    }
    if (!window.confirm(`Delete revenue of â‚¹${row.amount} (${row.revenueType}) on ${this.toApiDate(row.revenueDate)}?`)) return;
    this.api.deleteRevenue(row.revenueId).subscribe({
      next: r => {
        this.snackBar.open(r.message || 'Deleted.', 'Close', { duration: 3000 });
        if (r.success) { if (this.dataSource.data.length <= 1 && this.pageIndex > 0) this.pageIndex--; this.load(); }
      },
      error: err => this.snackBar.open(err?.status === 403 ? 'Access denied.' : (err?.error?.message || 'Failed to delete.'), 'Close', { duration: 4000 })
    });
  }

  exportToExcel(): void {
    const s = this.searchForm.value;
    const fetch = (page: number) => this.api.getRevenue(
      s.projectId || undefined, s.farmType || undefined, s.revenueType || undefined,
      undefined, undefined, { pageNumber: page, pageSize: 100 });
    this.api.fetchAll(fetch).subscribe(all => {
      if (!all.length) return;
      import('xlsx').then(xlsx => {
        const ws = xlsx.utils.json_to_sheet(all.map(r => ({
          'Date': this.toApiDate(r.revenueDate), 'Project': `${r.projectCode} - ${r.projectName}`,
          'Farm Type': r.farmType ?? '', 'Revenue Type': r.revenueType,
          'Customer': r.customerName ?? '', 'Quantity': r.quantity, 'Weight': r.weight,
          'Rate': r.rate, 'Amount': r.amount, 'Payment': r.paymentStatus
        })));
        const wb = xlsx.utils.book_new();
        xlsx.utils.book_append_sheet(wb, ws, 'Revenue');
        xlsx.writeFile(wb, `Revenue_${new Date().toISOString().split('T')[0]}.xlsx`);
      });
    });
  }

  formatCurrency(a: number): string {
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(a || 0);
  }

  toApiDate(v: Date | string | null): string {
    if (!v) return '';
    if (typeof v === 'string') return v.split('T')[0];
    return `${v.getFullYear()}-${String(v.getMonth() + 1).padStart(2, '0')}-${String(v.getDate()).padStart(2, '0')}`;
  }

  toDateObject(v: string | null): Date | null {
    if (!v) return null;
    const p = v.split('T')[0].split('-');
    if (p.length !== 3) return null;
    return new Date(Number(p[0]), Number(p[1]) - 1, Number(p[2]));
  }
}

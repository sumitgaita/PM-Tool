﻿import { Component, ChangeDetectorRef, OnInit, TemplateRef, ViewChild, AfterViewInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatPaginator } from '@angular/material/paginator';
import { Api } from '../../../services/api';
import { Auth } from '../../../services/auth';
import { FishType } from '../../../models/models';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialogModule } from '@angular/material/dialog';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatTooltipModule } from '@angular/material/tooltip';

@Component({
  selector: 'app-fish-types',
  templateUrl: './fish-types.html',
  styleUrls: ['../shared/farming.scss'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, RouterModule, MatCardModule, MatTableModule, MatFormFieldModule, MatInputModule, MatButtonModule, MatIconModule, MatSlideToggleModule, MatSnackBarModule, MatDialogModule, MatPaginatorModule, MatTooltipModule]
})
export class FishTypesComponent implements OnInit, AfterViewInit {
  @ViewChild('dialogContent') dialogContent!: TemplateRef<unknown>;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  private dialogRef: MatDialogRef<unknown> | null = null;
  rows: FishType[] = [];
  dataSource = new MatTableDataSource<FishType>([]);
  typeForm: FormGroup;
  searchForm: FormGroup;
  isEditing = false;
  selected: FishType | null = null;
  isLoading = false;
  isSaving = false;
  saveError = '';
  displayedColumns = ['fishCode', 'fishName', 'scientificName', 'isActive', 'actions'];

  constructor(
    private fb: FormBuilder,
    private api: Api,
    private dialog: MatDialog,
    private snackBar: MatSnackBar,
    private cdr: ChangeDetectorRef,
    public auth: Auth
  ) {
    this.typeForm = this.fb.group({
      fishCode: ['', Validators.required],
      fishName: ['', Validators.required],
      scientificName: [''],
      description: ['']
    });
    this.searchForm = this.fb.group({ searchText: [''] });
  }

  ngOnInit(): void { this.load(); }

  ngAfterViewInit(): void { this.dataSource.paginator = this.paginator; }

  load(): void {
    this.isLoading = true;
    this.api.getFishTypes().subscribe({
      next: r => {
        if (r.success) {
          this.rows = r.data;
          this.applySearch();
        }
        this.isLoading = false;
        this.cdr.markForCheck();
      },
      error: () => { this.isLoading = false; this.cdr.markForCheck(); }
    });
  }

  applySearch(): void {
    const text = ((this.searchForm.get('searchText')?.value ?? '') as string).trim().toLowerCase();
    this.dataSource.data = !text ? this.rows : this.rows.filter(f =>
      (f.fishCode || '').toLowerCase().includes(text) ||
      (f.fishName || '').toLowerCase().includes(text));
    this.cdr.markForCheck();
  }

  resetSearch(): void {
    this.searchForm.reset({ searchText: '' });
    this.applySearch();
  }

  openDialog(row?: FishType): void {
    this.isEditing = !!row;
    this.selected = row || null;
    this.isSaving = false;
    this.saveError = '';
    if (row) this.typeForm.patchValue({ ...row });
    else this.typeForm.reset();
    this.dialogRef = this.dialog.open(this.dialogContent, { width: '600px', maxHeight: '90vh' });
  }

  save(): void {
    if (this.typeForm.invalid) return;
    this.isSaving = true;
    this.saveError = '';
    const v = this.typeForm.value;
    const call = this.isEditing && this.selected
      ? this.api.updateFishType(this.selected.fishTypeId, v)
      : this.api.createFishType(v);
    call.subscribe({
      next: r => {
        this.isSaving = false;
        if (r.success) { this.snackBar.open(r.message || 'Saved.', 'Close', { duration: 3000 }); this.load(); this.closeDialog(); }
        else this.saveError = r.message || 'Failed to save.';
        this.cdr.markForCheck();
      },
      error: err => {
        this.isSaving = false;
        this.saveError = err?.status === 403 ? 'Access denied.' : (err?.error?.message || 'Failed to save. Code may already exist.');
        this.cdr.markForCheck();
      }
    });
  }

  closeDialog(): void {
    this.dialogRef?.close();
    this.dialogRef = null;
    this.typeForm.reset();
    this.isEditing = false;
    this.selected = null;
    this.isSaving = false;
    this.saveError = '';
  }

  toggleStatus(row: FishType): void {
    const call = row.isActive ? this.api.deactivateFishType(row.fishTypeId) : this.api.activateFishType(row.fishTypeId);
    call.subscribe(r => {
      this.snackBar.open(r.message || (r.success ? 'Done.' : 'Failed.'), 'Close', { duration: 3000 });
      if (r.success) this.load();
    });
  }

  remove(row: FishType): void {
    if (!window.confirm(`Delete fish type '${row.fishCode} - ${row.fishName}'?\n\nTypes used in transactions cannot be deleted.`)) return;
    this.api.deleteFishType(row.fishTypeId).subscribe({
      next: r => {
        this.snackBar.open(r.message || 'Deleted.', 'Close', { duration: 3000 });
        if (r.success) this.load();
      },
      error: err => this.snackBar.open(err?.status === 403 ? 'Access denied.' : (err?.error?.message || 'Failed to delete.'), 'Close', { duration: 4000 })
    });
  }

  exportToExcel(): void {
    if (!this.dataSource.data.length) return;
    import('xlsx').then(xlsx => {
      const ws = xlsx.utils.json_to_sheet(this.dataSource.data.map(f => ({
        'Fish Code': f.fishCode, 'Fish Name': f.fishName,
        'Scientific Name': f.scientificName ?? '', 'Description': f.description ?? '',
        'Active': f.isActive ? 'Yes' : 'No'
      })));
      const wb = xlsx.utils.book_new();
      xlsx.utils.book_append_sheet(wb, ws, 'Fish Types');
      xlsx.writeFile(wb, `Fish_Types_${new Date().toISOString().split('T')[0]}.xlsx`);
    });
  }
}

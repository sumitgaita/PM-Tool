﻿import { Component, ChangeDetectorRef, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Api } from '../../../services/api';
import { Auth } from '../../../services/auth';
import { EggProduction, PoultryBatch, Project } from '../../../models/models';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialogModule } from '@angular/material/dialog';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@Component({
  selector: 'app-egg-production',
  templateUrl: './egg-production.html',
  styleUrls: ['../shared/farming.scss'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, RouterModule, MatCardModule, MatTableModule, MatFormFieldModule, MatInputModule, MatSelectModule, MatButtonModule, MatIconModule, MatDatepickerModule, MatNativeDateModule, MatSnackBarModule, MatDialogModule, MatPaginatorModule, MatTooltipModule, MatProgressSpinnerModule]
})
export class EggProductionComponent implements OnInit {
  @ViewChild('dialogContent') dialogContent!: TemplateRef<unknown>;
  private dialogRef: MatDialogRef<unknown> | null = null;
  rows: EggProduction[] = [];
  dataSource = new MatTableDataSource<EggProduction>([]);
  projects: Project[] = [];
  batches: PoultryBatch[] = [];
  form: FormGroup;
  searchForm: FormGroup;
  isEditing = false;
  selected: EggProduction | null = null;
  isLoading = false;
  isSaving = false;
  saveError = '';
  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;
  todayEggs = 0;
  monthEggs = 0;
  displayedColumns = ['productionDate', 'batchCode', 'goodEggs', 'brokenEggs', 'totalEggs', 'actions'];

  constructor(
    private fb: FormBuilder, private api: Api, private dialog: MatDialog,
    private snackBar: MatSnackBar, private cdr: ChangeDetectorRef, public auth: Auth
  ) {
    this.form = this.fb.group({
      batchId: ['', Validators.required],
      productionDate: ['', Validators.required],
      goodEggs: [0, Validators.min(0)],
      brokenEggs: [0, Validators.min(0)],
      remarks: ['']
    });
    this.searchForm = this.fb.group({ projectId: [''], batchId: [''] });
  }

  ngOnInit(): void {
    this.api.getProjects().subscribe(r => { if (r.success) this.projects = r.data.filter((p: Project) => p.isActive); this.cdr.markForCheck(); });
    this.api.getPoultryBatches(undefined, undefined, undefined, undefined, { pageNumber: 1, pageSize: 100 }).subscribe(r => { if (r.success) this.batches = r.data; this.cdr.markForCheck(); });
    this.load();
    this.loadMetrics();
  }

  loadMetrics(): void {
    const today = new Date().toISOString().split('T')[0];
    const monthStart = today.slice(0, 7) + '-01';
    this.api.getEggProduction(undefined, undefined, today, today, { pageNumber: 1, pageSize: 100 }).subscribe(r => {
      if (r.success) this.todayEggs = r.data.reduce((s, e) => s + (e.totalEggs || 0), 0);
      this.cdr.markForCheck();
    });
    this.api.getEggProduction(undefined, undefined, monthStart, today, { pageNumber: 1, pageSize: 100 }).subscribe(r => {
      if (r.success) this.monthEggs = r.data.reduce((s, e) => s + (e.totalEggs || 0), 0);
      this.cdr.markForCheck();
    });
  }

  load(): void {
    this.isLoading = true;
    const s = this.searchForm.value;
    this.api.getEggProduction(s.projectId || undefined, s.batchId || undefined,
      undefined, undefined, { pageNumber: this.pageIndex + 1, pageSize: this.pageSize }).subscribe({
      next: r => {
        if (r.success) { this.rows = r.data; this.dataSource.data = r.data; this.totalRecords = r.totalRecords ?? r.data.length; }
        this.isLoading = false; this.cdr.markForCheck();
      },
      error: () => { this.isLoading = false; this.cdr.markForCheck(); }
    });
  }

  applySearch(): void { this.pageIndex = 0; this.load(); }
  resetSearch(): void { this.searchForm.reset({ projectId: '', batchId: '' }); this.pageIndex = 0; this.load(); }
  onPage(e: { pageIndex: number; pageSize: number }): void { this.pageIndex = e.pageIndex; this.pageSize = e.pageSize; this.load(); }

  openDialog(row?: EggProduction): void {
    this.isEditing = !!row;
    this.selected = row || null;
    this.isSaving = false;
    this.saveError = '';
    if (row) this.form.patchValue({ ...row, productionDate: this.toDateObject(row.productionDate) });
    else { this.form.reset(); this.form.patchValue({ productionDate: new Date(), goodEggs: 0, brokenEggs: 0 }); }
    this.dialogRef = this.dialog.open(this.dialogContent, { width: '600px', maxHeight: '90vh' });
  }

  save(): void {
    if (this.form.invalid) return;
    this.isSaving = true;
    this.saveError = '';
    const v = this.form.value;
    const payload: any = {
      batchId: Number(v.batchId), productionDate: this.toApiDate(v.productionDate),
      goodEggs: v.goodEggs ?? 0, brokenEggs: v.brokenEggs ?? 0, remarks: v.remarks || null
    };
    const call = this.isEditing && this.selected
      ? this.api.updateEggProduction(this.selected.productionId, payload)
      : this.api.createEggProduction(payload);
    call.subscribe({
      next: r => {
        this.isSaving = false;
        if (r.success) { this.snackBar.open(r.message || 'Saved.', 'Close', { duration: 3000 }); this.load(); this.loadMetrics(); this.closeDialog(); }
        else this.saveError = r.message || 'Failed to save.';
        this.cdr.markForCheck();
      },
      error: err => {
        this.isSaving = false;
        this.saveError = err?.status === 403 ? 'Access denied.' : (err?.error?.message || 'Failed to save.');
        this.cdr.markForCheck();
      }
    });
  }

  closeDialog(): void {
    this.dialogRef?.close(); this.dialogRef = null; this.form.reset();
    this.isEditing = false; this.selected = null; this.isSaving = false; this.saveError = '';
  }

  remove(row: EggProduction): void {
    if (!window.confirm(`Delete egg entry of ${row.totalEggs} eggs on ${this.toApiDate(row.productionDate)}?`)) return;
    this.api.deleteEggProduction(row.productionId).subscribe({
      next: r => {
        this.snackBar.open(r.message || 'Deleted.', 'Close', { duration: 3000 });
        if (r.success) { if (this.dataSource.data.length <= 1 && this.pageIndex > 0) this.pageIndex--; this.load(); this.loadMetrics(); }
      },
      error: err => this.snackBar.open(err?.status === 403 ? 'Access denied.' : (err?.error?.message || 'Failed to delete.'), 'Close', { duration: 4000 })
    });
  }

  exportToExcel(): void {
    const s = this.searchForm.value;
    const fetch = (page: number) => this.api.getEggProduction(
      s.projectId || undefined, s.batchId || undefined, undefined, undefined, { pageNumber: page, pageSize: 100 });
    this.api.fetchAll(fetch).subscribe(all => {
      if (!all.length) return;
      import('xlsx').then(xlsx => {
        const ws = xlsx.utils.json_to_sheet(all.map(r => ({
          'Date': this.toApiDate(r.productionDate), 'Batch': r.batchCode,
          'Good Eggs': r.goodEggs, 'Broken Eggs': r.brokenEggs, 'Total Eggs': r.totalEggs,
          'Remarks': r.remarks ?? ''
        })));
        const wb = xlsx.utils.book_new();
        xlsx.utils.book_append_sheet(wb, ws, 'Egg Production');
        xlsx.writeFile(wb, `Egg_Production_${new Date().toISOString().split('T')[0]}.xlsx`);
      });
    });
  }

  toApiDate(v: Date | string | null): string {
    if (!v) return '';
    if (typeof v === 'string') return v.split('T')[0];
    return `${v.getFullYear()}-${String(v.getMonth() + 1).padStart(2, '0')}-${String(v.getDate()).padStart(2, '0')}`;
  }

  toDateObject(v: string | null): Date | null {
    if (!v) return null;
    const p = v.split('T')[0].split('-');
    if (p.length !== 3) return null;
    return new Date(Number(p[0]), Number(p[1]) - 1, Number(p[2]));
  }
}

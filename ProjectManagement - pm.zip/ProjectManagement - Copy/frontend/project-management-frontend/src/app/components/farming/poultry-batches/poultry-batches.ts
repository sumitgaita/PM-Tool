﻿import { Component, ChangeDetectorRef, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Api } from '../../../services/api';
import { Auth } from '../../../services/auth';
import { PoultryBatch, PoultryShed, Project } from '../../../models/models';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatChipsModule } from '@angular/material/chips';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialogModule } from '@angular/material/dialog';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@Component({
  selector: 'app-poultry-batches',
  templateUrl: './poultry-batches.html',
  styleUrls: ['../shared/farming.scss'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, RouterModule, MatCardModule, MatTableModule, MatFormFieldModule, MatInputModule, MatSelectModule, MatButtonModule, MatIconModule, MatChipsModule, MatDatepickerModule, MatNativeDateModule, MatSlideToggleModule, MatSnackBarModule, MatDialogModule, MatPaginatorModule, MatTooltipModule, MatProgressSpinnerModule]
})
export class PoultryBatchesComponent implements OnInit {
  @ViewChild('dialogContent') dialogContent!: TemplateRef<unknown>;
  private dialogRef: MatDialogRef<unknown> | null = null;
  rows: PoultryBatch[] = [];
  dataSource = new MatTableDataSource<PoultryBatch>([]);
  projects: Project[] = [];
  sheds: PoultryShed[] = [];
  birdTypes = ['Broiler', 'Layer', 'Country Chicken', 'Other'];
  statuses = ['Active', 'Closed', 'Sold'];
  form: FormGroup;
  searchForm: FormGroup;
  isEditing = false;
  selected: PoultryBatch | null = null;
  isLoading = false;
  isSaving = false;
  saveError = '';
  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;
  displayedColumns = ['batchCode', 'shedCode', 'birdType', 'initialQuantity', 'status', 'isActive', 'actions'];

  constructor(
    private fb: FormBuilder, private api: Api, private dialog: MatDialog,
    private snackBar: MatSnackBar, private cdr: ChangeDetectorRef, public auth: Auth
  ) {
    this.form = this.fb.group({
      projectId: ['', Validators.required],
      shedId: ['', Validators.required],
      batchCode: ['', Validators.required],
      birdType: ['Broiler', Validators.required],
      startDate: ['', Validators.required],
      expectedSaleDate: [''],
      initialQuantity: [null, [Validators.required, Validators.min(1)]],
      purchaseCost: [0],
      status: ['Active', Validators.required],
      remarks: ['']
    });
    this.searchForm = this.fb.group({ searchText: [''], projectId: [''], shedId: [''], status: [''] });
  }

  ngOnInit(): void {
    this.api.getProjects().subscribe(r => { if (r.success) this.projects = r.data.filter((p: Project) => p.isActive); this.cdr.markForCheck(); });
    this.api.getPoultrySheds(undefined, undefined, { pageNumber: 1, pageSize: 100 }).subscribe(r => { if (r.success) this.sheds = r.data.filter((s: PoultryShed) => s.isActive); this.cdr.markForCheck(); });
    this.load();
  }

  load(): void {
    this.isLoading = true;
    const s = this.searchForm.value;
    this.api.getPoultryBatches(s.projectId || undefined, s.shedId || undefined,
      (s.searchText || '').trim() || undefined, s.status || undefined,
      { pageNumber: this.pageIndex + 1, pageSize: this.pageSize }).subscribe({
      next: r => {
        if (r.success) { this.rows = r.data; this.dataSource.data = r.data; this.totalRecords = r.totalRecords ?? r.data.length; }
        this.isLoading = false; this.cdr.markForCheck();
      },
      error: () => { this.isLoading = false; this.cdr.markForCheck(); }
    });
  }

  applySearch(): void { this.pageIndex = 0; this.load(); }
  resetSearch(): void { this.searchForm.reset({ searchText: '', projectId: '', shedId: '', status: '' }); this.pageIndex = 0; this.load(); }
  onPage(e: { pageIndex: number; pageSize: number }): void { this.pageIndex = e.pageIndex; this.pageSize = e.pageSize; this.load(); }
  isActiveBatch(row: PoultryBatch): boolean { return row.status === 'Active'; }

  openDialog(row?: PoultryBatch): void {
    this.isEditing = !!row;
    this.selected = row || null;
    this.isSaving = false;
    this.saveError = '';
    if (row) this.form.patchValue({
      ...row,
      startDate: this.toDateObject(row.startDate),
      expectedSaleDate: this.toDateObject(row.expectedSaleDate ?? null)
    });
    else { this.form.reset(); this.form.patchValue({ birdType: 'Broiler', status: 'Active', startDate: new Date() }); }
    this.dialogRef = this.dialog.open(this.dialogContent, { width: '700px', maxHeight: '90vh' });
  }

  save(): void {
    if (this.form.invalid) return;
    this.isSaving = true;
    this.saveError = '';
    const v = this.form.value;
    const payload: any = {
      projectId: Number(v.projectId), shedId: Number(v.shedId), batchCode: v.batchCode,
      birdType: v.birdType, startDate: this.toApiDate(v.startDate),
      expectedSaleDate: this.toApiDate(v.expectedSaleDate) || null,
      purchaseCost: v.purchaseCost ?? 0, status: v.status || 'Active', remarks: v.remarks || null
    };
    if (!this.isEditing) payload.initialQuantity = Number(v.initialQuantity);
    const call = this.isEditing && this.selected
      ? this.api.updatePoultryBatch(this.selected.batchId, payload)
      : this.api.createPoultryBatch({ ...payload, initialQuantity: Number(v.initialQuantity) });
    call.subscribe({
      next: r => {
        this.isSaving = false;
        if (r.success) { this.snackBar.open(r.message || 'Saved.', 'Close', { duration: 3000 }); this.load(); this.closeDialog(); }
        else this.saveError = r.message || 'Failed to save.';
        this.cdr.markForCheck();
      },
      error: err => {
        this.isSaving = false;
        this.saveError = err?.status === 403 ? 'Access denied.' : (err?.error?.message || 'Failed to save.');
        this.cdr.markForCheck();
      }
    });
  }

  closeDialog(): void {
    this.dialogRef?.close(); this.dialogRef = null; this.form.reset();
    this.isEditing = false; this.selected = null; this.isSaving = false; this.saveError = '';
  }

  toggleStatus(row: PoultryBatch): void {
    const active = row.status === 'Active';
    const call = active ? this.api.deactivatePoultryBatch(row.batchId) : this.api.activatePoultryBatch(row.batchId);
    call.subscribe(r => {
      if (r.success) { this.snackBar.open(r.message, 'Close', { duration: 3000 }); this.load(); }
      else this.snackBar.open(r.message || 'Failed.', 'Close', { duration: 3000 });
    });
  }

  remove(row: PoultryBatch): void {
    if (!window.confirm(`Delete batch '${row.batchCode}' (${row.initialQuantity} ${row.birdType})?\n\nBatches with transactions cannot be deleted.`)) return;
    this.api.deletePoultryBatch(row.batchId).subscribe({
      next: r => {
        this.snackBar.open(r.message || 'Deleted.', 'Close', { duration: 3000 });
        if (r.success) { if (this.dataSource.data.length <= 1 && this.pageIndex > 0) this.pageIndex--; this.load(); }
      },
      error: err => this.snackBar.open(err?.status === 403 ? 'Access denied.' : (err?.error?.message || 'Failed to delete.'), 'Close', { duration: 4000 })
    });
  }

  exportToExcel(): void {
    const s = this.searchForm.value;
    const fetch = (page: number) => this.api.getPoultryBatches(
      s.projectId || undefined, s.shedId || undefined, (s.searchText || '').trim() || undefined,
      s.status || undefined, { pageNumber: page, pageSize: 100 });
    this.api.fetchAll(fetch).subscribe(all => {
      if (!all.length) return;
      import('xlsx').then(xlsx => {
        const ws = xlsx.utils.json_to_sheet(all.map(r => ({
          'Batch Code': r.batchCode, 'Shed': `${r.shedCode} - ${r.shedName}`,
          'Project': `${r.projectCode} - ${r.projectName}`, 'Bird Type': r.birdType,
          'Start Date': this.toApiDate(r.startDate), 'Expected Sale': this.toApiDate(r.expectedSaleDate ?? null),
          'Initial Qty': r.initialQuantity, 'Purchase Cost': r.purchaseCost, 'Status': r.status
        })));
        const wb = xlsx.utils.book_new();
        xlsx.utils.book_append_sheet(wb, ws, 'Batches');
        xlsx.writeFile(wb, `Poultry_Batches_${new Date().toISOString().split('T')[0]}.xlsx`);
      });
    });
  }

  toApiDate(v: Date | string | null): string {
    if (!v) return '';
    if (typeof v === 'string') return v.split('T')[0];
    return `${v.getFullYear()}-${String(v.getMonth() + 1).padStart(2, '0')}-${String(v.getDate()).padStart(2, '0')}`;
  }

  toDateObject(v: string | null): Date | null {
    if (!v) return null;
    const p = v.split('T')[0].split('-');
    if (p.length !== 3) return null;
    return new Date(Number(p[0]), Number(p[1]) - 1, Number(p[2]));
  }
}

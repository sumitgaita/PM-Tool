﻿import { Component, ChangeDetectorRef, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Api } from '../../../services/api';
import { Auth } from '../../../services/auth';
import { Project } from '../../../models/models';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@Component({
  selector: 'app-profitability',
  templateUrl: './profitability.html',
  styleUrls: ['../shared/farming.scss'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, RouterModule, MatCardModule, MatTableModule, MatFormFieldModule, MatInputModule, MatSelectModule, MatButtonModule, MatIconModule, MatDatepickerModule, MatNativeDateModule, MatProgressSpinnerModule]
})
export class ProfitabilityComponent implements OnInit {
  projects: Project[] = [];
  farmTypes = ['Fish Farming', 'Poultry Farming'];
  form: FormGroup;
  summary: any = null;
  costRows = new MatTableDataSource<any>([]);
  isLoading = false;
  costColumns = ['projectName', 'farmType', 'budget', 'actual', 'operational', 'remaining', 'utilization'];

  constructor(
    private fb: FormBuilder, private api: Api,
    private cdr: ChangeDetectorRef, public auth: Auth
  ) {
    this.form = this.fb.group({
      projectId: [''],
      farmType: [''],
      fromDate: [''],
      toDate: ['']
    });
  }

  ngOnInit(): void {
    this.api.getProjects().subscribe(r => {
      if (r.success) this.projects = r.data.filter((p: Project) => p.isActive);
      this.cdr.markForCheck();
    });
    this.load();
  }

  filters(): { projectId?: number; farmType?: string; from?: string; to?: string } {
    const f = this.form.value;
    return {
      projectId: f.projectId || undefined,
      farmType: f.farmType || undefined,
      from: this.toApiDate(f.fromDate),
      to: this.toApiDate(f.toDate)
    };
  }

  load(): void {
    this.isLoading = true;
    const f = this.filters();
    this.api.getProfitability(f.projectId, f.farmType, f.from || undefined, f.to || undefined).subscribe({
      next: r => {
        if (r.success && r.data) {
          const d = r.data;
          const revenue = Number(d.totalRevenue) || 0;
          const expense = Number(d.totalExpense) || 0;
          const profit = revenue - expense;
          this.summary = {
            totalRevenue: revenue,
            totalExpense: expense,
            grossProfit: profit,
            profitPercent: revenue > 0 ? (profit / revenue) * 100 : 0,
            fishRevenue: Number(d.fishRevenue) || 0,
            poultryRevenue: Number(d.poultryRevenue) || 0,
            eggRevenue: Number(d.eggRevenue) || 0
          };
        }
        this.cdr.markForCheck();
      },
      error: () => undefined
    });
    this.api.getFarmCostVsBudget(f.projectId, f.farmType, undefined, undefined, f.from || undefined, f.to || undefined).subscribe({
      next: r => {
        if (r.success) this.costRows.data = r.data;
        this.isLoading = false;
        this.cdr.markForCheck();
      },
      error: () => { this.isLoading = false; this.cdr.markForCheck(); }
    });
  }

  applyFilters(): void { this.load(); }

  resetFilters(): void {
    this.form.reset({ projectId: '', farmType: '', fromDate: '', toDate: '' });
    this.load();
  }

  isOverBudget(row: any): boolean {
    return (Number(row.totalBudget) || 0) > 0 && (Number(row.actualExpense) || 0) > (Number(row.totalBudget) || 0);
  }

  utilization(row: any): number {
    const b = Number(row.totalBudget) || 0;
    if (b <= 0) return 0;
    return ((Number(row.actualExpense) || 0) / b) * 100;
  }

  formatCurrency(a: number): string {
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(a || 0);
  }

  toApiDate(v: Date | string | null): string {
    if (!v) return '';
    if (typeof v === 'string') return v.split('T')[0];
    return `${v.getFullYear()}-${String(v.getMonth() + 1).padStart(2, '0')}-${String(v.getDate()).padStart(2, '0')}`;
  }

  exportToExcel(): void {
    import('xlsx').then(xlsx => {
      const ws = xlsx.utils.json_to_sheet(this.costRows.data.map(r => ({
        'Project': `${r.projectCode} - ${r.projectName}`,
        'Farm Type': r.farmType ?? '',
        'Budget': Number(r.totalBudget) || 0,
        'Actual Expense': Number(r.actualExpense) || 0,
        'Operational Cost': Number(r.operationalCost) || 0,
        'Remaining': (Number(r.totalBudget) || 0) - (Number(r.actualExpense) || 0),
        'Utilization %': Math.round(this.utilization(r) * 100) / 100
      })));
      const wb = xlsx.utils.book_new();
      xlsx.utils.book_append_sheet(wb, ws, 'Cost vs Budget');
      xlsx.writeFile(wb, `Farm_Cost_vs_Budget_${new Date().toISOString().split('T')[0]}.xlsx`);
    });
  }
}

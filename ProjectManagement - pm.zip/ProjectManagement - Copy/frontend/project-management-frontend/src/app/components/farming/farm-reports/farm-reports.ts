﻿import { Component, ChangeDetectorRef, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Api } from '../../../services/api';
import { Auth } from '../../../services/auth';
import { Project, Pond, FishType, PoultryShed, PoultryBatch } from '../../../models/models';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

type ReportKind = 'farmwise' | 'fish' | 'poultry' | 'feed' | 'mortality';

@Component({
  selector: 'app-farm-reports',
  templateUrl: './farm-reports.html',
  styleUrls: ['../shared/farming.scss'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, RouterModule, MatCardModule, MatTableModule, MatFormFieldModule, MatInputModule, MatSelectModule, MatButtonModule, MatIconModule, MatDatepickerModule, MatNativeDateModule, MatPaginatorModule, MatProgressSpinnerModule]
})
export class FarmReportsComponent implements OnInit {
  reportTypes: { value: ReportKind; label: string }[] = [
    { value: 'farmwise', label: 'Farm-wise Report' },
    { value: 'fish', label: 'Fish Farming Report' },
    { value: 'poultry', label: 'Poultry Farming Report' },
    { value: 'feed', label: 'Feed Consumption Report' },
    { value: 'mortality', label: 'Mortality Report' }
  ];
  farmTypes = ['Fish Farming', 'Poultry Farming'];
  feedTypes = ['Starter Feed', 'Grower Feed', 'Floating Feed', 'Sinking Feed', 'Starter', 'Grower', 'Finisher', 'Layer Feed', 'Other'];
  projects: Project[] = [];
  ponds: Pond[] = [];
  fishTypes: FishType[] = [];
  sheds: PoultryShed[] = [];
  batches: PoultryBatch[] = [];
  form: FormGroup;
  kind: ReportKind = 'farmwise';
  rows = new MatTableDataSource<any>([]);
  fullRows: any[] = [];
  isLoading = false;
  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;

  farmwiseColumns = ['farmType', 'projectName', 'budget', 'expense', 'revenue', 'profit', 'profitPercent'];
  fishColumns = ['projectName', 'pondCode', 'fishName', 'stocked', 'mortality', 'current', 'harvestQty', 'harvestWt', 'sales', 'expense'];
  poultryColumns = ['projectName', 'shedCode', 'batchCode', 'initial', 'mortality', 'current', 'feed', 'avgWt', 'eggs', 'sales', 'expense'];
  feedColumns = ['farmType', 'projectName', 'entity', 'date', 'feedType', 'quantity', 'cost'];
  mortalityColumns = ['farmType', 'projectName', 'entity', 'subType', 'date', 'quantity'];

  constructor(
    private fb: FormBuilder, private api: Api,
    private cdr: ChangeDetectorRef, public auth: Auth
  ) {
    this.form = this.fb.group({
      reportType: ['farmwise'],
      farmType: [''],
      projectId: [''],
      pondId: [''],
      fishTypeId: [''],
      shedId: [''],
      batchId: [''],
      feedType: [''],
      fromDate: [''],
      toDate: ['']
    });
  }

  ngOnInit(): void {
    this.form.get('reportType')?.valueChanges.subscribe(v => {
      this.kind = v as ReportKind;
      this.pageIndex = 0;
      this.rows.data = [];
      this.fullRows = [];
      this.totalRecords = 0;
      this.cdr.markForCheck();
    });
    this.api.getProjects().subscribe(r => { if (r.success) this.projects = r.data; this.cdr.markForCheck(); });
    this.api.getPonds(undefined, undefined, { pageNumber: 1, pageSize: 100 }).subscribe(r => { if (r.success) this.ponds = r.data; this.cdr.markForCheck(); });
    this.api.getFishTypes().subscribe(r => { if (r.success) this.fishTypes = r.data; this.cdr.markForCheck(); });
    this.api.getPoultrySheds(undefined, undefined, { pageNumber: 1, pageSize: 100 }).subscribe(r => { if (r.success) this.sheds = r.data; this.cdr.markForCheck(); });
    this.api.getPoultryBatches(undefined, undefined, undefined, undefined, { pageNumber: 1, pageSize: 100 }).subscribe(r => { if (r.success) this.batches = r.data; this.cdr.markForCheck(); });
  }

  get columns(): string[] {
    switch (this.kind) {
      case 'fish': return this.fishColumns;
      case 'poultry': return this.poultryColumns;
      case 'feed': return this.feedColumns;
      case 'mortality': return this.mortalityColumns;
      default: return this.farmwiseColumns;
    }
  }

  filters(): any {
    const f = this.form.value;
    return {
      farmType: f.farmType || undefined,
      projectId: f.projectId || undefined,
      pondId: f.pondId || undefined,
      fishTypeId: f.fishTypeId || undefined,
      shedId: f.shedId || undefined,
      batchId: f.batchId || undefined,
      feedType: f.feedType || undefined,
      from: this.toApiDate(f.fromDate),
      to: this.toApiDate(f.toDate)
    };
  }

  run(): void {
    this.pageIndex = 0;
    this.load();
  }

  reset(): void {
    this.form.reset({ reportType: this.kind, farmType: '', projectId: '', pondId: '', fishTypeId: '', shedId: '', batchId: '', feedType: '', fromDate: '', toDate: '' });
    this.pageIndex = 0;
    this.load();
  }

  load(): void {
    this.isLoading = true;
    const f = this.filters();
    const page = { pageNumber: this.pageIndex + 1, pageSize: this.pageSize };
    const done = () => { this.isLoading = false; this.cdr.markForCheck(); };
    if (this.kind === 'farmwise') {
      this.api.getFarmWiseReport(f.farmType, f.projectId, page).subscribe({
        next: r => { if (r.success) this.setPaged(r); done(); }, error: done
      });
    } else if (this.kind === 'fish') {
      this.api.getFishReport(f.projectId, f.pondId, f.fishTypeId, page).subscribe({
        next: r => { if (r.success) this.setPaged(r); done(); }, error: done
      });
    } else if (this.kind === 'poultry') {
      this.api.getPoultryReport(f.projectId, f.shedId, f.batchId, page).subscribe({
        next: r => { if (r.success) this.setPaged(r); done(); }, error: done
      });
    } else if (this.kind === 'feed') {
      this.api.getFeedReport(f.farmType, f.projectId, f.pondId, f.batchId, f.feedType, f.from || undefined, f.to || undefined).subscribe({
        next: r => { if (r.success) this.setFull(r.data); done(); }, error: done
      });
    } else {
      this.api.getMortalityReport(f.farmType, f.projectId, f.pondId, f.batchId, f.from || undefined, f.to || undefined).subscribe({
        next: r => { if (r.success) this.setFull(r.data); done(); }, error: done
      });
    }
  }

  private setPaged(r: { data: any[]; totalRecords?: number }): void {
    this.totalRecords = r.totalRecords ?? r.data.length;
    this.rows.data = r.data;
  }

  private setFull(data: any[]): void {
    this.fullRows = data;
    this.totalRecords = data.length;
    this.slice();
  }

  private slice(): void {
    const start = this.pageIndex * this.pageSize;
    this.rows.data = this.fullRows.slice(start, start + this.pageSize);
  }

  onPage(e: { pageIndex: number; pageSize: number }): void {
    this.pageIndex = e.pageIndex;
    this.pageSize = e.pageSize;
    if (this.kind === 'feed' || this.kind === 'mortality') this.slice();
    else this.load();
  }

  formatCurrency(a: number): string {
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(a || 0);
  }

  toApiDate(v: Date | string | null): string {
    if (!v) return '';
    if (typeof v === 'string') return v.split('T')[0];
    return `${v.getFullYear()}-${String(v.getMonth() + 1).padStart(2, '0')}-${String(v.getDate()).padStart(2, '0')}`;
  }

  exportToExcel(): void {
    const data = (this.kind === 'feed' || this.kind === 'mortality') ? this.fullRows : this.rows.data;
    if (!data.length) return;
    import('xlsx').then(xlsx => {
      let sheet: any[];
      let name = 'Report';
      if (this.kind === 'farmwise') {
        name = 'Farm_Wise';
        sheet = data.map(r => ({
          'Farm Type': r.farmType ?? '', 'Project': `${r.projectCode} - ${r.projectName}`,
          'Budget': r.totalBudget, 'Expense': r.totalExpense, 'Revenue': r.totalRevenue,
          'Profit': r.profit, 'Profit %': Math.round((r.profitPercent || 0) * 100) / 100
        }));
      } else if (this.kind === 'fish') {
        name = 'Fish';
        sheet = data.map(r => ({
          'Project': `${r.projectCode} - ${r.projectName}`, 'Pond': `${r.pondCode} - ${r.pondName}`,
          'Fish': r.fishName, 'Stocked': r.stockedQuantity, 'Mortality': r.mortality,
          'Current Stock': r.currentStock, 'Harvest Qty': r.harvestQuantity,
          'Harvest Wt': r.harvestWeight, 'Sales': r.sales, 'Expense': r.expense
        }));
      } else if (this.kind === 'poultry') {
        name = 'Poultry';
        sheet = data.map(r => ({
          'Project': `${r.projectCode} - ${r.projectName}`, 'Shed': r.shedCode, 'Batch': r.batchCode,
          'Bird Type': r.birdType, 'Initial': r.initialQuantity, 'Mortality': r.mortality,
          'Current': r.currentBirds, 'Feed Cost': r.feedCost, 'Avg Weight': r.latestAvgWeight ?? '',
          'Eggs': r.eggs, 'Bird Sales': r.birdSales, 'Revenue': r.birdRevenue, 'Expense': r.expense
        }));
      } else if (this.kind === 'feed') {
        name = 'Feed';
        sheet = data.map(r => ({
          'Farm Type': r.farmType, 'Project': r.projectName, 'Entity': r.entityCode,
          'Date': (r.txnDate || '').split('T')[0], 'Feed Type': r.feedType,
          'Quantity': r.quantity, 'Unit': r.unit ?? '', 'Rate': r.rate, 'Total Cost': r.totalCost
        }));
      } else {
        name = 'Mortality';
        sheet = data.map(r => ({
          'Farm Type': r.farmType, 'Project': r.projectName, 'Entity': r.entityCode,
          'Type': r.subType ?? '', 'Date': (r.txnDate || '').split('T')[0],
          'Quantity': r.quantity, 'Reason': r.reason ?? ''
        }));
      }
      const ws = xlsx.utils.json_to_sheet(sheet);
      const wb = xlsx.utils.book_new();
      xlsx.utils.book_append_sheet(wb, ws, name);
      xlsx.writeFile(wb, `Farm_${name}_${new Date().toISOString().split('T')[0]}.xlsx`);
    });
  }
}

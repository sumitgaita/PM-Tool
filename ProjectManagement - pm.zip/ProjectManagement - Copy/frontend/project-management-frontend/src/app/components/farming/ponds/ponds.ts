﻿import { Component, ChangeDetectorRef, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Api } from '../../../services/api';
import { Auth } from '../../../services/auth';
import { Pond, Project } from '../../../models/models';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatChipsModule } from '@angular/material/chips';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialogModule } from '@angular/material/dialog';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@Component({
  selector: 'app-ponds',
  templateUrl: './ponds.html',
  styleUrls: ['./ponds.scss'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, RouterModule, MatCardModule, MatTableModule, MatFormFieldModule, MatInputModule, MatSelectModule, MatButtonModule, MatIconModule, MatSlideToggleModule, MatSnackBarModule, MatDialogModule, MatPaginatorModule, MatTooltipModule, MatProgressSpinnerModule, MatChipsModule]
})
export class PondsComponent implements OnInit {
  @ViewChild('dialogContent') dialogContent!: TemplateRef<unknown>;
  private dialogRef: MatDialogRef<unknown> | null = null;
  rows: Pond[] = [];
  dataSource = new MatTableDataSource<Pond>([]);
  projects: Project[] = [];
  pondForm: FormGroup;
  searchForm: FormGroup;
  isEditing = false;
  selected: Pond | null = null;
  isLoading = false;
  isSaving = false;
  saveError = '';
  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;
  displayedColumns = ['pondCode', 'pondName', 'projectName', 'area', 'status', 'isActive', 'actions'];

  constructor(
    private fb: FormBuilder,
    private api: Api,
    private dialog: MatDialog,
    private snackBar: MatSnackBar,
    private cdr: ChangeDetectorRef,
    public auth: Auth
  ) {
    this.pondForm = this.fb.group({
      projectId: ['', Validators.required],
      pondCode: ['', Validators.required],
      pondName: ['', Validators.required],
      area: [null],
      areaUnit: ['Acre'],
      depth: [''],
      waterCapacity: [null],
      pondType: [''],
      status: ['Active', Validators.required]
    });
    this.searchForm = this.fb.group({
      searchText: [''],
      projectId: ['']
    });
  }

  ngOnInit(): void {
    this.api.getProjects().subscribe(r => {
      if (r.success) this.projects = r.data.filter(p => p.isActive);
      this.cdr.markForCheck();
    });
    this.load();
  }

  load(): void {
    this.isLoading = true;
    const s = this.searchForm.value;
    this.api.getPonds(
      s.projectId || undefined,
      (s.searchText || '').trim() || undefined,
      { pageNumber: this.pageIndex + 1, pageSize: this.pageSize }
    ).subscribe({
      next: r => {
        if (r.success) {
          this.rows = r.data;
          this.dataSource.data = r.data;
          this.totalRecords = r.totalRecords ?? r.data.length;
        }
        this.isLoading = false;
        this.cdr.markForCheck();
      },
      error: () => { this.isLoading = false; this.cdr.markForCheck(); }
    });
  }

  applySearch(): void { this.pageIndex = 0; this.load(); }

  resetSearch(): void {
    this.searchForm.reset({ searchText: '', projectId: '' });
    this.pageIndex = 0;
    this.load();
  }

  onPage(e: { pageIndex: number; pageSize: number }): void {
    this.pageIndex = e.pageIndex;
    this.pageSize = e.pageSize;
    this.load();
  }

  openDialog(row?: Pond): void {
    this.isEditing = !!row;
    this.selected = row || null;
    this.isSaving = false;
    this.saveError = '';
    if (row) {
      this.pondForm.patchValue({ ...row });
    } else {
      this.pondForm.reset();
      this.pondForm.patchValue({ areaUnit: 'Acre', status: 'Active' });
    }
    this.dialogRef = this.dialog.open(this.dialogContent, { width: '600px', maxHeight: '90vh' });
  }

  save(): void {
    if (this.pondForm.invalid) return;
    this.isSaving = true;
    this.saveError = '';
    const v = this.pondForm.value;
    if (this.isEditing && this.selected) {
      this.api.updatePond(this.selected.pondId, v).subscribe({
        next: r => {
          this.isSaving = false;
          if (r.success) { this.snackBar.open(r.message || 'Pond updated.', 'Close', { duration: 3000 }); this.load(); this.closeDialog(); }
          else this.saveError = r.message || 'Failed to update pond.';
          this.cdr.markForCheck();
        },
        error: err => {
          this.isSaving = false;
          this.saveError = err?.status === 403 ? 'Access denied.' : (err?.error?.message || 'Failed to update pond.');
          this.cdr.markForCheck();
        }
      });
    } else {
      this.api.createPond(v).subscribe({
        next: r => {
          this.isSaving = false;
          if (r.success) { this.snackBar.open(r.message || 'Pond created.', 'Close', { duration: 3000 }); this.load(); this.closeDialog(); }
          else this.saveError = r.message || 'Failed to create pond.';
          this.cdr.markForCheck();
        },
        error: err => {
          this.isSaving = false;
          this.saveError = err?.status === 403 ? 'Access denied.' : (err?.error?.message || 'Failed to create pond. Code may already exist.');
          this.cdr.markForCheck();
        }
      });
    }
  }

  closeDialog(): void {
    this.dialogRef?.close();
    this.dialogRef = null;
    this.pondForm.reset();
    this.isEditing = false;
    this.selected = null;
    this.isSaving = false;
    this.saveError = '';
  }

  toggleStatus(row: Pond): void {
    const call = row.isActive ? this.api.deactivatePond(row.pondId) : this.api.activatePond(row.pondId);
    call.subscribe(r => {
      if (r.success) { this.snackBar.open(r.message, 'Close', { duration: 3000 }); this.load(); }
      else this.snackBar.open(r.message || 'Failed.', 'Close', { duration: 3000 });
    });
  }

  remove(row: Pond): void {
    if (!window.confirm(`Delete pond '${row.pondCode} - ${row.pondName}'?\n\nPonds with farming transactions cannot be deleted.`)) return;
    this.api.deletePond(row.pondId).subscribe({
      next: r => {
        this.snackBar.open(r.message || 'Pond deleted.', 'Close', { duration: 3000 });
        if (r.success) {
          if (this.dataSource.data.length <= 1 && this.pageIndex > 0) this.pageIndex--;
          this.load();
        }
      },
      error: err => this.snackBar.open(err?.status === 403 ? 'Access denied.' : (err?.error?.message || 'Failed to delete pond.'), 'Close', { duration: 4000 })
    });
  }

  exportToExcel(): void {
    const s = this.searchForm.value;
    const fetch = (page: number) => this.api.getPonds(
      s.projectId || undefined, (s.searchText || '').trim() || undefined, { pageNumber: page, pageSize: 100 });
    this.api.fetchAll(fetch).subscribe(all => {
      if (!all.length) return;
      import('xlsx').then(xlsx => {
        const ws = xlsx.utils.json_to_sheet(all.map(p => ({
          'Pond Code': p.pondCode, 'Pond Name': p.pondName,
          'Project': `${p.projectCode} - ${p.projectName}`,
          'Area': p.area ?? '', 'Area Unit': p.areaUnit ?? '', 'Depth': p.depth ?? '',
          'Water Capacity': p.waterCapacity ?? '', 'Pond Type': p.pondType ?? '',
          'Status': p.status, 'Active': p.isActive ? 'Yes' : 'No'
        })));
        const wb = xlsx.utils.book_new();
        xlsx.utils.book_append_sheet(wb, ws, 'Ponds');
        xlsx.writeFile(wb, `Ponds_${new Date().toISOString().split('T')[0]}.xlsx`);
      });
    });
  }
}

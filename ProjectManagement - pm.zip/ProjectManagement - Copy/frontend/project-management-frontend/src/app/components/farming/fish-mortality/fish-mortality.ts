﻿import { Component, ChangeDetectorRef, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Api } from '../../../services/api';
import { Auth } from '../../../services/auth';
import { FishMortality, Pond, FishType, Project } from '../../../models/models';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialogModule } from '@angular/material/dialog';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@Component({
  selector: 'app-fish-mortality',
  templateUrl: './fish-mortality.html',
  styleUrls: ['../shared/farming.scss'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, RouterModule, MatCardModule, MatTableModule, MatFormFieldModule, MatInputModule, MatSelectModule, MatButtonModule, MatIconModule, MatDatepickerModule, MatNativeDateModule, MatSnackBarModule, MatDialogModule, MatPaginatorModule, MatTooltipModule, MatProgressSpinnerModule]
})
export class FishMortalityComponent implements OnInit {
  @ViewChild('dialogContent') dialogContent!: TemplateRef<unknown>;
  private dialogRef: MatDialogRef<unknown> | null = null;
  rows: FishMortality[] = [];
  dataSource = new MatTableDataSource<FishMortality>([]);
  projects: Project[] = [];
  ponds: Pond[] = [];
  fishTypes: FishType[] = [];
  form: FormGroup;
  searchForm: FormGroup;
  isEditing = false;
  selected: FishMortality | null = null;
  isLoading = false;
  isSaving = false;
  saveError = '';
  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;
  displayedColumns = ['mortalityDate', 'pondCode', 'fishName', 'quantity', 'actions'];

  constructor(
    private fb: FormBuilder, private api: Api, private dialog: MatDialog,
    private snackBar: MatSnackBar, private cdr: ChangeDetectorRef, public auth: Auth
  ) {
    this.form = this.fb.group({
      pondId: ['', Validators.required],
      fishTypeId: ['', Validators.required],
      mortalityDate: ['', Validators.required],
      quantity: [null, [Validators.required, Validators.min(1)]],
      reason: [''],
      remarks: ['']
    });
    this.searchForm = this.fb.group({ projectId: [''], pondId: [''], fishTypeId: [''] });
  }

  ngOnInit(): void {
    this.api.getProjects().subscribe(r => { if (r.success) this.projects = r.data.filter((p: Project) => p.isActive); this.cdr.markForCheck(); });
    this.api.getPonds(undefined, undefined, { pageNumber: 1, pageSize: 100 }).subscribe(r => { if (r.success) this.ponds = r.data.filter((p: Pond) => p.isActive); this.cdr.markForCheck(); });
    this.api.getFishTypes().subscribe(r => { if (r.success) this.fishTypes = r.data.filter((f: FishType) => f.isActive); this.cdr.markForCheck(); });
    this.load();
  }

  load(): void {
    this.isLoading = true;
    const s = this.searchForm.value;
    this.api.getFishMortality(s.projectId || undefined, s.pondId || undefined, s.fishTypeId || undefined,
      undefined, undefined, { pageNumber: this.pageIndex + 1, pageSize: this.pageSize }).subscribe({
      next: r => {
        if (r.success) { this.rows = r.data; this.dataSource.data = r.data; this.totalRecords = r.totalRecords ?? r.data.length; }
        this.isLoading = false; this.cdr.markForCheck();
      },
      error: () => { this.isLoading = false; this.cdr.markForCheck(); }
    });
  }

  applySearch(): void { this.pageIndex = 0; this.load(); }
  resetSearch(): void { this.searchForm.reset({ projectId: '', pondId: '', fishTypeId: '' }); this.pageIndex = 0; this.load(); }
  onPage(e: { pageIndex: number; pageSize: number }): void { this.pageIndex = e.pageIndex; this.pageSize = e.pageSize; this.load(); }

  openDialog(row?: FishMortality): void {
    this.isEditing = !!row;
    this.selected = row || null;
    this.isSaving = false;
    this.saveError = '';
    if (row) this.form.patchValue({ ...row, mortalityDate: this.toDateObject(row.mortalityDate) });
    else { this.form.reset(); this.form.patchValue({ mortalityDate: new Date() }); }
    this.dialogRef = this.dialog.open(this.dialogContent, { width: '600px', maxHeight: '90vh' });
  }

  save(): void {
    if (this.form.invalid) return;
    this.isSaving = true;
    this.saveError = '';
    const v = this.form.value;
    const payload: any = {
      pondId: Number(v.pondId), fishTypeId: Number(v.fishTypeId),
      mortalityDate: this.toApiDate(v.mortalityDate), quantity: Number(v.quantity),
      reason: v.reason || null, remarks: v.remarks || null
    };
    const call = this.isEditing && this.selected
      ? this.api.updateFishMortality(this.selected.mortalityId, payload)
      : this.api.createFishMortality(payload);
    call.subscribe({
      next: r => {
        this.isSaving = false;
        if (r.success) { this.snackBar.open(r.message || 'Saved.', 'Close', { duration: 3000 }); this.load(); this.closeDialog(); }
        else this.saveError = r.message || 'Failed to save.';
        this.cdr.markForCheck();
      },
      error: err => {
        this.isSaving = false;
        this.saveError = err?.status === 403 ? 'Access denied.' : (err?.error?.message || 'Failed to save.');
        this.cdr.markForCheck();
      }
    });
  }

  closeDialog(): void {
    this.dialogRef?.close(); this.dialogRef = null; this.form.reset();
    this.isEditing = false; this.selected = null; this.isSaving = false; this.saveError = '';
  }

  remove(row: FishMortality): void {
    if (!window.confirm(`Delete mortality of ${row.quantity} ${row.fishName} on ${this.toApiDate(row.mortalityDate)}?`)) return;
    this.api.deleteFishMortality(row.mortalityId).subscribe({
      next: r => {
        this.snackBar.open(r.message || 'Deleted.', 'Close', { duration: 3000 });
        if (r.success) { if (this.dataSource.data.length <= 1 && this.pageIndex > 0) this.pageIndex--; this.load(); }
      },
      error: err => this.snackBar.open(err?.status === 403 ? 'Access denied.' : (err?.error?.message || 'Failed to delete.'), 'Close', { duration: 4000 })
    });
  }

  exportToExcel(): void {
    const s = this.searchForm.value;
    const fetch = (page: number) => this.api.getFishMortality(
      s.projectId || undefined, s.pondId || undefined, s.fishTypeId || undefined,
      undefined, undefined, { pageNumber: page, pageSize: 100 });
    this.api.fetchAll(fetch).subscribe(all => {
      if (!all.length) return;
      import('xlsx').then(xlsx => {
        const ws = xlsx.utils.json_to_sheet(all.map(r => ({
          'Date': this.toApiDate(r.mortalityDate), 'Pond': `${r.pondCode} - ${r.pondName}`,
          'Fish': `${r.fishCode} - ${r.fishName}`, 'Quantity': r.quantity,
          'Reason': r.reason ?? '', 'Remarks': r.remarks ?? ''
        })));
        const wb = xlsx.utils.book_new();
        xlsx.utils.book_append_sheet(wb, ws, 'Fish Mortality');
        xlsx.writeFile(wb, `Fish_Mortality_${new Date().toISOString().split('T')[0]}.xlsx`);
      });
    });
  }

  toApiDate(v: Date | string | null): string {
    if (!v) return '';
    if (typeof v === 'string') return v.split('T')[0];
    return `${v.getFullYear()}-${String(v.getMonth() + 1).padStart(2, '0')}-${String(v.getDate()).padStart(2, '0')}`;
  }

  toDateObject(v: string | null): Date | null {
    if (!v) return null;
    const p = v.split('T')[0].split('-');
    if (p.length !== 3) return null;
    return new Date(Number(p[0]), Number(p[1]) - 1, Number(p[2]));
  }
}

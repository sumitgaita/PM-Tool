﻿import { Component, ChangeDetectorRef, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Api } from '../../../services/api';
import { Auth } from '../../../services/auth';
import { PoultryShed, Project } from '../../../models/models';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatChipsModule } from '@angular/material/chips';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialogModule } from '@angular/material/dialog';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@Component({
  selector: 'app-poultry-sheds',
  templateUrl: './poultry-sheds.html',
  styleUrls: ['../shared/farming.scss'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, RouterModule, MatCardModule, MatTableModule, MatFormFieldModule, MatInputModule, MatSelectModule, MatButtonModule, MatIconModule, MatChipsModule, MatSlideToggleModule, MatSnackBarModule, MatDialogModule, MatPaginatorModule, MatTooltipModule, MatProgressSpinnerModule]
})
export class PoultryShedsComponent implements OnInit {
  @ViewChild('dialogContent') dialogContent!: TemplateRef<unknown>;
  private dialogRef: MatDialogRef<unknown> | null = null;
  rows: PoultryShed[] = [];
  dataSource = new MatTableDataSource<PoultryShed>([]);
  projects: Project[] = [];
  shedTypes = ['Broiler', 'Layer', 'Country Chicken', 'Other'];
  form: FormGroup;
  searchForm: FormGroup;
  isEditing = false;
  selected: PoultryShed | null = null;
  isLoading = false;
  isSaving = false;
  saveError = '';
  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;
  displayedColumns = ['shedCode', 'shedName', 'projectName', 'capacity', 'shedType', 'status', 'isActive', 'actions'];

  constructor(
    private fb: FormBuilder, private api: Api, private dialog: MatDialog,
    private snackBar: MatSnackBar, private cdr: ChangeDetectorRef, public auth: Auth
  ) {
    this.form = this.fb.group({
      projectId: ['', Validators.required],
      shedCode: ['', Validators.required],
      shedName: ['', Validators.required],
      capacity: [0],
      capacityUnit: ['Birds'],
      shedType: ['Broiler'],
      status: ['Active', Validators.required]
    });
    this.searchForm = this.fb.group({ searchText: [''], projectId: [''] });
  }

  ngOnInit(): void {
    this.api.getProjects().subscribe(r => { if (r.success) this.projects = r.data.filter((p: Project) => p.isActive); this.cdr.markForCheck(); });
    this.load();
  }

  load(): void {
    this.isLoading = true;
    const s = this.searchForm.value;
    this.api.getPoultrySheds(s.projectId || undefined, (s.searchText || '').trim() || undefined,
      { pageNumber: this.pageIndex + 1, pageSize: this.pageSize }).subscribe({
      next: r => {
        if (r.success) { this.rows = r.data; this.dataSource.data = r.data; this.totalRecords = r.totalRecords ?? r.data.length; }
        this.isLoading = false; this.cdr.markForCheck();
      },
      error: () => { this.isLoading = false; this.cdr.markForCheck(); }
    });
  }

  applySearch(): void { this.pageIndex = 0; this.load(); }
  resetSearch(): void { this.searchForm.reset({ searchText: '', projectId: '' }); this.pageIndex = 0; this.load(); }
  onPage(e: { pageIndex: number; pageSize: number }): void { this.pageIndex = e.pageIndex; this.pageSize = e.pageSize; this.load(); }

  openDialog(row?: PoultryShed): void {
    this.isEditing = !!row;
    this.selected = row || null;
    this.isSaving = false;
    this.saveError = '';
    if (row) this.form.patchValue({ ...row });
    else { this.form.reset(); this.form.patchValue({ capacityUnit: 'Birds', shedType: 'Broiler', status: 'Active' }); }
    this.dialogRef = this.dialog.open(this.dialogContent, { width: '600px', maxHeight: '90vh' });
  }

  save(): void {
    if (this.form.invalid) return;
    this.isSaving = true;
    this.saveError = '';
    const v = this.form.value;
    const call = this.isEditing && this.selected
      ? this.api.updatePoultryShed(this.selected.shedId, v)
      : this.api.createPoultryShed(v);
    call.subscribe({
      next: r => {
        this.isSaving = false;
        if (r.success) { this.snackBar.open(r.message || 'Saved.', 'Close', { duration: 3000 }); this.load(); this.closeDialog(); }
        else this.saveError = r.message || 'Failed to save.';
        this.cdr.markForCheck();
      },
      error: err => {
        this.isSaving = false;
        this.saveError = err?.status === 403 ? 'Access denied.' : (err?.error?.message || 'Failed to save. Code may already exist.');
        this.cdr.markForCheck();
      }
    });
  }

  closeDialog(): void {
    this.dialogRef?.close(); this.dialogRef = null; this.form.reset();
    this.isEditing = false; this.selected = null; this.isSaving = false; this.saveError = '';
  }

  toggleStatus(row: PoultryShed): void {
    const call = row.isActive ? this.api.deactivatePoultryShed(row.shedId) : this.api.activatePoultryShed(row.shedId);
    call.subscribe(r => {
      if (r.success) { this.snackBar.open(r.message, 'Close', { duration: 3000 }); this.load(); }
      else this.snackBar.open(r.message || 'Failed.', 'Close', { duration: 3000 });
    });
  }

  remove(row: PoultryShed): void {
    if (!window.confirm(`Delete shed '${row.shedCode} - ${row.shedName}'?\n\nSheds with batches cannot be deleted.`)) return;
    this.api.deletePoultryShed(row.shedId).subscribe({
      next: r => {
        this.snackBar.open(r.message || 'Deleted.', 'Close', { duration: 3000 });
        if (r.success) { if (this.dataSource.data.length <= 1 && this.pageIndex > 0) this.pageIndex--; this.load(); }
      },
      error: err => this.snackBar.open(err?.status === 403 ? 'Access denied.' : (err?.error?.message || 'Failed to delete.'), 'Close', { duration: 4000 })
    });
  }

  exportToExcel(): void {
    const s = this.searchForm.value;
    const fetch = (page: number) => this.api.getPoultrySheds(
      s.projectId || undefined, (s.searchText || '').trim() || undefined, { pageNumber: page, pageSize: 100 });
    this.api.fetchAll(fetch).subscribe(all => {
      if (!all.length) return;
      import('xlsx').then(xlsx => {
        const ws = xlsx.utils.json_to_sheet(all.map(x => ({
          'Shed Code': x.shedCode, 'Shed Name': x.shedName,
          'Project': `${x.projectCode} - ${x.projectName}`,
          'Capacity': x.capacity, 'Unit': x.capacityUnit ?? '', 'Shed Type': x.shedType ?? '',
          'Status': x.status, 'Active': x.isActive ? 'Yes' : 'No'
        })));
        const wb = xlsx.utils.book_new();
        xlsx.utils.book_append_sheet(wb, ws, 'Sheds');
        xlsx.writeFile(wb, `Poultry_Sheds_${new Date().toISOString().split('T')[0]}.xlsx`);
      });
    });
  }
}

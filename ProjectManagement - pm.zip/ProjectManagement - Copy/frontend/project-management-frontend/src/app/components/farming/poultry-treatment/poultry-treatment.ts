﻿import { Component, ChangeDetectorRef, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { Api } from '../../../services/api';
import { Auth } from '../../../services/auth';
import { PoultryTreatment, PoultryBatch, Project, BudgetCode, Resource } from '../../../models/models';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialogModule } from '@angular/material/dialog';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@Component({
  selector: 'app-poultry-treatment',
  templateUrl: './poultry-treatment.html',
  styleUrls: ['../shared/farming.scss'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, RouterModule, MatCardModule, MatTableModule, MatFormFieldModule, MatInputModule, MatSelectModule, MatButtonModule, MatIconModule, MatDatepickerModule, MatNativeDateModule, MatCheckboxModule, MatSnackBarModule, MatDialogModule, MatPaginatorModule, MatTooltipModule, MatProgressSpinnerModule]
})
export class PoultryTreatmentComponent implements OnInit {
  @ViewChild('dialogContent') dialogContent!: TemplateRef<unknown>;
  private dialogRef: MatDialogRef<unknown> | null = null;
  rows: PoultryTreatment[] = [];
  dataSource = new MatTableDataSource<PoultryTreatment>([]);
  projects: Project[] = [];
  batches: PoultryBatch[] = [];
  budgetCodes: BudgetCode[] = [];
  resources: Resource[] = [];
  treatmentTypes = ['Vaccination', 'Medicine', 'Vitamin', 'Antibiotic', 'Disease Treatment', 'Other'];
  form: FormGroup;
  searchForm: FormGroup;
  isEditing = false;
  selected: PoultryTreatment | null = null;
  isLoading = false;
  isSaving = false;
  saveError = '';
  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;
  displayedColumns = ['treatmentDate', 'batchCode', 'treatmentType', 'medicine', 'cost', 'actions'];

  constructor(
    private fb: FormBuilder, private api: Api, private dialog: MatDialog,
    private snackBar: MatSnackBar, private cdr: ChangeDetectorRef, public auth: Auth
  ) {
    this.form = this.fb.group({
      batchId: ['', Validators.required],
      treatmentDate: ['', Validators.required],
      treatmentType: ['', Validators.required],
      medicine: [''],
      quantity: [0],
      cost: [0],
      reason: [''],
      remarks: [''],
      recordExpense: [false],
      expProjectId: [''], expBudgetCodeId: [''], expResourceId: ['']
    });
    this.searchForm = this.fb.group({ searchText: [''], projectId: [''], batchId: [''] });
  }

  ngOnInit(): void {
    this.api.getProjects().subscribe(r => { if (r.success) this.projects = r.data.filter((p: Project) => p.isActive); this.cdr.markForCheck(); });
    this.api.getPoultryBatches(undefined, undefined, undefined, undefined, { pageNumber: 1, pageSize: 100 }).subscribe(r => { if (r.success) this.batches = r.data; this.cdr.markForCheck(); });
    this.api.getBudgetCodes().subscribe(r => { if (r.success) this.budgetCodes = r.data.filter((b: BudgetCode) => b.isActive); this.cdr.markForCheck(); });
    this.api.getResources().subscribe(r => { if (r.success) this.resources = r.data.filter((x: Resource) => x.isActive); this.cdr.markForCheck(); });
    this.load();
  }

  load(): void {
    this.isLoading = true;
    const s = this.searchForm.value;
    this.api.getPoultryTreatment(s.projectId || undefined, s.batchId || undefined,
      (s.searchText || '').trim() || undefined, undefined, undefined,
      { pageNumber: this.pageIndex + 1, pageSize: this.pageSize }).subscribe({
      next: r => {
        if (r.success) { this.rows = r.data; this.dataSource.data = r.data; this.totalRecords = r.totalRecords ?? r.data.length; }
        this.isLoading = false; this.cdr.markForCheck();
      },
      error: () => { this.isLoading = false; this.cdr.markForCheck(); }
    });
  }

  applySearch(): void { this.pageIndex = 0; this.load(); }
  resetSearch(): void { this.searchForm.reset({ searchText: '', projectId: '', batchId: '' }); this.pageIndex = 0; this.load(); }
  onPage(e: { pageIndex: number; pageSize: number }): void { this.pageIndex = e.pageIndex; this.pageSize = e.pageSize; this.load(); }

  openDialog(row?: PoultryTreatment): void {
    this.isEditing = !!row;
    this.selected = row || null;
    this.isSaving = false;
    this.saveError = '';
    if (row) this.form.patchValue({ ...row, treatmentDate: this.toDateObject(row.treatmentDate), recordExpense: false });
    else { this.form.reset(); this.form.patchValue({ treatmentDate: new Date(), recordExpense: false }); }
    this.dialogRef = this.dialog.open(this.dialogContent, { width: '700px', maxHeight: '90vh' });
  }

  save(): void {
    if (this.form.invalid) return;
    this.isSaving = true;
    this.saveError = '';
    const v = this.form.value;
    const payload: any = {
      batchId: Number(v.batchId), treatmentDate: this.toApiDate(v.treatmentDate), treatmentType: v.treatmentType,
      medicine: v.medicine || null, quantity: v.quantity ?? 0, cost: v.cost ?? 0,
      reason: v.reason || null, remarks: v.remarks || null
    };
    if (!this.isEditing && v.recordExpense) {
      payload.expProjectId = Number(v.expProjectId) || null;
      payload.expBudgetCodeId = Number(v.expBudgetCodeId) || null;
      payload.expResourceId = Number(v.expResourceId) || null;
    }
    const call = this.isEditing && this.selected
      ? this.api.updatePoultryTreatment(this.selected.treatmentId, payload)
      : this.api.createPoultryTreatment(payload);
    call.subscribe({
      next: r => {
        this.isSaving = false;
        if (r.success) { this.snackBar.open(r.message || 'Saved.', 'Close', { duration: 3000 }); this.load(); this.closeDialog(); }
        else this.saveError = r.message || 'Failed to save.';
        this.cdr.markForCheck();
      },
      error: err => {
        this.isSaving = false;
        this.saveError = err?.status === 403 ? 'Access denied.' : (err?.error?.message || 'Failed to save.');
        this.cdr.markForCheck();
      }
    });
  }

  closeDialog(): void {
    this.dialogRef?.close(); this.dialogRef = null; this.form.reset();
    this.isEditing = false; this.selected = null; this.isSaving = false; this.saveError = '';
  }

  remove(row: PoultryTreatment): void {
    if (!window.confirm(`Delete ${row.treatmentType} treatment on ${this.toApiDate(row.treatmentDate)} in ${row.batchCode}?`)) return;
    this.api.deletePoultryTreatment(row.treatmentId).subscribe({
      next: r => {
        this.snackBar.open(r.message || 'Deleted.', 'Close', { duration: 3000 });
        if (r.success) { if (this.dataSource.data.length <= 1 && this.pageIndex > 0) this.pageIndex--; this.load(); }
      },
      error: err => this.snackBar.open(err?.status === 403 ? 'Access denied.' : (err?.error?.message || 'Failed to delete.'), 'Close', { duration: 4000 })
    });
  }

  exportToExcel(): void {
    const s = this.searchForm.value;
    const fetch = (page: number) => this.api.getPoultryTreatment(
      s.projectId || undefined, s.batchId || undefined, (s.searchText || '').trim() || undefined,
      undefined, undefined, { pageNumber: page, pageSize: 100 });
    this.api.fetchAll(fetch).subscribe(all => {
      if (!all.length) return;
      import('xlsx').then(xlsx => {
        const ws = xlsx.utils.json_to_sheet(all.map(r => ({
          'Date': this.toApiDate(r.treatmentDate), 'Batch': r.batchCode,
          'Type': r.treatmentType, 'Medicine': r.medicine ?? '', 'Quantity': r.quantity,
          'Cost': r.cost, 'Reason': r.reason ?? ''
        })));
        const wb = xlsx.utils.book_new();
        xlsx.utils.book_append_sheet(wb, ws, 'Poultry Treatment');
        xlsx.writeFile(wb, `Poultry_Treatment_${new Date().toISOString().split('T')[0]}.xlsx`);
      });
    });
  }

  formatCurrency(a: number): string {
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(a || 0);
  }

  toApiDate(v: Date | string | null): string {
    if (!v) return '';
    if (typeof v === 'string') return v.split('T')[0];
    return `${v.getFullYear()}-${String(v.getMonth() + 1).padStart(2, '0')}-${String(v.getDate()).padStart(2, '0')}`;
  }

  toDateObject(v: string | null): Date | null {
    if (!v) return null;
    const p = v.split('T')[0].split('-');
    if (p.length !== 3) return null;
    return new Date(Number(p[0]), Number(p[1]) - 1, Number(p[2]));
  }
}

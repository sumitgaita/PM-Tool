import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Api } from '../../services/api';
import { Auth } from '../../services/auth';
import { Project, BudgetCode } from '../../models/models';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialogModule } from '@angular/material/dialog';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { BaseChartDirective } from 'ng2-charts';
import { MatChipsModule } from '@angular/material/chips';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@Component({
  selector: 'app-cost-vs-budget',
  templateUrl: './cost-vs-budget.html',
  styleUrls: ['./cost-vs-budget.scss'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, RouterModule, MatCardModule, MatTableModule, MatFormFieldModule, MatInputModule, MatSelectModule, MatButtonModule, MatIconModule, MatToolbarModule, MatSidenavModule, MatListModule, MatExpansionModule, MatDatepickerModule, MatNativeDateModule, MatSlideToggleModule, MatSnackBarModule, MatDialogModule, MatPaginatorModule, MatSortModule, MatChipsModule, MatTooltipModule, MatProgressSpinnerModule, BaseChartDirective]
})
export class CostVsBudgetComponent implements OnInit {
  filterForm: FormGroup;
  projects: Project[] = [];
  budgetCodes: BudgetCode[] = [];
  costVsBudgetData: any[] = [];
  costVsBudgetDataSource = new MatTableDataSource<any>([]);
  isLoading = false;
  displayedColumns: string[] = ['projectCode', 'projectName', 'budgetCode', 'budgetCodeName', 'budgetAmount', 'actualCost', 'remainingBudget', 'utilizationPercent', 'variance'];

  constructor(
    private fb: FormBuilder,
    private api: Api,
    public auth: Auth
  ) {
    this.filterForm = this.fb.group({
      projectId: [''],
      budgetCodeId: [''],
      fromDate: [''],
      toDate: ['']
    });
  }

  ngOnInit(): void {
    this.loadProjects();
    this.loadBudgetCodes();
    this.loadCostVsBudgetData();
  }

  loadProjects(): void {
    this.api.getProjects().subscribe(response => {
      if (response.success) {
        this.projects = response.data.filter(p => p.isActive);
      }
    });
  }

  loadBudgetCodes(): void {
    this.api.getBudgetCodes().subscribe(response => {
      if (response.success) {
        this.budgetCodes = response.data.filter(b => b.isActive);
      }
    });
  }

  loadCostVsBudgetData(): void {
    this.isLoading = true;
    const filters = this.filterForm.value;

    this.api.getCostVsBudgetReport(
      filters.projectId || undefined,
      filters.budgetCodeId || undefined,
      this.toApiDate(filters.fromDate),
      this.toApiDate(filters.toDate)
    ).subscribe(response => {
      if (response.success) {
        this.costVsBudgetData = response.data;
        this.costVsBudgetDataSource.data = response.data;
      }
      this.isLoading = false;
    });
  }

  private toApiDate(value: Date | string | null | undefined): string | undefined {
    if (!value) {
      return undefined;
    }
    if (typeof value === 'string') {
      return value.split('T')[0];
    }
    const month = String(value.getMonth() + 1).padStart(2, '0');
    const day = String(value.getDate()).padStart(2, '0');
    return `${value.getFullYear()}-${month}-${day}`;
  }

  applyFilters(): void {
    this.loadCostVsBudgetData();
  }

  resetFilters(): void {
    this.filterForm.reset();
    this.loadCostVsBudgetData();
  }

  formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 2
    }).format(amount);
  }

  getUtilizationColor(percent: number): string {
    if (percent >= 100) return 'warn';
    if (percent >= 80) return 'accent';
    return 'primary';
  }

  getValueClass(value: number | null | undefined): string {
    const num = Number(value);
    return num >= 0 ? 'positive-value' : 'negative-value';
  }

  getActualCostClass(actual: number | null | undefined, budget: number | null | undefined): string {
    return (Number(actual) || 0) > (Number(budget) || 0) ? 'negative-value' : 'positive-value';
  }

  getTotalBudget(): number {
    return this.costVsBudgetData.reduce((sum, row) => sum + (Number(row.budgetAmount) || 0), 0);
  }

  getTotalActual(): number {
    return this.costVsBudgetData.reduce((sum, row) => sum + (Number(row.actualCost) || 0), 0);
  }

  getTotalRemaining(): number {
    return this.costVsBudgetData.reduce((sum, row) => sum + (Number(row.remainingBudget) || 0), 0);
  }

  getTotalVariance(): number {
    return this.costVsBudgetData.reduce((sum, row) => sum + (Number(row.variance) || 0), 0);
  }

  getOverallUtilization(): number {
    const totalBudget = this.getTotalBudget();
    if (!totalBudget) return 0;
    return (this.getTotalActual() / totalBudget) * 100;
  }

  exportToExcel(): void {
    Promise.all([import('exceljs'), import('file-saver')]).then(([ExcelJS, FileSaver]) => {
      const workbook = new ExcelJS.Workbook();
      const ws = workbook.addWorksheet('Cost vs Budget');

      ws.columns = [
        { header: 'Project', key: 'project', width: 14 },
        { header: 'Project Name', key: 'projectName', width: 24 },
        { header: 'Budget Code', key: 'budgetCode', width: 14 },
        { header: 'Budget Code Name', key: 'budgetCodeName', width: 22 },
        { header: 'Budget', key: 'budget', width: 16 },
        { header: 'Actual Cost', key: 'actual', width: 16 },
        { header: 'Remaining', key: 'remaining', width: 16 },
        { header: 'Utilization %', key: 'utilization', width: 15 },
        { header: 'Variance', key: 'variance', width: 16 }
      ];

      const headerRow = ws.getRow(1);
      headerRow.font = { bold: true };

      for (const row of this.costVsBudgetData) {
        const excelRow = ws.addRow([
          row.projectCode,
          row.projectName,
          row.budgetCode,
          row.budgetCodeName,
          Number(row.budgetAmount) || 0,
          Number(row.actualCost) || 0,
          Number(row.remainingBudget) || 0,
          Number(row.utilizationPercent) || 0,
          Number(row.variance) || 0
        ]);
        this.styleConditionCell(excelRow.getCell(6), (Number(row.actualCost) || 0) <= (Number(row.budgetAmount) || 0));
        this.styleValueCell(excelRow.getCell(7), row.remainingBudget);
        this.styleValueCell(excelRow.getCell(8), row.utilizationPercent);
        this.styleValueCell(excelRow.getCell(9), row.variance);
      }

      const totalRow = ws.addRow([
        'Total', '', '', '',
        this.getTotalBudget(),
        this.getTotalActual(),
        this.getTotalRemaining(),
        this.getOverallUtilization(),
        this.getTotalVariance()
      ]);
      totalRow.font = { bold: true };
      this.styleConditionCell(totalRow.getCell(6), this.getTotalActual() <= this.getTotalBudget());
      this.styleValueCell(totalRow.getCell(7), this.getTotalRemaining());
      this.styleValueCell(totalRow.getCell(8), this.getOverallUtilization());
      this.styleValueCell(totalRow.getCell(9), this.getTotalVariance());

      for (let i = 2; i <= ws.rowCount; i++) {
        ws.getRow(i).getCell(5).numFmt = '#,##0.00';
        ws.getRow(i).getCell(6).numFmt = '#,##0.00';
        ws.getRow(i).getCell(7).numFmt = '#,##0.00';
        ws.getRow(i).getCell(8).numFmt = '0.00';
        ws.getRow(i).getCell(9).numFmt = '#,##0.00';
      }

      workbook.xlsx.writeBuffer().then(buffer => {
        const blob = new Blob([buffer], {
          type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        });
        FileSaver.saveAs(blob, `Cost_vs_Budget_${new Date().toISOString().split('T')[0]}.xlsx`);
      });
    });
  }

  private styleValueCell(cell: any, value: number | null | undefined): void {
    this.styleConditionCell(cell, (Number(value) || 0) >= 0);
  }

  private styleConditionCell(cell: any, isPositive: boolean): void {
    cell.font = { bold: true, color: { argb: isPositive ? 'FF2E7D32' : 'FFC62828' } };
  }
}


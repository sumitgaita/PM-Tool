import { Component, ChangeDetectorRef, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { Api } from '../../services/api';
import { Auth } from '../../services/auth';
import { Project, BudgetCode } from '../../models/models';

@Component({
  selector: 'app-project-budgets',
  templateUrl: './project-budgets.html',
  styleUrls: ['./project-budgets.scss'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, RouterModule, MatCardModule, MatTableModule, MatPaginatorModule, MatFormFieldModule, MatInputModule, MatSelectModule, MatDatepickerModule, MatNativeDateModule, MatButtonModule, MatIconModule, MatTooltipModule, MatSnackBarModule, MatProgressSpinnerModule]
})
export class ProjectBudgetsComponent implements OnInit {
  budgets: any[] = [];
  budgetsDataSource = new MatTableDataSource<any>([]);
  projects: Project[] = [];
  budgetCodes: BudgetCode[] = [];
  form: FormGroup;
  displayedColumns = ['projectName', 'budgetCode', 'budgetAmount', 'effectiveFrom', 'effectiveTo', 'actions'];
  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;
  searchProjectId: number | null = null;
  editingId: number | null = null;

  constructor(private api: Api, private fb: FormBuilder, private cdr: ChangeDetectorRef, private snackBar: MatSnackBar, public auth: Auth) {
    this.form = this.fb.group({
      projectId: ['', Validators.required],
      budgetCodeId: ['', Validators.required],
      budgetAmount: [0, [Validators.required, Validators.min(0.01)]],
      effectiveFrom: ['', Validators.required],
      effectiveTo: ['']
    });
  }

  ngOnInit(): void { this.loadLookups(); this.load(); }

  loadLookups(): void {
    this.api.getProjects().subscribe(r => { if (r.success) this.projects = r.data.filter(p => p.isActive); this.cdr.markForCheck(); });
    this.api.getBudgetCodes().subscribe(r => { if (r.success) this.budgetCodes = r.data.filter(b => b.isActive); this.cdr.markForCheck(); });
  }

  load(): void {
    const f = this.form.value;
    const projectId = this.searchProjectId ?? (f.projectId || undefined);
    this.api.getProjectBudgets(
      projectId,
      f.budgetCodeId || undefined,
      { pageNumber: this.pageIndex + 1, pageSize: this.pageSize }
    ).subscribe(r => {
      if (r.success) {
        this.budgets = r.data;
        this.budgetsDataSource.data = r.data;
        this.totalRecords = r.totalRecords ?? r.data.length;
      }
      this.cdr.markForCheck();
    });
  }

  onSearch(): void {
    this.pageIndex = 0;
    this.load();
  }

  onClearSearch(): void {
    this.searchProjectId = null;
    this.pageIndex = 0;
    this.load();
  }

  exportToExcel(): void {
    const f = this.form.value;
    const projectId = this.searchProjectId ?? (f.projectId || undefined);
    import('xlsx').then(xlsx => {
      this.api.getProjectBudgets(projectId, f.budgetCodeId || undefined, { pageNumber: 1, pageSize: 100 }).subscribe(r => {
        if (!r.success || !r.data || r.data.length === 0) {
          return;
        }
        const rows = r.data.map(b => ({
          'Project': `${b.projectCode} - ${b.projectName}`,
          'Budget Code': `${b.budgetCode} - ${b.budgetCodeName}`,
          'Budget Amount': Number(b.budgetAmount) || 0,
          'Effective From': (b.effectiveFrom || '').split('T')[0],
          'Effective To': (b.effectiveTo || '').split('T')[0]
        }));
        const ws = xlsx.utils.json_to_sheet(rows);
        const wb = xlsx.utils.book_new();
        xlsx.utils.book_append_sheet(wb, ws, 'Project Budgets');
        xlsx.writeFile(wb, `Project_Budgets_${new Date().toISOString().split('T')[0]}.xlsx`);
      });
    });
  }

  onPage(event: PageEvent): void {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.load();
  }

  onFilterChange(): void {
    if (this.editingId) return;
    this.searchProjectId = null;
    this.pageIndex = 0;
    this.load();
  }

  edit(row: any): void {
    this.editingId = row.projectBudgetId;
    // Project/budget-code cannot be changed by the update API (amount + dates only).
    this.form.get('projectId')?.disable({ emitEvent: false });
    this.form.get('budgetCodeId')?.disable({ emitEvent: false });
    this.form.patchValue({
      projectId: row.projectId,
      budgetCodeId: row.budgetCodeId,
      budgetAmount: row.budgetAmount,
      effectiveFrom: this.toDateObject(row.effectiveFrom),
      effectiveTo: this.toDateObject(row.effectiveTo)
    }, { emitEvent: false });
    this.cdr.markForCheck();
  }

  cancelEdit(): void {
    this.editingId = null;
    this.form.get('projectId')?.enable({ emitEvent: false });
    this.form.get('budgetCodeId')?.enable({ emitEvent: false });
    this.form.reset();
    this.cdr.markForCheck();
  }

  save(): void {
    if (this.form.invalid) return;
    if (this.editingId) {
      this.update();
      return;
    }
    const f = this.form.value;
    this.api.createProjectBudget({
      ...f,
      effectiveFrom: this.toApiDate(f.effectiveFrom),
      effectiveTo: this.toApiDate(f.effectiveTo) || undefined
    }).subscribe({
      next: r => {
        this.snackBar.open(r.message || 'Project budget saved successfully.', 'Close', { duration: 3000 });
        if (r.success) { this.load(); this.form.reset(); }
      },
      error: (err: { status?: number; error?: { message?: string } }) => {
        this.snackBar.open(
          err?.status === 403
            ? 'Access denied. You do not have Edit permission for Project Budgets.'
            : (err?.error?.message || 'Failed to save project budget. Please try again.'),
          'Close', { duration: 4000 });
      }
    });
  }

  private update(): void {
    const id = this.editingId;
    if (id == null) return;
    const ok = window.confirm('Are you sure you want to update this project budget?');
    if (!ok) return;
    const f = this.form.value;
    this.api.updateProjectBudget(id, {
      budgetAmount: f.budgetAmount,
      effectiveFrom: this.toApiDate(f.effectiveFrom),
      effectiveTo: this.toApiDate(f.effectiveTo) || undefined
    }).subscribe({
      next: r => {
        this.snackBar.open(r.message || 'Project budget updated successfully.', 'Close', { duration: 3000 });
        if (r.success) { this.cancelEdit(); this.load(); }
      },
      error: (err: { status?: number; error?: { message?: string } }) => {
        this.snackBar.open(
          err?.status === 403
            ? 'Access denied. You do not have Edit permission for Project Budgets.'
            : (err?.error?.message || 'Failed to update project budget. Please try again.'),
          'Close', { duration: 4000 });
      }
    });
  }

  private toDateObject(value: string | null | undefined): Date | null {
    if (!value) return null;
    const parts = value.split('T')[0].split('-');
    if (parts.length !== 3) return null;
    return new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
  }

  private toApiDate(value: Date | string | null | undefined): string | undefined {
    if (!value) {
      return undefined;
    }
    if (typeof value === 'string') {
      return value.split('T')[0];
    }
    const month = String(value.getMonth() + 1).padStart(2, '0');
    const day = String(value.getDate()).padStart(2, '0');
    return `${value.getFullYear()}-${month}-${day}`;
  }

  remove(id: number): void {
    if (!confirm('Delete this project budget?')) return;
    this.api.deleteProjectBudget(id).subscribe({
      next: r => {
        this.snackBar.open(r.message || 'Project budget deleted successfully.', 'Close', { duration: 3000 });
        if (r.success) this.load();
      },
      error: (err: { status?: number; error?: { message?: string } }) => {
        this.snackBar.open(
          err?.status === 403
            ? 'Access denied. You do not have Delete permission for Project Budgets.'
            : (err?.error?.message || 'Failed to delete project budget. Please try again.'),
          'Close', { duration: 4000 });
      }
    });
  }

  formatCurrency(a: number): string {
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(a);
  }
}



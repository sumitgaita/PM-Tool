import { Component, ChangeDetectorRef, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { forkJoin, of } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { Api } from '../../services/api';
import { Auth } from '../../services/auth';
import { User } from '../../models/models';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialogModule } from '@angular/material/dialog';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatChipsModule } from '@angular/material/chips';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@Component({
  selector: 'app-users',
  templateUrl: './users.html',
  styleUrls: ['./users.scss'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, RouterModule, MatCardModule, MatTableModule, MatFormFieldModule, MatInputModule, MatSelectModule, MatButtonModule, MatIconModule, MatToolbarModule, MatSidenavModule, MatListModule, MatExpansionModule, MatDatepickerModule, MatNativeDateModule, MatSlideToggleModule, MatSnackBarModule, MatDialogModule, MatPaginatorModule, MatSortModule, MatChipsModule, MatTooltipModule, MatProgressSpinnerModule]
})
export class UsersComponent implements OnInit {
  @ViewChild('dialogContent') dialogContent!: TemplateRef<unknown>;
  private dialogRef: MatDialogRef<unknown> | null = null;
  users: User[] = [];
  usersDataSource = new MatTableDataSource<User>([]);
  userForm: FormGroup;
  searchForm: FormGroup;
  roleOptions = ['Admin', 'Super Admin', 'User'];
  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;
  roles = [
    { roleId: 1, roleName: 'Admin' },
    { roleId: 2, roleName: 'User' },
    { roleId: 3, roleName: 'Super Admin' }
  ];
  isEditing = false;
  selectedUser: User | null = null;
  isLoading = false;
  isSaving = false;
  saveError = '';
  hidePassword = true;
  displayedColumns: string[] = ['username', 'fullName', 'email', 'mobileNumber', 'roleName', 'isActive', 'actions'];

  constructor(
    private fb: FormBuilder,
    private api: Api,
    private dialog: MatDialog,
    private cdr: ChangeDetectorRef,
    private snackBar: MatSnackBar,
    public auth: Auth
  ) {
    this.userForm = this.fb.group({
      username: ['', [Validators.required]],
      fullName: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.email]],
      mobileNumber: ['', [Validators.pattern(/^[0-9]{10}$/)]],
      password: ['', [Validators.required]],
      newPassword: [''],
      roleId: [2, [Validators.required]]
    });
    this.searchForm = this.fb.group({
      searchText: [''],
      roleName: ['']
    });
  }

  ngOnInit(): void {
    if (this.auth.isSuperAdmin()) {
      this.displayedColumns = ['username', 'fullName', 'email', 'mobileNumber', 'roleName', 'password', 'isActive', 'actions'];
    }
    this.loadUsers();
  }

  loadUsers(): void {
    this.isLoading = true;
    const searchText = ((this.searchForm.get('searchText')?.value ?? '') as string).trim();
    const roleName = (this.searchForm.get('roleName')?.value ?? '') as string;
    this.api.getUsersPaged(
      searchText || undefined,
      roleName || undefined,
      { pageNumber: this.pageIndex + 1, pageSize: this.pageSize }
    ).subscribe({
      next: response => {
        if (response.success) {
          this.users = response.data;
          this.usersDataSource.data = response.data;
          this.totalRecords = response.totalRecords ?? response.data.length;
        }
        this.isLoading = false;
        this.cdr.markForCheck();
      },
      error: () => {
        this.isLoading = false;
        this.cdr.markForCheck();
      }
    });
  }

  applySearch(): void {
    this.pageIndex = 0;
    this.loadUsers();
  }

  resetSearch(): void {
    this.searchForm.reset({ searchText: '', roleName: '' });
    this.pageIndex = 0;
    this.loadUsers();
  }

  onPage(event: { pageIndex: number; pageSize: number }): void {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.loadUsers();
  }
  openDialog(user?: User): void {
    this.isEditing = !!user;
    this.selectedUser = user || null;
    this.isSaving = false;
    this.saveError = '';
    this.hidePassword = true;

    if (user) {
      this.userForm.reset();
      this.userForm.patchValue({
        username: user.username,
        fullName: user.fullName,
        email: user.email,
        mobileNumber: user.mobileNumber ?? '',
        password: '',
        roleId: user.roleId
      });
      this.userForm.get('password')?.clearValidators();
      this.userForm.get('password')?.updateValueAndValidity();
    } else {
      this.userForm.reset();
      this.userForm.patchValue({ roleId: 2 });
      this.userForm.get('password')?.setValidators([Validators.required, Validators.minLength(6)]);
      this.userForm.get('password')?.updateValueAndValidity();
    }

    this.dialogRef = this.dialog.open(this.dialogContent, {
      width: '600px',
      maxHeight: '90vh'
    });
  }

  saveUser(): void {
    if (this.userForm.invalid) {
      return;
    }
    if (!this.isEditing && this.isUsernameTaken()) {
      this.saveError = `Username '${(this.userForm.get('username')?.value || '').trim()}' is already taken. Please choose another.`;
      this.cdr.markForCheck();
      return;
    }

    this.isSaving = true;
    this.saveError = '';

    if (this.isEditing && this.selectedUser) {
      const updateData = {
        fullName: this.userForm.get('fullName')?.value,
        email: this.userForm.get('email')?.value,
        mobileNumber: ((this.userForm.get('mobileNumber')?.value || '') as string).trim() || null,
        roleId: Number(this.userForm.get('roleId')?.value)
      };
      const newPassword: string = this.userForm.get('newPassword')?.value || '';
      if (newPassword && newPassword.length < 6) {
        this.saveError = 'New password must be at least 6 characters (or leave blank).';
        this.cdr.markForCheck();
        return;
      }
      this.api.updateUser(this.selectedUser.userId, updateData).pipe(
        switchMap(updateResponse => {
          if (!updateResponse.success) {
            throw { message: updateResponse.message || 'Failed to update user.' };
          }
          if (newPassword) {
            return this.api.resetUserPassword(this.selectedUser!.userId, newPassword);
          }
          return of({ success: true });
        })
      ).subscribe({
        next: response => {
          this.isSaving = false;
          if ((response as { success: boolean }).success) {
            this.loadUsers();
            this.closeDialog();
          } else {
            this.saveError = (response as { message?: string }).message || 'Failed to update user.';
          }
          this.cdr.markForCheck();
        },
        error: (err: { status?: number; error?: { message?: string }; message?: string }) => {
          this.isSaving = false;
          this.saveError = this.serverMessage(err, 'Failed to update user. Username or email may already exist.');
          this.cdr.markForCheck();
        }
      });
    } else {
      const createData = {
        username: (this.userForm.get('username')?.value || '').trim(),
        fullName: (this.userForm.get('fullName')?.value || '').trim(),
        email: (this.userForm.get('email')?.value || '').trim(),
        mobileNumber: ((this.userForm.get('mobileNumber')?.value || '') as string).trim() || null,
        password: this.userForm.get('password')?.value,
        roleId: Number(this.userForm.get('roleId')?.value)
      };
      this.api.createUser(createData).subscribe({
        next: response => {
          this.isSaving = false;
          if (response.success) {
            this.loadUsers();
            this.closeDialog();
          } else {
            this.saveError = response.message || 'Failed to create user.';
          }
          this.cdr.markForCheck();
        },
        error: (err: { status?: number; error?: { message?: string }; message?: string }) => {
          this.isSaving = false;
          this.saveError = this.serverMessage(err, 'Failed to create user. Username or email may already exist.');
          this.cdr.markForCheck();
        }
      });
    }
  }

  closeDialog(): void {
    this.dialogRef?.close();
    this.dialogRef = null;
    this.userForm.reset();
    this.isEditing = false;
    this.selectedUser = null;
    this.isSaving = false;
    this.saveError = '';
  }

  isSuperAdmin(user: User | null): boolean {
    return !!user && user.roleName === 'Super Admin';
  }

  isCurrentUser(user: User | null): boolean {
    const current = this.auth.getCurrentUser();
    return !!user && !!current && user.userId === current.userId;
  }

  deleteUser(user: User): void {
    if (this.isCurrentUser(user)) {
      this.snackBar.open('You cannot delete your own account.', 'Close', { duration: 4000 });
      return;
    }
    const ok = window.confirm(
      `Are you sure you want to delete user '${user.username} (${user.fullName})'?\n\nThe user will be deactivated (soft delete) and will no longer be able to log in.`);
    if (!ok) return;
    this.api.deleteUser(user.userId).subscribe({
      next: response => {
        this.snackBar.open(response.message || 'User deleted successfully.', 'Close', { duration: 3000 });
        if (response.success) {
          // If the last row of a later page was deleted, step back a page.
          if (this.usersDataSource.data.length <= 1 && this.pageIndex > 0) {
            this.pageIndex--;
          }
          this.loadUsers();
        } else {
          this.cdr.markForCheck();
        }
      },
      error: (err: { status?: number; error?: { message?: string } }) => {
        const message = err?.status === 403
          ? 'Access denied. Only Super Admin can delete users.'
          : (err?.error?.message || 'Failed to delete user. Please try again.');
        this.snackBar.open(message, 'Close', { duration: 4000 });
        this.cdr.markForCheck();
      }
    });
  }

  private serverMessage(err: { status?: number; error?: { message?: string }; message?: string }, fallback: string): string {
    if (err?.status === 401) {
      return 'Session expired. Please log out and log in again, then retry.';
    }
    return err?.error?.message || fallback;
  }

  isUsernameTaken(): boolean {
    if (this.isEditing) {
      return false;
    }
    const name = ((this.userForm.get('username')?.value || '') as string).trim().toLowerCase();
    if (!name) {
      return false;
    }
    return this.users.some(u => (u.username || '').trim().toLowerCase() === name);
  }

  isUsernameAvailable(): boolean {
    if (this.isEditing) {
      return false;
    }
    const name = ((this.userForm.get('username')?.value || '') as string).trim();
    return name.length > 0 && !this.isUsernameTaken();
  }

  toggleStatus(user: User): void {
    if (user.isActive) {
      this.api.deactivateUser(user.userId).subscribe(response => {
        if (response.success) {
          this.loadUsers();
        }
      });
    } else {
      this.api.activateUser(user.userId).subscribe(response => {
        if (response.success) {
          this.loadUsers();
        }
      });
    }
  }

  exportToExcel(): void {
    // Export all rows matching the current search (server-side paging
    // returns max 100 per call, so fetch remaining pages when needed).
    const searchText = ((this.searchForm.get('searchText')?.value ?? '') as string).trim();
    const roleName = (this.searchForm.get('roleName')?.value ?? '') as string;
    const fetch = (page: number) => this.api.getUsersPaged(
      searchText || undefined, roleName || undefined, { pageNumber: page, pageSize: 100 });
    fetch(1).pipe(
      switchMap(first => {
        if (!first.success) return of<User[]>([]);
        const total = first.totalRecords ?? first.data.length;
        const pages = Math.ceil(total / 100);
        if (pages <= 1) return of(first.data);
        const rest = [];
        for (let p = 2; p <= pages; p++) rest.push(fetch(p));
        return forkJoin(rest).pipe(
          switchMap(results => of([...first.data, ...results.flatMap(r => r.success ? r.data : [])]))
        );
      })
    ).subscribe(all => {
      if (all.length === 0) return;
      this.writeExcel(all);
    });
  }

  private writeExcel(rows: User[]): void {
    import('xlsx').then(xlsx => {
      const sheet = rows.map(u => ({
        'Username': u.username,
        'Full Name': u.fullName,
        'Email': u.email,
        'Mobile Number': u.mobileNumber ?? '',
        'Role': u.roleName,
        'Active': u.isActive ? 'Yes' : 'No'
      }));
      const ws = xlsx.utils.json_to_sheet(sheet);
      const wb = xlsx.utils.book_new();
      xlsx.utils.book_append_sheet(wb, ws, 'Users');
      xlsx.writeFile(wb, `Users_${new Date().toISOString().split('T')[0]}.xlsx`);
    });
  }
}


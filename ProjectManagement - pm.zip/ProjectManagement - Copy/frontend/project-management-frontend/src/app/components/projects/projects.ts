import { Component, OnInit, OnDestroy, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { forkJoin, of } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { Api } from '../../services/api';
import { Auth } from '../../services/auth';
import { Project } from '../../models/models';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialogModule } from '@angular/material/dialog';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatChipsModule } from '@angular/material/chips';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@Component({
  selector: 'app-projects',
  templateUrl: './projects.html',
  styleUrls: ['./projects.scss'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, RouterModule, MatCardModule, MatTableModule, MatFormFieldModule, MatInputModule, MatSelectModule, MatButtonModule, MatIconModule, MatToolbarModule, MatSidenavModule, MatListModule, MatExpansionModule, MatDatepickerModule, MatNativeDateModule, MatSlideToggleModule, MatSnackBarModule, MatDialogModule, MatPaginatorModule, MatSortModule, MatChipsModule, MatTooltipModule, MatProgressSpinnerModule]
})
export class ProjectsComponent implements OnInit, OnDestroy {
  @ViewChild('dialogContent') dialogContent!: TemplateRef<unknown>;
  private dialogRef: MatDialogRef<unknown> | null = null;
  private routeSub: Subscription | null = null;
  // Reused by the Completed Projects page (route data): lists inactive
  // projects only and hides the Add button.
  inactiveOnly = false;
  pageTitle = 'Projects';
  projects: Project[] = [];
  dataSource = new MatTableDataSource<Project>([]);
  projectForm: FormGroup;
  searchForm: FormGroup;
  statusOptions = ['Planning', 'Active', 'Completed', 'On Hold', 'Cancelled'];
  farmTypes = ['Fish Farming', 'Poultry Farming'];
  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;
  isEditing = false;
  selectedProject: Project | null = null;
  isLoading = false;
  displayedColumns: string[] = ['projectCode', 'projectName', 'clientName', 'farmType', 'startDate', 'endDate', 'status', 'totalBudget', 'isActive', 'actions'];

  constructor(
    private fb: FormBuilder,
    private api: Api,
    private dialog: MatDialog,
    private snackBar: MatSnackBar,
    public auth: Auth,
    private route: ActivatedRoute
  ) {
    this.projectForm = this.fb.group({
      projectCode: ['', [Validators.required]],
      projectName: ['', [Validators.required]],
      description: [''],
      clientName: [''],
      farmType: [''],
      startDate: [''],
      endDate: [''],
      totalBudget: [0, [Validators.required, Validators.min(0)]],
      status: ['Planning', [Validators.required]]
    });
    this.searchForm = this.fb.group({
      searchText: [''],
      status: [''],
      farmType: ['']
    });
  }

  ngOnInit(): void {
    // Same component instance is reused when navigating between
    // /projects and /completed-projects, so react to route data changes.
    this.routeSub = this.route.data.subscribe(data => {
      this.inactiveOnly = !!data['inactiveOnly'];
      this.pageTitle = (data['title'] as string) || 'Projects';
      this.pageIndex = 0;
      this.loadProjects();
    });
  }

  ngOnDestroy(): void {
    this.routeSub?.unsubscribe();
    this.routeSub = null;
  }

  loadProjects(): void {
    this.isLoading = true;
    const searchText = ((this.searchForm.get('searchText')?.value ?? '') as string).trim();
    const status = (this.searchForm.get('status')?.value ?? '') as string;
    const farmType = (this.searchForm.get('farmType')?.value ?? '') as string;
    const request = this.inactiveOnly
      ? this.api.getInactiveProjectsPaged(
        searchText || undefined,
        status || undefined,
        farmType || undefined,
        { pageNumber: this.pageIndex + 1, pageSize: this.pageSize }
      )
      : this.api.getProjectsPaged(
        searchText || undefined,
        status || undefined,
        farmType || undefined,
        { pageNumber: this.pageIndex + 1, pageSize: this.pageSize }
      );
    request.subscribe({
      next: response => {
        if (response.success) {
          this.projects = response.data;
          this.dataSource.data = response.data;
          this.totalRecords = response.totalRecords ?? response.data.length;
        }
        this.isLoading = false;
      },
      error: () => {
        this.isLoading = false;
      }
    });
  }

  applySearch(): void {
    this.pageIndex = 0;
    this.loadProjects();
  }

  resetSearch(): void {
    this.searchForm.reset({ searchText: '', status: '', farmType: '' });
    this.pageIndex = 0;
    this.loadProjects();
  }

  onPage(event: { pageIndex: number; pageSize: number }): void {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.loadProjects();
  }

  openDialog(project?: Project): void {
    this.isEditing = !!project;
    this.selectedProject = project || null;

    if (project) {
      this.projectForm.patchValue({
        ...project,
        startDate: this.toDateObject(project.startDate),
        endDate: this.toDateObject(project.endDate)
      });
    } else {
      this.projectForm.reset();
      this.projectForm.patchValue({ status: 'Planning', totalBudget: 0 });
    }

    this.dialogRef = this.dialog.open(this.dialogContent, {
      width: '600px',
      maxHeight: '90vh'
    });
  }

  saveProject(): void {
    if (this.projectForm.invalid) {
      return;
    }

    const projectData = {
      ...this.projectForm.value,
      startDate: this.toApiDate(this.projectForm.value.startDate),
      endDate: this.toApiDate(this.projectForm.value.endDate)
    };

    if (this.isEditing && this.selectedProject) {
      this.api.updateProject(this.selectedProject.projectId, projectData).subscribe(response => {
        if (response.success) {
          this.loadProjects();
          this.closeDialog();
        }
      });
    } else {
      this.api.createProject(projectData).subscribe(response => {
        if (response.success) {
          this.loadProjects();
          this.closeDialog();
        }
      });
    }
  }

  closeDialog(): void {
    this.dialogRef?.close();
    this.dialogRef = null;
    this.projectForm.reset();
    this.isEditing = false;
    this.selectedProject = null;
  }

  toggleStatus(project: Project): void {
    if (project.isActive) {
      this.api.deactivateProject(project.projectId).subscribe(response => {
        if (response.success) {
          this.loadProjects();
        }
      });
    } else {
      this.api.activateProject(project.projectId).subscribe(response => {
        if (response.success) {
          this.loadProjects();
        }
      });
    }
  }

  deleteProject(project: Project): void {
    const ok = window.confirm(
      `Are you sure you want to delete project '${project.projectCode} - ${project.projectName}'?\n\nThe project will be deactivated (soft delete) so its historical budgets and expenses are preserved.`);
    if (!ok) return;
    this.api.deleteProject(project.projectId).subscribe({
      next: response => {
        this.snackBar.open(response.message || 'Project deleted successfully.', 'Close', { duration: 3000 });
        if (response.success) {
          // If the last row of a later page was deleted, step back a page.
          if (this.dataSource.data.length <= 1 && this.pageIndex > 0) {
            this.pageIndex--;
          }
          this.loadProjects();
        }
      },
      error: (err: { status?: number; error?: { message?: string } }) => {
        const message = err?.status === 403
          ? 'Access denied. You do not have Delete permission for Projects.'
          : (err?.error?.message || 'Failed to delete project. Please try again.');
        this.snackBar.open(message, 'Close', { duration: 4000 });
      }
    });
  }

  private toDateObject(value: string | null | undefined): Date | null {
    if (!value) {
      return null;
    }
    const parts = value.split('T')[0].split('-');
    if (parts.length !== 3) {
      return null;
    }
    return new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
  }

  private toApiDate(value: Date | string | null | undefined): string {
    if (!value) {
      return '';
    }
    if (typeof value === 'string') {
      return value.split('T')[0];
    }
    const month = String(value.getMonth() + 1).padStart(2, '0');
    const day = String(value.getDate()).padStart(2, '0');
    return `${value.getFullYear()}-${month}-${day}`;
  }

  formatCurrency(amount: number): string {    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 2
    }).format(amount);
  }

  isOverdue(project: Project): boolean {
    if (!project.endDate) {
      return false;
    }
    const parts = project.endDate.split('T')[0].split('-');
    if (parts.length !== 3) {
      return false;
    }
    const end = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return end < today;
  }

  exportToExcel(): void {
    // Export all rows matching the current search (server-side paging
    // returns max 100 per call, so fetch remaining pages when needed).
    const searchText = ((this.searchForm.get('searchText')?.value ?? '') as string).trim();
    const status = (this.searchForm.get('status')?.value ?? '') as string;
    const farmType = (this.searchForm.get('farmType')?.value ?? '') as string;
    const fetch = (page: number) => this.inactiveOnly
      ? this.api.getInactiveProjectsPaged(
        searchText || undefined, status || undefined, farmType || undefined, { pageNumber: page, pageSize: 100 })
      : this.api.getProjectsPaged(
        searchText || undefined, status || undefined, farmType || undefined, { pageNumber: page, pageSize: 100 });
    fetch(1).pipe(
      switchMap(first => {
        if (!first.success) return of<Project[]>([]);
        const total = first.totalRecords ?? first.data.length;
        const pages = Math.ceil(total / 100);
        if (pages <= 1) return of(first.data);
        const rest = [];
        for (let p = 2; p <= pages; p++) rest.push(fetch(p));
        return forkJoin(rest).pipe(
          switchMap(results => of([...first.data, ...results.flatMap(r => r.success ? r.data : [])]))
        );
      })
    ).subscribe(all => {
      if (all.length === 0) return;
      this.writeExcel(all);
    });
  }

  private writeExcel(rows: Project[]): void {
    import('xlsx').then(xlsx => {
      const sheet = rows.map(p => ({
        'Project Code': p.projectCode,
        'Project Name': p.projectName,
        'Description': p.description ?? '',
        'Client Name': p.clientName ?? '',
        'Farm Type': p.farmType ?? '',
        'Start Date': (p.startDate || '').split('T')[0],
        'End Date': (p.endDate || '').split('T')[0],
        'Total Budget': Number(p.totalBudget) || 0,
        'Status': p.status,
        'Active': p.isActive ? 'Yes' : 'No'
      }));
      const ws = xlsx.utils.json_to_sheet(sheet);
      const wb = xlsx.utils.book_new();
      const filePrefix = this.inactiveOnly ? 'Completed_Projects' : 'Projects';
      xlsx.utils.book_append_sheet(wb, ws, this.inactiveOnly ? 'Completed Projects' : 'Projects');
      xlsx.writeFile(wb, `${filePrefix}_${new Date().toISOString().split('T')[0]}.xlsx`);
    });
  }
}


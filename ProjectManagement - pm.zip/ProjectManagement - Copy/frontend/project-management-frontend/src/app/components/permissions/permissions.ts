import { Component, ChangeDetectorRef, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { startWith } from 'rxjs';
import { Api } from '../../services/api';
import { User, PagePermission } from '../../models/models';
type PermField = 'canView' | 'canEdit' | 'canDelete' | 'canExport';import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialogModule } from '@angular/material/dialog';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatChipsModule } from '@angular/material/chips';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@Component({
  selector: 'app-permissions',
  templateUrl: './permissions.html',
  styleUrls: ['./permissions.scss'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, RouterModule, MatCardModule, MatTableModule, MatFormFieldModule, MatInputModule, MatAutocompleteModule, MatSelectModule, MatButtonModule, MatCheckboxModule, MatIconModule, MatToolbarModule, MatSidenavModule, MatListModule, MatExpansionModule, MatDatepickerModule, MatNativeDateModule, MatSlideToggleModule, MatSnackBarModule, MatDialogModule, MatPaginatorModule, MatSortModule, MatChipsModule, MatTooltipModule, MatProgressSpinnerModule]
})
export class PermissionsComponent implements OnInit {
  users: User[] = [];
  permissions: PagePermission[] = [];
  permissionsDataSource = new MatTableDataSource<PagePermission>([]);
  selectedUser: User | null = null;
  isLoading = false;
  isUsersLoading = false;
  usersError = '';
  permissionsError = '';
  userSearch = new FormControl<string>('');
  filteredUsers: User[] = [];
  displayedColumns: string[] = ['pageName', 'canView', 'canEdit', 'canDelete', 'canExport'];

  constructor(
    private fb: FormBuilder,
    private api: Api,
    private snackBar: MatSnackBar,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.userSearch.valueChanges.pipe(startWith('')).subscribe(value => {
      this.applyUserFilter(value ?? '');
    });
    this.loadUsers();
  }

  loadUsers(): void {
    this.isUsersLoading = true;
    this.usersError = '';
    this.api.getUsers().subscribe({
      next: response => {
        if (response.success) {
          this.users = (response.data ?? []).filter(u => u.isActive);
          this.applyUserFilter(this.userSearch.value ?? '');
        } else {
          this.usersError = response.message || 'Failed to load users.';
        }
        this.isUsersLoading = false;
        this.cdr.markForCheck();
      },
      error: (err: { status?: number; error?: { message?: string } }) => {
        this.isUsersLoading = false;
        this.usersError = err?.status === 401
          ? 'Session expired. Please log out and log in again.'
          : (err?.error?.message || 'Failed to load users. Please retry.');
        this.cdr.markForCheck();
      }
    });
  }

  retryLoadUsers(): void {
    this.loadUsers();
  }

  retryLoadPermissions(): void {
    if (this.selectedUser) {
      this.loadPermissions(this.selectedUser.userId);
    }
  }

  loadPermissions(userId: number): void {
    this.isLoading = true;
    this.permissionsError = '';
    // Clear stale rows immediately so a re-selected user never flashes old data.
    this.permissions = [];
    this.permissionsDataSource.data = [];
    if (this.isSuperAdmin(this.selectedUser)) {
      // Super Admin always has full access; permissions cannot be edited.
      this.api.getPages().subscribe({
        next: response => {
          if (response.success) {
            this.permissions = (response.data ?? []).map(p => ({
              pageId: p.pageId,
              pageName: p.pageName,
              canView: true,
              canEdit: true,
              canDelete: true,
              canExport: true
            }));
            this.permissionsDataSource.data = this.permissions;
          } else {
            this.permissionsError = response.message || 'Failed to load pages.';
          }
          this.isLoading = false;
          this.cdr.markForCheck();
        },
        error: (err: { status?: number; error?: { message?: string } }) => {
          this.isLoading = false;
          this.permissionsError = err?.error?.message || 'Failed to load pages. Please retry.';
          this.cdr.markForCheck();
        }
      });
      return;
    }
    this.api.getUserPermissions(userId).subscribe({
      next: response => {
        if (response.success) {
          this.permissions = response.data ?? [];
          this.permissionsDataSource.data = this.permissions;
        } else {
          this.permissionsError = response.message || 'Failed to load permissions.';
        }
        this.isLoading = false;
        this.cdr.markForCheck();
      },
      error: (err: { status?: number; error?: { message?: string } }) => {
        this.isLoading = false;
        this.permissionsError = err?.error?.message || 'Failed to load permissions. Please retry.';
        this.cdr.markForCheck();
      }
    });
  }

  onUserSelect(user: User): void {
    this.selectedUser = user;
    this.loadPermissions(user.userId);
  }

  applyUserFilter(searchText: string): void {
    const term = (searchText ?? '').trim().toLowerCase();
    this.filteredUsers = term
      ? this.users.filter(u => (u.username || '').toLowerCase().includes(term))
      : [...this.users];
    this.cdr.markForCheck();
  }

  displayUsername(user: User | null): string {
    return user?.username ?? '';
  }

  isSuperAdmin(user: User | null): boolean {
    return !!user && user.roleName === 'Super Admin';
  }

  allChecked(field: PermField): boolean {
    return this.permissions.length > 0 && this.permissions.every(p => p[field]);
  }

  isIndeterminate(field: PermField): boolean {
    const checked = this.permissions.filter(p => p[field]).length;
    return checked > 0 && checked < this.permissions.length;
  }

  toggleAll(field: PermField, checked: boolean): void {
    if (!this.selectedUser || this.isSuperAdmin(this.selectedUser) || this.permissions.length === 0) return;
    this.permissions.forEach(p => { p[field] = checked; });
    this.permissionsDataSource.data = [...this.permissions];
    this.api.saveUserPermissionsBulk(
      this.selectedUser.userId,
      this.permissions.map(p => ({
        userId: this.selectedUser!.userId,
        pageId: p.pageId,
        canView: p.canView,
        canEdit: p.canEdit,
        canDelete: p.canDelete,
        canExport: p.canExport
      }))
    ).subscribe({
      next: response => {
        this.snackBar.open(
          response.success ? 'Permissions saved successfully.' : (response.message || 'Failed to save permissions.'),
          'Close', { duration: response.success ? 2500 : 4000 });
        if (!response.success) this.loadPermissions(this.selectedUser!.userId);
      },
      error: (err: { error?: { message?: string } }) => {
        this.snackBar.open(err?.error?.message || 'Failed to save permissions.', 'Close', { duration: 4000 });
        this.loadPermissions(this.selectedUser!.userId);
      }
    });
  }

  savePermission(permission: PagePermission): void {
    if (!this.selectedUser || this.isSuperAdmin(this.selectedUser)) return;

    this.api.saveUserPermission({
      userId: this.selectedUser.userId,
      pageId: permission.pageId,
      canView: permission.canView,
      canEdit: permission.canEdit,
      canDelete: permission.canDelete,
      canExport: permission.canExport
    }).subscribe({
      next: response => {
        if (response.success) {
          this.snackBar.open('Permission saved successfully.', 'Close', { duration: 2500 });
        } else {
          this.snackBar.open(response.message || 'Failed to save permission.', 'Close', { duration: 4000 });
          // Revert the toggled value since the save failed.
          this.loadPermissions(this.selectedUser!.userId);
        }
      },
      error: (err: { status?: number; error?: { message?: string } }) => {
        this.snackBar.open(err?.error?.message || 'Failed to save permission.', 'Close', { duration: 4000 });
        this.loadPermissions(this.selectedUser!.userId);
      }
    });
  }
}


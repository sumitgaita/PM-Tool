import { Component, ChangeDetectorRef, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Api } from '../../services/api';
import { DashboardSummary, Project, BudgetCode } from '../../models/models';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialogModule } from '@angular/material/dialog';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { BaseChartDirective } from 'ng2-charts';
import { MatChipsModule } from '@angular/material/chips';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.html',
  styleUrls: ['./dashboard.scss'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, RouterModule, MatCardModule, MatTableModule, MatFormFieldModule, MatInputModule, MatSelectModule, MatButtonModule, MatIconModule, MatToolbarModule, MatSidenavModule, MatListModule, MatExpansionModule, MatDatepickerModule, MatNativeDateModule, MatSlideToggleModule, MatSnackBarModule, MatDialogModule, MatPaginatorModule, MatSortModule, MatChipsModule, MatTooltipModule, MatProgressSpinnerModule, BaseChartDirective]
})
export class DashboardComponent implements OnInit {
  filterForm: FormGroup;
  summary: DashboardSummary | null = null;
  projects: Project[] = [];
  budgetCodes: BudgetCode[] = [];
  projectWiseData: any[] = [];
  monthlyData: any[] = [];
  budgetCodeWiseData: any[] = [];
  resourceWiseData: any[] = [];
  farmTypes = ['Fish Farming', 'Poultry Farming'];
  farmSummary: any = null;
  fishKpis: any = null;
  poultryKpis: any = null;
  farmMonthly: any[] = [];
  fishTypeWise: any[] = [];
  fishPondWise: any[] = [];
  poultryBatchWise: any[] = [];
  eggSeries: any[] = [];
  isLoading = false;

  constructor(
    private fb: FormBuilder,
    private api: Api,
    private cdr: ChangeDetectorRef
  ) {
    this.filterForm = this.fb.group({
      projectId: [''],
      budgetCodeId: [''],
      farmType: [''],
      fromDate: [''],
      toDate: ['']
    });
  }

  ngOnInit(): void {
    this.loadProjects();
    this.loadBudgetCodes();
    this.loadDashboardData();
  }

  loadProjects(): void {
    this.api.getProjects().subscribe({
      next: response => {
        if (response.success) {
          this.projects = response.data.filter(p => p.isActive);
        }
        this.cdr.markForCheck();
      },
      error: () => this.cdr.markForCheck()
    });
  }

  loadBudgetCodes(): void {
    this.api.getBudgetCodes().subscribe({
      next: response => {
        if (response.success) {
          this.budgetCodes = response.data.filter(b => b.isActive);
        }
        this.cdr.markForCheck();
      },
      error: () => this.cdr.markForCheck()
    });
  }

  loadDashboardData(): void {
    this.isLoading = true;
    const filters = this.filterForm.value;
    const fromDate = this.toApiDate(filters.fromDate);
    const toDate = this.toApiDate(filters.toDate);

    this.api.getDashboardSummary(
      filters.projectId || undefined,
      filters.budgetCodeId || undefined,
      fromDate,
      toDate
    ).subscribe({
      next: response => {
        if (response.success) {
          this.summary = (Array.isArray((response as any).data) ? (response as any).data[0] : (response as any).data);
        }
        this.isLoading = false;
        this.cdr.markForCheck();
      },
      error: () => {
        this.isLoading = false;
        this.cdr.markForCheck();
      }
    });

    this.api.getDashboardProjectWise(fromDate, toDate)
      .subscribe({
        next: response => {
          if (response.success) {
            this.projectWiseData = response.data;
          }
          this.cdr.markForCheck();
        },
        error: () => this.cdr.markForCheck()
      });

    this.api.getDashboardMonthly(fromDate, toDate)
      .subscribe({
        next: response => {
          if (response.success) {
            this.monthlyData = response.data;
          }
          this.cdr.markForCheck();
        },
        error: () => this.cdr.markForCheck()
      });

    this.api.getDashboardBudgetCodeWise(fromDate, toDate)
      .subscribe({
        next: response => {
          if (response.success) {
            this.budgetCodeWiseData = response.data;
          }
          this.cdr.markForCheck();
        },
        error: () => this.cdr.markForCheck()
      });

    this.api.getDashboardResourceWise(fromDate, toDate)
      .subscribe({
        next: response => {
          if (response.success) {
            this.resourceWiseData = response.data;
          }
          this.cdr.markForCheck();
        },
        error: () => this.cdr.markForCheck()
      });

    this.loadFarmData(filters.projectId || undefined, filters.farmType || undefined, fromDate, toDate);
  }

  get showFish(): boolean {
    const t = this.filterForm.get('farmType')?.value;
    return !t || t === 'Fish Farming';
  }

  get showPoultry(): boolean {
    const t = this.filterForm.get('farmType')?.value;
    return !t || t === 'Poultry Farming';
  }

  get farmProfit(): number {
    if (!this.farmSummary) return 0;
    return (Number(this.farmSummary.totalRevenue) || 0) - (Number(this.farmSummary.totalExpense) || 0);
  }

  private loadFarmData(projectId?: number, farmType?: string, fromDate?: string, toDate?: string): void {
    this.api.getFarmDashboardSummary(projectId, farmType, fromDate, toDate).subscribe({
      next: r => { if (r.success) this.farmSummary = r.data; this.cdr.markForCheck(); },
      error: () => this.cdr.markForCheck()
    });
    this.api.getFarmDashboardMonthly(projectId, farmType, fromDate, toDate).subscribe({
      next: r => { if (r.success) this.farmMonthly = r.data; this.cdr.markForCheck(); },
      error: () => this.cdr.markForCheck()
    });
    if (!farmType || farmType === 'Fish Farming') {
      this.api.getFishDashboardKpis(projectId, fromDate, toDate).subscribe({
        next: r => { if (r.success) this.fishKpis = r.data; this.cdr.markForCheck(); },
        error: () => this.cdr.markForCheck()
      });
      this.api.getFishTypeWise(projectId).subscribe({
        next: r => { if (r.success) this.fishTypeWise = r.data; this.cdr.markForCheck(); },
        error: () => this.cdr.markForCheck()
      });
      this.api.getFishPondWise(projectId).subscribe({
        next: r => { if (r.success) this.fishPondWise = r.data; this.cdr.markForCheck(); },
        error: () => this.cdr.markForCheck()
      });
    }
    if (!farmType || farmType === 'Poultry Farming') {
      this.api.getPoultryDashboardKpis(projectId, fromDate, toDate).subscribe({
        next: r => { if (r.success) this.poultryKpis = r.data; this.cdr.markForCheck(); },
        error: () => this.cdr.markForCheck()
      });
      this.api.getPoultryBatchWise(projectId).subscribe({
        next: r => { if (r.success) this.poultryBatchWise = r.data; this.cdr.markForCheck(); },
        error: () => this.cdr.markForCheck()
      });
      this.api.getEggSeries(projectId, fromDate, toDate).subscribe({
        next: r => { if (r.success) this.eggSeries = r.data; this.cdr.markForCheck(); },
        error: () => this.cdr.markForCheck()
      });
    }
  }

  applyFilters(): void {
    this.loadDashboardData();
  }

  resetFilters(): void {
    this.filterForm.reset();
    this.loadDashboardData();
  }

  setQuickRange(range: 'month' | 'last3' | 'last6' | 'year'): void {
    const now = new Date();
    let from: Date;
    const to = now;
    if (range === 'month') {
      from = new Date(now.getFullYear(), now.getMonth(), 1);
    } else if (range === 'last3') {
      from = new Date(now.getFullYear(), now.getMonth() - 2, 1);
    } else if (range === 'last6') {
      from = new Date(now.getFullYear(), now.getMonth() - 5, 1);
    } else {
      from = new Date(now.getFullYear(), 0, 1);
    }
    this.filterForm.patchValue({
      fromDate: from,
      toDate: to
    });
    this.loadDashboardData();
  }

  get utilization(): number {
    if (!this.summary || !this.summary.totalBudget) {
      return 0;
    }
    return (this.summary.totalExpense / this.summary.totalBudget) * 100;
  }

  private toISODate(d: Date): string {
    const m = ('0' + (d.getMonth() + 1)).slice(-2);
    const day = ('0' + d.getDate()).slice(-2);
    return `${d.getFullYear()}-${m}-${day}`;
  }

  private toApiDate(value: Date | string | null | undefined): string | undefined {
    if (!value) {
      return undefined;
    }
    if (typeof value === 'string') {
      return value.split('T')[0];
    }
    return this.toISODate(value);
  }

  formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 2
    }).format(amount);
  }
}


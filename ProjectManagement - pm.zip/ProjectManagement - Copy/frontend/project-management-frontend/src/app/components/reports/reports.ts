import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Api } from '../../services/api';
import { Auth } from '../../services/auth';
import { Project, BudgetCode, Resource } from '../../models/models';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialogModule } from '@angular/material/dialog';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatChipsModule } from '@angular/material/chips';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@Component({
  selector: 'app-reports',
  templateUrl: './reports.html',
  styleUrls: ['./reports.scss'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, RouterModule, MatCardModule, MatTableModule, MatFormFieldModule, MatInputModule, MatSelectModule, MatButtonModule, MatIconModule, MatToolbarModule, MatSidenavModule, MatListModule, MatExpansionModule, MatDatepickerModule, MatNativeDateModule, MatSlideToggleModule, MatSnackBarModule, MatDialogModule, MatPaginatorModule, MatSortModule, MatChipsModule, MatTooltipModule, MatProgressSpinnerModule]
})
export class ReportsComponent implements OnInit {
  filterForm: FormGroup;
  projects: Project[] = [];
  budgetCodes: BudgetCode[] = [];
  resources: Resource[] = [];
  reportData: any[] = [];
  reportDataSource = new MatTableDataSource<any>([]);
  isLoading = false;
  reportType = 'project-wise';
  displayedColumns: string[] = [];

  constructor(
    private fb: FormBuilder,
    private api: Api,
    public auth: Auth
  ) {
    this.filterForm = this.fb.group({
      projectId: [''],
      budgetCodeId: [''],
      resourceId: [''],
      fromDate: [''],
      toDate: [''],
      expenseDate: ['']
    });
  }

  ngOnInit(): void {
    this.loadProjects();
    this.loadBudgetCodes();
    this.loadResources();
  }

  loadProjects(): void {
    this.api.getProjects().subscribe(response => {
      if (response.success) {
        this.projects = response.data.filter(p => p.isActive);
      }
    });
  }

  loadBudgetCodes(): void {
    this.api.getBudgetCodes().subscribe(response => {
      if (response.success) {
        this.budgetCodes = response.data.filter(b => b.isActive);
      }
    });
  }

  loadResources(): void {
    this.api.getResources().subscribe(response => {
      if (response.success) {
        this.resources = response.data.filter(r => r.isActive);
      }
    });
  }

  generateReport(): void {
    this.isLoading = true;
    const filters = this.filterForm.value;

    switch (this.reportType) {
      case 'project-wise':
        this.displayedColumns = ['projectCode', 'projectName', 'budgetCode', 'budgetCodeName', 'resourceCode', 'resourceName', 'budget', 'expense', 'variance', 'utilizationPercent'];
        this.api.getProjectWiseReport(
          filters.projectId || undefined,
          this.toApiDate(filters.fromDate),
          this.toApiDate(filters.toDate),
          filters.budgetCodeId || undefined,
          filters.resourceId || undefined
        ).subscribe(response => {
          if (response.success) {
            this.reportData = response.data;
            this.reportDataSource.data = response.data;
          }
          this.isLoading = false;
        });
        break;

      case 'date-wise':
        this.displayedColumns = ['expenseDate', 'projectCode', 'projectName', 'budgetCode', 'budgetCodeName', 'resourceCode', 'resourceName', 'amount', 'description', 'remarks'];
        this.api.getDateWiseReport(this.toApiDate(filters.expenseDate) || new Date().toISOString().split('T')[0])
          .subscribe(response => {
            if (response.success) {
              this.reportData = response.data;
              this.reportDataSource.data = response.data;
            }
            this.isLoading = false;
          });
        break;

      case 'date-range':
        this.displayedColumns = ['expenseDate', 'projectCode', 'projectName', 'budgetCode', 'budgetCodeName', 'resourceCode', 'resourceName', 'amount', 'description', 'referenceNo', 'remarks'];
        this.api.getDateRangeReport(
          this.toApiDate(filters.fromDate) || new Date().toISOString().split('T')[0],
          this.toApiDate(filters.toDate) || new Date().toISOString().split('T')[0],
          filters.projectId || undefined,
          filters.budgetCodeId || undefined,
          filters.resourceId || undefined
        ).subscribe(response => {
          if (response.success) {
            this.reportData = response.data;
            this.reportDataSource.data = response.data;
          }
          this.isLoading = false;
        });
        break;
    }
  }

  private toApiDate(value: Date | string | null | undefined): string | undefined {
    if (!value) {
      return undefined;
    }
    if (typeof value === 'string') {
      return value.split('T')[0];
    }
    const month = String(value.getMonth() + 1).padStart(2, '0');
    const day = String(value.getDate()).padStart(2, '0');
    return `${value.getFullYear()}-${month}-${day}`;
  }

  resetFilters(): void {
    this.filterForm.reset();
    this.reportData = [];
    this.reportDataSource.data = [];
  }

  exportToExcel(): void {
    import('xlsx').then(xlsx => {
      const ws = xlsx.utils.json_to_sheet(this.reportData);
      const wb = xlsx.utils.book_new();
      xlsx.utils.book_append_sheet(wb, ws, 'Report');
      xlsx.writeFile(wb, `Report_${new Date().toISOString().split('T')[0]}.xlsx`);
    });
  }

  formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 2
    }).format(amount);
  }
}


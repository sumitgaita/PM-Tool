import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { forkJoin, of } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { Api } from '../../services/api';
import { Auth } from '../../services/auth';
import { Resource } from '../../models/models';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialogModule, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatChipsModule } from '@angular/material/chips';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@Component({
  selector: 'app-resources',
  templateUrl: './resources.html',
  styleUrls: ['./resources.scss'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, RouterModule, MatCardModule, MatTableModule, MatFormFieldModule, MatInputModule, MatSelectModule, MatButtonModule, MatIconModule, MatToolbarModule, MatSidenavModule, MatListModule, MatExpansionModule, MatDatepickerModule, MatNativeDateModule, MatSlideToggleModule, MatSnackBarModule, MatDialogModule, MatPaginatorModule, MatSortModule, MatChipsModule, MatTooltipModule, MatProgressSpinnerModule]
})
export class ResourcesComponent implements OnInit {
  @ViewChild('dialogContent') dialogContent!: TemplateRef<unknown>;
  private dialogRef: MatDialogRef<unknown> | null = null;
  resources: Resource[] = [];
  resourcesDataSource = new MatTableDataSource<Resource>([]);
  resourceForm: FormGroup;
  searchForm: FormGroup;
  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;
  isEditing = false;
  selectedResource: Resource | null = null;
  isLoading = false;
  displayedColumns: string[] = ['resourceCode', 'resourceName', 'resourceType', 'email', 'department', 'isActive', 'actions'];

  constructor(
    private fb: FormBuilder,
    private api: Api,
    private dialog: MatDialog,
    private snackBar: MatSnackBar,
    public auth: Auth
  ) {
    this.resourceForm = this.fb.group({
      resourceCode: ['', [Validators.required]],
      resourceName: ['', [Validators.required]],
      resourceType: ['Employee', [Validators.required]],
      email: [''],
      phone: [''],
      department: ['']
    });
    this.searchForm = this.fb.group({
      searchText: ['']
    });
  }

  ngOnInit(): void {
    this.loadResources();
  }

  loadResources(): void {
    this.isLoading = true;
    const searchText = ((this.searchForm.get('searchText')?.value ?? '') as string).trim();
    this.api.getResourcesPaged(
      searchText || undefined,
      { pageNumber: this.pageIndex + 1, pageSize: this.pageSize }
    ).subscribe({
      next: response => {
        if (response.success) {
          this.resources = response.data;
          this.resourcesDataSource.data = response.data;
          this.totalRecords = response.totalRecords ?? response.data.length;
        }
        this.isLoading = false;
      },
      error: () => {
        this.isLoading = false;
      }
    });
  }

  applySearch(): void {
    this.pageIndex = 0;
    this.loadResources();
  }

  resetSearch(): void {
    this.searchForm.reset({ searchText: '' });
    this.pageIndex = 0;
    this.loadResources();
  }

  onPage(event: { pageIndex: number; pageSize: number }): void {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.loadResources();
  }

  openDialog(resource?: Resource): void {
    this.isEditing = !!resource;
    this.selectedResource = resource || null;

    if (resource) {
      this.resourceForm.patchValue(resource);
    } else {
      this.resourceForm.reset();
      this.resourceForm.patchValue({ resourceType: 'Employee' });
    }

    this.dialogRef = this.dialog.open(this.dialogContent, {
      width: '600px',
      maxHeight: '90vh'
    });
  }

  saveResource(): void {
    if (this.resourceForm.invalid) {
      return;
    }

    const resourceData = this.resourceForm.value;

    if (this.isEditing && this.selectedResource) {
      this.api.updateResource(this.selectedResource.resourceId, resourceData).subscribe(response => {
        if (response.success) {
          this.loadResources();
          this.closeDialog();
        }
      });
    } else {
      this.api.createResource(resourceData).subscribe(response => {
        if (response.success) {
          this.loadResources();
          this.closeDialog();
        }
      });
    }
  }

  closeDialog(): void {
    this.dialogRef?.close();
    this.dialogRef = null;
    this.resourceForm.reset();
    this.isEditing = false;
    this.selectedResource = null;
  }

  exportToExcel(): void {
    // Export all rows matching the current search (server-side paging
    // returns max 100 per call, so fetch remaining pages when needed).
    const searchText = ((this.searchForm.get('searchText')?.value ?? '') as string).trim();
    const fetch = (page: number) => this.api.getResourcesPaged(
      searchText || undefined, { pageNumber: page, pageSize: 100 });
    fetch(1).pipe(
      switchMap(first => {
        if (!first.success) return of<Resource[]>([]);
        const total = first.totalRecords ?? first.data.length;
        const pages = Math.ceil(total / 100);
        if (pages <= 1) return of(first.data);
        const rest = [];
        for (let p = 2; p <= pages; p++) rest.push(fetch(p));
        return forkJoin(rest).pipe(
          switchMap(results => of([...first.data, ...results.flatMap(r => r.success ? r.data : [])]))
        );
      })
    ).subscribe(all => {
      if (all.length === 0) return;
      this.writeExcel(all);
    });
  }

  private writeExcel(rows: Resource[]): void {
    import('xlsx').then(xlsx => {
      const sheet = rows.map(r => ({
        'Resource Code': r.resourceCode,
        'Resource Name': r.resourceName,
        'Resource Type': r.resourceType,
        'Email': r.email ?? '',
        'Phone': r.phone ?? '',
        'Department': r.department ?? '',
        'Active': r.isActive ? 'Yes' : 'No'
      }));
      const ws = xlsx.utils.json_to_sheet(sheet);
      const wb = xlsx.utils.book_new();
      xlsx.utils.book_append_sheet(wb, ws, 'Resources');
      xlsx.writeFile(wb, `Resources_${new Date().toISOString().split('T')[0]}.xlsx`);
    });
  }

  toggleStatus(resource: Resource): void {
    if (resource.isActive) {
      this.api.deactivateResource(resource.resourceId).subscribe(response => {
        if (response.success) {
          this.loadResources();
        }
      });
    } else {
      this.api.activateResource(resource.resourceId).subscribe(response => {
        if (response.success) {
          this.loadResources();
        }
      });
    }
  }

  deleteResource(resource: Resource): void {
    const ok = window.confirm(
      `Are you sure you want to delete resource '${resource.resourceCode} - ${resource.resourceName}'?\n\nThe resource will be deactivated (soft delete) so its historical expense records are preserved.`);
    if (!ok) return;
    this.api.deleteResource(resource.resourceId).subscribe({
      next: response => {
        this.snackBar.open(response.message || 'Resource deleted successfully.', 'Close', { duration: 3000 });
        if (response.success) {
          // If the last row of a later page was deleted, step back a page.
          if (this.resourcesDataSource.data.length <= 1 && this.pageIndex > 0) {
            this.pageIndex--;
          }
          this.loadResources();
        }
      },
      error: (err: { status?: number; error?: { message?: string } }) => {
        const message = err?.status === 403
          ? 'Access denied. You do not have Delete permission for Resources.'
          : (err?.error?.message || 'Failed to delete resource. Please try again.');
        this.snackBar.open(message, 'Close', { duration: 4000 });
      }
    });
  }
}


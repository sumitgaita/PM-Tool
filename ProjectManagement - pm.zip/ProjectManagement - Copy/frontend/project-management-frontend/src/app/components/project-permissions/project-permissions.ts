import { Component, ChangeDetectorRef, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { startWith } from 'rxjs';
import { Api } from '../../services/api';
import { User, UserProject } from '../../models/models';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialogModule } from '@angular/material/dialog';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatChipsModule } from '@angular/material/chips';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@Component({
  selector: 'app-project-permissions',
  templateUrl: './project-permissions.html',
  styleUrls: ['./project-permissions.scss'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, RouterModule, MatCardModule, MatTableModule, MatFormFieldModule, MatInputModule, MatAutocompleteModule, MatSelectModule, MatButtonModule, MatCheckboxModule, MatIconModule, MatToolbarModule, MatSidenavModule, MatListModule, MatExpansionModule, MatDatepickerModule, MatNativeDateModule, MatSlideToggleModule, MatSnackBarModule, MatDialogModule, MatPaginatorModule, MatSortModule, MatChipsModule, MatTooltipModule, MatProgressSpinnerModule]
})
export class ProjectPermissionsComponent implements OnInit {
  users: User[] = [];
  projects: UserProject[] = [];
  projectsDataSource = new MatTableDataSource<UserProject>([]);
  selectedUser: User | null = null;
  targetIsSuperAdmin = false;
  isLoading = false;
  isUsersLoading = false;
  isSaving = false;
  usersError = '';
  projectsError = '';
  userSearch = new FormControl<string>('');
  filteredUsers: User[] = [];
  displayedColumns: string[] = ['isAssigned', 'projectCode', 'projectName', 'status'];

  constructor(
    private api: Api,
    private snackBar: MatSnackBar,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.userSearch.valueChanges.pipe(startWith('')).subscribe(value => {
      this.applyUserFilter(value ?? '');
    });
    this.loadUsers();
  }

  loadUsers(): void {
    this.isUsersLoading = true;
    this.usersError = '';
    this.api.getUsers().subscribe({
      next: response => {
        if (response.success) {
          // Only Admin and Normal User accounts can be assigned projects.
          // Super Admin implicitly accesses every project.
          this.users = (response.data ?? []).filter(u => u.isActive && u.roleName !== 'Super Admin');
          this.applyUserFilter(this.userSearch.value ?? '');
        } else {
          this.usersError = response.message || 'Failed to load users.';
        }
        this.isUsersLoading = false;
        this.cdr.markForCheck();
      },
      error: (err: { status?: number; error?: { message?: string } }) => {
        this.isUsersLoading = false;
        this.usersError = err?.status === 401
          ? 'Session expired. Please log out and log in again.'
          : (err?.error?.message || 'Failed to load users. Please retry.');
        this.cdr.markForCheck();
      }
    });
  }

  retryLoadUsers(): void {
    this.loadUsers();
  }

  retryLoadProjects(): void {
    if (this.selectedUser) {
      this.loadProjects(this.selectedUser.userId);
    }
  }

  loadProjects(userId: number): void {
    this.isLoading = true;
    this.projectsError = '';
    // Clear stale rows immediately so a re-selected user never flashes old data.
    this.projects = [];
    this.projectsDataSource.data = [];
    this.targetIsSuperAdmin = false;
    this.api.getUserProjects(userId).subscribe({
      next: response => {
        if (response.success) {
          this.projects = (response.data ?? []).map(p => ({ ...p, isAssigned: !!p.isAssigned }));
          this.projectsDataSource.data = this.projects;
          this.targetIsSuperAdmin = !!response.isSuperAdmin;
        } else {
          this.projectsError = response.message || 'Failed to load projects.';
        }
        this.isLoading = false;
        this.cdr.markForCheck();
      },
      error: (err: { status?: number; error?: { message?: string } }) => {
        this.isLoading = false;
        this.projectsError = err?.error?.message || 'Failed to load projects. Please retry.';
        this.cdr.markForCheck();
      }
    });
  }

  onUserSelect(user: User): void {
    this.selectedUser = user;
    this.loadProjects(user.userId);
  }

  applyUserFilter(searchText: string): void {
    const term = (searchText ?? '').trim().toLowerCase();
    this.filteredUsers = term
      ? this.users.filter(u => (u.username || '').toLowerCase().includes(term)
        || (u.fullName || '').toLowerCase().includes(term))
      : [...this.users];
    this.cdr.markForCheck();
  }

  displayUsername(user: User | null): string {
    return user?.username ?? '';
  }

  get assignedCount(): number {
    return this.projects.filter(p => p.isAssigned).length;
  }

  allChecked(): boolean {
    return this.projects.length > 0 && this.projects.every(p => p.isAssigned);
  }

  isIndeterminate(): boolean {
    const checked = this.projects.filter(p => p.isAssigned).length;
    return checked > 0 && checked < this.projects.length;
  }

  toggleAll(checked: boolean): void {
    if (!this.selectedUser || this.targetIsSuperAdmin || this.projects.length === 0) return;
    this.projects.forEach(p => { p.isAssigned = checked; });
    this.projectsDataSource.data = [...this.projects];
  }

  save(): void {
    if (!this.selectedUser || this.targetIsSuperAdmin || this.isSaving) return;
    this.isSaving = true;
    const projectIds = this.projects.filter(p => p.isAssigned).map(p => p.projectId);
    this.api.saveUserProjectsBulk(this.selectedUser.userId, projectIds).subscribe({
      next: response => {
        this.isSaving = false;
        this.snackBar.open(
          response.success ? 'Project permissions saved successfully.' : (response.message || 'Failed to save project permissions.'),
          'Close', { duration: response.success ? 2500 : 4000 });
        if (response.success) {
          this.loadProjects(this.selectedUser!.userId);
        }
        this.cdr.markForCheck();
      },
      error: (err: { error?: { message?: string } }) => {
        this.isSaving = false;
        this.snackBar.open(err?.error?.message || 'Failed to save project permissions.', 'Close', { duration: 4000 });
        this.cdr.markForCheck();
      }
    });
  }
}

import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { Api } from '../../services/api';
import { Auth } from '../../services/auth';
import { DatabaseBackupFile } from '../../models/models';

@Component({
  selector: 'app-database-backup',
  templateUrl: './database-backup.html',
  styleUrls: ['./database-backup.scss'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, RouterModule, MatCardModule, MatTableModule, MatButtonModule, MatIconModule, MatTooltipModule, MatProgressSpinnerModule, MatSnackBarModule]
})
export class DatabaseBackupComponent implements OnInit {
  backupsDataSource = new MatTableDataSource<DatabaseBackupFile>([]);
  displayedColumns: string[] = ['fileName', 'sizeBytes', 'createdDate', 'actions'];
  isLoading = false;
  isRestoring = false;
  errorMessage = '';
  successMessage = '';

  constructor(
    private api: Api,
    public auth: Auth,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    this.loadBackups();
  }

  loadBackups(): void {
    this.isLoading = true;
    this.errorMessage = '';
    this.api.getDatabaseBackups().subscribe({
      next: (response) => {
        this.isLoading = false;
        if (response.success) {
          this.backupsDataSource.data = response.data ?? [];
        } else {
          this.errorMessage = response.message || 'Unable to load database backups.';
        }
      },
      error: (error) => {
        this.isLoading = false;
        this.errorMessage = error.error?.message || 'Unable to load database backups. Please try again.';
      }
    });
  }

  formatSize(bytes: number): string {
    if (!bytes || bytes <= 0) return '0 B';
    const units = ['B', 'KB', 'MB', 'GB'];
    let size = bytes;
    let unit = 0;
    while (size >= 1024 && unit < units.length - 1) {
      size /= 1024;
      unit++;
    }
    return `${size.toFixed(unit === 0 ? 0 : 2)} ${units[unit]}`;
  }

  downloadBackup(file: DatabaseBackupFile): void {
    this.errorMessage = '';
    this.successMessage = '';
    this.api.downloadDatabaseBackup(file.fileName).subscribe({
      next: (blob) => {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = file.fileName;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
        this.successMessage = `Backup file ${file.fileName} downloaded.`;
      },
      error: (error) => {
        this.errorMessage = error.error?.message || 'Unable to download the backup file. Please try again.';
      }
    });
  }

  createDatabase(file: DatabaseBackupFile): void {
    this.errorMessage = '';
    this.successMessage = '';
    const name = (window.prompt(
      `Create a NEW database from backup file:\n\n${file.fileName}\n\nEnter a name for the new database (letters, digits and underscore only):`,
      'ProjectManagementDB_Copy'
    ) ?? '').trim();
    if (!name) return;
    if (!/^[A-Za-z_][A-Za-z0-9_]{0,127}$/.test(name)) {
      this.errorMessage = 'Invalid database name. Use letters, digits and underscore only.';
      return;
    }
    const ok = window.confirm(
      `Create new database '${name}' from backup file:\n\n${file.fileName}\n\nThe existing database will NOT be touched. Continue?`
    );
    if (!ok) return;
    this.isRestoring = true;
    this.api.createDatabaseFromBackup(file.fileName, name).subscribe({
      next: (response) => {
        this.isRestoring = false;
        this.successMessage = response.message || `New database '${name}' created successfully.`;
        this.snackBar.open(this.successMessage, 'Close', { duration: 5000 });
      },
      error: (error) => {
        this.isRestoring = false;
        this.errorMessage = error.error?.message || 'Could not create the database. Please try again.';
      }
    });
  }

  restoreBackup(file: DatabaseBackupFile): void {    this.errorMessage = '';
    this.successMessage = '';
    const ok = window.confirm(
      `Restore database from backup file:\n\n${file.fileName}\n\nWARNING: The existing database will be completely overwritten and replaced with this backup. All data changes made after this backup was taken will be LOST.\n\nAre you sure you want to continue?`
    );
    if (!ok) return;
    this.isRestoring = true;
    this.api.restoreDatabaseBackup(file.fileName).subscribe({
      next: (response) => {
        this.isRestoring = false;
        this.successMessage = response.message || 'Database restored successfully.';
        this.snackBar.open(this.successMessage, 'Close', { duration: 5000 });
        this.loadBackups();
      },
      error: (error) => {
        this.isRestoring = false;
        this.errorMessage = error.error?.message || 'Database restore failed. No changes were applied.';
      }
    });
  }
}

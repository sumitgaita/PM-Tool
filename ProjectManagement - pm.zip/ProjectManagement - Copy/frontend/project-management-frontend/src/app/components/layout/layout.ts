import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { Auth } from '../../services/auth';
import { User } from '../../models/models';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialogModule } from '@angular/material/dialog';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatChipsModule } from '@angular/material/chips';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.html',
  styleUrls: ['./layout.scss'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, RouterModule, MatCardModule, MatTableModule, MatFormFieldModule, MatInputModule, MatSelectModule, MatButtonModule, MatIconModule, MatToolbarModule, MatSidenavModule, MatListModule, MatExpansionModule, MatDatepickerModule, MatNativeDateModule, MatSlideToggleModule, MatSnackBarModule, MatDialogModule, MatPaginatorModule, MatSortModule, MatChipsModule, MatTooltipModule, MatProgressSpinnerModule]
})
export class LayoutComponent implements OnInit, OnDestroy {
  currentUser: User | null = null;
  sidebarExpanded = true;
  private subs = new Subscription();

  menuItems = [
    { label: 'Dashboard', icon: 'dashboard', route: '/dashboard', permission: 'Dashboard' },
    {
      label: 'Master',
      icon: 'folder',
      children: [
        { label: 'Projects', route: '/projects', permission: 'Projects' },
        { label: 'Completed Projects', route: '/completed-projects', permission: 'Projects' },
        { label: 'Budget Codes', route: '/budget-codes', permission: 'Budget Codes' },
        { label: 'Resources', route: '/resources', permission: 'Resources' }
      ]
    },
    {
      label: 'Budget',
      icon: 'account_balance_wallet',
      children: [
        { label: 'Project Budget', route: '/project-budgets', permission: 'Project Budgets' }
      ]
    },
    {
      label: 'Expenses',
      icon: 'receipt',
      children: [
        { label: 'Daily Expense', route: '/expenses', permission: 'Expenses' },
        { label: 'Expense History', route: '/expense-history', permission: 'Expenses' }
      ]
    },
    {
      label: 'Analysis',
      icon: 'analytics',
      children: [
        { label: 'Cost vs Budget', route: '/cost-vs-budget', permission: 'Cost Vs Budget' },
        { label: 'Profitability', route: '/profitability', permission: 'Profitability' },
        { label: 'Revenue', route: '/revenue', permission: 'Revenue' }
      ]
    },
    {
      label: 'Fish Farming',
      icon: 'waves',
      children: [
        { label: 'Ponds', route: '/fish-ponds', permission: 'Fish Ponds' },
        { label: 'Fish Types', route: '/fish-types', permission: 'Fish Types' },
        { label: 'Fish Stocking', route: '/fish-stocking', permission: 'Fish Stocking' },
        { label: 'Fish Feed', route: '/fish-feed', permission: 'Fish Feed' },
        { label: 'Treatment', route: '/fish-treatment', permission: 'Fish Treatment' },
        { label: 'Mortality', route: '/fish-mortality', permission: 'Fish Mortality' },
        { label: 'Growth', route: '/fish-growth', permission: 'Fish Growth' },
        { label: 'Harvest', route: '/fish-harvest', permission: 'Fish Harvest' },
        { label: 'Sales', route: '/fish-sales', permission: 'Fish Sales' }
      ]
    },
    {
      label: 'Poultry Farming',
      icon: 'egg',
      children: [
        { label: 'Sheds', route: '/poultry-sheds', permission: 'Poultry Sheds' },
        { label: 'Batches', route: '/poultry-batches', permission: 'Poultry Batches' },
        { label: 'Chick Purchase', route: '/chick-purchase', permission: 'Chick Purchase' },
        { label: 'Feed', route: '/poultry-feed', permission: 'Poultry Feed' },
        { label: 'Treatment', route: '/poultry-treatment', permission: 'Poultry Treatment' },
        { label: 'Mortality', route: '/poultry-mortality', permission: 'Poultry Mortality' },
        { label: 'Growth', route: '/poultry-growth', permission: 'Poultry Growth' },
        { label: 'Egg Production', route: '/egg-production', permission: 'Egg Production' },
        { label: 'Sales', route: '/poultry-sales', permission: 'Poultry Sales' }
      ]
    },
    {
      label: 'Reports',
      icon: 'assessment',
      children: [
        { label: 'Project Report', route: '/reports/project', permission: 'Reports' },
        { label: 'Date-wise Report', route: '/reports/date-wise', permission: 'Reports' },
        { label: 'Date Range Report', route: '/reports/date-range', permission: 'Reports' },
        { label: 'Farm Reports', route: '/reports/farm', permission: 'Farm Reports' }
      ]
    },
    {
      label: 'Document',
      icon: 'description',
      children: [
        { label: 'Project Document', route: '/project-document', permission: 'Project Document' }
      ]
    },
    {
      label: 'Administration',
      icon: 'admin_panel_settings',
      children: [
        { label: 'Users', route: '/users', permission: 'Users' },
        { label: 'Permissions', route: '/permissions', permission: 'Permissions' },
        { label: 'Project Permissions', route: '/project-permissions', permission: 'Project Permissions', superAdminOnly: true },
        { label: 'Database Backup', route: '/database-backup', permission: 'Database Backup', superAdminOnly: true }
      ]
    }
  ];

  constructor(private auth: Auth, private router: Router, private cdr: ChangeDetectorRef) {
    this.currentUser = this.auth.getCurrentUser();
  }

  ngOnInit(): void {
    // Re-render the permission-gated sidebar once permissions arrive after a
    // browser refresh, and retry the load if the bootstrap-time attempt failed
    // (e.g. backend was still starting when the page reloaded).
    this.subs.add(this.auth.currentUser$.subscribe(u => {
      this.currentUser = u;
      this.cdr.markForCheck();
    }));
    this.subs.add(this.auth.permissions$.subscribe(() => this.cdr.markForCheck()));
    this.auth.loadMyPermissions().subscribe({ error: () => undefined });
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }

  logout(): void {
    this.auth.logout();
  }

  toggleSidebar(): void {
    this.sidebarExpanded = !this.sidebarExpanded;
  }

  hasPermission(permission: string): boolean {
    if (this.auth.isAdmin()) return true;
    if (!permission) return true;
    if (!this.auth.permissionsLoaded) return false;
    return this.auth.canView(permission);
  }

  isAdminUser(): boolean {
    return this.auth.isAdmin();
  }

  isSuperAdminUser(): boolean {
    return this.auth.isSuperAdmin();
  }

  canSeeChild(child: { route: string; permission: string; superAdminOnly?: boolean }): boolean {
    if (child.route === '/permissions' && !this.isAdminUser()) return false;
    if (child.superAdminOnly && !this.isSuperAdminUser()) return false;
    return this.hasPermission(child.permission);
  }

  hasVisibleChildren(item: { children?: { route: string; permission: string; superAdminOnly?: boolean }[] }): boolean {
    return !!item.children && item.children.some(c => this.canSeeChild(c));
  }
}


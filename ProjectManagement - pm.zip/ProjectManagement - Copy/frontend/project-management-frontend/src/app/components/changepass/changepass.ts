import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { Auth } from '../../services/auth';
import { SecurityQuestion, SecurityAnswer } from '../../models/models';
import { finalize } from 'rxjs/operators';

@Component({
  selector: 'app-changepass',
  templateUrl: './changepass.html',
  styleUrls: ['./changepass.scss'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, RouterModule, MatCardModule, MatFormFieldModule, MatInputModule, MatButtonModule, MatProgressSpinnerModule]
})
export class ChangePassComponent implements OnInit, OnDestroy {
  questions: SecurityQuestion[] = [];
  answersForm: FormGroup;
  passwordForm: FormGroup;
  step: 1 | 2 = 1;
  isLoading = false;
  isLoadingQuestions = true;
  errorMessage = '';
  successMessage = '';
  private questionsTimer: ReturnType<typeof setTimeout> | null = null;

  constructor(
    private fb: FormBuilder,
    private auth: Auth
  ) {
    this.answersForm = this.fb.group({});
    this.passwordForm = this.fb.group({
      newPassword: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', [Validators.required]]
    });
  }

  ngOnInit(): void {
    // Safety net: never leave the page stuck on "Loading..." — if the
    // questions request neither succeeds nor fails within 20s, surface it.
    this.questionsTimer = setTimeout(() => {
      if (this.isLoadingQuestions) {
        this.isLoadingQuestions = false;
        this.errorMessage = 'Loading security questions timed out. Please check your connection and refresh the page.';
      }
    }, 20000);
    this.auth.getChangePassQuestions().pipe(
      finalize(() => {
        if (this.questionsTimer) {
          clearTimeout(this.questionsTimer);
          this.questionsTimer = null;
        }
      })
    ).subscribe({
      next: (response) => {
        this.isLoadingQuestions = false;
        if (response.success) {
          this.questions = response.data ?? [];
          for (const q of this.questions) {
            this.answersForm.addControl(`answer_${q.questionId}`, this.fb.control('', [Validators.required]));
          }
        } else {
          this.errorMessage = response.message || 'Unable to load security questions.';
        }
      },
      error: (error) => {
        this.isLoadingQuestions = false;
        this.errorMessage = error.error?.message || 'Unable to load security questions. Please try again.';
      }
    });
  }

  // Background image resolved against the deployed <base href>, so it loads
  // both under `ng serve` (base `/`) and IIS sub-app hosting (`/pmtool/`).
  get changeBgImage(): string {
    let base = '/';
    try {
      if (typeof document !== 'undefined') {
        base = document.querySelector('base')?.getAttribute('href') || '/';
      }
    } catch {
      base = '/';
    }
    const prefix = base.endsWith('/') ? base : `${base}/`;
    return `url('${prefix}sumit_shreyan.jpeg')`;
  }

  private collectAnswers(): SecurityAnswer[] {
    return this.questions.map(q => ({
      questionId: q.questionId,
      answer: (this.answersForm.get(`answer_${q.questionId}`)?.value ?? '').trim()
    }));
  }

  onVerifyAnswers(): void {
    if (this.answersForm.invalid) {
      this.answersForm.markAllAsTouched();
      return;
    }
    this.isLoading = true;
    this.errorMessage = '';
    this.auth.verifyChangePassAnswers({ answers: this.collectAnswers() }).subscribe({
      next: () => {
        this.isLoading = false;
        this.step = 2;
      },
      error: (error) => {
        this.isLoading = false;
        this.errorMessage = error.error?.message || 'Security answers are incorrect.';
      }
    });
  }

  onResetPassword(): void {
    this.errorMessage = '';
    this.successMessage = '';
    if (this.passwordForm.invalid) {
      this.passwordForm.markAllAsTouched();
      return;
    }
    const newPassword: string = this.passwordForm.get('newPassword')?.value ?? '';
    const confirmPassword: string = this.passwordForm.get('confirmPassword')?.value ?? '';
    if (newPassword !== confirmPassword) {
      this.errorMessage = 'New password and confirm password do not match.';
      return;
    }
    this.isLoading = true;
    this.auth.resetSuperAdminPassword({
      answers: this.collectAnswers(),
      newPassword,
      confirmPassword
    }).subscribe({
      next: (response) => {
        this.isLoading = false;
        this.successMessage = response.message || 'Super Admin password updated successfully.';
        this.passwordForm.reset();
        this.answersForm.reset();
        this.step = 1;
      },
      error: (error) => {
        this.isLoading = false;
        this.errorMessage = error.error?.message || 'Unable to update password. Please try again.';
      }
    });
  }

  ngOnDestroy(): void {
    if (this.questionsTimer) {
      clearTimeout(this.questionsTimer);
      this.questionsTimer = null;
    }
  }

  backToQuestions(): void {
    this.step = 1;
    this.errorMessage = '';
    this.successMessage = '';
  }
}

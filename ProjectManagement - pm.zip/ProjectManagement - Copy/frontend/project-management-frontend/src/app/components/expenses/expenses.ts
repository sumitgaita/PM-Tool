import { Component, ChangeDetectorRef, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { forkJoin, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { Api } from '../../services/api';
import { Auth } from '../../services/auth';
import { Expense, Project, BudgetCode, Resource, ProjectBudget, ProjectResource } from '../../models/models';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialogModule } from '@angular/material/dialog';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatChipsModule } from '@angular/material/chips';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@Component({
  selector: 'app-expenses',
  templateUrl: './expenses.html',
  styleUrls: ['./expenses.scss'],
  standalone: true,
  providers: [{ provide: MAT_DATE_LOCALE, useValue: 'en-IN' }],
  imports: [CommonModule, ReactiveFormsModule, FormsModule, RouterModule, MatCardModule, MatTableModule, MatFormFieldModule, MatInputModule, MatSelectModule, MatButtonModule, MatIconModule, MatToolbarModule, MatSidenavModule, MatListModule, MatExpansionModule, MatDatepickerModule, MatNativeDateModule, MatSlideToggleModule, MatSnackBarModule, MatDialogModule, MatPaginatorModule, MatSortModule, MatChipsModule, MatTooltipModule, MatProgressSpinnerModule, MatCheckboxModule]
})
export class ExpensesComponent implements OnInit {
  @ViewChild('dialogContent') dialogContent!: TemplateRef<unknown>;
  @ViewChild('copyDialogContent') copyDialogContent!: TemplateRef<unknown>;
  private dialogRef: MatDialogRef<unknown> | null = null;
  private copyDialogRef: MatDialogRef<unknown> | null = null;
  expenses: Expense[] = [];
  expensesDataSource = new MatTableDataSource<Expense>([]);
  projects: Project[] = [];
  budgetCodes: BudgetCode[] = [];
  resources: Resource[] = [];
  filteredBudgetCodes: BudgetCode[] = [];
  filteredResources: Resource[] = [];
  farmPonds: any[] = [];
  farmBatches: any[] = [];
  expenseForm: FormGroup;
  isEditing = false;
  selectedExpense: Expense | null = null;
  isLoading = false;
  displayedColumns: string[] = ['expenseDate', 'projectCode', 'budgetCode', 'resourceName', 'amount', 'actions'];
  pageTitle = 'Daily Expenses';
  showCopyButton = true;
  showAddButton = true;
  showSearch = false;
  searchProjectId: number | null = null;
  searchDate: Date | null = null;
  searchBudgetCodeId: number | null = null;
  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;

  copyFromDate: Date | null = null;
  copyToDate: Date | null = null;
  copyProjectId: number | null = null;
  copyAllSourceExpenses: Expense[] = [];
  copySourceExpenses: Expense[] = [];
  copySelection = new Set<number>();
  copyEdits: { [expenseId: number]: { amount: number; description: string; remarks: string } } = {};
  copyLoaded = false;
  copyError = '';
  isCopyLoading = false;
  isCopySaving = false;

  constructor(
    private fb: FormBuilder,
    private api: Api,
    private dialog: MatDialog,
    private cdr: ChangeDetectorRef,
    private route: ActivatedRoute,
    public auth: Auth
  ) {
    this.expenseForm = this.fb.group({
      expenseDate: ['', [Validators.required]],
      projectId: ['', [Validators.required]],
      budgetCodeId: ['', [Validators.required]],
      resourceId: ['', [Validators.required]],
      amount: [0, [Validators.required, Validators.min(0)]],
      description: [''],
      referenceNo: [''],
      remarks: [''],
      farmPondId: [''],
      farmBatchId: ['']
    });
  }

  ngOnInit(): void {
    this.route.data.subscribe(data => {
      this.pageTitle = data['title'] ?? 'Daily Expenses';
      this.showCopyButton = data['showCopy'] ?? true;
      this.showAddButton = data['showAdd'] ?? true;
      this.showSearch = data['showSearch'] ?? false;
      this.pageIndex = 0;
      if (this.showSearch) {
        this.searchProjectId = null;
        this.searchBudgetCodeId = null;
        this.searchDate = null;
        this.loadGrid('2000-01-01', new Date().toISOString().split('T')[0]);
      } else {
        this.loadExpenses();
      }
      this.cdr.markForCheck();
    });
    this.loadProjects();
    this.loadBudgetCodes();
    this.loadResources();
  }

  loadProjects(): void {
    this.api.getProjects().subscribe(response => {
      if (response.success) {
        this.projects = response.data.filter(p => p.isActive);
      }
      this.cdr.markForCheck();
    });
  }

  loadBudgetCodes(): void {
    this.api.getBudgetCodes().subscribe(response => {
      if (response.success) {
        this.budgetCodes = response.data.filter(b => b.isActive);
      }
      this.cdr.markForCheck();
    });
  }

  loadResources(): void {
    this.api.getResources().subscribe(response => {
      if (response.success) {
        this.resources = response.data.filter(r => r.isActive);
      }
      this.cdr.markForCheck();
    });
  }

  loadExpenses(): void {
    const today = new Date().toISOString().split('T')[0];
    this.loadGrid(today, today);
  }

  private loadGrid(fromDate: string, toDate: string, projectId?: number, budgetCodeId?: number): void {
    this.isLoading = true;
    this.api.getExpensesByDateRange(
      fromDate,
      toDate,
      projectId,
      budgetCodeId,
      undefined,
      { pageNumber: this.pageIndex + 1, pageSize: this.pageSize }
    ).subscribe({
      next: response => {
        if (response.success) {
          this.expenses = response.data;
          this.expensesDataSource.data = response.data;
          this.totalRecords = response.totalRecords ?? response.data.length;
        }
        this.isLoading = false;
        this.cdr.markForCheck();
      },
      error: () => {
        this.isLoading = false;
        this.cdr.markForCheck();
      }
    });
  }

  private currentHistoryFilter(): { from: string; to: string; projectId?: number; budgetCodeId?: number } {
    const todayStr = new Date().toISOString().split('T')[0];
    const dateStr = this.toApiDate(this.searchDate);
    const from = dateStr || '2000-01-01';
    const to = dateStr || todayStr;
    return {
      from,
      to,
      projectId: this.searchProjectId ?? undefined,
      budgetCodeId: this.searchBudgetCodeId ?? undefined
    };
  }

  onPage(event: { pageIndex: number; pageSize: number }): void {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    if (this.showSearch) {
      const f = this.currentHistoryFilter();
      this.loadGrid(f.from, f.to, f.projectId, f.budgetCodeId);
    } else {
      this.loadExpenses();
    }
  }

  searchHistory(): void {
    this.pageIndex = 0;
    const f = this.currentHistoryFilter();
    this.loadGrid(f.from, f.to, f.projectId, f.budgetCodeId);
  }

  refreshGrid(): void {
    if (this.showSearch) {
      const f = this.currentHistoryFilter();
      this.loadGrid(f.from, f.to, f.projectId, f.budgetCodeId);
    } else {
      this.loadExpenses();
    }
  }

  resetHistorySearch(): void {
    this.searchProjectId = null;
    this.searchBudgetCodeId = null;
    this.searchDate = null;
    this.pageIndex = 0;
    this.searchHistory();
  }

  exportToPdf(): void {
    Promise.all([import('jspdf'), import('jspdf-autotable')]).then(([jsPdfModule, autoTableModule]) => {
      const doc = new jsPdfModule.jsPDF();
      const autoTable = (autoTableModule as unknown as { default: (doc: unknown, opts: unknown) => void }).default;
      const title = this.showSearch ? 'Expense History' : 'Daily Expenses';
      doc.setFontSize(14);
      doc.text(title, 14, 15);
      doc.setFontSize(10);
      doc.text(`Generated: ${new Date().toLocaleString('en-IN')}`, 14, 22);
      const total = this.expenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
      autoTable(doc, {
        startY: 27,
        head: [['Date', 'Project', 'Budget Code', 'Resource', 'Amount (Rs.)', 'Description']],
        body: this.expenses.map(e => [
          this.toDateInput(e.expenseDate).split('-').reverse().join('-'),
          `${e.projectCode} - ${e.projectName}`,
          `${e.budgetCode} - ${e.budgetCodeName}`,
          e.resourceName,
          new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2 }).format(Number(e.amount) || 0),
          e.description ?? ''
        ]),
        foot: [['', '', '', 'Total', new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2 }).format(total), '']],
        styles: { fontSize: 8 },
        headStyles: { fillColor: [63, 81, 181] }
      });
      doc.save(`${this.showSearch ? 'Expense_History' : 'Daily_Expenses'}_${new Date().toISOString().split('T')[0]}.pdf`);
    });
  }

  exportHistoryToExcel(): void {    const f = this.currentHistoryFilter();
    import('xlsx').then(xlsx => {
      this.api.getExpensesByDateRange(f.from, f.to, f.projectId, f.budgetCodeId, undefined, { pageNumber: 1, pageSize: 100 }).subscribe(response => {
        if (!response.success || !response.data || response.data.length === 0) {
          return;
        }
        const rows = response.data.map(e => ({
          'Date': this.toDateInput(e.expenseDate),
          'Project': `${e.projectCode} - ${e.projectName}`,
          'Budget Code': `${e.budgetCode} - ${e.budgetCodeName}`,
          'Resource': `${e.resourceCode} - ${e.resourceName}`,
          'Amount': Number(e.amount) || 0,
          'Description': e.description ?? '',
          'Reference No': e.referenceNo ?? '',
          'Remarks': e.remarks ?? ''
        }));
        const ws = xlsx.utils.json_to_sheet(rows);
        const wb = xlsx.utils.book_new();
        xlsx.utils.book_append_sheet(wb, ws, 'Expense History');
        xlsx.writeFile(wb, `Expense_History_${new Date().toISOString().split('T')[0]}.xlsx`);
      });
    });
  }

  openDialog(expense?: Expense): void {
    this.isEditing = !!expense;
    this.selectedExpense = expense || null;

    if (expense) {
      this.expenseForm.patchValue({
        ...expense,
        expenseDate: this.toDateObject(this.toDateInput(expense.expenseDate)),
        farmPondId: expense.farmEntityType === 'Pond' && expense.farmEntityId ? expense.farmEntityId : '',
        farmBatchId: expense.farmEntityType === 'PoultryBatch' && expense.farmEntityId ? expense.farmEntityId : ''
      });
      this.onProjectChange(expense.projectId);
    } else {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      this.expenseForm.reset();
      this.expenseForm.patchValue({ expenseDate: today });
      this.filteredBudgetCodes = [];
      this.filteredResources = [];
      this.farmPonds = [];
      this.farmBatches = [];
    }

    this.dialogRef = this.dialog.open(this.dialogContent, {
      width: '600px',
      maxHeight: '90vh'
    });
  }

  onProjectChange(projectId?: number | string): void {
    const pid = Number(projectId);
    if (!pid) {
      this.filteredBudgetCodes = [];
      this.filteredResources = [];
      this.farmPonds = [];
      this.farmBatches = [];
      return;
    }
    this.api.getProjectBudgets(pid, undefined, { pageSize: 100 }).subscribe(response => {
      if (response.success) {
        const ids = new Set(response.data.map((b: ProjectBudget) => b.budgetCodeId));
        this.filteredBudgetCodes = this.budgetCodes.filter(bc => ids.has(bc.budgetCodeId));
      }
    });
    this.api.getProjectResources(pid).subscribe(response => {
      if (response.success) {
        const ids = new Set(response.data.map((pr: ProjectResource) => pr.resourceId));
        this.filteredResources = this.resources.filter(r => ids.has(r.resourceId));
      }
    });
    this.api.getPonds(pid, undefined, { pageNumber: 1, pageSize: 100 }).subscribe(response => {
      this.farmPonds = response.success ? response.data.filter((p: any) => p.isActive) : [];
    });
    this.api.getPoultryBatches(pid, undefined, undefined, undefined, { pageNumber: 1, pageSize: 100 }).subscribe(response => {
      this.farmBatches = response.success ? response.data : [];
    });
  }

  onFarmPondChange(): void {
    if (this.expenseForm.get('farmPondId')?.value) {
      this.expenseForm.patchValue({ farmBatchId: '' }, { emitEvent: false });
    }
  }

  onFarmBatchChange(): void {
    if (this.expenseForm.get('farmBatchId')?.value) {
      this.expenseForm.patchValue({ farmPondId: '' }, { emitEvent: false });
    }
  }

  private toDateInput(value: string): string {
    if (!value) {
      return '';
    }
    return value.split('T')[0];
  }

  private toDateObject(value: string): Date | null {
    if (!value) {
      return null;
    }
    const parts = value.split('T')[0].split('-');
    if (parts.length !== 3) {
      return null;
    }
    return new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
  }

  saveExpense(): void {
    if (this.expenseForm.invalid) {
      return;
    }

    const expenseData = {
      ...this.expenseForm.value,
      expenseDate: this.toApiDate(this.expenseForm.value.expenseDate)
    };
    const pondId = Number(this.expenseForm.value.farmPondId) || null;
    const batchId = Number(this.expenseForm.value.farmBatchId) || null;
    const project = this.projects.find(p => p.projectId === Number(this.expenseForm.value.projectId));
    expenseData.farmType = project?.farmType || null;
    expenseData.farmEntityType = pondId ? 'Pond' : (batchId ? 'PoultryBatch' : null);
    expenseData.farmEntityId = pondId ?? batchId;
    delete expenseData.farmPondId;
    delete expenseData.farmBatchId;

    if (this.isEditing && this.selectedExpense) {
      this.api.updateExpense(this.selectedExpense.expenseId, expenseData).subscribe(response => {
        if (response.success) {
          this.refreshGrid();
          this.closeDialog();
        }
      });
    } else {
      this.api.createExpense(expenseData).subscribe(response => {
        if (response.success) {
          this.refreshGrid();
          this.closeDialog();
        }
      });
    }
  }

  closeDialog(): void {
    this.dialogRef?.close();
    this.dialogRef = null;
    this.expenseForm.reset();
    this.isEditing = false;
    this.selectedExpense = null;
  }

  deleteExpense(expense: Expense): void {
    if (confirm('Are you sure you want to delete this expense?')) {
      this.api.deleteExpense(expense.expenseId).subscribe(response => {
        if (response.success) {
          this.refreshGrid();
        }
      });
    }
  }

  openCopyDialog(): void {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const yesterday = new Date(today);
    yesterday.setDate(today.getDate() - 1);
    this.copyToDate = today;
    this.copyFromDate = yesterday;
    this.copyProjectId = null;
    this.copyAllSourceExpenses = [];
    this.copySourceExpenses = [];
    this.copySelection = new Set<number>();
    this.copyEdits = {};
    this.copyLoaded = false;
    this.copyError = '';
    this.isCopyLoading = false;
    this.isCopySaving = false;

    this.copyDialogRef = this.dialog.open(this.copyDialogContent, {
      width: '950px',
      maxHeight: '90vh'
    });
  }

  loadCopySource(): void {
    const fromDate = this.toApiDate(this.copyFromDate);
    if (!fromDate) {
      return;
    }
    this.isCopyLoading = true;
    this.copyLoaded = true;
    this.copyError = '';
    this.api.getExpensesByDate(fromDate).subscribe({
      next: response => {
        if (response.success) {
          this.copyAllSourceExpenses = response.data;
          this.copyEdits = {};
          for (const e of response.data) {
            this.copyEdits[e.expenseId] = {
              amount: e.amount,
              description: e.description ?? '',
              remarks: e.remarks ?? ''
            };
          }
          this.refreshCopyView(true);
        } else {
          this.copyError = response.message || 'Failed to load expenses for the selected date.';
        }
        this.isCopyLoading = false;
        this.cdr.markForCheck();
      },
      error: err => {
        this.isCopyLoading = false;
        this.copyError = err?.status === 401
          ? 'Session expired. Please log out and log in again, then retry.'
          : 'Failed to load expenses. Please check the connection and retry.';
        this.cdr.markForCheck();
      }
    });
  }

  onCopyProjectChange(): void {
    if (!this.copyLoaded || this.copyAllSourceExpenses.length === 0) {
      return;
    }
    this.refreshCopyView(false);
    this.cdr.markForCheck();
  }

  private refreshCopyView(selectAllVisible: boolean): void {
    this.copySourceExpenses = this.copyProjectId
      ? this.copyAllSourceExpenses.filter(e => e.projectId === this.copyProjectId)
      : [...this.copyAllSourceExpenses];
    if (selectAllVisible) {
      this.copySelection = new Set<number>(this.copySourceExpenses.map(e => e.expenseId));
    }
  }

  toggleCopySelection(expenseId: number): void {
    if (this.copySelection.has(expenseId)) {
      this.copySelection.delete(expenseId);
    } else {
      this.copySelection.add(expenseId);
    }
  }

  toggleCopySelectAll(): void {
    if (this.isAllCopySelected()) {
      this.copySelection.clear();
    } else {
      this.copySelection = new Set<number>(this.copySourceExpenses.map(e => e.expenseId));
    }
  }

  isAllCopySelected(): boolean {
    return this.copySourceExpenses.length > 0 &&
      this.copySelection.size === this.copySourceExpenses.length;
  }

  selectedCopyCount(): number {
    return this.copySourceExpenses.filter(e => this.copySelection.has(e.expenseId)).length;
  }

  selectedCopyTotal(): number {
    return this.copySourceExpenses
      .filter(e => this.copySelection.has(e.expenseId))
      .reduce((sum, e) => sum + (Number(this.copyEdits[e.expenseId]?.amount) || 0), 0);
  }

  private toApiDate(value: Date | string | null): string {
    if (!value) {
      return '';
    }
    if (typeof value === 'string') {
      return value.split('T')[0];
    }
    const year = value.getFullYear();
    const month = String(value.getMonth() + 1).padStart(2, '0');
    const day = String(value.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  saveCopiedExpenses(): void {
    const selected = this.copySourceExpenses.filter(e => this.copySelection.has(e.expenseId));
    const targetDate = this.toApiDate(this.copyToDate);
    if (selected.length === 0 || !targetDate) {
      return;
    }
    const invalid = selected.filter(e => {
      const amount = Number(this.copyEdits[e.expenseId]?.amount);
      return !amount || amount <= 0;
    });
    if (invalid.length > 0) {
      this.copyError = `Amount must be greater than zero for all selected rows (${invalid.length} row(s) need fixing).`;
      return;
    }
    this.copyError = '';
    this.isCopySaving = true;
    const requests = selected.map(e => {
      const edit = this.copyEdits[e.expenseId] ?? {
        amount: e.amount,
        description: e.description ?? '',
        remarks: e.remarks ?? ''
      };
      return this.api.createExpense({
        expenseDate: targetDate,
        projectId: e.projectId,
        budgetCodeId: e.budgetCodeId,
        resourceId: e.resourceId,
        amount: Number(edit.amount),
        description: edit.description,
        referenceNo: e.referenceNo,
        remarks: edit.remarks
      }).pipe(catchError(err => of({ success: false, status: err?.status })));
    });
    forkJoin(requests).subscribe({
      next: results => {
        this.isCopySaving = false;
        const failed = results.filter(r => !(r as { success: boolean }).success).length;
        if (failed === 0) {
          this.closeCopyDialog();
          this.loadExpenses();
        } else if (failed === results.length) {
          this.copyError = 'Failed to save copied expenses. Please check the connection and retry.';
          this.cdr.markForCheck();
        } else {
          this.copyError = `${results.length - failed} of ${results.length} copied, ${failed} failed. Please retry the failed rows.`;
          this.loadExpenses();
        }
      },
      error: () => {
        this.isCopySaving = false;
        this.copyError = 'Failed to save copied expenses. Nothing was lost — please retry.';
        this.cdr.markForCheck();
      }
    });
  }

  closeCopyDialog(): void {
    this.copyDialogRef?.close();
    this.copyDialogRef = null;
    this.copyAllSourceExpenses = [];
    this.copySourceExpenses = [];
    this.copySelection = new Set<number>();
    this.copyEdits = {};
    this.copyLoaded = false;
    this.copyError = '';
    this.isCopySaving = false;
  }

  formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 2
    }).format(amount);
  }
}


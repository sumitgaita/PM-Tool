import { ApplicationConfig, provideBrowserGlobalErrorListeners, APP_INITIALIZER, provideZoneChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient, withInterceptorsFromDi, HTTP_INTERCEPTORS } from '@angular/common/http';
import { provideAnimations } from '@angular/platform-browser/animations';
import { routes } from './app.routes';
import { AuthInterceptor } from './core/interceptors/auth.interceptor';
import { Auth } from './services/auth';
import { provideCharts, withDefaultRegisterables } from 'ng2-charts';

// On a browser refresh the app bootstraps from scratch: restore the session
// (token + user come from localStorage inside Auth) and preload permissions
// BEFORE the first guard/component runs, so reload behaves exactly like a
// fresh login instead of rendering with empty permissions/menus.
function restoreSession(auth: Auth): () => Promise<void> {
  return () =>
    new Promise<void>((resolve) => {
      try {
        const token = auth.getToken();
        if (!token || auth.isTokenExpired(token) || auth.permissionsLoaded) {
          resolve();
          return;
        }
        auth.loadMyPermissions().subscribe({ next: () => resolve(), error: () => resolve() });
      } catch {
        resolve();
      }
    });
}

export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection(),
    provideBrowserGlobalErrorListeners(),
    provideRouter(routes),
    provideHttpClient(withInterceptorsFromDi()),
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true },
    { provide: APP_INITIALIZER, useFactory: restoreSession, deps: [Auth], multi: true },
    provideAnimations(),
    provideCharts(withDefaultRegisterables())
  ]
};

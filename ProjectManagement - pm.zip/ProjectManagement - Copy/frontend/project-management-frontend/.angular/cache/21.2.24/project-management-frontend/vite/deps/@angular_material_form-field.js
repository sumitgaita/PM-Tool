import {
  MatFormFieldModule
} from "./chunk-5OGBAECM.js";
import {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
} from "./chunk-Z3PGDRUY.js";
import "./chunk-6LZZF7VX.js";
import "./chunk-PLJ2QXBA.js";
import "./chunk-VON75VBJ.js";
import "./chunk-KUXD6W73.js";
import "./chunk-XA6252L2.js";
import "./chunk-42DE7R33.js";
import "./chunk-N4DOILP3.js";
import "./chunk-NFNEDZLR.js";
import "./chunk-HXAVHHUY.js";
import "./chunk-S4VEXWPH.js";
import "./chunk-CWHJQ52Q.js";
import "./chunk-GUGIMSVJ.js";
import "./chunk-6A3HUM4G.js";
import "./chunk-CWF5ZQ4W.js";
import "./chunk-DPFYMBU6.js";
import "./chunk-PXAPRNCG.js";
import "./chunk-LGYLMJ3I.js";
import "./chunk-P7R5Y5YD.js";
import "./chunk-VGQQBGPE.js";
import "./chunk-JRFR6BLO.js";
import "./chunk-HWYXSU2G.js";
import "./chunk-MARUHEWW.js";
import "./chunk-7PLCLRNK.js";
export {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatFormFieldModule,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
};

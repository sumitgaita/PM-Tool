using System.Security.Cryptography;
using System.Text;

namespace ProjectManagement.Tests;

/// <summary>
/// Mirrors business rules in vw_CostVsBudget / usp_Report_CostVsBudget:
/// Remaining = Budget - Actual; Variance = Budget - Actual;
/// Utilization% = Actual/Budget*100 (0 when Budget=0); OverBudget when Actual &gt; Budget.
/// </summary>
public static class CostVsBudgetCalc
{
    public static decimal Remaining(decimal budget, decimal actual) => budget - actual;
    public static decimal Variance(decimal budget, decimal actual) => budget - actual;
    public static decimal Utilization(decimal budget, decimal actual)
        => budget == 0 ? 0 : Math.Round(actual / budget * 100, 2);
    public static bool IsOverBudget(decimal budget, decimal actual) => actual > budget;
    public static decimal Total(IEnumerable<decimal> amounts) => amounts.Sum();
}

public static class PermissionMatrix
{
    // Mirrors RequirePermissionAttribute: Admin bypass; else check flag per action.
    public static bool IsAllowed(string role, bool canView, bool canEdit, bool canDelete, string action)
    {
        if (string.Equals(role, "Admin", StringComparison.OrdinalIgnoreCase)) return true;
        return action.ToLower() switch
        {
            "view" => canView,
            "edit" => canEdit,
            "delete" => canDelete,
            _ => false
        };
    }
}

public class BudgetCalculationTests
{
    [Fact]
    public void Remaining_Equals_Budget_Minus_Actual()
    {
        Assert.Equal(7000m, CostVsBudgetCalc.Remaining(20000m, 13000m));
    }

    [Fact]
    public void Variance_Equals_Budget_Minus_Actual()
    {
        Assert.Equal(-5000m, CostVsBudgetCalc.Variance(20000m, 25000m));
    }

    [Fact]
    public void Utilization_Percentage_Correct()
    {
        Assert.Equal(65m, CostVsBudgetCalc.Utilization(20000m, 13000m));
    }

    [Fact]
    public void Utilization_Zero_Budget_No_Divide_By_Zero()
    {
        Assert.Equal(0m, CostVsBudgetCalc.Utilization(0m, 5000m));
    }

    [Fact]
    public void OverBudget_Flagged_When_Actual_Exceeds_Budget()
    {
        Assert.True(CostVsBudgetCalc.IsOverBudget(20000m, 25001m));
        Assert.False(CostVsBudgetCalc.IsOverBudget(20000m, 20000m));
    }

    [Fact]
    public void Expense_Total_Sums_Amounts()
    {
        Assert.Equal(35500m, CostVsBudgetCalc.Total(new[] { 5000m, 3000m, 1500m, 8000m, 12000m, 6000m }));
    }

    [Fact]
    public void Seed_Dashboard_Totals_Consistent()
    {
        // Seed: budgets 20000+15000+10000+25000+30000+40000=140000; expenses=35500
        decimal budget = CostVsBudgetCalc.Total(new[] { 20000m, 15000m, 10000m, 25000m, 30000m, 40000m });
        decimal expense = CostVsBudgetCalc.Total(new[] { 5000m, 3000m, 1500m, 8000m, 12000m, 6000m });
        Assert.Equal(140000m, budget);
        Assert.Equal(35500m, expense);
        Assert.Equal(104500m, CostVsBudgetCalc.Remaining(budget, expense));
        Assert.Equal(25.36m, CostVsBudgetCalc.Utilization(budget, expense));
    }
}

public class PermissionTests
{
    [Fact]
    public void Admin_Allowed_Everything_Without_Rows()
    {
        Assert.True(PermissionMatrix.IsAllowed("Admin", false, false, false, "view"));
        Assert.True(PermissionMatrix.IsAllowed("Admin", false, false, false, "edit"));
        Assert.True(PermissionMatrix.IsAllowed("Admin", false, false, false, "delete"));
    }

    [Fact]
    public void User_View_Allowed_Edit_Delete_Denied()
    {
        Assert.True(PermissionMatrix.IsAllowed("User", true, false, false, "view"));
        Assert.False(PermissionMatrix.IsAllowed("User", true, false, false, "edit"));
        Assert.False(PermissionMatrix.IsAllowed("User", true, false, false, "delete"));
    }

    [Fact]
    public void User_Full_Expense_Permission_Allows_All()
    {
        Assert.True(PermissionMatrix.IsAllowed("User", true, true, true, "view"));
        Assert.True(PermissionMatrix.IsAllowed("User", true, true, true, "edit"));
        Assert.True(PermissionMatrix.IsAllowed("User", true, true, true, "delete"));
    }

    [Fact]
    public void User_No_Permission_Row_Denied()
    {
        Assert.False(PermissionMatrix.IsAllowed("User", false, false, false, "view"));
    }
}

public class AuthHashTests
{
    private static string Sha256(string s)
    {
        using var sha = SHA256.Create();
        return Convert.ToHexString(sha.ComputeHash(Encoding.UTF8.GetBytes(s))).ToLower();
    }

    [Fact]
    public void Admin_Default_Password_Hash_Matches_Seed()
    {
        Assert.Equal("240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9", Sha256("admin123"));
    }

    [Fact]
    public void Different_Passwords_Different_Hashes()
    {
        Assert.NotEqual(Sha256("admin123"), Sha256("Admin@123"));
    }
}

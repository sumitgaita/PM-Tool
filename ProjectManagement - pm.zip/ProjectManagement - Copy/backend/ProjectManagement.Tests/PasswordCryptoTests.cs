using System.Security.Cryptography;
using ProjectManagement.Api.Services;

namespace ProjectManagement.Tests;

/// <summary>
/// Verifies reversible password protection used for Super Admin grid display.
/// Auth itself stays one-way SHA256; these tests cover only the AES envelope.
/// </summary>
public class PasswordCryptoTests
{
    private static byte[] NewKey()
    {
        var key = new byte[32];
        RandomNumberGenerator.Fill(key);
        return key;
    }

    [Fact]
    public void Encrypt_Then_Decrypt_RoundTrips_Password()
    {
        var key = NewKey();
        var cipher = PasswordCrypto.Encrypt("Secret@123", key);
        Assert.True(PasswordCrypto.TryDecrypt(cipher, key, out var plain));
        Assert.Equal("Secret@123", plain);
    }

    [Fact]
    public void Encrypt_Produces_Nondeterministic_Output()
    {
        var key = NewKey();
        Assert.NotEqual(PasswordCrypto.Encrypt("same", key), PasswordCrypto.Encrypt("same", key));
    }

    [Fact]
    public void Decrypt_With_Wrong_Key_Fails()
    {
        var cipher = PasswordCrypto.Encrypt("Secret@123", NewKey());
        Assert.False(PasswordCrypto.TryDecrypt(cipher, NewKey(), out var plain));
        Assert.Null(plain);
    }

    [Fact]
    public void Decrypt_Invalid_Inputs_Return_False()
    {
        var key = NewKey();
        Assert.False(PasswordCrypto.TryDecrypt(null, key, out _));
        Assert.False(PasswordCrypto.TryDecrypt("", key, out _));
        Assert.False(PasswordCrypto.TryDecrypt("not-encrypted", key, out _));
        Assert.False(PasswordCrypto.TryDecrypt(PasswordCrypto.Encrypt("x", key), null, out _));
        Assert.False(PasswordCrypto.TryDecrypt(PasswordCrypto.Encrypt("x", key), new byte[16], out _));
    }
}

using System.Security.Claims;
using Microsoft.Data.SqlClient;
using ProjectManagement.Api.DTOs;

namespace ProjectManagement.Api.Services;

/// <summary>
/// Central project-permission enforcement. Super Admin bypasses everything;
/// Admin/Normal users may only access projects assigned to them
/// (managed on the Project Permissions page).
/// </summary>
public static class ProjectAccessHelper
{
    public const string DeniedMessage = "Access denied. This project is not assigned to you.";

    public static bool IsSuperAdmin(ClaimsPrincipal user)
    {
        var role = user.FindFirst(ClaimTypes.Role)?.Value;
        return string.Equals(role, "Super Admin", StringComparison.OrdinalIgnoreCase);
    }

    public static int CurrentUserId(ClaimsPrincipal user)
    {
        var userIdClaim = user.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        return int.TryParse(userIdClaim, out var userId) ? userId : 0;
    }

    public static async Task<bool> HasProjectAccessAsync(ClaimsPrincipal user, IDatabaseService db, int projectId)
    {
        if (IsSuperAdmin(user)) return true;

        var rows = await db.ExecuteStoredProcedureAsync<AssignedProjectIdDto>(
            "usp_UserProject_GetAssignedIds", new[] { new SqlParameter("@UserId", CurrentUserId(user)) });
        return rows.Any(r => r.ProjectId == projectId);
    }

    /// <summary>True when an optional ?projectId= query value targets an unassigned project.</summary>
    public static async Task<bool> QueryProjectDeniedAsync(ClaimsPrincipal user, IDatabaseService db, int? projectId)
        => projectId.HasValue && !await HasProjectAccessAsync(user, db, projectId.Value);

    /// <summary>Resolves an entity id to its project (usp_EntityProject_Resolve) and checks access.</summary>
    public static async Task<bool> HasEntityAccessAsync(ClaimsPrincipal user, IDatabaseService db, string entity, int id)
    {
        if (IsSuperAdmin(user)) return true;

        var rows = await db.ExecuteStoredProcedureAsync<EntityProjectDto>(
            "usp_EntityProject_Resolve",
            new[] { new SqlParameter("@Entity", entity), new SqlParameter("@Id", id) });
        if (rows.Count == 0) return false;
        return await HasProjectAccessAsync(user, db, rows[0].ProjectId);
    }
}

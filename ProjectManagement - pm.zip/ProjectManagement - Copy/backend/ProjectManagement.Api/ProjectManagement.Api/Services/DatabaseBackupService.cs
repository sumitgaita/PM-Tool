using Microsoft.Data.SqlClient;
using ProjectManagement.Api.DTOs;

namespace ProjectManagement.Api.Services
{
    public interface IBackupService
    {
        IReadOnlyList<BackupFileDto> ListBackups();
        Task<BackupResultDto> TakeBackupAsync();
        string ResolveBackupPath(string fileName);
        Task<BackupResultDto> RestoreAsync(string fileName);
        Task<BackupResultDto> CreateDatabaseAsync(string fileName, string newDatabaseName);
    }

    public class DatabaseBackupService : IBackupService
    {
        private const string DatabaseName = "ProjectManagementDB";
        private readonly string _connectionString;
        private readonly string _folder;
        private readonly ILogger<DatabaseBackupService> _logger;

        public DatabaseBackupService(IConfiguration configuration, ILogger<DatabaseBackupService> logger)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection") ?? string.Empty;
            _folder = configuration["DatabaseBackup:Folder"]
                ?? Path.Combine(AppContext.BaseDirectory, "..", "Database Backup");
            _logger = logger;
        }

        public IReadOnlyList<BackupFileDto> ListBackups()
        {
            if (!Directory.Exists(_folder))
            {
                return Array.Empty<BackupFileDto>();
            }

            return Directory.GetFiles(_folder, "*.bak")
                .Select(p => new FileInfo(p))
                .OrderByDescending(f => f.CreationTime)
                .Select(f => new BackupFileDto
                {
                    FileName = f.Name,
                    SizeBytes = f.Length,
                    CreatedDate = f.CreationTime
                })
                .ToList();
        }

        public string ResolveBackupPath(string fileName)
        {
            // Never trust client-supplied paths: strip directories, allow .bak only,
            // and require the file to live inside the configured backup folder.
            var safeName = Path.GetFileName(fileName ?? string.Empty);
            if (string.IsNullOrWhiteSpace(safeName)
                || !safeName.EndsWith(".bak", StringComparison.OrdinalIgnoreCase))
            {
                throw new ArgumentException("Invalid backup file name.", nameof(fileName));
            }

            var fullPath = Path.GetFullPath(Path.Combine(_folder, safeName));
            var root = Path.GetFullPath(_folder);
            if (!fullPath.StartsWith(root + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
            {
                throw new ArgumentException("Invalid backup file name.", nameof(fileName));
            }
            if (!File.Exists(fullPath))
            {
                throw new FileNotFoundException("Backup file not found.", safeName);
            }
            return fullPath;
        }

        public async Task<BackupResultDto> TakeBackupAsync()
        {
            try
            {
                Directory.CreateDirectory(_folder);
                var fileName = $"{DatabaseName}_{DateTime.Now:yyyyMMdd_HHmmss}.bak";
                var fullPath = Path.GetFullPath(Path.Combine(_folder, fileName));

                await using var conn = new SqlConnection(_connectionString);
                await conn.OpenAsync();
                await using var cmd = conn.CreateCommand();
                cmd.CommandTimeout = 3600;
                cmd.CommandText = "BACKUP DATABASE [" + DatabaseName + "] TO DISK = @Path WITH INIT, CHECKSUM;";
                cmd.Parameters.Add(new SqlParameter("@Path", fullPath));
                await cmd.ExecuteNonQueryAsync();

                _logger.LogInformation("Database backup created: {File}", fullPath);
                return new BackupResultDto { Success = true, Message = "Database backup created successfully.", FileName = fileName };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Database backup failed.");
                return new BackupResultDto { Success = false, Message = "Database backup failed. Please try again." };
            }
        }

        public async Task<BackupResultDto> RestoreAsync(string fileName)
        {
            string fullPath;
            try
            {
                fullPath = ResolveBackupPath(fileName);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Database restore rejected for file name: {File}", fileName);
                return new BackupResultDto { Success = false, Message = "Invalid backup file selected." };
            }

            try
            {
                // RESTORE must run outside the target database context.
                var builder = new SqlConnectionStringBuilder(_connectionString) { InitialCatalog = "master" };
                await using var conn = new SqlConnection(builder.ConnectionString);
                await conn.OpenAsync();

                await using var verify = conn.CreateCommand();
                verify.CommandTimeout = 3600;
                verify.CommandText = "RESTORE VERIFYONLY FROM DISK = @Path;";
                verify.Parameters.Add(new SqlParameter("@Path", fullPath));
                await verify.ExecuteNonQueryAsync();

                await using var restore = conn.CreateCommand();
                restore.CommandTimeout = 3600;
                restore.CommandText =
                    "ALTER DATABASE [" + DatabaseName + "] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;" +
                    "RESTORE DATABASE [" + DatabaseName + "] FROM DISK = @Path WITH REPLACE, RECOVERY;" +
                    "ALTER DATABASE [" + DatabaseName + "] SET MULTI_USER;";
                restore.Parameters.Add(new SqlParameter("@Path", fullPath));
                await restore.ExecuteNonQueryAsync();

                _logger.LogWarning("Database restored from backup: {File}", fullPath);
                return new BackupResultDto { Success = true, Message = "Database restored successfully from " + Path.GetFileName(fullPath) + "." };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Database restore failed.");
                try
                {
                    var builder = new SqlConnectionStringBuilder(_connectionString) { InitialCatalog = "master" };
                    await using var conn = new SqlConnection(builder.ConnectionString);
                    await conn.OpenAsync();
                    await using var cmd = conn.CreateCommand();
                    cmd.CommandText = "ALTER DATABASE [" + DatabaseName + "] SET MULTI_USER;";
                    await cmd.ExecuteNonQueryAsync();
                }
                catch (Exception multiEx)
                {
                    _logger.LogError(multiEx, "Failed to reset database to MULTI_USER after restore failure.");
                }
                return new BackupResultDto { Success = false, Message = "Database restore failed. No changes were applied." };
            }
        }

        public async Task<BackupResultDto> CreateDatabaseAsync(string fileName, string newDatabaseName)
        {
            string fullPath;
            try
            {
                fullPath = ResolveBackupPath(fileName);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Database create rejected for file name: {File}", fileName);
                return new BackupResultDto { Success = false, Message = "Invalid backup file selected." };
            }

            var dbName = (newDatabaseName ?? string.Empty).Trim();
            if (!System.Text.RegularExpressions.Regex.IsMatch(dbName, @"^[A-Za-z_][A-Za-z0-9_]{0,127}$"))
            {
                return new BackupResultDto { Success = false, Message = "Invalid database name. Use letters, digits and underscore only." };
            }
            var reserved = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
                { "master", "model", "msdb", "tempdb", DatabaseName };
            if (reserved.Contains(dbName))
            {
                return new BackupResultDto { Success = false, Message = "This database name is reserved. Choose another name." };
            }

            try
            {
                var builder = new SqlConnectionStringBuilder(_connectionString) { InitialCatalog = "master" };
                await using var conn = new SqlConnection(builder.ConnectionString);
                await conn.OpenAsync();

                await using (var exists = conn.CreateCommand())
                {
                    exists.CommandText = "SELECT DB_ID(@Db);";
                    exists.Parameters.Add(new SqlParameter("@Db", dbName));
                    var existing = await exists.ExecuteScalarAsync();
                    if (existing != null && existing != DBNull.Value)
                    {
                        return new BackupResultDto { Success = false, Message = $"Database '{dbName}' already exists." };
                    }
                }

                await using (var verify = conn.CreateCommand())
                {
                    verify.CommandTimeout = 3600;
                    verify.CommandText = "RESTORE VERIFYONLY FROM DISK = @Path;";
                    verify.Parameters.Add(new SqlParameter("@Path", fullPath));
                    await verify.ExecuteNonQueryAsync();
                }

                var files = new List<(string LogicalName, string Type)>();
                await using (var list = conn.CreateCommand())
                {
                    list.CommandText = "RESTORE FILELISTONLY FROM DISK = @Path;";
                    list.Parameters.Add(new SqlParameter("@Path", fullPath));
                    await using var reader = await list.ExecuteReaderAsync();
                    while (await reader.ReadAsync())
                    {
                        files.Add((reader["LogicalName"].ToString()!, reader["Type"].ToString()!));
                    }
                }
                if (files.Count == 0)
                {
                    return new BackupResultDto { Success = false, Message = "Backup file contains no data files." };
                }

                string dataDir;
                await using (var dir = conn.CreateCommand())
                {
                    dir.CommandText = "SELECT ISNULL(CONVERT(NVARCHAR(1000), SERVERPROPERTY('InstanceDefaultDataPath')), N'');";
                    dataDir = (await dir.ExecuteScalarAsync())?.ToString() ?? string.Empty;
                }
                if (string.IsNullOrWhiteSpace(dataDir))
                {
                    await using var dir = conn.CreateCommand();
                    dir.CommandText = "SELECT SUBSTRING(physical_name, 1, LEN(physical_name) - CHARINDEX('\\', REVERSE(physical_name))) FROM sys.master_files WHERE database_id = 1 AND file_id = 1;";
                    dataDir = (await dir.ExecuteScalarAsync())?.ToString() ?? string.Empty;
                }
                if (!dataDir.EndsWith("\\")) dataDir += "\\";

                var moves = new List<string>();
                var usedPaths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                int dataIndex = 0, logIndex = 0;
                foreach (var (logicalName, type) in files)
                {
                    string target;
                    if (type == "D")
                    {
                        target = dataDir + dbName + (dataIndex == 0 ? ".mdf" : $"_{dataIndex}.mdf");
                        dataIndex++;
                    }
                    else
                    {
                        target = dataDir + dbName + (logIndex == 0 ? "_log.ldf" : $"_log{logIndex}.ldf");
                        logIndex++;
                    }
                    if (File.Exists(target) || !usedPaths.Add(target))
                    {
                        return new BackupResultDto { Success = false, Message = "Target data files already exist. Choose another database name." };
                    }
                    moves.Add("MOVE N'" + logicalName.Replace("'", "''") + "' TO N'" + target.Replace("'", "''") + "'");
                }

                // Identifier is safe: name passed the strict regex above.
                var quotedDb = "[" + dbName.Replace("]", "]]") + "]";
                await using (var restore = conn.CreateCommand())
                {
                    restore.CommandTimeout = 3600;
                    restore.CommandText = "RESTORE DATABASE " + quotedDb + " FROM DISK = @Path WITH " +
                        string.Join(", ", moves) + ", RECOVERY;";
                    restore.Parameters.Add(new SqlParameter("@Path", fullPath));
                    await restore.ExecuteNonQueryAsync();
                }

                // Best effort: re-link orphaned users whose server logins exist.
                try
                {
                    conn.ChangeDatabase(dbName);
                    var orphans = new List<string>();
                    await using (var cmd = conn.CreateCommand())
                    {
                        cmd.CommandText = "SELECT dp.name FROM sys.database_principals dp " +
                            "LEFT JOIN sys.server_principals sp ON sp.sid = dp.sid " +
                            "WHERE sp.sid IS NULL AND dp.type IN ('S', 'U', 'G') " +
                            "AND dp.name NOT IN ('dbo', 'guest', 'INFORMATION_SCHEMA', 'sys');";
                        await using var reader = await cmd.ExecuteReaderAsync();
                        while (await reader.ReadAsync()) orphans.Add(reader.GetString(0));
                    }
                    foreach (var user in orphans)
                    {
                        try
                        {
                            await using var link = conn.CreateCommand();
                            link.CommandText = "IF EXISTS (SELECT 1 FROM sys.server_principals WHERE name = @N) " +
                                "ALTER USER " + "[" + user.Replace("]", "]]") + "] WITH LOGIN = @N;";
                            link.Parameters.Add(new SqlParameter("@N", user));
                            await link.ExecuteNonQueryAsync();
                        }
                        catch (Exception ex)
                        {
                            _logger.LogWarning(ex, "Could not re-link user {User} in database {Db}.", user, dbName);
                        }
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Orphaned-user repair skipped for database {Db}.", dbName);
                }

                _logger.LogWarning("New database {Db} created from backup: {File}", dbName, fullPath);
                return new BackupResultDto { Success = true, Message = $"New database '{dbName}' created successfully from {Path.GetFileName(fullPath)}.", FileName = dbName };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Create database from backup failed.");
                return new BackupResultDto { Success = false, Message = "Could not create the database. Please try again." };
            }
        }
    }

    /// <summary>
    /// Takes a database backup every day at the configured time of day
    /// (DatabaseBackup:TimeOfDay, default 02:00) and once on startup when no
    /// backup exists yet for the current day. Runs inside the API process, so
    /// it keeps working under IIS as long as the application pool is running.
    /// </summary>
    public class DailyBackupHostedService : BackgroundService
    {
        private readonly IServiceProvider _services;
        private readonly ILogger<DailyBackupHostedService> _logger;

        public DailyBackupHostedService(IServiceProvider services, ILogger<DailyBackupHostedService> logger)
        {
            _services = services;
            _logger = logger;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            await TakeBackupIfNoneTodayAsync(stoppingToken);

            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    TimeSpan timeOfDay = new(2, 0, 0);
                    using (var scope = _services.CreateScope())
                    {
                        var config = scope.ServiceProvider.GetRequiredService<IConfiguration>();
                        var configured = config["DatabaseBackup:TimeOfDay"];
                        if (!string.IsNullOrWhiteSpace(configured) && TimeSpan.TryParse(configured, out var parsed))
                        {
                            timeOfDay = parsed;
                        }
                    }

                    var now = DateTime.Now;
                    var next = now.Date.Add(timeOfDay);
                    if (next <= now)
                    {
                        next = next.AddDays(1);
                    }

                    _logger.LogInformation("Next daily database backup scheduled at {Next}.", next);
                    await Task.Delay(next - now, stoppingToken);

                    using var backupScope = _services.CreateScope();
                    var backup = backupScope.ServiceProvider.GetRequiredService<IBackupService>();
                    var result = await backup.TakeBackupAsync();
                    _logger.LogInformation("Daily database backup finished: {Message}", result.Message);
                }
                catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
                {
                    break;
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Daily database backup failed; retrying at the next scheduled time.");
                    try
                    {
                        await Task.Delay(TimeSpan.FromHours(1), stoppingToken);
                    }
                    catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
                    {
                        break;
                    }
                }
            }
        }

        private async Task TakeBackupIfNoneTodayAsync(CancellationToken stoppingToken)
        {
            try
            {
                using var scope = _services.CreateScope();
                var backup = scope.ServiceProvider.GetRequiredService<IBackupService>();
                var today = DateTime.Today;
                if (!backup.ListBackups().Any(f => f.CreatedDate.Date == today))
                {
                    var result = await backup.TakeBackupAsync();
                    _logger.LogInformation("Startup database backup finished: {Message}", result.Message);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Startup database backup check failed.");
            }
            await Task.CompletedTask;
        }
    }
}

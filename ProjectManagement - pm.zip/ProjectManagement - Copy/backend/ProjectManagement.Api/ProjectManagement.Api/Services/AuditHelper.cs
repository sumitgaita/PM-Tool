using System.Security.Claims;
using Microsoft.Data.SqlClient;

namespace ProjectManagement.Api.Services;

// §107 Farming audit logging. Writes into the existing AuditLogs table via
// usp_AuditLog_Insert. Never throws: audit must not fail the operation.
public static class AuditHelper
{
    public static async Task LogAsync(
        IDatabaseService db,
        ILogger logger,
        int userId,
        string action,
        string module,
        object? recordId = null)
    {
        try
        {
            await db.ExecuteNonQueryAsync("usp_AuditLog_Insert", new[]
            {
                new SqlParameter("@UserId", userId),
                new SqlParameter("@Action", action),
                new SqlParameter("@Module", module),
                new SqlParameter("@RecordId", recordId?.ToString() ?? (object)DBNull.Value),
                new SqlParameter("@OldValue", DBNull.Value),
                new SqlParameter("@NewValue", DBNull.Value),
                new SqlParameter("@IPAddress", DBNull.Value)
            });
        }
        catch (Exception ex)
        {
            logger.LogWarning(ex, "Audit log write failed for {Module}/{Action}", module, action);
        }
    }

    public static int CurrentUserId(ClaimsPrincipal user)
    {
        var id = user.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        return int.TryParse(id, out var userId) ? userId : 0;
    }
}

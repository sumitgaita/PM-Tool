using System.Security.Cryptography;
using System.Text;

namespace ProjectManagement.Api.Services;

/// <summary>
/// Reversible AES-256-CBC password protection used ONLY so Super Admin can
/// view original passwords on the Users grid. Authentication still uses the
/// one-way SHA256 hash. Wire format: "v1." + Base64(IV | Ciphertext).
/// NOTE: reversible storage is weaker than hashing. Localhost use only.
/// </summary>
public static class PasswordCrypto
{
    private const string Prefix = "v1.";

    public static string Encrypt(string plainText, byte[] key)
    {
        if (plainText is null) throw new ArgumentNullException(nameof(plainText));
        if (key is null || key.Length != 32) throw new ArgumentException("Encryption key must be 32 bytes.", nameof(key));
        using var aes = Aes.Create();
        aes.Key = key;
        aes.GenerateIV();
        using var encryptor = aes.CreateEncryptor();
        var plain = Encoding.UTF8.GetBytes(plainText);
        var cipher = encryptor.TransformFinalBlock(plain, 0, plain.Length);
        var combined = new byte[aes.IV.Length + cipher.Length];
        Buffer.BlockCopy(aes.IV, 0, combined, 0, aes.IV.Length);
        Buffer.BlockCopy(cipher, 0, combined, aes.IV.Length, cipher.Length);
        return Prefix + Convert.ToBase64String(combined);
    }

    public static bool TryDecrypt(string? cipherText, byte[]? key, out string? plainText)
    {
        plainText = null;
        try
        {
            if (string.IsNullOrEmpty(cipherText) || key is null || key.Length != 32) return false;
            if (!cipherText.StartsWith(Prefix, StringComparison.Ordinal)) return false;
            var combined = Convert.FromBase64String(cipherText.Substring(Prefix.Length));
            if (combined.Length <= 16) return false;
            var iv = new byte[16];
            var cipher = new byte[combined.Length - 16];
            Buffer.BlockCopy(combined, 0, iv, 0, 16);
            Buffer.BlockCopy(combined, 16, cipher, 0, cipher.Length);
            using var aes = Aes.Create();
            aes.Key = key;
            aes.IV = iv;
            using var decryptor = aes.CreateDecryptor();
            var plain = decryptor.TransformFinalBlock(cipher, 0, cipher.Length);
            plainText = Encoding.UTF8.GetString(plain);
            return true;
        }
        catch
        {
            return false;
        }
    }

    public static byte[]? GetKey(IConfiguration configuration)
    {
        try
        {
            var raw = configuration["Security:PasswordEncryptionKey"];
            if (string.IsNullOrWhiteSpace(raw)) return null;
            var key = Convert.FromBase64String(raw);
            return key.Length == 32 ? key : null;
        }
        catch
        {
            return null;
        }
    }
}

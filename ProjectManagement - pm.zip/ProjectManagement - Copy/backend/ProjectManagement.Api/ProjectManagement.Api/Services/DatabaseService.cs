using System.Data;
using Microsoft.Data.SqlClient;
using ProjectManagement.Api.DTOs;

namespace ProjectManagement.Api.Services
{
    public interface IDatabaseService
    {
        Task<SqlConnection> GetConnectionAsync();
        Task<List<T>> ExecuteStoredProcedureAsync<T>(string procedureName, SqlParameter[]? parameters = null) where T : new();
        Task<(List<T> Items, Dictionary<string, object?> Outputs)> ExecuteStoredProcedureWithOutputsAsync<T>(string procedureName, SqlParameter[]? parameters = null) where T : new();
        Task<T?> ExecuteScalarAsync<T>(string procedureName, SqlParameter[]? parameters = null);
        Task<int> ExecuteNonQueryAsync(string procedureName, SqlParameter[]? parameters = null);
        Task<DataTable> ExecuteStoredProcedureDataTableAsync(string procedureName, SqlParameter[]? parameters = null);
    }

    public class DatabaseService : IDatabaseService
    {
        private readonly string _connectionString;
        private readonly ILogger<DatabaseService> _logger;

        public DatabaseService(IConfiguration configuration, ILogger<DatabaseService> logger)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection") ?? string.Empty;
            _logger = logger;
        }

        public async Task<SqlConnection> GetConnectionAsync()
        {
            var connection = new SqlConnection(_connectionString);
            await connection.OpenAsync();
            return connection;
        }

        public async Task<List<T>> ExecuteStoredProcedureAsync<T>(string procedureName, SqlParameter[]? parameters = null) where T : new()
        {
            var results = new List<T>();

            try
            {
                using var connection = await GetConnectionAsync();
                using var command = new SqlCommand(procedureName, connection)
                {
                    CommandType = CommandType.StoredProcedure
                };

                if (parameters != null)
                {
                    command.Parameters.AddRange(parameters);
                }

                using var reader = await command.ExecuteReaderAsync();
                var properties = typeof(T).GetProperties();

                while (await reader.ReadAsync())
                {
                    var item = new T();
                    foreach (var property in properties)
                    {
                        if (reader.HasColumn(property.Name) && !reader.IsDBNull(property.Name))
                        {
                            var value = reader[property.Name];
                            if (value != DBNull.Value)
                            {
                                var targetType = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                                property.SetValue(item, Convert.ChangeType(value, targetType));
                            }
                        }
                    }
                    results.Add(item);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error executing stored procedure: {ProcedureName}", procedureName);
                throw;
            }

            return results;
        }

        public async Task<(List<T> Items, Dictionary<string, object?> Outputs)> ExecuteStoredProcedureWithOutputsAsync<T>(string procedureName, SqlParameter[]? parameters = null) where T : new()
        {
            var results = new List<T>();
            var outputs = new Dictionary<string, object?>(StringComparer.OrdinalIgnoreCase);

            try
            {
                using var connection = await GetConnectionAsync();
                using var command = new SqlCommand(procedureName, connection)
                {
                    CommandType = CommandType.StoredProcedure
                };

                if (parameters != null)
                {
                    command.Parameters.AddRange(parameters);
                }

                using (var reader = await command.ExecuteReaderAsync())
                {
                    var properties = typeof(T).GetProperties();

                    while (await reader.ReadAsync())
                    {
                        var item = new T();
                        foreach (var property in properties)
                        {
                            if (reader.HasColumn(property.Name) && !reader.IsDBNull(property.Name))
                            {
                                var value = reader[property.Name];
                                if (value != DBNull.Value)
                                {
                                    var targetType = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                                    property.SetValue(item, Convert.ChangeType(value, targetType));
                                }
                            }
                        }
                        results.Add(item);
                    }

                    await reader.CloseAsync();
                }

                if (parameters != null)
                {
                    foreach (var parameter in command.Parameters.Cast<SqlParameter>())
                    {
                        if (parameter.Direction == ParameterDirection.Output
                            || parameter.Direction == ParameterDirection.InputOutput
                            || parameter.Direction == ParameterDirection.ReturnValue)
                        {
                            outputs[parameter.ParameterName.TrimStart('@')] = parameter.Value == DBNull.Value ? null : parameter.Value;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error executing stored procedure: {ProcedureName}", procedureName);
                throw;
            }

            return (results, outputs);
        }

        public async Task<T?> ExecuteScalarAsync<T>(string procedureName, SqlParameter[]? parameters = null)
        {
            try
            {
                using var connection = await GetConnectionAsync();
                using var command = new SqlCommand(procedureName, connection)
                {
                    CommandType = CommandType.StoredProcedure
                };

                if (parameters != null)
                {
                    command.Parameters.AddRange(parameters);
                }

                var result = await command.ExecuteScalarAsync();
                if (result == null || result == DBNull.Value)
                {
                    return default;
                }

                return (T)Convert.ChangeType(result, typeof(T));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error executing scalar stored procedure: {ProcedureName}", procedureName);
                throw;
            }
        }

        public async Task<int> ExecuteNonQueryAsync(string procedureName, SqlParameter[]? parameters = null)
        {
            try
            {
                using var connection = await GetConnectionAsync();
                using var command = new SqlCommand(procedureName, connection)
                {
                    CommandType = CommandType.StoredProcedure
                };

                if (parameters != null)
                {
                    command.Parameters.AddRange(parameters);
                }

                return await command.ExecuteNonQueryAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error executing non-query stored procedure: {ProcedureName}", procedureName);
                throw;
            }
        }

        public async Task<DataTable> ExecuteStoredProcedureDataTableAsync(string procedureName, SqlParameter[]? parameters = null)
        {
            var dataTable = new DataTable();

            try
            {
                using var connection = await GetConnectionAsync();
                using var command = new SqlCommand(procedureName, connection)
                {
                    CommandType = CommandType.StoredProcedure
                };

                if (parameters != null)
                {
                    command.Parameters.AddRange(parameters);
                }

                using var reader = await command.ExecuteReaderAsync();
                dataTable.Load(reader);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error executing stored procedure: {ProcedureName}", procedureName);
                throw;
            }

            return dataTable;
        }
    }

    public static class SqlDataReaderExtensions
    {
        public static bool HasColumn(this SqlDataReader reader, string columnName)
        {
            for (int i = 0; i < reader.FieldCount; i++)
            {
                if (reader.GetName(i).Equals(columnName, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }
            return false;
        }
    }
}

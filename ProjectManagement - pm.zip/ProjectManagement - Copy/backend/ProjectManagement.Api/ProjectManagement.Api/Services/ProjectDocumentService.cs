using System.Security.Claims;
using Microsoft.Data.SqlClient;
using ProjectManagement.Api.DTOs;

namespace ProjectManagement.Api.Services
{
    public interface IDocumentService
    {
        Task<List<DocumentProjectDto>> GetAccessibleProjectsAsync(ClaimsPrincipal user);
        Task<string> ResolveProjectFolderAsync(ClaimsPrincipal user, int projectId);
        IReadOnlyList<DocumentFileDto> ListDocuments(string folder);
        string ResolveDocumentPath(string folder, string fileName);
        string GetContentType(string fileName);
        Task<DocumentFileDto> SaveDocumentAsync(string folder, string fileName, Stream content, long length);
    }

    public class ProjectDocumentService : IDocumentService
    {
        private static readonly HashSet<string> AllowedExtensions = new(StringComparer.OrdinalIgnoreCase)
        {
            ".pdf", ".doc", ".docx", ".xls", ".xlsx",
            ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp"
        };

        private static readonly Dictionary<string, string> ContentTypes = new(StringComparer.OrdinalIgnoreCase)
        {
            [".pdf"] = "application/pdf",
            [".doc"] = "application/msword",
            [".docx"] = "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            [".xls"] = "application/vnd.ms-excel",
            [".xlsx"] = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            [".jpg"] = "image/jpeg",
            [".jpeg"] = "image/jpeg",
            [".png"] = "image/png",
            [".gif"] = "image/gif",
            [".bmp"] = "image/bmp",
            [".webp"] = "image/webp"
        };

        private static readonly HashSet<string> ReservedNames = new(StringComparer.OrdinalIgnoreCase)
        {
            "CON", "PRN", "AUX", "NUL",
            "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9",
            "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9"
        };

        private readonly IDatabaseService _databaseService;
        private readonly string _root;
        private readonly long _maxFileBytes;
        private readonly ILogger<ProjectDocumentService> _logger;

        public ProjectDocumentService(
            IDatabaseService databaseService, IConfiguration configuration, ILogger<ProjectDocumentService> logger)
        {
            _databaseService = databaseService;
            _root = configuration["DocumentStore:Folder"]
                ?? Path.Combine(AppContext.BaseDirectory, "..", "Document");
            var maxMb = 25;
            if (int.TryParse(configuration["DocumentStore:MaxFileMB"], out var parsed) && parsed > 0 && parsed <= 200)
            {
                maxMb = parsed;
            }
            _maxFileBytes = maxMb * 1024L * 1024L;
            _logger = logger;
        }

        public async Task<List<DocumentProjectDto>> GetAccessibleProjectsAsync(ClaimsPrincipal user)
        {
            List<ProjectDto> projects;
            if (ProjectAccessHelper.IsSuperAdmin(user))
            {
                projects = await _databaseService.ExecuteStoredProcedureAsync<ProjectDto>("usp_Project_GetAll");
            }
            else
            {
                projects = await _databaseService.ExecuteStoredProcedureAsync<ProjectDto>(
                    "usp_UserProject_GetMyProjects",
                    new[] { new SqlParameter("@UserId", ProjectAccessHelper.CurrentUserId(user)) });
            }

            return projects
                .Where(p => p.IsActive)
                .OrderBy(p => p.ProjectName)
                .Select(p => new DocumentProjectDto
                {
                    ProjectId = p.ProjectId,
                    ProjectCode = p.ProjectCode,
                    ProjectName = p.ProjectName
                })
                .ToList();
        }

        public async Task<string> ResolveProjectFolderAsync(ClaimsPrincipal user, int projectId)
        {
            var projects = await GetAccessibleProjectsAsync(user);
            var project = projects.FirstOrDefault(p => p.ProjectId == projectId);
            if (project is null)
            {
                throw new UnauthorizedAccessException(ProjectAccessHelper.DeniedMessage);
            }

            // Folder per project NAME; a colliding sanitized name is
            // disambiguated with the project code so files never mix.
            var groups = projects
                .GroupBy(p => SanitizeFolderName(p.ProjectName))
                .ToDictionary(g => g.Key, g => g.Count(), StringComparer.OrdinalIgnoreCase);
            var folderName = SanitizeFolderName(project.ProjectName);
            if (groups.TryGetValue(folderName, out var count) && count > 1)
            {
                folderName = SanitizeFolderName($"{project.ProjectName} ({project.ProjectCode})");
            }

            var folder = Path.GetFullPath(Path.Combine(_root, folderName));
            Directory.CreateDirectory(folder);
            return folder;
        }

        public IReadOnlyList<DocumentFileDto> ListDocuments(string folder)
        {
            if (!Directory.Exists(folder))
            {
                return Array.Empty<DocumentFileDto>();
            }

            return Directory.GetFiles(folder)
                .Select(p => new FileInfo(p))
                .Where(f => AllowedExtensions.Contains(f.Extension))
                .OrderByDescending(f => f.CreationTime)
                .Select(f => new DocumentFileDto
                {
                    FileName = f.Name,
                    SizeBytes = f.Length,
                    CreatedDate = f.CreationTime
                })
                .ToList();
        }

        public string ResolveDocumentPath(string folder, string fileName)
        {
            var safeName = ValidateFileName(fileName);
            var root = Path.GetFullPath(folder);
            var fullPath = Path.GetFullPath(Path.Combine(folder, safeName));
            if (!fullPath.StartsWith(root + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase)
                || !File.Exists(fullPath))
            {
                throw new FileNotFoundException("Document not found.", safeName);
            }
            return fullPath;
        }

        public string GetContentType(string fileName)
        {
            var ext = Path.GetExtension(fileName ?? string.Empty);
            return ContentTypes.TryGetValue(ext, out var mime) ? mime : "application/octet-stream";
        }

        public async Task<DocumentFileDto> SaveDocumentAsync(string folder, string fileName, Stream content, long length)
        {
            var safeName = ValidateFileName(fileName);
            if (length <= 0)
            {
                throw new ArgumentException("The uploaded file is empty.");
            }
            if (length > _maxFileBytes)
            {
                throw new ArgumentException($"File size exceeds the {_maxFileBytes / (1024 * 1024)} MB limit.");
            }

            Directory.CreateDirectory(folder);
            var target = Path.GetFullPath(Path.Combine(folder, safeName));
            var root = Path.GetFullPath(folder);
            if (!target.StartsWith(root + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
            {
                throw new ArgumentException("Invalid file name.");
            }

            // Never overwrite: suffix duplicates so uploads are never lost.
            target = NextAvailablePath(target);

            await using (var output = File.Create(target))
            {
                await content.CopyToAsync(output);
            }

            var info = new FileInfo(target);
            _logger.LogInformation("Project document uploaded: {File}", target);
            return new DocumentFileDto
            {
                FileName = info.Name,
                SizeBytes = info.Length,
                CreatedDate = info.CreationTime
            };
        }

        private static string ValidateFileName(string? fileName)
        {
            var safeName = Path.GetFileName((fileName ?? string.Empty).Trim());
            if (string.IsNullOrWhiteSpace(safeName) || safeName.Length > 200)
            {
                throw new ArgumentException("Invalid file name.");
            }
            if (safeName.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0)
            {
                throw new ArgumentException("Invalid file name.");
            }
            if (!AllowedExtensions.Contains(Path.GetExtension(safeName)))
            {
                throw new ArgumentException("File type not allowed. Allowed: PDF, Word, Excel and images.");
            }
            return safeName;
        }

        private static string NextAvailablePath(string target)
        {
            if (!File.Exists(target)) return target;
            var dir = Path.GetDirectoryName(target)!;
            var name = Path.GetFileNameWithoutExtension(target);
            var ext = Path.GetExtension(target);
            for (var i = 1; i < 1000; i++)
            {
                var candidate = Path.Combine(dir, $"{name} ({i}){ext}");
                if (!File.Exists(candidate)) return candidate;
            }
            throw new IOException("Too many files with the same name.");
        }

        internal static string SanitizeFolderName(string projectName)
        {
            var name = (projectName ?? string.Empty).Trim();
            foreach (var c in Path.GetInvalidFileNameChars())
            {
                name = name.Replace(c, '_');
            }
            name = name.Trim().TrimEnd('.');
            if (string.IsNullOrWhiteSpace(name)) return "Project_Unknown";
            if (ReservedNames.Contains(name)) return "_" + name;
            return name.Length > 100 ? name[..100] : name;
        }
    }
}

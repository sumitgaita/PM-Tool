using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Data.SqlClient;
using ProjectManagement.Api.Services;

namespace ProjectManagement.Api.Authorization;

/// <summary>Requires page-level permission. Admin bypasses. Usage: [RequirePermission("Projects","View")]</summary>
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true)]
public class RequirePermissionAttribute : Attribute, IAsyncAuthorizationFilter
{
    private readonly string _page;
    private readonly string _action; // View | Edit | Delete
    public RequirePermissionAttribute(string page, string action = "View")
    { _page = page; _action = action; }

    public async Task OnAuthorizationAsync(AuthorizationFilterContext context)
    {
        var user = context.HttpContext.User;
        if (user?.Identity?.IsAuthenticated != true) { context.Result = new UnauthorizedResult(); return; }
        var role = user.FindFirst(ClaimTypes.Role)?.Value;
        if (string.Equals(role, "Admin", StringComparison.OrdinalIgnoreCase)
            || string.Equals(role, "Super Admin", StringComparison.OrdinalIgnoreCase)) return;

        var userIdStr = user.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        if (!int.TryParse(userIdStr, out var userId)) { context.Result = new ForbidResult(); return; }

        var db = context.HttpContext.RequestServices.GetService<IDatabaseService>();
        if (db == null) { context.Result = new StatusCodeResult(500); return; }

        try
        {
            await using var conn = await db.GetConnectionAsync();
            await using var cmd = conn.CreateCommand();
            cmd.CommandText = @"SELECT p.CanView, p.CanEdit, p.CanDelete, p.CanExport
                                FROM UserPermissions p INNER JOIN Pages pg ON pg.PageId = p.PageId
                                WHERE p.UserId = @U AND pg.PageName = @P";
            cmd.Parameters.Add(new SqlParameter("@U", userId));
            cmd.Parameters.Add(new SqlParameter("@P", _page));
            await using var r = await cmd.ExecuteReaderAsync();
            if (!await r.ReadAsync()) { context.Result = new ObjectResult(new { success = false, message = $"Access denied. No {_action} permission for {_page}." }) { StatusCode = 403 }; return; }
            bool allowed = _action.ToLower() switch
            {
                "view" => r.GetBoolean(0),
                "edit" or "add/edit" or "add" => r.GetBoolean(1),
                "delete" => r.GetBoolean(2),
                "export" => r.GetBoolean(3),
                _ => r.GetBoolean(0)
            };
            if (!allowed) context.Result = new ObjectResult(new { success = false, message = $"Access denied. No {_action} permission for {_page}." }) { StatusCode = 403 };
        }
        catch { context.Result = new StatusCodeResult(500); }
    }
}

using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace ProjectManagement.Api.Authorization;

/// <summary>Allows only Super Admin users. Usage: [RequireSuperAdmin]</summary>
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = false)]
public class RequireSuperAdminAttribute : Attribute, IAsyncAuthorizationFilter
{
    public Task OnAuthorizationAsync(AuthorizationFilterContext context)
    {
        var user = context.HttpContext.User;
        if (user?.Identity?.IsAuthenticated != true)
        {
            context.Result = new UnauthorizedResult();
            return Task.CompletedTask;
        }

        var role = user.FindFirst(ClaimTypes.Role)?.Value;
        if (!string.Equals(role, "Super Admin", StringComparison.OrdinalIgnoreCase))
        {
            context.Result = new ObjectResult(new { success = false, message = "Access denied. Super Admin only." }) { StatusCode = 403 };
        }

        return Task.CompletedTask;
    }
}

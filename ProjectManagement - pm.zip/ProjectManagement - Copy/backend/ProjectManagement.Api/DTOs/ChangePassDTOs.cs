namespace ProjectManagement.Api.DTOs
{
    public class SecurityQuestionDto
    {
        public int QuestionId { get; set; }
        public string QuestionCode { get; set; } = string.Empty;
        public string QuestionText { get; set; } = string.Empty;
    }

    public class SecurityAnswerDto
    {
        public int QuestionId { get; set; }
        public string Answer { get; set; } = string.Empty;
    }

    public class VerifySecurityAnswersRequest
    {
        public List<SecurityAnswerDto> Answers { get; set; } = new();
    }

    public class SuperAdminChangePassRequest
    {
        public List<SecurityAnswerDto> Answers { get; set; } = new();
        public string NewPassword { get; set; } = string.Empty;
        public string ConfirmPassword { get; set; } = string.Empty;
    }

    public class SecurityValidationDto
    {
        public bool IsValid { get; set; }
    }

    public class SuperAdminResetResultDto
    {
        public bool Success { get; set; }
        public string Message { get; set; } = string.Empty;
    }
}

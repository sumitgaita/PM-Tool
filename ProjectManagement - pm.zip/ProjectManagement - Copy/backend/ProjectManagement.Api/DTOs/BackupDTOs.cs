namespace ProjectManagement.Api.DTOs
{
    public class BackupFileDto
    {
        public string FileName { get; set; } = string.Empty;
        public long SizeBytes { get; set; }
        public DateTime CreatedDate { get; set; }
    }

    public class RestoreBackupRequest
    {
        public string FileName { get; set; } = string.Empty;
    }

    public class CreateDatabaseRequest
    {
        public string FileName { get; set; } = string.Empty;
        public string NewDatabaseName { get; set; } = string.Empty;
    }

    public class BackupResultDto
    {
        public bool Success { get; set; }
        public string Message { get; set; } = string.Empty;
        public string? FileName { get; set; }
    }
}

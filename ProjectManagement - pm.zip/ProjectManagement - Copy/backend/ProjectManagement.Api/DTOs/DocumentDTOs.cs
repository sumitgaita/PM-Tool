namespace ProjectManagement.Api.DTOs
{
    public class DocumentFileDto
    {
        public string FileName { get; set; } = string.Empty;
        public long SizeBytes { get; set; }
        public DateTime CreatedDate { get; set; }
    }

    public class DocumentProjectDto
    {
        public int ProjectId { get; set; }
        public string ProjectCode { get; set; } = string.Empty;
        public string ProjectName { get; set; } = string.Empty;
    }
}

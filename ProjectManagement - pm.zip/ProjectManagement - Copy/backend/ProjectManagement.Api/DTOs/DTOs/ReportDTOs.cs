namespace ProjectManagement.Api.DTOs
{
    public class ProjectWiseReportDto
    {
        public string ProjectCode { get; set; } = string.Empty;
        public string ProjectName { get; set; } = string.Empty;
        public string BudgetCode { get; set; } = string.Empty;
        public string BudgetCodeName { get; set; } = string.Empty;
        public string ResourceCode { get; set; } = string.Empty;
        public string ResourceName { get; set; } = string.Empty;
        public decimal Budget { get; set; }
        public decimal Expense { get; set; }
        public decimal Variance { get; set; }
        public decimal UtilizationPercent { get; set; }
    }

    public class DateWiseReportDto
    {
        public DateTime ExpenseDate { get; set; }
        public string ProjectCode { get; set; } = string.Empty;
        public string ProjectName { get; set; } = string.Empty;
        public string BudgetCode { get; set; } = string.Empty;
        public string BudgetCodeName { get; set; } = string.Empty;
        public string ResourceCode { get; set; } = string.Empty;
        public string ResourceName { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public string? Description { get; set; }
        public string? Remarks { get; set; }
    }

    public class DateRangeReportDto
    {
        public DateTime ExpenseDate { get; set; }
        public string ProjectCode { get; set; } = string.Empty;
        public string ProjectName { get; set; } = string.Empty;
        public string BudgetCode { get; set; } = string.Empty;
        public string BudgetCodeName { get; set; } = string.Empty;
        public string ResourceCode { get; set; } = string.Empty;
        public string ResourceName { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public string? Description { get; set; }
        public string? ReferenceNo { get; set; }
        public string? Remarks { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
    }

    public class CostVsBudgetReportDto
    {
        public string ProjectCode { get; set; } = string.Empty;
        public string ProjectName { get; set; } = string.Empty;
        public string BudgetCode { get; set; } = string.Empty;
        public string BudgetCodeName { get; set; } = string.Empty;
        public decimal BudgetAmount { get; set; }
        public decimal ActualCost { get; set; }
        public decimal RemainingBudget { get; set; }
        public decimal UtilizationPercent { get; set; }
        public decimal Variance { get; set; }
    }

    public class ReportFilterRequest
    {
        public int? ProjectId { get; set; }
        public int? BudgetCodeId { get; set; }
        public int? ResourceId { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
    }
}

namespace ProjectManagement.Api.DTOs
{
    public class DashboardSummaryDto
    {
        public int TotalProjects { get; set; }
        public int ActiveProjects { get; set; }
        public decimal TotalBudget { get; set; }
        public decimal TotalExpense { get; set; }
        public int ActiveResources { get; set; }
    }

    public class ProjectWiseExpenseDto
    {
        public int ProjectId { get; set; }
        public string ProjectCode { get; set; } = string.Empty;
        public string ProjectName { get; set; } = string.Empty;
        public decimal TotalExpense { get; set; }
    }

    public class BudgetCodeWiseExpenseDto
    {
        public int BudgetCodeId { get; set; }
        public string BudgetCode { get; set; } = string.Empty;
        public string BudgetCodeName { get; set; } = string.Empty;
        public decimal TotalExpense { get; set; }
    }

    public class MonthlyExpenseDto
    {
        public int ExpenseYear { get; set; }
        public int ExpenseMonth { get; set; }
        public string MonthName { get; set; } = string.Empty;
        public decimal TotalExpense { get; set; }
    }

    public class YearlyExpenseDto
    {
        public int ExpenseYear { get; set; }
        public decimal TotalExpense { get; set; }
    }

    public class ResourceWiseExpenseDto
    {
        public int ResourceId { get; set; }
        public string ResourceCode { get; set; } = string.Empty;
        public string ResourceName { get; set; } = string.Empty;
        public string ResourceType { get; set; } = string.Empty;
        public decimal TotalExpense { get; set; }
    }

    public class DashboardFilterRequest
    {
        public int? ProjectId { get; set; }
        public int? BudgetCodeId { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
    }
}

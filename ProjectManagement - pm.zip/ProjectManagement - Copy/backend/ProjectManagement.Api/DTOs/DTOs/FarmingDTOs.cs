namespace ProjectManagement.Api.DTOs;

// §68-§94 Farming DTOs. Property names match stored-procedure column
// names exactly (DatabaseService maps by name).

public class PondDto
{
    public int PondId { get; set; }
    public int ProjectId { get; set; }
    public string ProjectCode { get; set; } = string.Empty;
    public string ProjectName { get; set; } = string.Empty;
    public string PondCode { get; set; } = string.Empty;
    public string PondName { get; set; } = string.Empty;
    public decimal? Area { get; set; }
    public string? AreaUnit { get; set; }
    public string? Depth { get; set; }
    public decimal? WaterCapacity { get; set; }
    public string? PondType { get; set; }
    public string Status { get; set; } = "Active";
    public bool IsActive { get; set; }
    public int? CreatedBy { get; set; }
    public DateTime CreatedDate { get; set; }
    public int? ModifiedBy { get; set; }
    public DateTime? ModifiedDate { get; set; }
}

public class CreatePondRequest
{
    public int ProjectId { get; set; }
    public string PondCode { get; set; } = string.Empty;
    public string PondName { get; set; } = string.Empty;
    public decimal? Area { get; set; }
    public string? AreaUnit { get; set; }
    public string? Depth { get; set; }
    public decimal? WaterCapacity { get; set; }
    public string? PondType { get; set; }
    public string? Status { get; set; }
}

public class UpdatePondRequest : CreatePondRequest { }

public class FishTypeDto
{
    public int FishTypeId { get; set; }
    public string FishCode { get; set; } = string.Empty;
    public string FishName { get; set; } = string.Empty;
    public string? ScientificName { get; set; }
    public string? Description { get; set; }
    public bool IsActive { get; set; }
    public int? CreatedBy { get; set; }
    public DateTime CreatedDate { get; set; }
    public int? ModifiedBy { get; set; }
    public DateTime? ModifiedDate { get; set; }
}

public class CreateFishTypeRequest
{
    public string FishCode { get; set; } = string.Empty;
    public string FishName { get; set; } = string.Empty;
    public string? ScientificName { get; set; }
    public string? Description { get; set; }
}

public class UpdateFishTypeRequest : CreateFishTypeRequest { }

public class FishStockingDto
{
    public int StockingId { get; set; }
    public int PondId { get; set; }
    public string PondCode { get; set; } = string.Empty;
    public string PondName { get; set; } = string.Empty;
    public int ProjectId { get; set; }
    public int FishTypeId { get; set; }
    public string FishCode { get; set; } = string.Empty;
    public string FishName { get; set; } = string.Empty;
    public DateTime StockingDate { get; set; }
    public int Quantity { get; set; }
    public decimal? AverageWeight { get; set; }
    public decimal PurchaseRate { get; set; }
    public decimal TotalCost { get; set; }
    public string? Supplier { get; set; }
    public string? ReferenceNo { get; set; }
    public string? Remarks { get; set; }
    public int? CreatedBy { get; set; }
    public DateTime CreatedDate { get; set; }
    public int? ModifiedBy { get; set; }
    public DateTime? ModifiedDate { get; set; }
}

public class CreateFishStockingRequest
{
    public int PondId { get; set; }
    public int FishTypeId { get; set; }
    public DateTime StockingDate { get; set; }
    public int Quantity { get; set; }
    public decimal? AverageWeight { get; set; }
    public decimal? PurchaseRate { get; set; }
    public decimal? TotalCost { get; set; }
    public string? Supplier { get; set; }
    public string? ReferenceNo { get; set; }
    public string? Remarks { get; set; }
    public int? ExpProjectId { get; set; }
    public int? ExpBudgetCodeId { get; set; }
    public int? ExpResourceId { get; set; }
}

public class UpdateFishStockingRequest
{
    public DateTime StockingDate { get; set; }
    public int Quantity { get; set; }
    public decimal? AverageWeight { get; set; }
    public decimal? PurchaseRate { get; set; }
    public decimal? TotalCost { get; set; }
    public string? Supplier { get; set; }
    public string? ReferenceNo { get; set; }
    public string? Remarks { get; set; }
}

public class FishFeedDto
{
    public int FishFeedId { get; set; }
    public int PondId { get; set; }
    public string PondCode { get; set; } = string.Empty;
    public string PondName { get; set; } = string.Empty;
    public int ProjectId { get; set; }
    public DateTime FeedDate { get; set; }
    public string FeedType { get; set; } = string.Empty;
    public decimal Quantity { get; set; }
    public string? Unit { get; set; }
    public decimal Rate { get; set; }
    public decimal TotalCost { get; set; }
    public string? Remarks { get; set; }
    public int? CreatedBy { get; set; }
    public DateTime CreatedDate { get; set; }
    public int? ModifiedBy { get; set; }
    public DateTime? ModifiedDate { get; set; }
}

public class CreateFishFeedRequest
{
    public int PondId { get; set; }
    public DateTime FeedDate { get; set; }
    public string FeedType { get; set; } = string.Empty;
    public decimal Quantity { get; set; }
    public string? Unit { get; set; }
    public decimal? Rate { get; set; }
    public decimal? TotalCost { get; set; }
    public string? Remarks { get; set; }
    public int? ExpProjectId { get; set; }
    public int? ExpBudgetCodeId { get; set; }
    public int? ExpResourceId { get; set; }
}

public class UpdateFishFeedRequest
{
    public DateTime FeedDate { get; set; }
    public string FeedType { get; set; } = string.Empty;
    public decimal Quantity { get; set; }
    public string? Unit { get; set; }
    public decimal? Rate { get; set; }
    public decimal? TotalCost { get; set; }
    public string? Remarks { get; set; }
}

public class FishTreatmentDto
{
    public int TreatmentId { get; set; }
    public int PondId { get; set; }
    public string PondCode { get; set; } = string.Empty;
    public string PondName { get; set; } = string.Empty;
    public int ProjectId { get; set; }
    public DateTime TreatmentDate { get; set; }
    public string TreatmentType { get; set; } = string.Empty;
    public string? Medicine { get; set; }
    public decimal Quantity { get; set; }
    public string? Unit { get; set; }
    public decimal Cost { get; set; }
    public string? Reason { get; set; }
    public string? Remarks { get; set; }
    public int? CreatedBy { get; set; }
    public DateTime CreatedDate { get; set; }
    public int? ModifiedBy { get; set; }
    public DateTime? ModifiedDate { get; set; }
}

public class CreateFishTreatmentRequest
{
    public int PondId { get; set; }
    public DateTime TreatmentDate { get; set; }
    public string TreatmentType { get; set; } = string.Empty;
    public string? Medicine { get; set; }
    public decimal? Quantity { get; set; }
    public string? Unit { get; set; }
    public decimal? Cost { get; set; }
    public string? Reason { get; set; }
    public string? Remarks { get; set; }
    public int? ExpProjectId { get; set; }
    public int? ExpBudgetCodeId { get; set; }
    public int? ExpResourceId { get; set; }
}

public class UpdateFishTreatmentRequest
{
    public DateTime TreatmentDate { get; set; }
    public string TreatmentType { get; set; } = string.Empty;
    public string? Medicine { get; set; }
    public decimal? Quantity { get; set; }
    public string? Unit { get; set; }
    public decimal? Cost { get; set; }
    public string? Reason { get; set; }
    public string? Remarks { get; set; }
}

public class FishMortalityDto
{
    public int MortalityId { get; set; }
    public int PondId { get; set; }
    public string PondCode { get; set; } = string.Empty;
    public string PondName { get; set; } = string.Empty;
    public int ProjectId { get; set; }
    public int FishTypeId { get; set; }
    public string FishCode { get; set; } = string.Empty;
    public string FishName { get; set; } = string.Empty;
    public DateTime MortalityDate { get; set; }
    public int Quantity { get; set; }
    public string? Reason { get; set; }
    public string? Remarks { get; set; }
    public int? CreatedBy { get; set; }
    public DateTime CreatedDate { get; set; }
    public int? ModifiedBy { get; set; }
    public DateTime? ModifiedDate { get; set; }
}

public class CreateFishMortalityRequest
{
    public int PondId { get; set; }
    public int FishTypeId { get; set; }
    public DateTime MortalityDate { get; set; }
    public int Quantity { get; set; }
    public string? Reason { get; set; }
    public string? Remarks { get; set; }
}

public class UpdateFishMortalityRequest
{
    public DateTime MortalityDate { get; set; }
    public int Quantity { get; set; }
    public string? Reason { get; set; }
    public string? Remarks { get; set; }
}

public class FishGrowthDto
{
    public int GrowthId { get; set; }
    public int PondId { get; set; }
    public string PondCode { get; set; } = string.Empty;
    public string PondName { get; set; } = string.Empty;
    public int ProjectId { get; set; }
    public int FishTypeId { get; set; }
    public string FishCode { get; set; } = string.Empty;
    public string FishName { get; set; } = string.Empty;
    public DateTime SamplingDate { get; set; }
    public int SampleQuantity { get; set; }
    public decimal AverageWeight { get; set; }
    public string? Remarks { get; set; }
    public int? CreatedBy { get; set; }
    public DateTime CreatedDate { get; set; }
    public int? ModifiedBy { get; set; }
    public DateTime? ModifiedDate { get; set; }
}

public class CreateFishGrowthRequest
{
    public int PondId { get; set; }
    public int FishTypeId { get; set; }
    public DateTime SamplingDate { get; set; }
    public int SampleQuantity { get; set; }
    public decimal AverageWeight { get; set; }
    public string? Remarks { get; set; }
}

public class UpdateFishGrowthRequest
{
    public DateTime SamplingDate { get; set; }
    public int SampleQuantity { get; set; }
    public decimal AverageWeight { get; set; }
    public string? Remarks { get; set; }
}

public class FishHarvestDto
{
    public int HarvestId { get; set; }
    public int PondId { get; set; }
    public string PondCode { get; set; } = string.Empty;
    public string PondName { get; set; } = string.Empty;
    public int ProjectId { get; set; }
    public int FishTypeId { get; set; }
    public string FishCode { get; set; } = string.Empty;
    public string FishName { get; set; } = string.Empty;
    public DateTime HarvestDate { get; set; }
    public int Quantity { get; set; }
    public decimal TotalWeight { get; set; }
    public decimal? AverageWeight { get; set; }
    public decimal HarvestCost { get; set; }
    public string? Remarks { get; set; }
    public int? CreatedBy { get; set; }
    public DateTime CreatedDate { get; set; }
    public int? ModifiedBy { get; set; }
    public DateTime? ModifiedDate { get; set; }
}

public class CreateFishHarvestRequest
{
    public int PondId { get; set; }
    public int FishTypeId { get; set; }
    public DateTime HarvestDate { get; set; }
    public int Quantity { get; set; }
    public decimal? TotalWeight { get; set; }
    public decimal? HarvestCost { get; set; }
    public string? Remarks { get; set; }
}

public class UpdateFishHarvestRequest
{
    public DateTime HarvestDate { get; set; }
    public int Quantity { get; set; }
    public decimal? TotalWeight { get; set; }
    public decimal? HarvestCost { get; set; }
    public string? Remarks { get; set; }
}

public class FishSalesDto
{
    public int SaleId { get; set; }
    public int ProjectId { get; set; }
    public string ProjectCode { get; set; } = string.Empty;
    public string ProjectName { get; set; } = string.Empty;
    public int? HarvestId { get; set; }
    public int FishTypeId { get; set; }
    public string FishCode { get; set; } = string.Empty;
    public string FishName { get; set; } = string.Empty;
    public DateTime SaleDate { get; set; }
    public string CustomerName { get; set; } = string.Empty;
    public int Quantity { get; set; }
    public decimal TotalWeight { get; set; }
    public decimal Rate { get; set; }
    public decimal TotalAmount { get; set; }
    public string PaymentStatus { get; set; } = "Pending";
    public string? ReferenceNo { get; set; }
    public string? Remarks { get; set; }
    public int? CreatedBy { get; set; }
    public DateTime CreatedDate { get; set; }
    public int? ModifiedBy { get; set; }
    public DateTime? ModifiedDate { get; set; }
}

public class CreateFishSalesRequest
{
    public int ProjectId { get; set; }
    public int? HarvestId { get; set; }
    public int FishTypeId { get; set; }
    public DateTime SaleDate { get; set; }
    public string CustomerName { get; set; } = string.Empty;
    public int Quantity { get; set; }
    public decimal? TotalWeight { get; set; }
    public decimal? Rate { get; set; }
    public decimal? TotalAmount { get; set; }
    public string? PaymentStatus { get; set; }
    public string? ReferenceNo { get; set; }
    public string? Remarks { get; set; }
}

public class UpdateFishSalesRequest
{
    public DateTime SaleDate { get; set; }
    public string CustomerName { get; set; } = string.Empty;
    public int Quantity { get; set; }
    public decimal? TotalWeight { get; set; }
    public decimal? Rate { get; set; }
    public decimal? TotalAmount { get; set; }
    public string? PaymentStatus { get; set; }
    public string? ReferenceNo { get; set; }
    public string? Remarks { get; set; }
}

public class PoultryShedDto
{
    public int ShedId { get; set; }
    public int ProjectId { get; set; }
    public string ProjectCode { get; set; } = string.Empty;
    public string ProjectName { get; set; } = string.Empty;
    public string ShedCode { get; set; } = string.Empty;
    public string ShedName { get; set; } = string.Empty;
    public int Capacity { get; set; }
    public string? CapacityUnit { get; set; }
    public string? ShedType { get; set; }
    public string Status { get; set; } = "Active";
    public bool IsActive { get; set; }
    public int? CreatedBy { get; set; }
    public DateTime CreatedDate { get; set; }
    public int? ModifiedBy { get; set; }
    public DateTime? ModifiedDate { get; set; }
}

public class CreatePoultryShedRequest
{
    public int ProjectId { get; set; }
    public string ShedCode { get; set; } = string.Empty;
    public string ShedName { get; set; } = string.Empty;
    public int? Capacity { get; set; }
    public string? CapacityUnit { get; set; }
    public string? ShedType { get; set; }
    public string? Status { get; set; }
}

public class UpdatePoultryShedRequest : CreatePoultryShedRequest { }

public class PoultryBatchDto
{
    public int BatchId { get; set; }
    public int ProjectId { get; set; }
    public string ProjectCode { get; set; } = string.Empty;
    public string ProjectName { get; set; } = string.Empty;
    public int ShedId { get; set; }
    public string ShedCode { get; set; } = string.Empty;
    public string ShedName { get; set; } = string.Empty;
    public string BatchCode { get; set; } = string.Empty;
    public string BirdType { get; set; } = string.Empty;
    public DateTime StartDate { get; set; }
    public DateTime? ExpectedSaleDate { get; set; }
    public int InitialQuantity { get; set; }
    public decimal PurchaseCost { get; set; }
    public string Status { get; set; } = "Active";
    public string? Remarks { get; set; }
    public int? CreatedBy { get; set; }
    public DateTime CreatedDate { get; set; }
    public int? ModifiedBy { get; set; }
    public DateTime? ModifiedDate { get; set; }
}

public class CreatePoultryBatchRequest
{
    public int ProjectId { get; set; }
    public int ShedId { get; set; }
    public string BatchCode { get; set; } = string.Empty;
    public string BirdType { get; set; } = string.Empty;
    public DateTime StartDate { get; set; }
    public DateTime? ExpectedSaleDate { get; set; }
    public int InitialQuantity { get; set; }
    public decimal? PurchaseCost { get; set; }
    public string? Status { get; set; }
    public string? Remarks { get; set; }
}

public class UpdatePoultryBatchRequest
{
    public string BatchCode { get; set; } = string.Empty;
    public string BirdType { get; set; } = string.Empty;
    public DateTime StartDate { get; set; }
    public DateTime? ExpectedSaleDate { get; set; }
    public decimal? PurchaseCost { get; set; }
    public string? Status { get; set; }
    public string? Remarks { get; set; }
}

public class ChickPurchaseDto
{
    public int PurchaseId { get; set; }
    public int BatchId { get; set; }
    public string BatchCode { get; set; } = string.Empty;
    public int ProjectId { get; set; }
    public DateTime PurchaseDate { get; set; }
    public string? Supplier { get; set; }
    public int Quantity { get; set; }
    public decimal Rate { get; set; }
    public decimal TotalAmount { get; set; }
    public string? ReferenceNo { get; set; }
    public string? Remarks { get; set; }
    public int? CreatedBy { get; set; }
    public DateTime CreatedDate { get; set; }
    public int? ModifiedBy { get; set; }
    public DateTime? ModifiedDate { get; set; }
}

public class CreateChickPurchaseRequest
{
    public int BatchId { get; set; }
    public DateTime PurchaseDate { get; set; }
    public string? Supplier { get; set; }
    public int Quantity { get; set; }
    public decimal? Rate { get; set; }
    public string? ReferenceNo { get; set; }
    public string? Remarks { get; set; }
    public int? ExpProjectId { get; set; }
    public int? ExpBudgetCodeId { get; set; }
    public int? ExpResourceId { get; set; }
}

public class UpdateChickPurchaseRequest
{
    public DateTime PurchaseDate { get; set; }
    public string? Supplier { get; set; }
    public int Quantity { get; set; }
    public decimal? Rate { get; set; }
    public string? ReferenceNo { get; set; }
    public string? Remarks { get; set; }
}

public class PoultryFeedDto
{
    public int FeedId { get; set; }
    public int BatchId { get; set; }
    public string BatchCode { get; set; } = string.Empty;
    public int ProjectId { get; set; }
    public DateTime FeedDate { get; set; }
    public string FeedType { get; set; } = string.Empty;
    public decimal Quantity { get; set; }
    public string? Unit { get; set; }
    public decimal Rate { get; set; }
    public decimal TotalCost { get; set; }
    public string? Remarks { get; set; }
    public int? CreatedBy { get; set; }
    public DateTime CreatedDate { get; set; }
    public int? ModifiedBy { get; set; }
    public DateTime? ModifiedDate { get; set; }
}

public class CreatePoultryFeedRequest
{
    public int BatchId { get; set; }
    public DateTime FeedDate { get; set; }
    public string FeedType { get; set; } = string.Empty;
    public decimal Quantity { get; set; }
    public string? Unit { get; set; }
    public decimal? Rate { get; set; }
    public decimal? TotalCost { get; set; }
    public string? Remarks { get; set; }
    public int? ExpProjectId { get; set; }
    public int? ExpBudgetCodeId { get; set; }
    public int? ExpResourceId { get; set; }
}

public class UpdatePoultryFeedRequest
{
    public DateTime FeedDate { get; set; }
    public string FeedType { get; set; } = string.Empty;
    public decimal Quantity { get; set; }
    public string? Unit { get; set; }
    public decimal? Rate { get; set; }
    public decimal? TotalCost { get; set; }
    public string? Remarks { get; set; }
}

public class PoultryTreatmentDto
{
    public int TreatmentId { get; set; }
    public int BatchId { get; set; }
    public string BatchCode { get; set; } = string.Empty;
    public int ProjectId { get; set; }
    public DateTime TreatmentDate { get; set; }
    public string TreatmentType { get; set; } = string.Empty;
    public string? Medicine { get; set; }
    public decimal Quantity { get; set; }
    public decimal Cost { get; set; }
    public string? Reason { get; set; }
    public string? Remarks { get; set; }
    public int? CreatedBy { get; set; }
    public DateTime CreatedDate { get; set; }
    public int? ModifiedBy { get; set; }
    public DateTime? ModifiedDate { get; set; }
}

public class CreatePoultryTreatmentRequest
{
    public int BatchId { get; set; }
    public DateTime TreatmentDate { get; set; }
    public string TreatmentType { get; set; } = string.Empty;
    public string? Medicine { get; set; }
    public decimal? Quantity { get; set; }
    public decimal? Cost { get; set; }
    public string? Reason { get; set; }
    public string? Remarks { get; set; }
    public int? ExpProjectId { get; set; }
    public int? ExpBudgetCodeId { get; set; }
    public int? ExpResourceId { get; set; }
}

public class UpdatePoultryTreatmentRequest
{
    public DateTime TreatmentDate { get; set; }
    public string TreatmentType { get; set; } = string.Empty;
    public string? Medicine { get; set; }
    public decimal? Quantity { get; set; }
    public decimal? Cost { get; set; }
    public string? Reason { get; set; }
    public string? Remarks { get; set; }
}

public class PoultryMortalityDto
{
    public int MortalityId { get; set; }
    public int BatchId { get; set; }
    public string BatchCode { get; set; } = string.Empty;
    public int ProjectId { get; set; }
    public DateTime MortalityDate { get; set; }
    public int Quantity { get; set; }
    public string? Reason { get; set; }
    public string? Remarks { get; set; }
    public int? CreatedBy { get; set; }
    public DateTime CreatedDate { get; set; }
    public int? ModifiedBy { get; set; }
    public DateTime? ModifiedDate { get; set; }
}

public class CreatePoultryMortalityRequest
{
    public int BatchId { get; set; }
    public DateTime MortalityDate { get; set; }
    public int Quantity { get; set; }
    public string? Reason { get; set; }
    public string? Remarks { get; set; }
}

public class UpdatePoultryMortalityRequest
{
    public DateTime MortalityDate { get; set; }
    public int Quantity { get; set; }
    public string? Reason { get; set; }
    public string? Remarks { get; set; }
}

public class PoultryGrowthDto
{
    public int GrowthId { get; set; }
    public int BatchId { get; set; }
    public string BatchCode { get; set; } = string.Empty;
    public int ProjectId { get; set; }
    public DateTime SampleDate { get; set; }
    public int SampleQuantity { get; set; }
    public decimal AverageWeight { get; set; }
    public string? Remarks { get; set; }
    public int? CreatedBy { get; set; }
    public DateTime CreatedDate { get; set; }
    public int? ModifiedBy { get; set; }
    public DateTime? ModifiedDate { get; set; }
}

public class CreatePoultryGrowthRequest
{
    public int BatchId { get; set; }
    public DateTime SampleDate { get; set; }
    public int SampleQuantity { get; set; }
    public decimal AverageWeight { get; set; }
    public string? Remarks { get; set; }
}

public class UpdatePoultryGrowthRequest
{
    public DateTime SampleDate { get; set; }
    public int SampleQuantity { get; set; }
    public decimal AverageWeight { get; set; }
    public string? Remarks { get; set; }
}

public class EggProductionDto
{
    public int ProductionId { get; set; }
    public int BatchId { get; set; }
    public string BatchCode { get; set; } = string.Empty;
    public int ProjectId { get; set; }
    public DateTime ProductionDate { get; set; }
    public int GoodEggs { get; set; }
    public int BrokenEggs { get; set; }
    public int TotalEggs { get; set; }
    public string? Remarks { get; set; }
    public int? CreatedBy { get; set; }
    public DateTime CreatedDate { get; set; }
    public int? ModifiedBy { get; set; }
    public DateTime? ModifiedDate { get; set; }
}

public class CreateEggProductionRequest
{
    public int BatchId { get; set; }
    public DateTime ProductionDate { get; set; }
    public int? GoodEggs { get; set; }
    public int? BrokenEggs { get; set; }
    public string? Remarks { get; set; }
}

public class UpdateEggProductionRequest
{
    public DateTime ProductionDate { get; set; }
    public int? GoodEggs { get; set; }
    public int? BrokenEggs { get; set; }
    public string? Remarks { get; set; }
}

public class PoultrySalesDto
{
    public int SaleId { get; set; }
    public int ProjectId { get; set; }
    public string ProjectCode { get; set; } = string.Empty;
    public string ProjectName { get; set; } = string.Empty;
    public int? BatchId { get; set; }
    public string? BatchCode { get; set; }
    public DateTime SaleDate { get; set; }
    public string CustomerName { get; set; } = string.Empty;
    public int BirdQuantity { get; set; }
    public decimal TotalWeight { get; set; }
    public decimal Rate { get; set; }
    public decimal TotalAmount { get; set; }
    public string PaymentStatus { get; set; } = "Pending";
    public string? ReferenceNo { get; set; }
    public string? Remarks { get; set; }
    public int? CreatedBy { get; set; }
    public DateTime CreatedDate { get; set; }
    public int? ModifiedBy { get; set; }
    public DateTime? ModifiedDate { get; set; }
}

public class CreatePoultrySalesRequest
{
    public int ProjectId { get; set; }
    public int? BatchId { get; set; }
    public DateTime SaleDate { get; set; }
    public string CustomerName { get; set; } = string.Empty;
    public int BirdQuantity { get; set; }
    public decimal? TotalWeight { get; set; }
    public decimal? Rate { get; set; }
    public decimal? TotalAmount { get; set; }
    public string? PaymentStatus { get; set; }
    public string? ReferenceNo { get; set; }
    public string? Remarks { get; set; }
}

public class UpdatePoultrySalesRequest
{
    public DateTime SaleDate { get; set; }
    public string CustomerName { get; set; } = string.Empty;
    public int BirdQuantity { get; set; }
    public decimal? TotalWeight { get; set; }
    public decimal? Rate { get; set; }
    public decimal? TotalAmount { get; set; }
    public string? PaymentStatus { get; set; }
    public string? ReferenceNo { get; set; }
    public string? Remarks { get; set; }
}

public class RevenueDto
{
    public int RevenueId { get; set; }
    public DateTime RevenueDate { get; set; }
    public int ProjectId { get; set; }
    public string ProjectCode { get; set; } = string.Empty;
    public string ProjectName { get; set; } = string.Empty;
    public string? FarmType { get; set; }
    public string RevenueType { get; set; } = string.Empty;
    public int? ReferenceId { get; set; }
    public string? CustomerName { get; set; }
    public decimal Quantity { get; set; }
    public decimal Weight { get; set; }
    public decimal Rate { get; set; }
    public decimal Amount { get; set; }
    public string PaymentStatus { get; set; } = "Pending";
    public string? Remarks { get; set; }
    public int? CreatedBy { get; set; }
    public DateTime CreatedDate { get; set; }
    public int? ModifiedBy { get; set; }
    public DateTime? ModifiedDate { get; set; }
}

public class CreateRevenueRequest
{
    public DateTime RevenueDate { get; set; }
    public int ProjectId { get; set; }
    public string? FarmType { get; set; }
    public string RevenueType { get; set; } = string.Empty;
    public int? ReferenceId { get; set; }
    public string? CustomerName { get; set; }
    public decimal? Quantity { get; set; }
    public decimal? Weight { get; set; }
    public decimal? Rate { get; set; }
    public decimal Amount { get; set; }
    public string? PaymentStatus { get; set; }
    public string? Remarks { get; set; }
}

public class UpdateRevenueRequest
{
    public DateTime RevenueDate { get; set; }
    public string RevenueType { get; set; } = string.Empty;
    public string? CustomerName { get; set; }
    public decimal? Quantity { get; set; }
    public decimal? Weight { get; set; }
    public decimal? Rate { get; set; }
    public decimal Amount { get; set; }
    public string? PaymentStatus { get; set; }
    public string? Remarks { get; set; }
}

// Dashboard / report row shapes (property names match proc columns).
public class FarmDashboardSummaryDto
{
    public decimal TotalRevenue { get; set; }
    public decimal TotalExpense { get; set; }
    public int TotalPonds { get; set; }
    public int ActivePonds { get; set; }
    public int TotalSheds { get; set; }
    public int ActiveBatches { get; set; }
}

public class FishDashboardKpisDto
{
    public int ActivePonds { get; set; }
    public int TotalStocked { get; set; }
    public int CurrentStock { get; set; }
    public int TotalMortality { get; set; }
    public int TotalHarvest { get; set; }
    public decimal TotalHarvestWeight { get; set; }
    public decimal FeedCost { get; set; }
    public decimal TreatmentCost { get; set; }
    public decimal FishRevenue { get; set; }
}

public class PoultryDashboardKpisDto
{
    public int ActiveSheds { get; set; }
    public int ActiveBatches { get; set; }
    public int TotalBirds { get; set; }
    public int CurrentBirds { get; set; }
    public int TotalMortality { get; set; }
    public decimal TotalFeed { get; set; }
    public decimal FeedCost { get; set; }
    public int TotalEggs { get; set; }
    public int GoodEggs { get; set; }
    public int BrokenEggs { get; set; }
    public int BirdSales { get; set; }
    public decimal PoultryRevenue { get; set; }
}

public class FarmMonthlyDto
{
    public string YearMonth { get; set; } = string.Empty;
    public decimal Revenue { get; set; }
    public decimal Expense { get; set; }
}

public class FishTypeWiseDto
{
    public string FishName { get; set; } = string.Empty;
    public int StockedQuantity { get; set; }
    public int MortalityQuantity { get; set; }
    public int HarvestQuantity { get; set; }
    public int CurrentStock { get; set; }
}

public class FishPondWiseDto
{
    public string PondCode { get; set; } = string.Empty;
    public string PondName { get; set; } = string.Empty;
    public decimal OperationalCost { get; set; }
    public decimal LinkedExpense { get; set; }
}

public class PoultryBatchWiseDto
{
    public string BatchCode { get; set; } = string.Empty;
    public string BirdType { get; set; } = string.Empty;
    public int InitialQuantity { get; set; }
    public int MortalityQuantity { get; set; }
    public int SoldQuantity { get; set; }
    public int CurrentBirds { get; set; }
    public decimal FeedCost { get; set; }
    public int TotalEggs { get; set; }
}

public class EggSeriesDto
{
    public DateTime ProductionDate { get; set; }
    public int GoodEggs { get; set; }
    public int BrokenEggs { get; set; }
    public int TotalEggs { get; set; }
}

public class FarmWiseReportDto
{
    public string? FarmType { get; set; }
    public int ProjectId { get; set; }
    public string ProjectCode { get; set; } = string.Empty;
    public string ProjectName { get; set; } = string.Empty;
    public decimal TotalBudget { get; set; }
    public decimal TotalExpense { get; set; }
    public decimal TotalRevenue { get; set; }
    public decimal Profit { get; set; }
    public decimal ProfitPercent { get; set; }
}

public class FishReportDto
{
    public int ProjectId { get; set; }
    public string ProjectCode { get; set; } = string.Empty;
    public string ProjectName { get; set; } = string.Empty;
    public int PondId { get; set; }
    public string PondCode { get; set; } = string.Empty;
    public string PondName { get; set; } = string.Empty;
    public int FishTypeId { get; set; }
    public string FishName { get; set; } = string.Empty;
    public int StockedQuantity { get; set; }
    public int Mortality { get; set; }
    public int CurrentStock { get; set; }
    public int HarvestQuantity { get; set; }
    public decimal HarvestWeight { get; set; }
    public decimal Sales { get; set; }
    public decimal Expense { get; set; }
}

public class PoultryReportDto
{
    public int ProjectId { get; set; }
    public string ProjectCode { get; set; } = string.Empty;
    public string ProjectName { get; set; } = string.Empty;
    public int ShedId { get; set; }
    public string ShedCode { get; set; } = string.Empty;
    public string ShedName { get; set; } = string.Empty;
    public int BatchId { get; set; }
    public string BatchCode { get; set; } = string.Empty;
    public string BirdType { get; set; } = string.Empty;
    public int InitialQuantity { get; set; }
    public int Mortality { get; set; }
    public int CurrentBirds { get; set; }
    public decimal FeedCost { get; set; }
    public decimal? LatestAvgWeight { get; set; }
    public int Eggs { get; set; }
    public int BirdSales { get; set; }
    public decimal BirdRevenue { get; set; }
    public decimal Expense { get; set; }
}

public class FeedReportDto
{
    public string FarmType { get; set; } = string.Empty;
    public int ProjectId { get; set; }
    public string ProjectName { get; set; } = string.Empty;
    public int EntityId { get; set; }
    public string EntityCode { get; set; } = string.Empty;
    public DateTime TxnDate { get; set; }
    public string FeedType { get; set; } = string.Empty;
    public decimal Quantity { get; set; }
    public string? Unit { get; set; }
    public decimal Rate { get; set; }
    public decimal TotalCost { get; set; }
}

public class MortalityReportDto
{
    public string FarmType { get; set; } = string.Empty;
    public int ProjectId { get; set; }
    public string ProjectName { get; set; } = string.Empty;
    public int EntityId { get; set; }
    public string EntityCode { get; set; } = string.Empty;
    public string? SubType { get; set; }
    public DateTime TxnDate { get; set; }
    public int Quantity { get; set; }
    public string? Reason { get; set; }
}

public class ProfitabilityDto
{
    public decimal TotalRevenue { get; set; }
    public decimal TotalExpense { get; set; }
    public decimal FishRevenue { get; set; }
    public decimal PoultryRevenue { get; set; }
    public decimal EggRevenue { get; set; }
}

public class FarmCostVsBudgetDto
{
    public int ProjectId { get; set; }
    public string ProjectCode { get; set; } = string.Empty;
    public string ProjectName { get; set; } = string.Empty;
    public string? FarmType { get; set; }
    public decimal TotalBudget { get; set; }
    public decimal ActualExpense { get; set; }
    public decimal OperationalCost { get; set; }
}

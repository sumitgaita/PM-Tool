namespace ProjectManagement.Api.DTOs
{
    public class UserProjectDto
    {
        public int ProjectId { get; set; }
        public string ProjectCode { get; set; } = string.Empty;
        public string ProjectName { get; set; } = string.Empty;
        public string Status { get; set; } = string.Empty;
        public string? FarmType { get; set; }
        public bool IsActive { get; set; }
        public bool IsAssigned { get; set; }
        public DateTime? AssignedDate { get; set; }
    }

    public class AssignedProjectIdDto
    {
        public int ProjectId { get; set; }
    }

    public class EntityProjectDto
    {
        public int ProjectId { get; set; }
    }

    public class SaveUserProjectsBulkRequest
    {
        public int UserId { get; set; }
        public List<int> ProjectIds { get; set; } = new();
    }
}

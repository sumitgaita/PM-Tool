namespace ProjectManagement.Api.DTOs
{
    public class ExpenseDto
    {
        public int ExpenseId { get; set; }
        public DateTime ExpenseDate { get; set; }
        public int ProjectId { get; set; }
        public string ProjectCode { get; set; } = string.Empty;
        public string ProjectName { get; set; } = string.Empty;
        public int BudgetCodeId { get; set; }
        public string BudgetCode { get; set; } = string.Empty;
        public string BudgetCodeName { get; set; } = string.Empty;
        public int ResourceId { get; set; }
        public string ResourceCode { get; set; } = string.Empty;
        public string ResourceName { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public string? Description { get; set; }
        public string? ReferenceNo { get; set; }
        public string? Remarks { get; set; }
        public string? FarmType { get; set; }
        public string? FarmEntityType { get; set; }
        public int? FarmEntityId { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
    }

    public class CreateExpenseRequest
    {
        public DateTime ExpenseDate { get; set; }
        public int ProjectId { get; set; }
        public int BudgetCodeId { get; set; }
        public int ResourceId { get; set; }
        public decimal Amount { get; set; }
        public string? Description { get; set; }
        public string? ReferenceNo { get; set; }
        public string? Remarks { get; set; }
        public string? FarmType { get; set; }
        public string? FarmEntityType { get; set; }
        public int? FarmEntityId { get; set; }
    }

    public class UpdateExpenseRequest
    {
        public int ExpenseId { get; set; }
        public DateTime ExpenseDate { get; set; }
        public int ProjectId { get; set; }
        public int BudgetCodeId { get; set; }
        public int ResourceId { get; set; }
        public decimal Amount { get; set; }
        public string? Description { get; set; }
        public string? ReferenceNo { get; set; }
        public string? Remarks { get; set; }
        public string? FarmType { get; set; }
        public string? FarmEntityType { get; set; }
        public int? FarmEntityId { get; set; }
    }

    public class CopyExpenseRequest
    {
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public int? ProjectId { get; set; }
        public int? ResourceId { get; set; }
    }
}

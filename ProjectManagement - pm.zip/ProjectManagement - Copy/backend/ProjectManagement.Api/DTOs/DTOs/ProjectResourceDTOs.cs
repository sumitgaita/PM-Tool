namespace ProjectManagement.Api.DTOs
{
    public class ProjectResourceDto
    {
        public int ProjectResourceId { get; set; }
        public int ProjectId { get; set; }
        public string ProjectCode { get; set; } = string.Empty;
        public string ProjectName { get; set; } = string.Empty;
        public int ResourceId { get; set; }
        public string ResourceCode { get; set; } = string.Empty;
        public string ResourceName { get; set; } = string.Empty;
        public string ResourceType { get; set; } = string.Empty;
        public DateTime AssignedFrom { get; set; }
        public DateTime? AssignedTo { get; set; }
        public bool IsActive { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
    }

    public class CreateProjectResourceRequest
    {
        public int ProjectId { get; set; }
        public int ResourceId { get; set; }
        public DateTime AssignedFrom { get; set; }
        public DateTime? AssignedTo { get; set; }
    }

    public class UpdateProjectResourceRequest
    {
        public int ProjectResourceId { get; set; }
        public DateTime AssignedFrom { get; set; }
        public DateTime? AssignedTo { get; set; }
    }
}

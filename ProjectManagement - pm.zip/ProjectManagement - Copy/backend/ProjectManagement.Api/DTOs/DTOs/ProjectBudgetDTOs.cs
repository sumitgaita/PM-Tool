namespace ProjectManagement.Api.DTOs
{
    public class ProjectBudgetDto
    {
        public int ProjectBudgetId { get; set; }
        public int ProjectId { get; set; }
        public string ProjectCode { get; set; } = string.Empty;
        public string ProjectName { get; set; } = string.Empty;
        public int BudgetCodeId { get; set; }
        public string BudgetCode { get; set; } = string.Empty;
        public string BudgetCodeName { get; set; } = string.Empty;
        public decimal BudgetAmount { get; set; }
        public DateTime EffectiveFrom { get; set; }
        public DateTime? EffectiveTo { get; set; }
        public bool IsActive { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
    }

    public class CreateProjectBudgetRequest
    {
        public int ProjectId { get; set; }
        public int BudgetCodeId { get; set; }
        public decimal BudgetAmount { get; set; }
        public DateTime EffectiveFrom { get; set; }
        public DateTime? EffectiveTo { get; set; }
    }

    public class UpdateProjectBudgetRequest
    {
        public int ProjectBudgetId { get; set; }
        public decimal BudgetAmount { get; set; }
        public DateTime EffectiveFrom { get; set; }
        public DateTime? EffectiveTo { get; set; }
    }
}

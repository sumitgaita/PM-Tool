namespace ProjectManagement.Api.DTOs
{
    public class BudgetCodeDto
    {
        public int BudgetCodeId { get; set; }
        public string BudgetCode { get; set; } = string.Empty;
        public string BudgetCodeName { get; set; } = string.Empty;
        public string? Description { get; set; }
        public bool IsActive { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
    }

    public class CreateBudgetCodeRequest
    {
        public string BudgetCode { get; set; } = string.Empty;
        public string BudgetCodeName { get; set; } = string.Empty;
        public string? Description { get; set; }
    }

    public class UpdateBudgetCodeRequest
    {
        public int BudgetCodeId { get; set; }
        public string BudgetCodeName { get; set; } = string.Empty;
        public string? Description { get; set; }
    }
}

using System.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using ProjectManagement.Api.DTOs;
using ProjectManagement.Api.Authorization;
using ProjectManagement.Api.Services;

namespace ProjectManagement.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class BudgetCodeController : ControllerBase
    {
        private readonly IDatabaseService _databaseService;
        private readonly ILogger<BudgetCodeController> _logger;

        public BudgetCodeController(IDatabaseService databaseService, ILogger<BudgetCodeController> logger)
        {
            _databaseService = databaseService;
            _logger = logger;
        }

        [RequirePermission("Budget Codes", "View")]
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                var budgetCodes = await _databaseService.ExecuteStoredProcedureAsync<BudgetCodeDto>("usp_BudgetCode_GetAll");
                return Ok(new { Success = true, Data = budgetCodes });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting all budget codes");
                return StatusCode(500, new { Success = false, Message = "An error occurred while fetching budget codes." });
            }
        }

        [RequirePermission("Budget Codes", "View")]
        [HttpGet("paged")]
        public async Task<IActionResult> GetPaged(
            [FromQuery] string? searchText = null,
            [FromQuery] int pageNumber = 1,
            [FromQuery] int pageSize = 10,
            [FromQuery] string? sortBy = "budgetCode",
            [FromQuery] string? sortDir = "asc")
        {
            try
            {
                if (pageNumber < 1) pageNumber = 1;
                if (pageSize < 1) pageSize = 10;
                if (pageSize > 100) pageSize = 100;

                var allowedSortBy = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
                {
                    "budgetCodeId", "budgetCode", "budgetCodeName",
                    "description", "createdDate"
                };
                if (string.IsNullOrWhiteSpace(sortBy) || !allowedSortBy.Contains(sortBy)) sortBy = "budgetCode";
                sortDir = string.Equals(sortDir, "desc", StringComparison.OrdinalIgnoreCase) ? "desc" : "asc";

                var parameters = new[]
                {
                    new SqlParameter("@SearchText", (object?)searchText ?? DBNull.Value),
                    new SqlParameter("@PageNumber", pageNumber),
                    new SqlParameter("@PageSize", pageSize),
                    new SqlParameter("@SortBy", sortBy),
                    new SqlParameter("@SortDir", sortDir),
                    new SqlParameter("@TotalRecords", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };

                var (budgetCodes, outputs) = await _databaseService.ExecuteStoredProcedureWithOutputsAsync<BudgetCodeDto>("usp_BudgetCode_GetPaged", parameters);
                var totalRecords = outputs.TryGetValue("TotalRecords", out var total) && total != null
                    ? Convert.ToInt32(total)
                    : budgetCodes.Count;
                var totalPages = (int)Math.Ceiling(totalRecords / (double)pageSize);

                return Ok(new { Success = true, Data = budgetCodes, PageNumber = pageNumber, PageSize = pageSize, TotalRecords = totalRecords, TotalPages = totalPages });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting paged budget codes");
                return StatusCode(500, new { Success = false, Message = "An error occurred while fetching budget codes." });
            }
        }

        [RequirePermission("Budget Codes", "Edit")]
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateBudgetCodeRequest request)
        {
            try
            {
                var createdBy = GetCurrentUserId();

                var parameters = new[]
                {
                    new SqlParameter("@BudgetCode", request.BudgetCode),
                    new SqlParameter("@BudgetCodeName", request.BudgetCodeName),
                    new SqlParameter("@Description", (object?)request.Description ?? DBNull.Value),
                    new SqlParameter("@CreatedBy", createdBy),
                    new SqlParameter("@BudgetCodeId", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };

                await _databaseService.ExecuteNonQueryAsync("usp_BudgetCode_Insert", parameters);

                return Ok(new { Success = true, Message = "Budget code created successfully." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating budget code");
                return StatusCode(500, new { Success = false, Message = "An error occurred while creating budget code." });
            }
        }

        [RequirePermission("Budget Codes", "Edit")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateBudgetCodeRequest request)
        {
            try
            {
                var modifiedBy = GetCurrentUserId();

                var parameters = new[]
                {
                    new SqlParameter("@BudgetCodeId", id),
                    new SqlParameter("@BudgetCodeName", request.BudgetCodeName),
                    new SqlParameter("@Description", (object?)request.Description ?? DBNull.Value),
                    new SqlParameter("@ModifiedBy", modifiedBy)
                };

                await _databaseService.ExecuteNonQueryAsync("usp_BudgetCode_Update", parameters);

                return Ok(new { Success = true, Message = "Budget code updated successfully." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating budget code: {BudgetCodeId}", id);
                return StatusCode(500, new { Success = false, Message = "An error occurred while updating budget code." });
            }
        }

        [RequirePermission("Budget Codes", "Edit")]
        [HttpPost("{id}/activate")]
        public async Task<IActionResult> Activate(int id)
        {
            try
            {
                var modifiedBy = GetCurrentUserId();
                var parameters = new[]
                {
                    new SqlParameter("@BudgetCodeId", id),
                    new SqlParameter("@IsActive", true),
                    new SqlParameter("@ModifiedBy", modifiedBy)
                };

                await _databaseService.ExecuteNonQueryAsync("usp_BudgetCode_SetActive", parameters);

                return Ok(new { Success = true, Message = "Budget code activated successfully." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error activating budget code: {BudgetCodeId}", id);
                return StatusCode(500, new { Success = false, Message = "An error occurred while activating budget code." });
            }
        }

        [RequirePermission("Budget Codes", "Edit")]
        [HttpPost("{id}/deactivate")]
        public async Task<IActionResult> Deactivate(int id)
        {
            try
            {
                var modifiedBy = GetCurrentUserId();
                var parameters = new[]
                {
                    new SqlParameter("@BudgetCodeId", id),
                    new SqlParameter("@IsActive", false),
                    new SqlParameter("@ModifiedBy", modifiedBy)
                };

                await _databaseService.ExecuteNonQueryAsync("usp_BudgetCode_SetActive", parameters);

                return Ok(new { Success = true, Message = "Budget code deactivated successfully." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deactivating budget code: {BudgetCodeId}", id);
                return StatusCode(500, new { Success = false, Message = "An error occurred while deactivating budget code." });
            }
        }

        [RequirePermission("Budget Codes", "Delete")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                if (await IsBudgetCodeInUseAsync(id))
                {
                    return Conflict(new { Success = false, Message = "Budget code is in use (budgets or expenses exist) and cannot be deleted." });
                }

                var modifiedBy = GetCurrentUserId();
                var parameters = new[]
                {
                    new SqlParameter("@BudgetCodeId", id),
                    new SqlParameter("@IsActive", false),
                    new SqlParameter("@ModifiedBy", modifiedBy)
                };

                await _databaseService.ExecuteNonQueryAsync("usp_BudgetCode_SetActive", parameters);

                return Ok(new { Success = true, Message = "Budget code deleted (deactivated) successfully." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting budget code: {BudgetCodeId}", id);
                return StatusCode(500, new { Success = false, Message = "An error occurred while deleting budget code." });
            }
        }

        private int GetCurrentUserId()
        {
            var userIdClaim = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            return int.TryParse(userIdClaim, out var userId) ? userId : 0;
        }

        private async Task<bool> IsBudgetCodeInUseAsync(int budgetCodeId)
        {
            await using var conn = await _databaseService.GetConnectionAsync();
            await using var cmd = conn.CreateCommand();
            cmd.CommandText = @"SELECT CASE WHEN EXISTS (SELECT 1 FROM ProjectBudgets WHERE BudgetCodeId = @B AND IsActive = 1)
                OR EXISTS (SELECT 1 FROM Expenses WHERE BudgetCodeId = @B AND IsDeleted = 0)
                THEN 1 ELSE 0 END";
            cmd.Parameters.Add(new SqlParameter("@B", budgetCodeId));
            var result = await cmd.ExecuteScalarAsync();
            return result != null && result != DBNull.Value && Convert.ToInt32(result) == 1;
        }
    }
}

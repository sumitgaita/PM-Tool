using System.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using ProjectManagement.Api.DTOs;
using ProjectManagement.Api.Authorization;
using ProjectManagement.Api.Services;

namespace ProjectManagement.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class PoultryBatchController : ControllerBase
    {
        private const string Page = "Poultry Batches";
        private readonly IDatabaseService _db;
        private readonly ILogger<PoultryBatchController> _logger;
        public PoultryBatchController(IDatabaseService db, ILogger<PoultryBatchController> logger)
        { _db = db; _logger = logger; }

        [RequirePermission(Page, "View")]
        [HttpGet("paged")]
        public async Task<IActionResult> GetPaged(
            [FromQuery] int? projectId = null,
            [FromQuery] int? shedId = null,
            [FromQuery] string? searchText = null,
            [FromQuery] string? status = null,
            [FromQuery] int pageNumber = 1,
            [FromQuery] int pageSize = 10,
            [FromQuery] string? sortBy = "startDate",
            [FromQuery] string? sortDir = "desc")
        {
            try
            {
                if (pageNumber < 1) pageNumber = 1;
                if (pageSize < 1) pageSize = 10;
                if (pageSize > 100) pageSize = 100;
                var allowed = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
                    { "batchId", "batchCode", "startDate", "initialQuantity", "status" };
                if (string.IsNullOrWhiteSpace(sortBy) || !allowed.Contains(sortBy)) sortBy = "startDate";
                sortDir = string.Equals(sortDir, "asc", StringComparison.OrdinalIgnoreCase) ? "asc" : "desc";
                var p = new[]
                {
                    new SqlParameter("@ProjectId", (object?)projectId ?? DBNull.Value),
                    new SqlParameter("@ShedId", (object?)shedId ?? DBNull.Value),
                    new SqlParameter("@SearchText", (object?)searchText ?? DBNull.Value),
                    new SqlParameter("@Status", (object?)status ?? DBNull.Value),
                    new SqlParameter("@PageNumber", pageNumber),
                    new SqlParameter("@PageSize", pageSize),
                    new SqlParameter("@SortBy", sortBy),
                    new SqlParameter("@SortDir", sortDir),
                    new SqlParameter("@TotalRecords", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };
                var (data, outputs) = await _db.ExecuteStoredProcedureWithOutputsAsync<PoultryBatchDto>("usp_PoultryBatch_GetPaged", p);
                var total = outputs.TryGetValue("TotalRecords", out var t) && t != null ? Convert.ToInt32(t) : data.Count;
                return Ok(new { success = true, data, pageNumber, pageSize, totalRecords = total, totalPages = (int)Math.Ceiling(total / (double)pageSize) });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "PoultryBatch paged fetch failed"); }
        }

        [RequirePermission(Page, "Edit")]
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreatePoultryBatchRequest req)
        {
            try
            {
                if (req.ProjectId <= 0) return BadRequest(new { success = false, message = "Project is required." });
                if (req.ShedId <= 0) return BadRequest(new { success = false, message = "Shed is required." });
                if (string.IsNullOrWhiteSpace(req.BatchCode)) return BadRequest(new { success = false, message = "Batch code is required." });
                if (string.IsNullOrWhiteSpace(req.BirdType)) return BadRequest(new { success = false, message = "Bird type is required." });
                if (req.InitialQuantity <= 0) return BadRequest(new { success = false, message = "Initial birds must be greater than zero." });
                var me = AuditHelper.CurrentUserId(User);
                var p = new[]
                {
                    new SqlParameter("@ProjectId", req.ProjectId),
                    new SqlParameter("@ShedId", req.ShedId),
                    new SqlParameter("@BatchCode", req.BatchCode.Trim()),
                    new SqlParameter("@BirdType", req.BirdType.Trim()),
                    new SqlParameter("@StartDate", req.StartDate),
                    new SqlParameter("@ExpectedSaleDate", (object?)req.ExpectedSaleDate ?? DBNull.Value),
                    new SqlParameter("@InitialQuantity", req.InitialQuantity),
                    new SqlParameter("@PurchaseCost", (object?)req.PurchaseCost ?? DBNull.Value),
                    new SqlParameter("@Status", (object?)req.Status ?? "Active"),
                    new SqlParameter("@Remarks", (object?)req.Remarks ?? DBNull.Value),
                    new SqlParameter("@CreatedBy", me),
                    new SqlParameter("@BatchId", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };
                await _db.ExecuteNonQueryAsync("usp_PoultryBatch_Insert", p);
                await AuditHelper.LogAsync(_db, _logger, me, "Poultry Batch Created", Page, req.BatchCode);
                return Ok(new { success = true, message = "Poultry batch created successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "PoultryBatch insert failed"); }
        }

        [RequirePermission(Page, "Edit")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdatePoultryBatchRequest req)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(req.BatchCode)) return BadRequest(new { success = false, message = "Batch code is required." });
                if (string.IsNullOrWhiteSpace(req.BirdType)) return BadRequest(new { success = false, message = "Bird type is required." });
                var me = AuditHelper.CurrentUserId(User);
                var p = new[]
                {
                    new SqlParameter("@BatchId", id),
                    new SqlParameter("@BatchCode", req.BatchCode.Trim()),
                    new SqlParameter("@BirdType", req.BirdType.Trim()),
                    new SqlParameter("@StartDate", req.StartDate),
                    new SqlParameter("@ExpectedSaleDate", (object?)req.ExpectedSaleDate ?? DBNull.Value),
                    new SqlParameter("@PurchaseCost", (object?)req.PurchaseCost ?? DBNull.Value),
                    new SqlParameter("@Status", (object?)req.Status ?? DBNull.Value),
                    new SqlParameter("@Remarks", (object?)req.Remarks ?? DBNull.Value),
                    new SqlParameter("@ModifiedBy", me)
                };
                await _db.ExecuteNonQueryAsync("usp_PoultryBatch_Update", p);
                await AuditHelper.LogAsync(_db, _logger, me, "Poultry Batch Updated", Page, id);
                return Ok(new { success = true, message = "Poultry batch updated successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "PoultryBatch update failed"); }
        }

        [RequirePermission(Page, "Delete")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var me = AuditHelper.CurrentUserId(User);
                await _db.ExecuteNonQueryAsync("usp_PoultryBatch_Delete", new[] { new SqlParameter("@BatchId", id) });
                await AuditHelper.LogAsync(_db, _logger, me, "Poultry Batch Deleted", Page, id);
                return Ok(new { success = true, message = "Poultry batch deleted successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "PoultryBatch delete failed"); }
        }

        [RequirePermission(Page, "Edit")]
        [HttpPost("{id}/activate")]
        public async Task<IActionResult> Activate(int id) => await SetActive(id, true);

        [RequirePermission(Page, "Edit")]
        [HttpPost("{id}/deactivate")]
        public async Task<IActionResult> Deactivate(int id) => await SetActive(id, false);

        private async Task<IActionResult> SetActive(int id, bool active)
        {
            try
            {
                var me = AuditHelper.CurrentUserId(User);
                await _db.ExecuteNonQueryAsync("usp_PoultryBatch_SetActive", new[]
                {
                    new SqlParameter("@BatchId", id),
                    new SqlParameter("@IsActive", active),
                    new SqlParameter("@ModifiedBy", me)
                });
                return Ok(new { success = true, message = active ? "Batch activated successfully." : "Batch closed successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "PoultryBatch status change failed"); }
        }
    }
}

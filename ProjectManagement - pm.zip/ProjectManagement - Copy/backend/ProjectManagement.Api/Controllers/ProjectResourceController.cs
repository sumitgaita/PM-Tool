using System.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using ProjectManagement.Api.DTOs;
using ProjectManagement.Api.Authorization;
using ProjectManagement.Api.Services;

namespace ProjectManagement.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class ProjectResourceController : ControllerBase
    {
        private readonly IDatabaseService _db;
        private readonly ILogger<ProjectResourceController> _logger;
        public ProjectResourceController(IDatabaseService db, ILogger<ProjectResourceController> logger)
        { _db = db; _logger = logger; }

        [RequirePermission("Project Resources", "View")]
        [HttpGet]
        public async Task<IActionResult> Get([FromQuery] int? projectId = null, [FromQuery] int? resourceId = null)
        {
            try
            {
                var p = new[]
                {
                    new SqlParameter("@ProjectId", (object?)projectId ?? DBNull.Value),
                    new SqlParameter("@ResourceId", (object?)resourceId ?? DBNull.Value)
                };
                var data = await _db.ExecuteStoredProcedureAsync<ProjectResourceDto>("usp_ProjectResource_Get", p);
                return Ok(new { success = true, data });
            }
            catch (Exception ex) { _logger.LogError(ex, "ProjectResource Get failed"); return StatusCode(500, new { success = false, message = "Failed to fetch project resources." }); }
        }

        [RequirePermission("Project Resources", "Edit")]
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateProjectResourceRequest req)
        {
            try
            {
                var p = new[]
                {
                    new SqlParameter("@ProjectId", req.ProjectId),
                    new SqlParameter("@ResourceId", req.ResourceId),
                    new SqlParameter("@AssignedFrom", req.AssignedFrom),
                    new SqlParameter("@AssignedTo", (object?)req.AssignedTo ?? DBNull.Value),
                    new SqlParameter("@CreatedBy", CurrentUserId()),
                    new SqlParameter("@ProjectResourceId", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };
                await _db.ExecuteNonQueryAsync("usp_ProjectResource_Insert", p);
                return Ok(new { success = true, message = "Resource assigned to project successfully." });
            }
            catch (Exception ex) { _logger.LogError(ex, "ProjectResource insert failed"); return StatusCode(500, new { success = false, message = "Failed to assign resource." }); }
        }

        [RequirePermission("Project Resources", "Edit")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateProjectResourceRequest req)
        {
            try
            {
                var p = new[]
                {
                    new SqlParameter("@ProjectResourceId", id),
                    new SqlParameter("@AssignedFrom", req.AssignedFrom),
                    new SqlParameter("@AssignedTo", (object?)req.AssignedTo ?? DBNull.Value),
                    new SqlParameter("@ModifiedBy", CurrentUserId())
                };
                await _db.ExecuteNonQueryAsync("usp_ProjectResource_Update", p);
                return Ok(new { success = true, message = "Project resource updated successfully." });
            }
            catch (Exception ex) { _logger.LogError(ex, "ProjectResource update failed"); return StatusCode(500, new { success = false, message = "Failed to update project resource." }); }
        }

        [RequirePermission("Project Resources", "Delete")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var p = new[] { new SqlParameter("@ProjectResourceId", id), new SqlParameter("@ModifiedBy", CurrentUserId()) };
                await _db.ExecuteNonQueryAsync("usp_ProjectResource_Delete", p);
                return Ok(new { success = true, message = "Project resource removed successfully." });
            }
            catch (Exception ex) { _logger.LogError(ex, "ProjectResource delete failed"); return StatusCode(500, new { success = false, message = "Failed to remove project resource." }); }
        }

        private int CurrentUserId() => int.TryParse(User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value, out var i) ? i : 0;
    }
}

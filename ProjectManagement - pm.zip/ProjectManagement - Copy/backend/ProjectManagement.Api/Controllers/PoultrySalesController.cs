using System.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using ProjectManagement.Api.DTOs;
using ProjectManagement.Api.Authorization;
using ProjectManagement.Api.Services;

namespace ProjectManagement.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class PoultrySalesController : ControllerBase
    {
        private const string Page = "Poultry Sales";
        private readonly IDatabaseService _db;
        private readonly ILogger<PoultrySalesController> _logger;
        public PoultrySalesController(IDatabaseService db, ILogger<PoultrySalesController> logger)
        { _db = db; _logger = logger; }

        [RequirePermission(Page, "View")]
        [HttpGet("paged")]
        public async Task<IActionResult> GetPaged(
            [FromQuery] int? projectId = null,
            [FromQuery] int? batchId = null,
            [FromQuery] string? paymentStatus = null,
            [FromQuery] DateTime? fromDate = null,
            [FromQuery] DateTime? toDate = null,
            [FromQuery] int pageNumber = 1,
            [FromQuery] int pageSize = 10,
            [FromQuery] string? sortBy = "saleDate",
            [FromQuery] string? sortDir = "desc")
        {
            try
            {
                if (pageNumber < 1) pageNumber = 1;
                if (pageSize < 1) pageSize = 10;
                if (pageSize > 100) pageSize = 100;
                var allowed = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
                    { "saleId", "saleDate", "customerName", "birdQuantity", "totalAmount" };
                if (string.IsNullOrWhiteSpace(sortBy) || !allowed.Contains(sortBy)) sortBy = "saleDate";
                sortDir = string.Equals(sortDir, "asc", StringComparison.OrdinalIgnoreCase) ? "asc" : "desc";
                var p = new[]
                {
                    new SqlParameter("@ProjectId", (object?)projectId ?? DBNull.Value),
                    new SqlParameter("@BatchId", (object?)batchId ?? DBNull.Value),
                    new SqlParameter("@PaymentStatus", (object?)paymentStatus ?? DBNull.Value),
                    new SqlParameter("@FromDate", (object?)fromDate ?? DBNull.Value),
                    new SqlParameter("@ToDate", (object?)toDate ?? DBNull.Value),
                    new SqlParameter("@PageNumber", pageNumber),
                    new SqlParameter("@PageSize", pageSize),
                    new SqlParameter("@SortBy", sortBy),
                    new SqlParameter("@SortDir", sortDir),
                    new SqlParameter("@TotalRecords", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };
                var (data, outputs) = await _db.ExecuteStoredProcedureWithOutputsAsync<PoultrySalesDto>("usp_PoultrySales_GetPaged", p);
                var total = outputs.TryGetValue("TotalRecords", out var t) && t != null ? Convert.ToInt32(t) : data.Count;
                return Ok(new { success = true, data, pageNumber, pageSize, totalRecords = total, totalPages = (int)Math.Ceiling(total / (double)pageSize) });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "PoultrySales paged fetch failed"); }
        }

        [RequirePermission(Page, "Edit")]
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreatePoultrySalesRequest req)
        {
            try
            {
                if (req.ProjectId <= 0) return BadRequest(new { success = false, message = "Project is required." });
                if (string.IsNullOrWhiteSpace(req.CustomerName)) return BadRequest(new { success = false, message = "Customer name is required." });
                if (req.BirdQuantity <= 0) return BadRequest(new { success = false, message = "Quantity must be greater than zero." });
                var me = AuditHelper.CurrentUserId(User);
                var p = new[]
                {
                    new SqlParameter("@ProjectId", req.ProjectId),
                    new SqlParameter("@BatchId", (object?)req.BatchId ?? DBNull.Value),
                    new SqlParameter("@SaleDate", req.SaleDate),
                    new SqlParameter("@CustomerName", req.CustomerName.Trim()),
                    new SqlParameter("@BirdQuantity", req.BirdQuantity),
                    new SqlParameter("@TotalWeight", (object?)req.TotalWeight ?? DBNull.Value),
                    new SqlParameter("@Rate", (object?)req.Rate ?? DBNull.Value),
                    new SqlParameter("@TotalAmount", (object?)req.TotalAmount ?? DBNull.Value),
                    new SqlParameter("@PaymentStatus", (object?)req.PaymentStatus ?? "Pending"),
                    new SqlParameter("@ReferenceNo", (object?)req.ReferenceNo ?? DBNull.Value),
                    new SqlParameter("@Remarks", (object?)req.Remarks ?? DBNull.Value),
                    new SqlParameter("@CreatedBy", me),
                    new SqlParameter("@SaleId", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };
                await _db.ExecuteNonQueryAsync("usp_PoultrySales_Insert", p);
                await AuditHelper.LogAsync(_db, _logger, me, "Poultry Sale Added", Page, null);
                return Ok(new { success = true, message = "Poultry sale recorded successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "PoultrySales insert failed"); }
        }

        [RequirePermission(Page, "Edit")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdatePoultrySalesRequest req)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(req.CustomerName)) return BadRequest(new { success = false, message = "Customer name is required." });
                if (req.BirdQuantity <= 0) return BadRequest(new { success = false, message = "Quantity must be greater than zero." });
                var me = AuditHelper.CurrentUserId(User);
                var p = new[]
                {
                    new SqlParameter("@SaleId", id),
                    new SqlParameter("@SaleDate", req.SaleDate),
                    new SqlParameter("@CustomerName", req.CustomerName.Trim()),
                    new SqlParameter("@BirdQuantity", req.BirdQuantity),
                    new SqlParameter("@TotalWeight", (object?)req.TotalWeight ?? DBNull.Value),
                    new SqlParameter("@Rate", (object?)req.Rate ?? DBNull.Value),
                    new SqlParameter("@TotalAmount", (object?)req.TotalAmount ?? DBNull.Value),
                    new SqlParameter("@PaymentStatus", (object?)req.PaymentStatus ?? DBNull.Value),
                    new SqlParameter("@ReferenceNo", (object?)req.ReferenceNo ?? DBNull.Value),
                    new SqlParameter("@Remarks", (object?)req.Remarks ?? DBNull.Value),
                    new SqlParameter("@ModifiedBy", me)
                };
                await _db.ExecuteNonQueryAsync("usp_PoultrySales_Update", p);
                await AuditHelper.LogAsync(_db, _logger, me, "Poultry Sale Updated", Page, id);
                return Ok(new { success = true, message = "Poultry sale updated successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "PoultrySales update failed"); }
        }

        [RequirePermission(Page, "Delete")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var me = AuditHelper.CurrentUserId(User);
                await _db.ExecuteNonQueryAsync("usp_PoultrySales_Delete", new[] { new SqlParameter("@SaleId", id) });
                await AuditHelper.LogAsync(_db, _logger, me, "Poultry Sale Deleted", Page, id);
                return Ok(new { success = true, message = "Poultry sale deleted successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "PoultrySales delete failed"); }
        }
    }
}

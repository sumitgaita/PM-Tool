using Microsoft.AspNetCore.Mvc;
using ProjectManagement.Api.DTOs;
using ProjectManagement.Api.Services;

namespace ProjectManagement.Api.Controllers
{
    // Anonymous Super Admin password reset via security questions.
    // No [Authorize] / permission attributes: reachable without login, like login.
    [ApiController]
    [Route("api/[controller]")]
    public class ChangePassController : ControllerBase
    {
        private readonly IAuthService _authService;
        private readonly ILogger<ChangePassController> _logger;

        public ChangePassController(IAuthService authService, ILogger<ChangePassController> logger)
        {
            _authService = authService;
            _logger = logger;
        }

        [HttpGet("questions")]
        public async Task<IActionResult> GetQuestions()
        {
            try
            {
                var data = await _authService.GetSecurityQuestionsAsync();
                return Ok(new { success = true, data });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching security questions.");
                return StatusCode(500, new { success = false, message = "An error occurred. Please try again." });
            }
        }

        [HttpPost("verify")]
        public async Task<IActionResult> Verify([FromBody] VerifySecurityAnswersRequest request)
        {
            try
            {
                if (request?.Answers is null || request.Answers.Count != 2
                    || request.Answers.Any(a => string.IsNullOrWhiteSpace(a.Answer)))
                {
                    return BadRequest(new { success = false, message = "Please answer all security questions." });
                }

                var valid = await _authService.VerifySecurityAnswersAsync(request.Answers);
                if (!valid)
                {
                    return BadRequest(new { success = false, message = "Security answers are incorrect." });
                }
                return Ok(new { success = true, valid = true, message = "Security answers verified." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error verifying security answers.");
                return StatusCode(500, new { success = false, message = "An error occurred. Please try again." });
            }
        }

        [HttpPost("reset")]
        public async Task<IActionResult> Reset([FromBody] SuperAdminChangePassRequest request)
        {
            try
            {
                if (request?.Answers is null || request.Answers.Count != 2
                    || request.Answers.Any(a => string.IsNullOrWhiteSpace(a.Answer)))
                {
                    return BadRequest(new { success = false, message = "Please answer all security questions." });
                }
                if (string.IsNullOrWhiteSpace(request.NewPassword) || request.NewPassword.Length < 6)
                {
                    return BadRequest(new { success = false, message = "Password must be at least 6 characters." });
                }
                if (request.NewPassword != request.ConfirmPassword)
                {
                    return BadRequest(new { success = false, message = "New password and confirm password do not match." });
                }

                var result = await _authService.ResetSuperAdminPasswordAsync(request);
                if (!result.Success)
                {
                    return BadRequest(new { success = false, message = result.Message });
                }
                return Ok(new { success = true, message = result.Message });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error resetting Super Admin password.");
                return StatusCode(500, new { success = false, message = "An error occurred. Please try again." });
            }
        }
    }
}

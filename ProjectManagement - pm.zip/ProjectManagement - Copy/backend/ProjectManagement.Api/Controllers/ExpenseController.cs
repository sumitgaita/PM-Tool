using System.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using ProjectManagement.Api.DTOs;
using ProjectManagement.Api.Authorization;
using ProjectManagement.Api.Services;

namespace ProjectManagement.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class ExpenseController : ControllerBase
    {
        private readonly IDatabaseService _databaseService;
        private readonly ILogger<ExpenseController> _logger;

        public ExpenseController(IDatabaseService databaseService, ILogger<ExpenseController> logger)
        {
            _databaseService = databaseService;
            _logger = logger;
        }

        [RequirePermission("Expenses", "View")]
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            try
            {
                var parameters = new[] { new SqlParameter("@ExpenseId", id) };
                var expenses = await _databaseService.ExecuteStoredProcedureAsync<ExpenseDto>("usp_Expense_GetById", parameters);

                if (expenses.Count == 0)
                {
                    return NotFound(new { Success = false, Message = "Expense not found." });
                }

                return Ok(new { Success = true, Data = expenses[0] });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting expense by id: {ExpenseId}", id);
                return StatusCode(500, new { Success = false, Message = "An error occurred while fetching expense." });
            }
        }

        [RequirePermission("Expenses", "View")]
        [HttpGet("by-date/{date}")]
        public async Task<IActionResult> GetByDate(DateTime date)
        {
            try
            {
                var parameters = new[] { new SqlParameter("@ExpenseDate", date) };
                var expenses = await _databaseService.ExecuteStoredProcedureAsync<ExpenseDto>("usp_Expense_GetByDate", parameters);

                return Ok(new { Success = true, Data = expenses });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting expenses by date: {Date}", date);
                return StatusCode(500, new { Success = false, Message = "An error occurred while fetching expenses." });
            }
        }

        [RequirePermission("Expenses", "View")]
        [HttpGet("by-date-range")]
        public async Task<IActionResult> GetByDateRange(
            [FromQuery] DateTime fromDate,
            [FromQuery] DateTime toDate,
            [FromQuery] int? projectId = null,
            [FromQuery] int? budgetCodeId = null,
            [FromQuery] int? resourceId = null,
            [FromQuery] int pageNumber = 1,
            [FromQuery] int pageSize = 10,
            [FromQuery] string? sortBy = "expenseDate",
            [FromQuery] string? sortDir = "desc")
        {
            try
            {
                if (pageNumber < 1) pageNumber = 1;
                if (pageSize < 1) pageSize = 10;
                if (pageSize > 100) pageSize = 100;

                var allowedSortBy = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
                {
                    "expenseId", "expenseDate", "projectCode", "projectName",
                    "budgetCode", "budgetCodeName", "resourceName", "amount", "createdDate"
                };
                if (string.IsNullOrWhiteSpace(sortBy) || !allowedSortBy.Contains(sortBy)) sortBy = "expenseDate";
                sortDir = string.Equals(sortDir, "asc", StringComparison.OrdinalIgnoreCase) ? "asc" : "desc";

                var parameters = new[]
                {
                    new SqlParameter("@FromDate", fromDate),
                    new SqlParameter("@ToDate", toDate),
                    new SqlParameter("@ProjectId", (object?)projectId ?? DBNull.Value),
                    new SqlParameter("@BudgetCodeId", (object?)budgetCodeId ?? DBNull.Value),
                    new SqlParameter("@ResourceId", (object?)resourceId ?? DBNull.Value),
                    new SqlParameter("@PageNumber", pageNumber),
                    new SqlParameter("@PageSize", pageSize),
                    new SqlParameter("@SortBy", sortBy),
                    new SqlParameter("@SortDir", sortDir),
                    new SqlParameter("@TotalRecords", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };

                var (expenses, outputs) = await _databaseService.ExecuteStoredProcedureWithOutputsAsync<ExpenseDto>("usp_Expense_GetByDateRange", parameters);
                var totalRecords = outputs.TryGetValue("TotalRecords", out var total) && total != null
                    ? Convert.ToInt32(total)
                    : expenses.Count;
                var totalPages = (int)Math.Ceiling(totalRecords / (double)pageSize);

                return Ok(new { Success = true, Data = expenses, PageNumber = pageNumber, PageSize = pageSize, TotalRecords = totalRecords, TotalPages = totalPages });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting expenses by date range");
                return StatusCode(500, new { Success = false, Message = "An error occurred while fetching expenses." });
            }
        }

        [RequirePermission("Expenses", "Edit")]
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateExpenseRequest request)
        {
            try
            {
                var createdBy = GetCurrentUserId();

                var parameters = new[]
                {
                    new SqlParameter("@ExpenseDate", request.ExpenseDate),
                    new SqlParameter("@ProjectId", request.ProjectId),
                    new SqlParameter("@BudgetCodeId", request.BudgetCodeId),
                    new SqlParameter("@ResourceId", request.ResourceId),
                    new SqlParameter("@Amount", request.Amount),
                    new SqlParameter("@Description", (object?)request.Description ?? DBNull.Value),
                    new SqlParameter("@ReferenceNo", (object?)request.ReferenceNo ?? DBNull.Value),
                    new SqlParameter("@Remarks", (object?)request.Remarks ?? DBNull.Value),
                    new SqlParameter("@CreatedBy", createdBy),
                    new SqlParameter("@FarmType", (object?)request.FarmType ?? DBNull.Value),
                    new SqlParameter("@FarmEntityType", (object?)request.FarmEntityType ?? DBNull.Value),
                    new SqlParameter("@FarmEntityId", (object?)request.FarmEntityId ?? DBNull.Value),
                    new SqlParameter("@ExpenseId", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };

                await _databaseService.ExecuteNonQueryAsync("usp_Expense_Insert", parameters);

                return Ok(new { Success = true, Message = "Expense created successfully." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating expense");
                return StatusCode(500, new { Success = false, Message = "An error occurred while creating expense." });
            }
        }

        [RequirePermission("Expenses", "Edit")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateExpenseRequest request)
        {
            try
            {
                var modifiedBy = GetCurrentUserId();

                var parameters = new[]
                {
                    new SqlParameter("@ExpenseId", id),
                    new SqlParameter("@ExpenseDate", request.ExpenseDate),
                    new SqlParameter("@ProjectId", request.ProjectId),
                    new SqlParameter("@BudgetCodeId", request.BudgetCodeId),
                    new SqlParameter("@ResourceId", request.ResourceId),
                    new SqlParameter("@Amount", request.Amount),
                    new SqlParameter("@Description", (object?)request.Description ?? DBNull.Value),
                    new SqlParameter("@ReferenceNo", (object?)request.ReferenceNo ?? DBNull.Value),
                    new SqlParameter("@Remarks", (object?)request.Remarks ?? DBNull.Value),
                    new SqlParameter("@ModifiedBy", modifiedBy),
                    new SqlParameter("@FarmType", (object?)request.FarmType ?? DBNull.Value),
                    new SqlParameter("@FarmEntityType", (object?)request.FarmEntityType ?? DBNull.Value),
                    new SqlParameter("@FarmEntityId", (object?)request.FarmEntityId ?? DBNull.Value)
                };

                await _databaseService.ExecuteNonQueryAsync("usp_Expense_Update", parameters);

                return Ok(new { Success = true, Message = "Expense updated successfully." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating expense: {ExpenseId}", id);
                return StatusCode(500, new { Success = false, Message = "An error occurred while updating expense." });
            }
        }

        [RequirePermission("Expenses", "Delete")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var modifiedBy = GetCurrentUserId();
                var parameters = new[]
                {
                    new SqlParameter("@ExpenseId", id),
                    new SqlParameter("@ModifiedBy", modifiedBy)
                };

                await _databaseService.ExecuteNonQueryAsync("usp_Expense_Delete", parameters);

                return Ok(new { Success = true, Message = "Expense deleted successfully." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting expense: {ExpenseId}", id);
                return StatusCode(500, new { Success = false, Message = "An error occurred while deleting expense." });
            }
        }

        [RequirePermission("Expenses", "Edit")]
        [HttpPost("copy-from-date")]
        public async Task<IActionResult> CopyFromDate([FromBody] CopyExpenseRequest request)
        {
            try
            {
                var createdBy = GetCurrentUserId();

                var parameters = new[]
                {
                    new SqlParameter("@FromDate", request.FromDate),
                    new SqlParameter("@ToDate", request.ToDate),
                    new SqlParameter("@ProjectId", (object?)request.ProjectId ?? DBNull.Value),
                    new SqlParameter("@ResourceId", (object?)request.ResourceId ?? DBNull.Value),
                    new SqlParameter("@CreatedBy", createdBy)
                };

                await _databaseService.ExecuteNonQueryAsync("usp_Expense_CopyFromDate", parameters);

                return Ok(new { Success = true, Message = "Expenses copied successfully." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error copying expenses from date");
                return StatusCode(500, new { Success = false, Message = "An error occurred while copying expenses." });
            }
        }

        private int GetCurrentUserId()
        {
            var userIdClaim = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            return int.TryParse(userIdClaim, out var userId) ? userId : 0;
        }
    }
}

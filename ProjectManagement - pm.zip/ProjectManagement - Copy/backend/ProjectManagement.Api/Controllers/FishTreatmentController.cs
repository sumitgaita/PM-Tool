using System.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using ProjectManagement.Api.DTOs;
using ProjectManagement.Api.Authorization;
using ProjectManagement.Api.Services;

namespace ProjectManagement.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class FishTreatmentController : ControllerBase
    {
        private const string Page = "Fish Treatment";
        private readonly IDatabaseService _db;
        private readonly ILogger<FishTreatmentController> _logger;
        public FishTreatmentController(IDatabaseService db, ILogger<FishTreatmentController> logger)
        { _db = db; _logger = logger; }

        [RequirePermission(Page, "View")]
        [HttpGet("paged")]
        public async Task<IActionResult> GetPaged(
            [FromQuery] int? projectId = null,
            [FromQuery] int? pondId = null,
            [FromQuery] string? searchText = null,
            [FromQuery] DateTime? fromDate = null,
            [FromQuery] DateTime? toDate = null,
            [FromQuery] int pageNumber = 1,
            [FromQuery] int pageSize = 10,
            [FromQuery] string? sortBy = "treatmentDate",
            [FromQuery] string? sortDir = "desc")
        {
            try
            {
                if (pageNumber < 1) pageNumber = 1;
                if (pageSize < 1) pageSize = 10;
                if (pageSize > 100) pageSize = 100;
                var allowed = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
                    { "treatmentId", "treatmentDate", "pondCode", "treatmentType", "cost" };
                if (string.IsNullOrWhiteSpace(sortBy) || !allowed.Contains(sortBy)) sortBy = "treatmentDate";
                sortDir = string.Equals(sortDir, "asc", StringComparison.OrdinalIgnoreCase) ? "asc" : "desc";
                var p = new[]
                {
                    new SqlParameter("@ProjectId", (object?)projectId ?? DBNull.Value),
                    new SqlParameter("@PondId", (object?)pondId ?? DBNull.Value),
                    new SqlParameter("@SearchText", (object?)searchText ?? DBNull.Value),
                    new SqlParameter("@FromDate", (object?)fromDate ?? DBNull.Value),
                    new SqlParameter("@ToDate", (object?)toDate ?? DBNull.Value),
                    new SqlParameter("@PageNumber", pageNumber),
                    new SqlParameter("@PageSize", pageSize),
                    new SqlParameter("@SortBy", sortBy),
                    new SqlParameter("@SortDir", sortDir),
                    new SqlParameter("@TotalRecords", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };
                var (data, outputs) = await _db.ExecuteStoredProcedureWithOutputsAsync<FishTreatmentDto>("usp_FishTreatment_GetPaged", p);
                var total = outputs.TryGetValue("TotalRecords", out var t) && t != null ? Convert.ToInt32(t) : data.Count;
                return Ok(new { success = true, data, pageNumber, pageSize, totalRecords = total, totalPages = (int)Math.Ceiling(total / (double)pageSize) });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "FishTreatment paged fetch failed"); }
        }

        [RequirePermission(Page, "Edit")]
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateFishTreatmentRequest req)
        {
            try
            {
                if (req.PondId <= 0) return BadRequest(new { success = false, message = "Pond is required." });
                if (string.IsNullOrWhiteSpace(req.TreatmentType)) return BadRequest(new { success = false, message = "Treatment type is required." });
                var me = AuditHelper.CurrentUserId(User);
                var p = new[]
                {
                    new SqlParameter("@PondId", req.PondId),
                    new SqlParameter("@TreatmentDate", req.TreatmentDate),
                    new SqlParameter("@TreatmentType", req.TreatmentType.Trim()),
                    new SqlParameter("@Medicine", (object?)req.Medicine ?? DBNull.Value),
                    new SqlParameter("@Quantity", (object?)req.Quantity ?? DBNull.Value),
                    new SqlParameter("@Unit", (object?)req.Unit ?? DBNull.Value),
                    new SqlParameter("@Cost", (object?)req.Cost ?? DBNull.Value),
                    new SqlParameter("@Reason", (object?)req.Reason ?? DBNull.Value),
                    new SqlParameter("@Remarks", (object?)req.Remarks ?? DBNull.Value),
                    new SqlParameter("@CreatedBy", me),
                    new SqlParameter("@ExpProjectId", (object?)req.ExpProjectId ?? DBNull.Value),
                    new SqlParameter("@ExpBudgetCodeId", (object?)req.ExpBudgetCodeId ?? DBNull.Value),
                    new SqlParameter("@ExpResourceId", (object?)req.ExpResourceId ?? DBNull.Value),
                    new SqlParameter("@TreatmentId", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };
                await _db.ExecuteNonQueryAsync("usp_FishTreatment_Insert", p);
                await AuditHelper.LogAsync(_db, _logger, me, "Fish Treatment Added", Page, null);
                return Ok(new { success = true, message = "Fish treatment recorded successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "FishTreatment insert failed"); }
        }

        [RequirePermission(Page, "Edit")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateFishTreatmentRequest req)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(req.TreatmentType)) return BadRequest(new { success = false, message = "Treatment type is required." });
                var me = AuditHelper.CurrentUserId(User);
                var p = new[]
                {
                    new SqlParameter("@TreatmentId", id),
                    new SqlParameter("@TreatmentDate", req.TreatmentDate),
                    new SqlParameter("@TreatmentType", req.TreatmentType.Trim()),
                    new SqlParameter("@Medicine", (object?)req.Medicine ?? DBNull.Value),
                    new SqlParameter("@Quantity", (object?)req.Quantity ?? DBNull.Value),
                    new SqlParameter("@Unit", (object?)req.Unit ?? DBNull.Value),
                    new SqlParameter("@Cost", (object?)req.Cost ?? DBNull.Value),
                    new SqlParameter("@Reason", (object?)req.Reason ?? DBNull.Value),
                    new SqlParameter("@Remarks", (object?)req.Remarks ?? DBNull.Value),
                    new SqlParameter("@ModifiedBy", me)
                };
                await _db.ExecuteNonQueryAsync("usp_FishTreatment_Update", p);
                await AuditHelper.LogAsync(_db, _logger, me, "Fish Treatment Updated", Page, id);
                return Ok(new { success = true, message = "Fish treatment updated successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "FishTreatment update failed"); }
        }

        [RequirePermission(Page, "Delete")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var me = AuditHelper.CurrentUserId(User);
                await _db.ExecuteNonQueryAsync("usp_FishTreatment_Delete", new[] { new SqlParameter("@TreatmentId", id) });
                await AuditHelper.LogAsync(_db, _logger, me, "Fish Treatment Deleted", Page, id);
                return Ok(new { success = true, message = "Fish treatment deleted successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "FishTreatment delete failed"); }
        }
    }
}

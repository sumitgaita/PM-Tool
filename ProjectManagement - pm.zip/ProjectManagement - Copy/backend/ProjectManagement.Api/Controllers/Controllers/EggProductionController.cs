using System.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using ProjectManagement.Api.DTOs;
using ProjectManagement.Api.Authorization;
using ProjectManagement.Api.Services;

namespace ProjectManagement.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class EggProductionController : ControllerBase
    {
        private const string Page = "Egg Production";
        private readonly IDatabaseService _db;
        private readonly ILogger<EggProductionController> _logger;
        public EggProductionController(IDatabaseService db, ILogger<EggProductionController> logger)
        { _db = db; _logger = logger; }

        [RequirePermission(Page, "View")]
        [HttpGet("paged")]
        public async Task<IActionResult> GetPaged(
            [FromQuery] int? projectId = null,
            [FromQuery] int? batchId = null,
            [FromQuery] DateTime? fromDate = null,
            [FromQuery] DateTime? toDate = null,
            [FromQuery] int pageNumber = 1,
            [FromQuery] int pageSize = 10,
            [FromQuery] string? sortBy = "productionDate",
            [FromQuery] string? sortDir = "desc")
        {
            try
            {
                if (await ProjectAccessHelper.QueryProjectDeniedAsync(User, _db, projectId)) return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
                if (pageNumber < 1) pageNumber = 1;
                if (pageSize < 1) pageSize = 10;
                if (pageSize > 100) pageSize = 100;
                var allowed = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
                    { "productionId", "productionDate", "batchCode", "totalEggs" };
                if (string.IsNullOrWhiteSpace(sortBy) || !allowed.Contains(sortBy)) sortBy = "productionDate";
                sortDir = string.Equals(sortDir, "asc", StringComparison.OrdinalIgnoreCase) ? "asc" : "desc";
                var p = new[]
                {
                    new SqlParameter("@ProjectId", (object?)projectId ?? DBNull.Value),
                    new SqlParameter("@BatchId", (object?)batchId ?? DBNull.Value),
                    new SqlParameter("@FromDate", (object?)fromDate ?? DBNull.Value),
                    new SqlParameter("@ToDate", (object?)toDate ?? DBNull.Value),
                    new SqlParameter("@PageNumber", pageNumber),
                    new SqlParameter("@PageSize", pageSize),
                    new SqlParameter("@SortBy", sortBy),
                    new SqlParameter("@SortDir", sortDir),
                    new SqlParameter("@TotalRecords", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };
                var (data, outputs) = await _db.ExecuteStoredProcedureWithOutputsAsync<EggProductionDto>("usp_EggProduction_GetPaged", p);
                var total = outputs.TryGetValue("TotalRecords", out var t) && t != null ? Convert.ToInt32(t) : data.Count;
                return Ok(new { success = true, data, pageNumber, pageSize, totalRecords = total, totalPages = (int)Math.Ceiling(total / (double)pageSize) });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "EggProduction paged fetch failed"); }
        }

        [RequirePermission(Page, "Edit")]
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateEggProductionRequest req)
        {
            try
            {
                if (!await ProjectAccessHelper.HasEntityAccessAsync(User, _db, "PoultryBatch", req.BatchId)) return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
                if (req.BatchId <= 0) return BadRequest(new { success = false, message = "Batch is required." });
                if ((req.GoodEggs ?? 0) < 0 || (req.BrokenEggs ?? 0) < 0)
                    return BadRequest(new { success = false, message = "Egg quantity cannot be negative." });
                var me = AuditHelper.CurrentUserId(User);
                var p = new[]
                {
                    new SqlParameter("@BatchId", req.BatchId),
                    new SqlParameter("@ProductionDate", req.ProductionDate),
                    new SqlParameter("@GoodEggs", (object?)req.GoodEggs ?? DBNull.Value),
                    new SqlParameter("@BrokenEggs", (object?)req.BrokenEggs ?? DBNull.Value),
                    new SqlParameter("@Remarks", (object?)req.Remarks ?? DBNull.Value),
                    new SqlParameter("@CreatedBy", me),
                    new SqlParameter("@ProductionId", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };
                await _db.ExecuteNonQueryAsync("usp_EggProduction_Insert", p);
                await AuditHelper.LogAsync(_db, _logger, me, "Egg Production Added", Page, null);
                return Ok(new { success = true, message = "Egg production recorded successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "EggProduction insert failed"); }
        }

        [RequirePermission(Page, "Edit")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateEggProductionRequest req)
        {
            try
            {
                if (!await ProjectAccessHelper.HasEntityAccessAsync(User, _db, "EggProduction", id)) return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
                if ((req.GoodEggs ?? 0) < 0 || (req.BrokenEggs ?? 0) < 0)
                    return BadRequest(new { success = false, message = "Egg quantity cannot be negative." });
                var me = AuditHelper.CurrentUserId(User);
                var p = new[]
                {
                    new SqlParameter("@ProductionId", id),
                    new SqlParameter("@ProductionDate", req.ProductionDate),
                    new SqlParameter("@GoodEggs", (object?)req.GoodEggs ?? DBNull.Value),
                    new SqlParameter("@BrokenEggs", (object?)req.BrokenEggs ?? DBNull.Value),
                    new SqlParameter("@Remarks", (object?)req.Remarks ?? DBNull.Value),
                    new SqlParameter("@ModifiedBy", me)
                };
                await _db.ExecuteNonQueryAsync("usp_EggProduction_Update", p);
                await AuditHelper.LogAsync(_db, _logger, me, "Egg Production Updated", Page, id);
                return Ok(new { success = true, message = "Egg production updated successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "EggProduction update failed"); }
        }

        [RequirePermission(Page, "Delete")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                if (!await ProjectAccessHelper.HasEntityAccessAsync(User, _db, "EggProduction", id)) return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
                var me = AuditHelper.CurrentUserId(User);
                await _db.ExecuteNonQueryAsync("usp_EggProduction_Delete", new[] { new SqlParameter("@ProductionId", id) });
                await AuditHelper.LogAsync(_db, _logger, me, "Egg Production Deleted", Page, id);
                return Ok(new { success = true, message = "Egg production deleted successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "EggProduction delete failed"); }
        }
    }
}

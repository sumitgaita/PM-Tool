using System.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using ProjectManagement.Api.DTOs;
using ProjectManagement.Api.Authorization;
using ProjectManagement.Api.Services;

namespace ProjectManagement.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class RevenueController : ControllerBase
    {
        private const string Page = "Revenue";
        private readonly IDatabaseService _db;
        private readonly ILogger<RevenueController> _logger;
        public RevenueController(IDatabaseService db, ILogger<RevenueController> logger)
        { _db = db; _logger = logger; }

        [RequirePermission(Page, "View")]
        [HttpGet("paged")]
        public async Task<IActionResult> GetPaged(
            [FromQuery] int? projectId = null,
            [FromQuery] string? farmType = null,
            [FromQuery] string? revenueType = null,
            [FromQuery] DateTime? fromDate = null,
            [FromQuery] DateTime? toDate = null,
            [FromQuery] int pageNumber = 1,
            [FromQuery] int pageSize = 10,
            [FromQuery] string? sortBy = "revenueDate",
            [FromQuery] string? sortDir = "desc")
        {
            try
            {
                if (projectId.HasValue && !await ProjectAccessHelper.HasProjectAccessAsync(User, _db, projectId.Value))
                    return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
                if (pageNumber < 1) pageNumber = 1;
                if (pageSize < 1) pageSize = 10;
                if (pageSize > 100) pageSize = 100;
                var allowed = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
                    { "revenueId", "revenueDate", "revenueType", "customerName", "amount" };
                if (string.IsNullOrWhiteSpace(sortBy) || !allowed.Contains(sortBy)) sortBy = "revenueDate";
                sortDir = string.Equals(sortDir, "asc", StringComparison.OrdinalIgnoreCase) ? "asc" : "desc";
                var p = new[]
                {
                    new SqlParameter("@ProjectId", (object?)projectId ?? DBNull.Value),
                    new SqlParameter("@UserId", AuditHelper.CurrentUserId(User)),
                    new SqlParameter("@FarmType", (object?)farmType ?? DBNull.Value),
                    new SqlParameter("@RevenueType", (object?)revenueType ?? DBNull.Value),
                    new SqlParameter("@FromDate", (object?)fromDate ?? DBNull.Value),
                    new SqlParameter("@ToDate", (object?)toDate ?? DBNull.Value),
                    new SqlParameter("@PageNumber", pageNumber),
                    new SqlParameter("@PageSize", pageSize),
                    new SqlParameter("@SortBy", sortBy),
                    new SqlParameter("@SortDir", sortDir),
                    new SqlParameter("@TotalRecords", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };
                var (data, outputs) = await _db.ExecuteStoredProcedureWithOutputsAsync<RevenueDto>("usp_Revenue_GetPaged", p);
                var total = outputs.TryGetValue("TotalRecords", out var t) && t != null ? Convert.ToInt32(t) : data.Count;
                return Ok(new { success = true, data, pageNumber, pageSize, totalRecords = total, totalPages = (int)Math.Ceiling(total / (double)pageSize) });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "Revenue paged fetch failed"); }
        }

        [RequirePermission(Page, "Edit")]
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateRevenueRequest req)
        {
            try
            {
                if (req.ProjectId <= 0) return BadRequest(new { success = false, message = "Project is required." });
                if (!await ProjectAccessHelper.HasProjectAccessAsync(User, _db, req.ProjectId))
                    return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
                if (string.IsNullOrWhiteSpace(req.RevenueType)) return BadRequest(new { success = false, message = "Revenue type is required." });
                if (req.Amount < 0) return BadRequest(new { success = false, message = "Amount must not be negative." });
                var me = AuditHelper.CurrentUserId(User);
                var p = new[]
                {
                    new SqlParameter("@RevenueDate", req.RevenueDate),
                    new SqlParameter("@ProjectId", req.ProjectId),
                    new SqlParameter("@FarmType", (object?)req.FarmType ?? DBNull.Value),
                    new SqlParameter("@RevenueType", req.RevenueType.Trim()),
                    new SqlParameter("@ReferenceId", (object?)req.ReferenceId ?? DBNull.Value),
                    new SqlParameter("@CustomerName", (object?)req.CustomerName ?? DBNull.Value),
                    new SqlParameter("@Quantity", (object?)req.Quantity ?? DBNull.Value),
                    new SqlParameter("@Weight", (object?)req.Weight ?? DBNull.Value),
                    new SqlParameter("@Rate", (object?)req.Rate ?? DBNull.Value),
                    new SqlParameter("@Amount", req.Amount),
                    new SqlParameter("@PaymentStatus", (object?)req.PaymentStatus ?? "Pending"),
                    new SqlParameter("@Remarks", (object?)req.Remarks ?? DBNull.Value),
                    new SqlParameter("@CreatedBy", me),
                    new SqlParameter("@RevenueId", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };
                await _db.ExecuteNonQueryAsync("usp_Revenue_Insert", p);
                await AuditHelper.LogAsync(_db, _logger, me, "Revenue Added", Page, null);
                return Ok(new { success = true, message = "Revenue recorded successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "Revenue insert failed"); }
        }

        [RequirePermission(Page, "Edit")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateRevenueRequest req)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(req.RevenueType)) return BadRequest(new { success = false, message = "Revenue type is required." });
                if (req.Amount < 0) return BadRequest(new { success = false, message = "Amount must not be negative." });
                if (!await ProjectAccessHelper.HasEntityAccessAsync(User, _db, "Revenue", id))
                    return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
                var me = AuditHelper.CurrentUserId(User);
                var p = new[]
                {
                    new SqlParameter("@RevenueId", id),
                    new SqlParameter("@RevenueDate", req.RevenueDate),
                    new SqlParameter("@RevenueType", req.RevenueType.Trim()),
                    new SqlParameter("@CustomerName", (object?)req.CustomerName ?? DBNull.Value),
                    new SqlParameter("@Quantity", (object?)req.Quantity ?? DBNull.Value),
                    new SqlParameter("@Weight", (object?)req.Weight ?? DBNull.Value),
                    new SqlParameter("@Rate", (object?)req.Rate ?? DBNull.Value),
                    new SqlParameter("@Amount", req.Amount),
                    new SqlParameter("@PaymentStatus", (object?)req.PaymentStatus ?? DBNull.Value),
                    new SqlParameter("@Remarks", (object?)req.Remarks ?? DBNull.Value),
                    new SqlParameter("@ModifiedBy", me)
                };
                await _db.ExecuteNonQueryAsync("usp_Revenue_Update", p);
                await AuditHelper.LogAsync(_db, _logger, me, "Revenue Updated", Page, id);
                return Ok(new { success = true, message = "Revenue updated successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "Revenue update failed"); }
        }

        [RequirePermission(Page, "Delete")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                if (!await ProjectAccessHelper.HasEntityAccessAsync(User, _db, "Revenue", id))
                    return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
                var me = AuditHelper.CurrentUserId(User);
                await _db.ExecuteNonQueryAsync("usp_Revenue_Delete", new[] { new SqlParameter("@RevenueId", id) });
                await AuditHelper.LogAsync(_db, _logger, me, "Revenue Deleted", Page, id);
                return Ok(new { success = true, message = "Revenue deleted successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "Revenue delete failed"); }
        }
    }
}

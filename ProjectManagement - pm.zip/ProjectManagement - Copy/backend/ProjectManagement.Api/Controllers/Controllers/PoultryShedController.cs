using System.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using ProjectManagement.Api.DTOs;
using ProjectManagement.Api.Authorization;
using ProjectManagement.Api.Services;

namespace ProjectManagement.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class PoultryShedController : ControllerBase
    {
        private const string Page = "Poultry Sheds";
        private readonly IDatabaseService _db;
        private readonly ILogger<PoultryShedController> _logger;
        public PoultryShedController(IDatabaseService db, ILogger<PoultryShedController> logger)
        { _db = db; _logger = logger; }

        [RequirePermission(Page, "View")]
        [HttpGet("paged")]
        public async Task<IActionResult> GetPaged(
            [FromQuery] int? projectId = null,
            [FromQuery] string? searchText = null,
            [FromQuery] int pageNumber = 1,
            [FromQuery] int pageSize = 10,
            [FromQuery] string? sortBy = "shedCode",
            [FromQuery] string? sortDir = "asc")
        {
            try
            {
                if (await ProjectAccessHelper.QueryProjectDeniedAsync(User, _db, projectId)) return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
                if (pageNumber < 1) pageNumber = 1;
                if (pageSize < 1) pageSize = 10;
                if (pageSize > 100) pageSize = 100;
                var allowed = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
                    { "shedId", "shedCode", "shedName", "capacity", "status", "createdDate" };
                if (string.IsNullOrWhiteSpace(sortBy) || !allowed.Contains(sortBy)) sortBy = "shedCode";
                sortDir = string.Equals(sortDir, "desc", StringComparison.OrdinalIgnoreCase) ? "desc" : "asc";
                var p = new[]
                {
                    new SqlParameter("@ProjectId", (object?)projectId ?? DBNull.Value),
                    new SqlParameter("@UserId", AuditHelper.CurrentUserId(User)),
                    new SqlParameter("@SearchText", (object?)searchText ?? DBNull.Value),
                    new SqlParameter("@PageNumber", pageNumber),
                    new SqlParameter("@PageSize", pageSize),
                    new SqlParameter("@SortBy", sortBy),
                    new SqlParameter("@SortDir", sortDir),
                    new SqlParameter("@TotalRecords", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };
                var (data, outputs) = await _db.ExecuteStoredProcedureWithOutputsAsync<PoultryShedDto>("usp_PoultryShed_GetPaged", p);
                var total = outputs.TryGetValue("TotalRecords", out var t) && t != null ? Convert.ToInt32(t) : data.Count;
                return Ok(new { success = true, data, pageNumber, pageSize, totalRecords = total, totalPages = (int)Math.Ceiling(total / (double)pageSize) });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "PoultryShed paged fetch failed"); }
        }

        [RequirePermission(Page, "Edit")]
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreatePoultryShedRequest req)
        {
            try
            {
                if (!await ProjectAccessHelper.HasProjectAccessAsync(User, _db, req.ProjectId)) return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
                if (req.ProjectId <= 0) return BadRequest(new { success = false, message = "Project is required." });
                if (string.IsNullOrWhiteSpace(req.ShedCode)) return BadRequest(new { success = false, message = "Shed code is required." });
                if (string.IsNullOrWhiteSpace(req.ShedName)) return BadRequest(new { success = false, message = "Shed name is required." });
                var me = AuditHelper.CurrentUserId(User);
                var p = new[]
                {
                    new SqlParameter("@ProjectId", req.ProjectId),
                    new SqlParameter("@ShedCode", req.ShedCode.Trim()),
                    new SqlParameter("@ShedName", req.ShedName.Trim()),
                    new SqlParameter("@Capacity", (object?)req.Capacity ?? DBNull.Value),
                    new SqlParameter("@CapacityUnit", (object?)req.CapacityUnit ?? DBNull.Value),
                    new SqlParameter("@ShedType", (object?)req.ShedType ?? DBNull.Value),
                    new SqlParameter("@Status", (object?)req.Status ?? "Active"),
                    new SqlParameter("@CreatedBy", me),
                    new SqlParameter("@ShedId", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };
                await _db.ExecuteNonQueryAsync("usp_PoultryShed_Insert", p);
                await AuditHelper.LogAsync(_db, _logger, me, "Poultry Shed Created", Page, req.ShedCode);
                return Ok(new { success = true, message = "Poultry shed created successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "PoultryShed insert failed"); }
        }

        [RequirePermission(Page, "Edit")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdatePoultryShedRequest req)
        {
            try
            {
                if (!await ProjectAccessHelper.HasEntityAccessAsync(User, _db, "PoultryShed", id)) return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
                if (string.IsNullOrWhiteSpace(req.ShedCode)) return BadRequest(new { success = false, message = "Shed code is required." });
                if (string.IsNullOrWhiteSpace(req.ShedName)) return BadRequest(new { success = false, message = "Shed name is required." });
                var me = AuditHelper.CurrentUserId(User);
                var p = new[]
                {
                    new SqlParameter("@ShedId", id),
                    new SqlParameter("@ShedCode", req.ShedCode.Trim()),
                    new SqlParameter("@ShedName", req.ShedName.Trim()),
                    new SqlParameter("@Capacity", (object?)req.Capacity ?? DBNull.Value),
                    new SqlParameter("@CapacityUnit", (object?)req.CapacityUnit ?? DBNull.Value),
                    new SqlParameter("@ShedType", (object?)req.ShedType ?? DBNull.Value),
                    new SqlParameter("@Status", (object?)req.Status ?? DBNull.Value),
                    new SqlParameter("@ModifiedBy", me)
                };
                await _db.ExecuteNonQueryAsync("usp_PoultryShed_Update", p);
                await AuditHelper.LogAsync(_db, _logger, me, "Poultry Shed Updated", Page, id);
                return Ok(new { success = true, message = "Poultry shed updated successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "PoultryShed update failed"); }
        }

        [RequirePermission(Page, "Delete")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                if (!await ProjectAccessHelper.HasEntityAccessAsync(User, _db, "PoultryShed", id)) return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
                var me = AuditHelper.CurrentUserId(User);
                await _db.ExecuteNonQueryAsync("usp_PoultryShed_Delete", new[] { new SqlParameter("@ShedId", id) });
                await AuditHelper.LogAsync(_db, _logger, me, "Poultry Shed Deleted", Page, id);
                return Ok(new { success = true, message = "Poultry shed deleted successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "PoultryShed delete failed"); }
        }

        [RequirePermission(Page, "Edit")]
        [HttpPost("{id}/activate")]
        public async Task<IActionResult> Activate(int id) => await SetActive(id, true);

        [RequirePermission(Page, "Edit")]
        [HttpPost("{id}/deactivate")]
        public async Task<IActionResult> Deactivate(int id) => await SetActive(id, false);

        private async Task<IActionResult> SetActive(int id, bool active)
        {
            try
            {
                if (!await ProjectAccessHelper.HasEntityAccessAsync(User, _db, "PoultryShed", id)) return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
                var me = AuditHelper.CurrentUserId(User);
                await _db.ExecuteNonQueryAsync("usp_PoultryShed_SetActive", new[]
                {
                    new SqlParameter("@ShedId", id),
                    new SqlParameter("@IsActive", active),
                    new SqlParameter("@ModifiedBy", me)
                });
                return Ok(new { success = true, message = active ? "Shed activated successfully." : "Shed deactivated successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "PoultryShed status change failed"); }
        }
    }
}

using System.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using ProjectManagement.Api.DTOs;
using ProjectManagement.Api.Authorization;
using ProjectManagement.Api.Services;

namespace ProjectManagement.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class ChickPurchaseController : ControllerBase
    {
        private const string Page = "Chick Purchase";
        private readonly IDatabaseService _db;
        private readonly ILogger<ChickPurchaseController> _logger;
        public ChickPurchaseController(IDatabaseService db, ILogger<ChickPurchaseController> logger)
        { _db = db; _logger = logger; }

        [RequirePermission(Page, "View")]
        [HttpGet("paged")]
        public async Task<IActionResult> GetPaged(
            [FromQuery] int? projectId = null,
            [FromQuery] int? batchId = null,
            [FromQuery] DateTime? fromDate = null,
            [FromQuery] DateTime? toDate = null,
            [FromQuery] int pageNumber = 1,
            [FromQuery] int pageSize = 10,
            [FromQuery] string? sortBy = "purchaseDate",
            [FromQuery] string? sortDir = "desc")
        {
            try
            {
                if (await ProjectAccessHelper.QueryProjectDeniedAsync(User, _db, projectId)) return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
                if (pageNumber < 1) pageNumber = 1;
                if (pageSize < 1) pageSize = 10;
                if (pageSize > 100) pageSize = 100;
                var allowed = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
                    { "purchaseId", "purchaseDate", "batchCode", "quantity", "totalAmount" };
                if (string.IsNullOrWhiteSpace(sortBy) || !allowed.Contains(sortBy)) sortBy = "purchaseDate";
                sortDir = string.Equals(sortDir, "asc", StringComparison.OrdinalIgnoreCase) ? "asc" : "desc";
                var p = new[]
                {
                    new SqlParameter("@ProjectId", (object?)projectId ?? DBNull.Value),
                    new SqlParameter("@BatchId", (object?)batchId ?? DBNull.Value),
                    new SqlParameter("@FromDate", (object?)fromDate ?? DBNull.Value),
                    new SqlParameter("@ToDate", (object?)toDate ?? DBNull.Value),
                    new SqlParameter("@PageNumber", pageNumber),
                    new SqlParameter("@PageSize", pageSize),
                    new SqlParameter("@SortBy", sortBy),
                    new SqlParameter("@SortDir", sortDir),
                    new SqlParameter("@TotalRecords", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };
                var (data, outputs) = await _db.ExecuteStoredProcedureWithOutputsAsync<ChickPurchaseDto>("usp_ChickPurchase_GetPaged", p);
                var total = outputs.TryGetValue("TotalRecords", out var t) && t != null ? Convert.ToInt32(t) : data.Count;
                return Ok(new { success = true, data, pageNumber, pageSize, totalRecords = total, totalPages = (int)Math.Ceiling(total / (double)pageSize) });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "ChickPurchase paged fetch failed"); }
        }

        [RequirePermission(Page, "Edit")]
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateChickPurchaseRequest req)
        {
            try
            {
                if (!await ProjectAccessHelper.HasEntityAccessAsync(User, _db, "PoultryBatch", req.BatchId)) return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
                if (req.ExpProjectId.HasValue && req.ExpProjectId.Value > 0 && !await ProjectAccessHelper.HasProjectAccessAsync(User, _db, req.ExpProjectId.Value)) return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
                if (req.BatchId <= 0) return BadRequest(new { success = false, message = "Batch is required." });
                if (req.Quantity <= 0) return BadRequest(new { success = false, message = "Quantity must be greater than zero." });
                var me = AuditHelper.CurrentUserId(User);
                var p = new[]
                {
                    new SqlParameter("@BatchId", req.BatchId),
                    new SqlParameter("@PurchaseDate", req.PurchaseDate),
                    new SqlParameter("@Supplier", (object?)req.Supplier ?? DBNull.Value),
                    new SqlParameter("@Quantity", req.Quantity),
                    new SqlParameter("@Rate", (object?)req.Rate ?? DBNull.Value),
                    new SqlParameter("@ReferenceNo", (object?)req.ReferenceNo ?? DBNull.Value),
                    new SqlParameter("@Remarks", (object?)req.Remarks ?? DBNull.Value),
                    new SqlParameter("@CreatedBy", me),
                    new SqlParameter("@ExpProjectId", (object?)req.ExpProjectId ?? DBNull.Value),
                    new SqlParameter("@ExpBudgetCodeId", (object?)req.ExpBudgetCodeId ?? DBNull.Value),
                    new SqlParameter("@ExpResourceId", (object?)req.ExpResourceId ?? DBNull.Value),
                    new SqlParameter("@PurchaseId", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };
                await _db.ExecuteNonQueryAsync("usp_ChickPurchase_Insert", p);
                await AuditHelper.LogAsync(_db, _logger, me, "Chick Purchase Added", Page, null);
                return Ok(new { success = true, message = "Chick purchase recorded successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "ChickPurchase insert failed"); }
        }

        [RequirePermission(Page, "Edit")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateChickPurchaseRequest req)
        {
            try
            {
                if (!await ProjectAccessHelper.HasEntityAccessAsync(User, _db, "ChickPurchase", id)) return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
                if (req.Quantity <= 0) return BadRequest(new { success = false, message = "Quantity must be greater than zero." });
                var me = AuditHelper.CurrentUserId(User);
                var p = new[]
                {
                    new SqlParameter("@PurchaseId", id),
                    new SqlParameter("@PurchaseDate", req.PurchaseDate),
                    new SqlParameter("@Supplier", (object?)req.Supplier ?? DBNull.Value),
                    new SqlParameter("@Quantity", req.Quantity),
                    new SqlParameter("@Rate", (object?)req.Rate ?? DBNull.Value),
                    new SqlParameter("@ReferenceNo", (object?)req.ReferenceNo ?? DBNull.Value),
                    new SqlParameter("@Remarks", (object?)req.Remarks ?? DBNull.Value),
                    new SqlParameter("@ModifiedBy", me)
                };
                await _db.ExecuteNonQueryAsync("usp_ChickPurchase_Update", p);
                await AuditHelper.LogAsync(_db, _logger, me, "Chick Purchase Updated", Page, id);
                return Ok(new { success = true, message = "Chick purchase updated successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "ChickPurchase update failed"); }
        }

        [RequirePermission(Page, "Delete")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                if (!await ProjectAccessHelper.HasEntityAccessAsync(User, _db, "ChickPurchase", id)) return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
                var me = AuditHelper.CurrentUserId(User);
                await _db.ExecuteNonQueryAsync("usp_ChickPurchase_Delete", new[] { new SqlParameter("@PurchaseId", id) });
                await AuditHelper.LogAsync(_db, _logger, me, "Chick Purchase Deleted", Page, id);
                return Ok(new { success = true, message = "Chick purchase deleted successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "ChickPurchase delete failed"); }
        }
    }
}

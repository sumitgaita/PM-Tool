using System.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using ProjectManagement.Api.DTOs;
using ProjectManagement.Api.Authorization;
using ProjectManagement.Api.Services;

namespace ProjectManagement.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class DashboardController : ControllerBase
    {
        private readonly IDatabaseService _databaseService;
        private readonly ILogger<DashboardController> _logger;

        public DashboardController(IDatabaseService databaseService, ILogger<DashboardController> logger)
        {
            _databaseService = databaseService;
            _logger = logger;
        }

        [RequirePermission("Dashboard", "View")]
        [HttpGet("summary")]
        public async Task<IActionResult> GetSummary([FromQuery] int? projectId = null, [FromQuery] int? budgetCodeId = null, [FromQuery] DateTime? fromDate = null, [FromQuery] DateTime? toDate = null)
        {
            try
            {
                if (await ProjectAccessHelper.QueryProjectDeniedAsync(User, _databaseService, projectId)) return StatusCode(403, new { Success = false, Message = ProjectAccessHelper.DeniedMessage });
                var parameters = new[]
                {
                    new SqlParameter("@ProjectId", (object?)projectId ?? DBNull.Value),
                    new SqlParameter("@BudgetCodeId", (object?)budgetCodeId ?? DBNull.Value),
                    new SqlParameter("@FromDate", (object?)fromDate ?? DBNull.Value),
                    new SqlParameter("@ToDate", (object?)toDate ?? DBNull.Value)
                };

                var summary = await _databaseService.ExecuteStoredProcedureAsync<DashboardSummaryDto>("usp_Dashboard_Summary", parameters);

                return Ok(new { Success = true, Data = summary });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting dashboard summary");
                return StatusCode(500, new { Success = false, Message = "An error occurred while fetching dashboard summary." });
            }
        }

        [RequirePermission("Dashboard", "View")]
        [HttpGet("project-wise")]
        public async Task<IActionResult> GetProjectWise([FromQuery] DateTime? fromDate = null, [FromQuery] DateTime? toDate = null)
        {
            try
            {
                var parameters = new[]
                {
                    new SqlParameter("@FromDate", (object?)fromDate ?? DBNull.Value),
                    new SqlParameter("@ToDate", (object?)toDate ?? DBNull.Value)
                };

                var data = await _databaseService.ExecuteStoredProcedureAsync<ProjectWiseExpenseDto>("usp_Dashboard_ProjectWise", parameters);

                return Ok(new { Success = true, Data = data });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting project-wise dashboard data");
                return StatusCode(500, new { Success = false, Message = "An error occurred while fetching project-wise data." });
            }
        }

        [RequirePermission("Dashboard", "View")]
        [HttpGet("budget-code-wise")]
        public async Task<IActionResult> GetBudgetCodeWise([FromQuery] DateTime? fromDate = null, [FromQuery] DateTime? toDate = null)
        {
            try
            {
                var parameters = new[]
                {
                    new SqlParameter("@FromDate", (object?)fromDate ?? DBNull.Value),
                    new SqlParameter("@ToDate", (object?)toDate ?? DBNull.Value)
                };

                var data = await _databaseService.ExecuteStoredProcedureAsync<BudgetCodeWiseExpenseDto>("usp_Dashboard_BudgetCodeWise", parameters);

                return Ok(new { Success = true, Data = data });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting budget-code-wise dashboard data");
                return StatusCode(500, new { Success = false, Message = "An error occurred while fetching budget-code-wise data." });
            }
        }

        [RequirePermission("Dashboard", "View")]
        [HttpGet("monthly")]
        public async Task<IActionResult> GetMonthly([FromQuery] DateTime? fromDate = null, [FromQuery] DateTime? toDate = null)
        {
            try
            {
                var parameters = new[]
                {
                    new SqlParameter("@FromDate", (object?)fromDate ?? DBNull.Value),
                    new SqlParameter("@ToDate", (object?)toDate ?? DBNull.Value)
                };

                var data = await _databaseService.ExecuteStoredProcedureAsync<MonthlyExpenseDto>("usp_Dashboard_Monthly", parameters);

                return Ok(new { Success = true, Data = data });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting monthly dashboard data");
                return StatusCode(500, new { Success = false, Message = "An error occurred while fetching monthly data." });
            }
        }

        [RequirePermission("Dashboard", "View")]
        [HttpGet("year-wise")]
        public async Task<IActionResult> GetYearWise([FromQuery] int? year = null)
        {
            try
            {
                var parameters = new[]
                {
                    new SqlParameter("@Year", (object?)year ?? DBNull.Value)
                };

                var data = await _databaseService.ExecuteStoredProcedureAsync<YearlyExpenseDto>("usp_Dashboard_YearWise", parameters);

                return Ok(new { Success = true, Data = data });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting year-wise dashboard data");
                return StatusCode(500, new { Success = false, Message = "An error occurred while fetching year-wise data." });
            }
        }

        [RequirePermission("Dashboard", "View")]
        [HttpGet("resource-wise")]
        public async Task<IActionResult> GetResourceWise([FromQuery] DateTime? fromDate = null, [FromQuery] DateTime? toDate = null)
        {
            try
            {
                var parameters = new[]
                {
                    new SqlParameter("@FromDate", (object?)fromDate ?? DBNull.Value),
                    new SqlParameter("@ToDate", (object?)toDate ?? DBNull.Value)
                };

                var data = await _databaseService.ExecuteStoredProcedureAsync<ResourceWiseExpenseDto>("usp_Dashboard_ResourceWise", parameters);

                return Ok(new { Success = true, Data = data });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting resource-wise dashboard data");
                return StatusCode(500, new { Success = false, Message = "An error occurred while fetching resource-wise data." });
            }
        }
    }
}

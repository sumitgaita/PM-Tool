using System.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using ProjectManagement.Api.DTOs;
using ProjectManagement.Api.Authorization;
using ProjectManagement.Api.Services;

namespace ProjectManagement.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class FishTypeController : ControllerBase
    {
        private const string Page = "Fish Types";
        private readonly IDatabaseService _db;
        private readonly ILogger<FishTypeController> _logger;
        public FishTypeController(IDatabaseService db, ILogger<FishTypeController> logger)
        { _db = db; _logger = logger; }

        [RequirePermission(Page, "View")]
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                var data = await _db.ExecuteStoredProcedureAsync<FishTypeDto>("usp_FishType_GetAll");
                return Ok(new { success = true, data });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "FishType fetch failed"); }
        }

        [RequirePermission(Page, "Edit")]
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateFishTypeRequest req)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(req.FishCode)) return BadRequest(new { success = false, message = "Fish code is required." });
                if (string.IsNullOrWhiteSpace(req.FishName)) return BadRequest(new { success = false, message = "Fish name is required." });
                var me = AuditHelper.CurrentUserId(User);
                var p = new[]
                {
                    new SqlParameter("@FishCode", req.FishCode.Trim()),
                    new SqlParameter("@FishName", req.FishName.Trim()),
                    new SqlParameter("@ScientificName", (object?)req.ScientificName ?? DBNull.Value),
                    new SqlParameter("@Description", (object?)req.Description ?? DBNull.Value),
                    new SqlParameter("@CreatedBy", me),
                    new SqlParameter("@FishTypeId", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };
                await _db.ExecuteNonQueryAsync("usp_FishType_Insert", p);
                await AuditHelper.LogAsync(_db, _logger, me, "Fish Type Created", Page, req.FishCode);
                return Ok(new { success = true, message = "Fish type created successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "FishType insert failed"); }
        }

        [RequirePermission(Page, "Edit")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateFishTypeRequest req)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(req.FishCode)) return BadRequest(new { success = false, message = "Fish code is required." });
                if (string.IsNullOrWhiteSpace(req.FishName)) return BadRequest(new { success = false, message = "Fish name is required." });
                var me = AuditHelper.CurrentUserId(User);
                var p = new[]
                {
                    new SqlParameter("@FishTypeId", id),
                    new SqlParameter("@FishCode", req.FishCode.Trim()),
                    new SqlParameter("@FishName", req.FishName.Trim()),
                    new SqlParameter("@ScientificName", (object?)req.ScientificName ?? DBNull.Value),
                    new SqlParameter("@Description", (object?)req.Description ?? DBNull.Value),
                    new SqlParameter("@ModifiedBy", me)
                };
                await _db.ExecuteNonQueryAsync("usp_FishType_Update", p);
                await AuditHelper.LogAsync(_db, _logger, me, "Fish Type Updated", Page, id);
                return Ok(new { success = true, message = "Fish type updated successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "FishType update failed"); }
        }

        [RequirePermission(Page, "Delete")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var me = AuditHelper.CurrentUserId(User);
                await _db.ExecuteNonQueryAsync("usp_FishType_Delete", new[] { new SqlParameter("@FishTypeId", id) });
                await AuditHelper.LogAsync(_db, _logger, me, "Fish Type Deleted", Page, id);
                return Ok(new { success = true, message = "Fish type deleted successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "FishType delete failed"); }
        }

        [RequirePermission(Page, "Edit")]
        [HttpPost("{id}/activate")]
        public async Task<IActionResult> Activate(int id) => await SetActive(id, true);

        [RequirePermission(Page, "Edit")]
        [HttpPost("{id}/deactivate")]
        public async Task<IActionResult> Deactivate(int id) => await SetActive(id, false);

        private async Task<IActionResult> SetActive(int id, bool active)
        {
            try
            {
                var me = AuditHelper.CurrentUserId(User);
                await _db.ExecuteNonQueryAsync("usp_FishType_SetActive", new[]
                {
                    new SqlParameter("@FishTypeId", id),
                    new SqlParameter("@IsActive", active),
                    new SqlParameter("@ModifiedBy", me)
                });
                return Ok(new { success = true, message = active ? "Fish type activated successfully." : "Fish type deactivated successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "FishType status change failed"); }
        }
    }
}

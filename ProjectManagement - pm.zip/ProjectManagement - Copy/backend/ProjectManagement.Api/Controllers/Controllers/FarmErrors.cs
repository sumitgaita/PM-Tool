using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;

namespace ProjectManagement.Api.Controllers;

// Shared error mapping for farming controllers: SQL business-rule
// violations (RAISERROR severity 16 → SqlException Number 50000)
// become 400 responses carrying the rule message; everything else
// becomes a generic 500 without leaking internals.
public static class FarmErrors
{
    public static IActionResult Handle(ILogger logger, Exception ex, string logMessage)
    {
        logger.LogError(ex, "{LogMessage}", logMessage);
        var current = ex;
        while (current != null)
        {
            if (current is SqlException sql && sql.Number == 50000)
                return new BadRequestObjectResult(new { success = false, message = FirstLine(sql.Message) });
            current = current.InnerException;
        }
        return new ObjectResult(new { success = false, message = "An unexpected error occurred. Please try again." }) { StatusCode = 500 };
    }

    private static string FirstLine(string message)
    {
        if (string.IsNullOrWhiteSpace(message)) return "Validation failed.";
        var line = message.Split('\n')[0].Trim();
        return string.IsNullOrWhiteSpace(line) ? "Validation failed." : line;
    }
}

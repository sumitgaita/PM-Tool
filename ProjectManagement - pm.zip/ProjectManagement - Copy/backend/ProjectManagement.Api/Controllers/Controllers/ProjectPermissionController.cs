using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using ProjectManagement.Api.DTOs;
using ProjectManagement.Api.Authorization;
using ProjectManagement.Api.Services;

namespace ProjectManagement.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    [RequireSuperAdmin]
    public class ProjectPermissionController : ControllerBase
    {
        private readonly IDatabaseService _databaseService;
        private readonly ILogger<ProjectPermissionController> _logger;

        public ProjectPermissionController(IDatabaseService databaseService, ILogger<ProjectPermissionController> logger)
        {
            _databaseService = databaseService;
            _logger = logger;
        }

        [HttpGet("user/{userId}")]
        public async Task<IActionResult> GetUserProjects(int userId)
        {
            try
            {
                var target = await _databaseService.ExecuteStoredProcedureAsync<UserDto>(
                    "usp_User_GetById", new[] { new SqlParameter("@UserId", userId) });
                if (target.Count == 0)
                {
                    return NotFound(new { Success = false, Message = "User not found." });
                }

                var isSuperAdmin = string.Equals(target[0].RoleName, "Super Admin", StringComparison.OrdinalIgnoreCase);
                var parameters = new[] { new SqlParameter("@UserId", userId) };
                var data = await _databaseService.ExecuteStoredProcedureAsync<UserProjectDto>("usp_UserProject_GetByUser", parameters);

                if (isSuperAdmin)
                {
                    // Super Admin implicitly accesses every project; assignments cannot be modified.
                    foreach (var row in data)
                    {
                        row.IsAssigned = true;
                    }
                }

                return Ok(new { Success = true, Data = data, IsSuperAdmin = isSuperAdmin });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting project permissions for user: {UserId}", userId);
                return StatusCode(500, new { Success = false, Message = "An error occurred while fetching project permissions." });
            }
        }

        [HttpPost("user/bulk")]
        public async Task<IActionResult> SaveBulk([FromBody] SaveUserProjectsBulkRequest request)
        {
            try
            {
                var target = await _databaseService.ExecuteStoredProcedureAsync<UserDto>(
                    "usp_User_GetById", new[] { new SqlParameter("@UserId", request.UserId) });
                if (target.Count == 0)
                {
                    return NotFound(new { Success = false, Message = "User not found." });
                }
                if (string.Equals(target[0].RoleName, "Super Admin", StringComparison.OrdinalIgnoreCase))
                {
                    return StatusCode(403, new { Success = false, Message = "Super Admin has access to all projects. Project permissions cannot be modified." });
                }

                // The management grid lists running (IsActive + Status='Active')
                // projects only, so the replace is scoped to them: assignments to
                // other projects are kept untouched.
                var assignableProjectIds = (await _databaseService.ExecuteStoredProcedureAsync<ProjectDto>("usp_Project_GetAll"))
                    .Where(p => p.IsActive && string.Equals(p.Status, "Active", StringComparison.OrdinalIgnoreCase))
                    .Select(p => p.ProjectId)
                    .ToHashSet();
                var distinctIds = (request.ProjectIds ?? new List<int>()).Distinct().ToList();
                if (distinctIds.Any(id => !assignableProjectIds.Contains(id)))
                {
                    return BadRequest(new { Success = false, Message = "One or more selected projects do not exist or are not active." });
                }

                var me = GetCurrentUserId();
                var currentlyAssigned = (await _databaseService.ExecuteStoredProcedureAsync<AssignedProjectIdDto>(
                        "usp_UserProject_GetAssignedIds", new[] { new SqlParameter("@UserId", request.UserId) }))
                    .Select(r => r.ProjectId)
                    .ToHashSet();

                var toRemove = currentlyAssigned.Where(id => assignableProjectIds.Contains(id) && !distinctIds.Contains(id)).ToList();
                var toAdd = distinctIds.Where(id => !currentlyAssigned.Contains(id)).ToList();

                foreach (var projectId in toRemove)
                {
                    await _databaseService.ExecuteNonQueryAsync("usp_UserProject_Save", new[]
                    {
                        new SqlParameter("@UserId", request.UserId),
                        new SqlParameter("@ProjectId", projectId),
                        new SqlParameter("@IsAssigned", false),
                        new SqlParameter("@CreatedBy", me)
                    });
                }
                foreach (var projectId in toAdd)
                {
                    await _databaseService.ExecuteNonQueryAsync("usp_UserProject_Save", new[]
                    {
                        new SqlParameter("@UserId", request.UserId),
                        new SqlParameter("@ProjectId", projectId),
                        new SqlParameter("@IsAssigned", true),
                        new SqlParameter("@CreatedBy", me)
                    });
                }

                return Ok(new { Success = true, Message = "Project permissions saved successfully." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error saving project permissions for user");
                return StatusCode(500, new { Success = false, Message = "An error occurred while saving project permissions." });
            }
        }

        private int GetCurrentUserId()
        {
            var userIdClaim = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            return int.TryParse(userIdClaim, out var userId) ? userId : 0;
        }
    }
}

using System.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using ProjectManagement.Api.DTOs;
using ProjectManagement.Api.Authorization;
using ProjectManagement.Api.Services;

namespace ProjectManagement.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class FishStockingController : ControllerBase
    {
        private const string Page = "Fish Stocking";
        private readonly IDatabaseService _db;
        private readonly ILogger<FishStockingController> _logger;
        public FishStockingController(IDatabaseService db, ILogger<FishStockingController> logger)
        { _db = db; _logger = logger; }

        [RequirePermission(Page, "View")]
        [HttpGet("paged")]
        public async Task<IActionResult> GetPaged(
            [FromQuery] int? projectId = null,
            [FromQuery] int? pondId = null,
            [FromQuery] int? fishTypeId = null,
            [FromQuery] string? searchText = null,
            [FromQuery] DateTime? fromDate = null,
            [FromQuery] DateTime? toDate = null,
            [FromQuery] int pageNumber = 1,
            [FromQuery] int pageSize = 10,
            [FromQuery] string? sortBy = "stockingDate",
            [FromQuery] string? sortDir = "desc")
        {
            try
            {
                if (await ProjectAccessHelper.QueryProjectDeniedAsync(User, _db, projectId)) return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
                if (pageNumber < 1) pageNumber = 1;
                if (pageSize < 1) pageSize = 10;
                if (pageSize > 100) pageSize = 100;
                var allowed = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
                    { "stockingId", "stockingDate", "pondCode", "fishName", "quantity", "totalCost" };
                if (string.IsNullOrWhiteSpace(sortBy) || !allowed.Contains(sortBy)) sortBy = "stockingDate";
                sortDir = string.Equals(sortDir, "asc", StringComparison.OrdinalIgnoreCase) ? "asc" : "desc";
                var p = new[]
                {
                    new SqlParameter("@ProjectId", (object?)projectId ?? DBNull.Value),
                    new SqlParameter("@PondId", (object?)pondId ?? DBNull.Value),
                    new SqlParameter("@FishTypeId", (object?)fishTypeId ?? DBNull.Value),
                    new SqlParameter("@SearchText", (object?)searchText ?? DBNull.Value),
                    new SqlParameter("@FromDate", (object?)fromDate ?? DBNull.Value),
                    new SqlParameter("@ToDate", (object?)toDate ?? DBNull.Value),
                    new SqlParameter("@PageNumber", pageNumber),
                    new SqlParameter("@PageSize", pageSize),
                    new SqlParameter("@SortBy", sortBy),
                    new SqlParameter("@SortDir", sortDir),
                    new SqlParameter("@TotalRecords", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };
                var (data, outputs) = await _db.ExecuteStoredProcedureWithOutputsAsync<FishStockingDto>("usp_FishStocking_GetPaged", p);
                var total = outputs.TryGetValue("TotalRecords", out var t) && t != null ? Convert.ToInt32(t) : data.Count;
                return Ok(new { success = true, data, pageNumber, pageSize, totalRecords = total, totalPages = (int)Math.Ceiling(total / (double)pageSize) });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "FishStocking paged fetch failed"); }
        }

        [RequirePermission(Page, "Edit")]
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateFishStockingRequest req)
        {
            try
            {
                if (!await ProjectAccessHelper.HasEntityAccessAsync(User, _db, "Pond", req.PondId)) return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
                if (req.ExpProjectId.HasValue && req.ExpProjectId.Value > 0 && !await ProjectAccessHelper.HasProjectAccessAsync(User, _db, req.ExpProjectId.Value)) return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
                if (req.PondId <= 0) return BadRequest(new { success = false, message = "Pond is required." });
                if (req.FishTypeId <= 0) return BadRequest(new { success = false, message = "Fish type is required." });
                if (req.Quantity <= 0) return BadRequest(new { success = false, message = "Quantity must be greater than zero." });
                var me = AuditHelper.CurrentUserId(User);
                var p = new[]
                {
                    new SqlParameter("@PondId", req.PondId),
                    new SqlParameter("@FishTypeId", req.FishTypeId),
                    new SqlParameter("@StockingDate", req.StockingDate),
                    new SqlParameter("@Quantity", req.Quantity),
                    new SqlParameter("@AverageWeight", (object?)req.AverageWeight ?? DBNull.Value),
                    new SqlParameter("@PurchaseRate", (object?)req.PurchaseRate ?? DBNull.Value),
                    new SqlParameter("@TotalCost", (object?)req.TotalCost ?? DBNull.Value),
                    new SqlParameter("@Supplier", (object?)req.Supplier ?? DBNull.Value),
                    new SqlParameter("@ReferenceNo", (object?)req.ReferenceNo ?? DBNull.Value),
                    new SqlParameter("@Remarks", (object?)req.Remarks ?? DBNull.Value),
                    new SqlParameter("@CreatedBy", me),
                    new SqlParameter("@ExpProjectId", (object?)req.ExpProjectId ?? DBNull.Value),
                    new SqlParameter("@ExpBudgetCodeId", (object?)req.ExpBudgetCodeId ?? DBNull.Value),
                    new SqlParameter("@ExpResourceId", (object?)req.ExpResourceId ?? DBNull.Value),
                    new SqlParameter("@StockingId", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };
                await _db.ExecuteNonQueryAsync("usp_FishStocking_Insert", p);
                await AuditHelper.LogAsync(_db, _logger, me, "Fish Stocking Added", Page, null);
                return Ok(new { success = true, message = "Fish stocking recorded successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "FishStocking insert failed"); }
        }

        [RequirePermission(Page, "Edit")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateFishStockingRequest req)
        {
            try
            {
                if (!await ProjectAccessHelper.HasEntityAccessAsync(User, _db, "FishStocking", id)) return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
                if (req.Quantity <= 0) return BadRequest(new { success = false, message = "Quantity must be greater than zero." });
                var me = AuditHelper.CurrentUserId(User);
                var p = new[]
                {
                    new SqlParameter("@StockingId", id),
                    new SqlParameter("@StockingDate", req.StockingDate),
                    new SqlParameter("@Quantity", req.Quantity),
                    new SqlParameter("@AverageWeight", (object?)req.AverageWeight ?? DBNull.Value),
                    new SqlParameter("@PurchaseRate", (object?)req.PurchaseRate ?? DBNull.Value),
                    new SqlParameter("@TotalCost", (object?)req.TotalCost ?? DBNull.Value),
                    new SqlParameter("@Supplier", (object?)req.Supplier ?? DBNull.Value),
                    new SqlParameter("@ReferenceNo", (object?)req.ReferenceNo ?? DBNull.Value),
                    new SqlParameter("@Remarks", (object?)req.Remarks ?? DBNull.Value),
                    new SqlParameter("@ModifiedBy", me)
                };
                await _db.ExecuteNonQueryAsync("usp_FishStocking_Update", p);
                await AuditHelper.LogAsync(_db, _logger, me, "Fish Stocking Updated", Page, id);
                return Ok(new { success = true, message = "Fish stocking updated successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "FishStocking update failed"); }
        }

        [RequirePermission(Page, "Delete")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                if (!await ProjectAccessHelper.HasEntityAccessAsync(User, _db, "FishStocking", id)) return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
                var me = AuditHelper.CurrentUserId(User);
                await _db.ExecuteNonQueryAsync("usp_FishStocking_Delete", new[] { new SqlParameter("@StockingId", id) });
                await AuditHelper.LogAsync(_db, _logger, me, "Fish Stocking Deleted", Page, id);
                return Ok(new { success = true, message = "Fish stocking deleted successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "FishStocking delete failed"); }
        }
    }
}

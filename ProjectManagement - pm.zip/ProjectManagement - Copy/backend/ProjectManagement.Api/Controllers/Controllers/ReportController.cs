using System.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using ProjectManagement.Api.DTOs;
using ProjectManagement.Api.Authorization;
using ProjectManagement.Api.Services;

namespace ProjectManagement.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class ReportController : ControllerBase
    {
        private readonly IDatabaseService _databaseService;
        private readonly ILogger<ReportController> _logger;

        public ReportController(IDatabaseService databaseService, ILogger<ReportController> logger)
        {
            _databaseService = databaseService;
            _logger = logger;
        }

        [RequirePermission("Reports", "View")]
        [HttpGet("project-wise")]
        public async Task<IActionResult> GetProjectWise([FromQuery] int? projectId = null, [FromQuery] DateTime? fromDate = null, [FromQuery] DateTime? toDate = null, [FromQuery] int? budgetCodeId = null, [FromQuery] int? resourceId = null)
        {
            try
            {
                if (await ProjectAccessHelper.QueryProjectDeniedAsync(User, _databaseService, projectId)) return StatusCode(403, new { Success = false, Message = ProjectAccessHelper.DeniedMessage });
                var parameters = new[]
                {
                    new SqlParameter("@ProjectId", (object?)projectId ?? DBNull.Value),
                    new SqlParameter("@FromDate", (object?)fromDate ?? DBNull.Value),
                    new SqlParameter("@ToDate", (object?)toDate ?? DBNull.Value),
                    new SqlParameter("@BudgetCodeId", (object?)budgetCodeId ?? DBNull.Value),
                    new SqlParameter("@ResourceId", (object?)resourceId ?? DBNull.Value)
                };

                var data = await _databaseService.ExecuteStoredProcedureAsync<ProjectWiseReportDto>("usp_Report_ProjectWise", parameters);

                return Ok(new { Success = true, Data = data });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting project-wise report");
                return StatusCode(500, new { Success = false, Message = "An error occurred while fetching project-wise report." });
            }
        }

        [RequirePermission("Reports", "View")]
        [HttpGet("date-wise/{date}")]
        public async Task<IActionResult> GetDateWise(DateTime date)
        {
            try
            {
                var parameters = new[] { new SqlParameter("@ExpenseDate", date) };
                var data = await _databaseService.ExecuteStoredProcedureAsync<DateWiseReportDto>("usp_Report_DateWise", parameters);

                return Ok(new { Success = true, Data = data });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting date-wise report for date: {Date}", date);
                return StatusCode(500, new { Success = false, Message = "An error occurred while fetching date-wise report." });
            }
        }

        [RequirePermission("Reports", "View")]
        [HttpGet("date-range")]
        public async Task<IActionResult> GetDateRange([FromQuery] DateTime fromDate, [FromQuery] DateTime toDate, [FromQuery] int? projectId = null, [FromQuery] int? budgetCodeId = null, [FromQuery] int? resourceId = null)
        {
            try
            {
                if (await ProjectAccessHelper.QueryProjectDeniedAsync(User, _databaseService, projectId)) return StatusCode(403, new { Success = false, Message = ProjectAccessHelper.DeniedMessage });
                var parameters = new[]
                {
                    new SqlParameter("@FromDate", fromDate),
                    new SqlParameter("@ToDate", toDate),
                    new SqlParameter("@ProjectId", (object?)projectId ?? DBNull.Value),
                    new SqlParameter("@BudgetCodeId", (object?)budgetCodeId ?? DBNull.Value),
                    new SqlParameter("@ResourceId", (object?)resourceId ?? DBNull.Value)
                };

                var data = await _databaseService.ExecuteStoredProcedureAsync<DateRangeReportDto>("usp_Report_DateRange", parameters);

                return Ok(new { Success = true, Data = data });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting date-range report");
                return StatusCode(500, new { Success = false, Message = "An error occurred while fetching date-range report." });
            }
        }

        [RequirePermission("Reports", "View")]
        [HttpGet("cost-vs-budget")]
        public async Task<IActionResult> GetCostVsBudget([FromQuery] int? projectId = null, [FromQuery] int? budgetCodeId = null, [FromQuery] DateTime? fromDate = null, [FromQuery] DateTime? toDate = null)
        {
            try
            {
                if (await ProjectAccessHelper.QueryProjectDeniedAsync(User, _databaseService, projectId)) return StatusCode(403, new { Success = false, Message = ProjectAccessHelper.DeniedMessage });
                var parameters = new[]
                {
                    new SqlParameter("@ProjectId", (object?)projectId ?? DBNull.Value),
                    new SqlParameter("@BudgetCodeId", (object?)budgetCodeId ?? DBNull.Value),
                    new SqlParameter("@FromDate", (object?)fromDate ?? DBNull.Value),
                    new SqlParameter("@ToDate", (object?)toDate ?? DBNull.Value)
                };

                var data = await _databaseService.ExecuteStoredProcedureAsync<CostVsBudgetReportDto>("usp_Report_CostVsBudget", parameters);

                return Ok(new { Success = true, Data = data });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting cost vs budget report");
                return StatusCode(500, new { Success = false, Message = "An error occurred while fetching cost vs budget report." });
            }
        }
    }
}

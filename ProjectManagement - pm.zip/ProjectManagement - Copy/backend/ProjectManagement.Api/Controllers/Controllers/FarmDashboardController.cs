using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using ProjectManagement.Api.DTOs;
using ProjectManagement.Api.Authorization;
using ProjectManagement.Api.Services;

namespace ProjectManagement.Api.Controllers
{
    // §97-§99 dashboards. All aggregation happens in SQL procedures.
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class FarmDashboardController : ControllerBase
    {
        private readonly IDatabaseService _db;
        private readonly ILogger<FarmDashboardController> _logger;
        public FarmDashboardController(IDatabaseService db, ILogger<FarmDashboardController> logger)
        { _db = db; _logger = logger; }

        private static SqlParameter[] Scope(int? projectId, string? farmType, DateTime? from, DateTime? to) => new[]
        {
            new SqlParameter("@ProjectId", (object?)projectId ?? DBNull.Value),
            new SqlParameter("@FarmType", (object?)farmType ?? DBNull.Value),
            new SqlParameter("@FromDate", (object?)from ?? DBNull.Value),
            new SqlParameter("@ToDate", (object?)to ?? DBNull.Value)
        };

        [RequirePermission("Dashboard", "View")]
        [HttpGet("summary")]
        public async Task<IActionResult> Summary(
            [FromQuery] int? projectId = null, [FromQuery] string? farmType = null,
            [FromQuery] DateTime? fromDate = null, [FromQuery] DateTime? toDate = null)
        {
            if (await ProjectAccessHelper.QueryProjectDeniedAsync(User, _db, projectId)) return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
            try
            {
                var data = await _db.ExecuteStoredProcedureAsync<FarmDashboardSummaryDto>(
                    "usp_FarmDashboard_Summary", Scope(projectId, farmType, fromDate, toDate));
                return Ok(new { success = true, data = data.FirstOrDefault() });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "Farm dashboard summary failed"); }
        }

        [RequirePermission("Dashboard", "View")]
        [HttpGet("fish-kpis")]
        public async Task<IActionResult> FishKpis(
            [FromQuery] int? projectId = null,
            [FromQuery] DateTime? fromDate = null, [FromQuery] DateTime? toDate = null)
        {
            if (await ProjectAccessHelper.QueryProjectDeniedAsync(User, _db, projectId)) return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
            try
            {
                var p = new[]
                {
                    new SqlParameter("@ProjectId", (object?)projectId ?? DBNull.Value),
                    new SqlParameter("@FromDate", (object?)fromDate ?? DBNull.Value),
                    new SqlParameter("@ToDate", (object?)toDate ?? DBNull.Value)
                };
                var data = await _db.ExecuteStoredProcedureAsync<FishDashboardKpisDto>("usp_FishDashboard_Kpis", p);
                return Ok(new { success = true, data = data.FirstOrDefault() });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "Fish dashboard KPIs failed"); }
        }

        [RequirePermission("Dashboard", "View")]
        [HttpGet("poultry-kpis")]
        public async Task<IActionResult> PoultryKpis(
            [FromQuery] int? projectId = null,
            [FromQuery] DateTime? fromDate = null, [FromQuery] DateTime? toDate = null)
        {
            if (await ProjectAccessHelper.QueryProjectDeniedAsync(User, _db, projectId)) return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
            try
            {
                var p = new[]
                {
                    new SqlParameter("@ProjectId", (object?)projectId ?? DBNull.Value),
                    new SqlParameter("@FromDate", (object?)fromDate ?? DBNull.Value),
                    new SqlParameter("@ToDate", (object?)toDate ?? DBNull.Value)
                };
                var data = await _db.ExecuteStoredProcedureAsync<PoultryDashboardKpisDto>("usp_PoultryDashboard_Kpis", p);
                return Ok(new { success = true, data = data.FirstOrDefault() });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "Poultry dashboard KPIs failed"); }
        }

        [RequirePermission("Dashboard", "View")]
        [HttpGet("monthly")]
        public async Task<IActionResult> Monthly(
            [FromQuery] int? projectId = null, [FromQuery] string? farmType = null,
            [FromQuery] DateTime? fromDate = null, [FromQuery] DateTime? toDate = null)
        {
            if (await ProjectAccessHelper.QueryProjectDeniedAsync(User, _db, projectId)) return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
            try
            {
                var data = await _db.ExecuteStoredProcedureAsync<FarmMonthlyDto>(
                    "usp_FarmDashboard_Monthly", Scope(projectId, farmType, fromDate, toDate));
                return Ok(new { success = true, data });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "Farm dashboard monthly failed"); }
        }

        [RequirePermission("Dashboard", "View")]
        [HttpGet("typewise")]
        public async Task<IActionResult> TypeWise([FromQuery] int? projectId = null)
        {
            if (await ProjectAccessHelper.QueryProjectDeniedAsync(User, _db, projectId)) return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
            try
            {
                var data = await _db.ExecuteStoredProcedureAsync<FishTypeWiseDto>(
                    "usp_FishDashboard_TypeWise", new[] { new SqlParameter("@ProjectId", (object?)projectId ?? DBNull.Value) });
                return Ok(new { success = true, data });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "Fish type-wise failed"); }
        }

        [RequirePermission("Dashboard", "View")]
        [HttpGet("pondwise")]
        public async Task<IActionResult> PondWise([FromQuery] int? projectId = null)
        {
            if (await ProjectAccessHelper.QueryProjectDeniedAsync(User, _db, projectId)) return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
            try
            {
                var data = await _db.ExecuteStoredProcedureAsync<FishPondWiseDto>(
                    "usp_FishDashboard_PondWise", new[] { new SqlParameter("@ProjectId", (object?)projectId ?? DBNull.Value) });
                return Ok(new { success = true, data });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "Fish pond-wise failed"); }
        }

        [RequirePermission("Dashboard", "View")]
        [HttpGet("batchwise")]
        public async Task<IActionResult> BatchWise([FromQuery] int? projectId = null)
        {
            if (await ProjectAccessHelper.QueryProjectDeniedAsync(User, _db, projectId)) return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
            try
            {
                var data = await _db.ExecuteStoredProcedureAsync<PoultryBatchWiseDto>(
                    "usp_PoultryDashboard_BatchWise", new[] { new SqlParameter("@ProjectId", (object?)projectId ?? DBNull.Value) });
                return Ok(new { success = true, data });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "Poultry batch-wise failed"); }
        }

        [RequirePermission("Dashboard", "View")]
        [HttpGet("eggs")]
        public async Task<IActionResult> Eggs(
            [FromQuery] int? projectId = null,
            [FromQuery] DateTime? fromDate = null, [FromQuery] DateTime? toDate = null)
        {
            if (await ProjectAccessHelper.QueryProjectDeniedAsync(User, _db, projectId)) return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
            try
            {
                var p = new[]
                {
                    new SqlParameter("@ProjectId", (object?)projectId ?? DBNull.Value),
                    new SqlParameter("@FromDate", (object?)fromDate ?? DBNull.Value),
                    new SqlParameter("@ToDate", (object?)toDate ?? DBNull.Value)
                };
                var data = await _db.ExecuteStoredProcedureAsync<EggSeriesDto>("usp_PoultryDashboard_Eggs", p);
                return Ok(new { success = true, data });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "Poultry egg series failed"); }
        }
    }
}

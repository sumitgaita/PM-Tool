using System.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using ProjectManagement.Api.DTOs;
using ProjectManagement.Api.Authorization;
using ProjectManagement.Api.Services;

namespace ProjectManagement.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class ResourceController : ControllerBase
    {
        private readonly IDatabaseService _databaseService;
        private readonly ILogger<ResourceController> _logger;

        public ResourceController(IDatabaseService databaseService, ILogger<ResourceController> logger)
        {
            _databaseService = databaseService;
            _logger = logger;
        }

        [RequirePermission("Resources", "View")]
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                var resources = await _databaseService.ExecuteStoredProcedureAsync<ResourceDto>("usp_Resource_GetAll");
                return Ok(new { Success = true, Data = resources });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting all resources");
                return StatusCode(500, new { Success = false, Message = "An error occurred while fetching resources." });
            }
        }

        [RequirePermission("Resources", "View")]
        [HttpGet("paged")]
        public async Task<IActionResult> GetPaged(
            [FromQuery] string? searchText = null,
            [FromQuery] int pageNumber = 1,
            [FromQuery] int pageSize = 10,
            [FromQuery] string? sortBy = "resourceCode",
            [FromQuery] string? sortDir = "asc")
        {
            try
            {
                if (pageNumber < 1) pageNumber = 1;
                if (pageSize < 1) pageSize = 10;
                if (pageSize > 100) pageSize = 100;

                var allowedSortBy = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
                {
                    "resourceId", "resourceCode", "resourceName",
                    "resourceType", "department", "createdDate"
                };
                if (string.IsNullOrWhiteSpace(sortBy) || !allowedSortBy.Contains(sortBy)) sortBy = "resourceCode";
                sortDir = string.Equals(sortDir, "desc", StringComparison.OrdinalIgnoreCase) ? "desc" : "asc";

                var parameters = new[]
                {
                    new SqlParameter("@SearchText", (object?)searchText ?? DBNull.Value),
                    new SqlParameter("@PageNumber", pageNumber),
                    new SqlParameter("@PageSize", pageSize),
                    new SqlParameter("@SortBy", sortBy),
                    new SqlParameter("@SortDir", sortDir),
                    new SqlParameter("@TotalRecords", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };

                var (resources, outputs) = await _databaseService.ExecuteStoredProcedureWithOutputsAsync<ResourceDto>("usp_Resource_GetPaged", parameters);
                var totalRecords = outputs.TryGetValue("TotalRecords", out var total) && total != null
                    ? Convert.ToInt32(total)
                    : resources.Count;
                var totalPages = (int)Math.Ceiling(totalRecords / (double)pageSize);

                return Ok(new { Success = true, Data = resources, PageNumber = pageNumber, PageSize = pageSize, TotalRecords = totalRecords, TotalPages = totalPages });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting paged resources");
                return StatusCode(500, new { Success = false, Message = "An error occurred while fetching resources." });
            }
        }

        [RequirePermission("Resources", "Edit")]
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateResourceRequest request)
        {
            try
            {
                var createdBy = GetCurrentUserId();

                var parameters = new[]
                {
                    new SqlParameter("@ResourceCode", request.ResourceCode),
                    new SqlParameter("@ResourceName", request.ResourceName),
                    new SqlParameter("@ResourceType", request.ResourceType),
                    new SqlParameter("@Email", (object?)request.Email ?? DBNull.Value),
                    new SqlParameter("@Phone", (object?)request.Phone ?? DBNull.Value),
                    new SqlParameter("@Department", (object?)request.Department ?? DBNull.Value),
                    new SqlParameter("@CreatedBy", createdBy),
                    new SqlParameter("@ResourceId", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };

                await _databaseService.ExecuteNonQueryAsync("usp_Resource_Insert", parameters);

                return Ok(new { Success = true, Message = "Resource created successfully." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating resource");
                return StatusCode(500, new { Success = false, Message = "An error occurred while creating resource." });
            }
        }

        [RequirePermission("Resources", "Edit")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateResourceRequest request)
        {
            try
            {
                var modifiedBy = GetCurrentUserId();

                var parameters = new[]
                {
                    new SqlParameter("@ResourceId", id),
                    new SqlParameter("@ResourceName", request.ResourceName),
                    new SqlParameter("@ResourceType", request.ResourceType),
                    new SqlParameter("@Email", (object?)request.Email ?? DBNull.Value),
                    new SqlParameter("@Phone", (object?)request.Phone ?? DBNull.Value),
                    new SqlParameter("@Department", (object?)request.Department ?? DBNull.Value),
                    new SqlParameter("@ModifiedBy", modifiedBy)
                };

                await _databaseService.ExecuteNonQueryAsync("usp_Resource_Update", parameters);

                return Ok(new { Success = true, Message = "Resource updated successfully." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating resource: {ResourceId}", id);
                return StatusCode(500, new { Success = false, Message = "An error occurred while updating resource." });
            }
        }

        [RequirePermission("Resources", "Edit")]
        [HttpPost("{id}/activate")]
        public async Task<IActionResult> Activate(int id)
        {
            try
            {
                var modifiedBy = GetCurrentUserId();
                var parameters = new[]
                {
                    new SqlParameter("@ResourceId", id),
                    new SqlParameter("@IsActive", true),
                    new SqlParameter("@ModifiedBy", modifiedBy)
                };

                await _databaseService.ExecuteNonQueryAsync("usp_Resource_SetActive", parameters);

                return Ok(new { Success = true, Message = "Resource activated successfully." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error activating resource: {ResourceId}", id);
                return StatusCode(500, new { Success = false, Message = "An error occurred while activating resource." });
            }
        }

        [RequirePermission("Resources", "Edit")]
        [HttpPost("{id}/deactivate")]
        public async Task<IActionResult> Deactivate(int id)
        {
            try
            {
                var modifiedBy = GetCurrentUserId();
                var parameters = new[]
                {
                    new SqlParameter("@ResourceId", id),
                    new SqlParameter("@IsActive", false),
                    new SqlParameter("@ModifiedBy", modifiedBy)
                };

                await _databaseService.ExecuteNonQueryAsync("usp_Resource_SetActive", parameters);

                return Ok(new { Success = true, Message = "Resource deactivated successfully." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deactivating resource: {ResourceId}", id);
                return StatusCode(500, new { Success = false, Message = "An error occurred while deactivating resource." });
            }
        }

        [RequirePermission("Resources", "Delete")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var modifiedBy = GetCurrentUserId();
                var parameters = new[]
                {
                    new SqlParameter("@ResourceId", id),
                    new SqlParameter("@IsActive", false),
                    new SqlParameter("@ModifiedBy", modifiedBy)
                };

                await _databaseService.ExecuteNonQueryAsync("usp_Resource_SetActive", parameters);

                return Ok(new { Success = true, Message = "Resource deleted (deactivated) successfully." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting resource: {ResourceId}", id);
                return StatusCode(500, new { Success = false, Message = "An error occurred while deleting resource." });
            }
        }

        private int GetCurrentUserId()
        {
            var userIdClaim = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            return int.TryParse(userIdClaim, out var userId) ? userId : 0;
        }
    }
}

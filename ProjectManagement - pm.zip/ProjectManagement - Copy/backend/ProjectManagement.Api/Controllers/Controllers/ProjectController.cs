using System.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using ProjectManagement.Api.DTOs;
using ProjectManagement.Api.Authorization;
using ProjectManagement.Api.Services;

namespace ProjectManagement.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class ProjectController : ControllerBase
    {
        private readonly IDatabaseService _databaseService;
        private readonly ILogger<ProjectController> _logger;

        public ProjectController(IDatabaseService databaseService, ILogger<ProjectController> logger)
        {
            _databaseService = databaseService;
            _logger = logger;
        }

        [RequirePermission("Projects", "View")]
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                if (IsSuperAdmin())
                {
                    var projects = await _databaseService.ExecuteStoredProcedureAsync<ProjectDto>("usp_Project_GetAll");
                    return Ok(new { Success = true, Data = projects });
                }

                // Admin/Normal users only see projects assigned to them (see Project Permissions page).
                var mine = await _databaseService.ExecuteStoredProcedureAsync<ProjectDto>(
                    "usp_UserProject_GetMyProjects", new[] { new SqlParameter("@UserId", GetCurrentUserId()) });
                return Ok(new { Success = true, Data = mine });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting all projects");
                return StatusCode(500, new { Success = false, Message = "An error occurred while fetching projects." });
            }
        }

        [RequirePermission("Projects", "View")]
        [HttpGet("mine")]
        public async Task<IActionResult> Mine()
        {
            try
            {
                if (IsSuperAdmin())
                {
                    var all = await _databaseService.ExecuteStoredProcedureAsync<ProjectDto>("usp_Project_GetAll");
                    return Ok(new { Success = true, Data = all });
                }

                var parameters = new[] { new SqlParameter("@UserId", GetCurrentUserId()) };
                var mine = await _databaseService.ExecuteStoredProcedureAsync<ProjectDto>("usp_UserProject_GetMyProjects", parameters);
                return Ok(new { Success = true, Data = mine });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting my projects");
                return StatusCode(500, new { Success = false, Message = "An error occurred while fetching projects." });
            }
        }

        [RequirePermission("Projects", "View")]
        [HttpGet("paged")]
        public async Task<IActionResult> GetPaged(
            [FromQuery] string? searchText = null,
            [FromQuery] string? status = null,
            [FromQuery] string? farmType = null,
            [FromQuery] int pageNumber = 1,
            [FromQuery] int pageSize = 10,
            [FromQuery] string? sortBy = "projectCode",
            [FromQuery] string? sortDir = "asc")
        {
            try
            {
                if (pageNumber < 1) pageNumber = 1;
                if (pageSize < 1) pageSize = 10;
                if (pageSize > 100) pageSize = 100;

                var allowedSortBy = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
                {
                    "projectId", "projectCode", "projectName",
                    "clientName", "status", "totalBudget", "createdDate"
                };
                if (string.IsNullOrWhiteSpace(sortBy) || !allowedSortBy.Contains(sortBy)) sortBy = "projectCode";
                sortDir = string.Equals(sortDir, "desc", StringComparison.OrdinalIgnoreCase) ? "desc" : "asc";

                var parameters = new[]
                {
                    new SqlParameter("@SearchText", (object?)searchText ?? DBNull.Value),
                    new SqlParameter("@Status", (object?)status ?? DBNull.Value),
                    new SqlParameter("@FarmType", (object?)farmType ?? DBNull.Value),
                    new SqlParameter("@PageNumber", pageNumber),
                    new SqlParameter("@PageSize", pageSize),
                    new SqlParameter("@SortBy", sortBy),
                    new SqlParameter("@SortDir", sortDir),
                    new SqlParameter("@TotalRecords", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };

                // Admin/Normal users only see assigned projects (Super Admin sees all).
                var procedureName = "usp_Project_GetPaged";
                if (!IsSuperAdmin())
                {
                    parameters =
                    [
                        new SqlParameter("@UserId", GetCurrentUserId()),
                        .. parameters,
                    ];
                    procedureName = "usp_Project_GetPagedAuthorized";
                }

                var (projects, outputs) = await _databaseService.ExecuteStoredProcedureWithOutputsAsync<ProjectDto>(procedureName, parameters);
                var totalRecords = outputs.TryGetValue("TotalRecords", out var total) && total != null
                    ? Convert.ToInt32(total)
                    : projects.Count;
                var totalPages = (int)Math.Ceiling(totalRecords / (double)pageSize);

                return Ok(new { Success = true, Data = projects, PageNumber = pageNumber, PageSize = pageSize, TotalRecords = totalRecords, TotalPages = totalPages });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting paged projects");
                return StatusCode(500, new { Success = false, Message = "An error occurred while fetching projects." });
            }
        }

        [RequirePermission("Projects", "View")]
        [HttpGet("paged/inactive")]
        public async Task<IActionResult> GetPagedInactive(
            [FromQuery] string? searchText = null,
            [FromQuery] string? status = null,
            [FromQuery] string? farmType = null,
            [FromQuery] int pageNumber = 1,
            [FromQuery] int pageSize = 10,
            [FromQuery] string? sortBy = "projectCode",
            [FromQuery] string? sortDir = "asc")
        {
            try
            {
                if (pageNumber < 1) pageNumber = 1;
                if (pageSize < 1) pageSize = 10;
                if (pageSize > 100) pageSize = 100;

                var allowedSortBy = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
                {
                    "projectId", "projectCode", "projectName",
                    "clientName", "status", "totalBudget", "createdDate"
                };
                if (string.IsNullOrWhiteSpace(sortBy) || !allowedSortBy.Contains(sortBy)) sortBy = "projectCode";
                sortDir = string.Equals(sortDir, "desc", StringComparison.OrdinalIgnoreCase) ? "desc" : "asc";

                var parameters = new[]
                {
                    new SqlParameter("@UserId", GetCurrentUserId()),
                    new SqlParameter("@SearchText", (object?)searchText ?? DBNull.Value),
                    new SqlParameter("@Status", (object?)status ?? DBNull.Value),
                    new SqlParameter("@FarmType", (object?)farmType ?? DBNull.Value),
                    new SqlParameter("@PageNumber", pageNumber),
                    new SqlParameter("@PageSize", pageSize),
                    new SqlParameter("@SortBy", sortBy),
                    new SqlParameter("@SortDir", sortDir),
                    new SqlParameter("@TotalRecords", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };

                var (projects, outputs) = await _databaseService.ExecuteStoredProcedureWithOutputsAsync<ProjectDto>("usp_Project_GetPagedInactive", parameters);
                var totalRecords = outputs.TryGetValue("TotalRecords", out var total) && total != null
                    ? Convert.ToInt32(total)
                    : projects.Count;
                var totalPages = (int)Math.Ceiling(totalRecords / (double)pageSize);

                return Ok(new { Success = true, Data = projects, PageNumber = pageNumber, PageSize = pageSize, TotalRecords = totalRecords, TotalPages = totalPages });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting paged inactive projects");
                return StatusCode(500, new { Success = false, Message = "An error occurred while fetching projects." });
            }
        }

        [RequirePermission("Projects", "View")]
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            try
            {
                var parameters = new[] { new SqlParameter("@ProjectId", id) };
                var projects = await _databaseService.ExecuteStoredProcedureAsync<ProjectDto>("usp_Project_GetById", parameters);

                if (projects.Count == 0)
                {
                    return NotFound(new { Success = false, Message = "Project not found." });
                }

                if (!IsSuperAdmin() && !await HasProjectAccessAsync(id))
                {
                    return StatusCode(403, new { Success = false, Message = "Access denied. This project is not assigned to you." });
                }

                return Ok(new { Success = true, Data = projects[0] });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting project by id: {ProjectId}", id);
                return StatusCode(500, new { Success = false, Message = "An error occurred while fetching project." });
            }
        }

        [RequirePermission("Projects", "Edit")]
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateProjectRequest request)
        {
            try
            {
                var createdBy = GetCurrentUserId();

                var parameters = new[]
                {
                    new SqlParameter("@ProjectCode", request.ProjectCode),
                    new SqlParameter("@ProjectName", request.ProjectName),
                    new SqlParameter("@Description", (object?)request.Description ?? DBNull.Value),
                    new SqlParameter("@ClientName", (object?)request.ClientName ?? DBNull.Value),
                    new SqlParameter("@StartDate", (object?)request.StartDate ?? DBNull.Value),
                    new SqlParameter("@EndDate", (object?)request.EndDate ?? DBNull.Value),
                    new SqlParameter("@TotalBudget", request.TotalBudget),
                    new SqlParameter("@Status", request.Status),
                    new SqlParameter("@FarmType", (object?)request.FarmType ?? DBNull.Value),
                    new SqlParameter("@CreatedBy", createdBy),
                    new SqlParameter("@ProjectId", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };

                var (_, outputs) = await _databaseService.ExecuteStoredProcedureWithOutputsAsync<ProjectDto>("usp_Project_Insert", parameters);

                // The creator gets access to the new project automatically
                // (Super Admin implicitly accesses everything).
                if (!IsSuperAdmin()
                    && outputs.TryGetValue("ProjectId", out var newId)
                    && newId != null
                    && int.TryParse(newId.ToString(), out var newProjectId)
                    && newProjectId > 0)
                {
                    await _databaseService.ExecuteNonQueryAsync("usp_UserProject_Save", new[]
                    {
                        new SqlParameter("@UserId", createdBy),
                        new SqlParameter("@ProjectId", newProjectId),
                        new SqlParameter("@IsAssigned", true),
                        new SqlParameter("@CreatedBy", createdBy)
                    });
                }

                return Ok(new { Success = true, Message = "Project created successfully." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating project");
                return StatusCode(500, new { Success = false, Message = "An error occurred while creating project." });
            }
        }

        [RequirePermission("Projects", "Edit")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateProjectRequest request)
        {
            try
            {
                if (!IsSuperAdmin() && !await HasProjectAccessAsync(id))
                {
                    return StatusCode(403, new { Success = false, Message = "Access denied. This project is not assigned to you." });
                }

                var modifiedBy = GetCurrentUserId();

                var parameters = new[]
                {
                    new SqlParameter("@ProjectId", id),
                    new SqlParameter("@ProjectName", request.ProjectName),
                    new SqlParameter("@Description", (object?)request.Description ?? DBNull.Value),
                    new SqlParameter("@ClientName", (object?)request.ClientName ?? DBNull.Value),
                    new SqlParameter("@StartDate", (object?)request.StartDate ?? DBNull.Value),
                    new SqlParameter("@EndDate", (object?)request.EndDate ?? DBNull.Value),
                    new SqlParameter("@TotalBudget", request.TotalBudget),
                    new SqlParameter("@Status", request.Status),
                    new SqlParameter("@FarmType", (object?)request.FarmType ?? DBNull.Value),
                    new SqlParameter("@ModifiedBy", modifiedBy)
                };

                await _databaseService.ExecuteNonQueryAsync("usp_Project_Update", parameters);

                return Ok(new { Success = true, Message = "Project updated successfully." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating project: {ProjectId}", id);
                return StatusCode(500, new { Success = false, Message = "An error occurred while updating project." });
            }
        }

        [RequirePermission("Projects", "Edit")]
        [HttpPost("{id}/activate")]
        public async Task<IActionResult> Activate(int id)
        {
            try
            {
                if (!IsSuperAdmin() && !await HasProjectAccessAsync(id))
                {
                    return StatusCode(403, new { Success = false, Message = "Access denied. This project is not assigned to you." });
                }

                var modifiedBy = GetCurrentUserId();
                var parameters = new[]
                {
                    new SqlParameter("@ProjectId", id),
                    new SqlParameter("@IsActive", true),
                    new SqlParameter("@ModifiedBy", modifiedBy)
                };

                await _databaseService.ExecuteNonQueryAsync("usp_Project_SetActive", parameters);

                return Ok(new { Success = true, Message = "Project activated successfully." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error activating project: {ProjectId}", id);
                return StatusCode(500, new { Success = false, Message = "An error occurred while activating project." });
            }
        }

        [RequirePermission("Projects", "Edit")]
        [HttpPost("{id}/deactivate")]
        public async Task<IActionResult> Deactivate(int id)
        {
            try
            {
                if (!IsSuperAdmin() && !await HasProjectAccessAsync(id))
                {
                    return StatusCode(403, new { Success = false, Message = "Access denied. This project is not assigned to you." });
                }

                var modifiedBy = GetCurrentUserId();
                var parameters = new[]
                {
                    new SqlParameter("@ProjectId", id),
                    new SqlParameter("@IsActive", false),
                    new SqlParameter("@ModifiedBy", modifiedBy)
                };

                await _databaseService.ExecuteNonQueryAsync("usp_Project_SetActive", parameters);

                return Ok(new { Success = true, Message = "Project deactivated successfully." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deactivating project: {ProjectId}", id);
                return StatusCode(500, new { Success = false, Message = "An error occurred while deactivating project." });
            }
        }

        [RequirePermission("Projects", "Delete")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                if (!IsSuperAdmin() && !await HasProjectAccessAsync(id))
                {
                    return StatusCode(403, new { Success = false, Message = "Access denied. This project is not assigned to you." });
                }

                var modifiedBy = GetCurrentUserId();
                var parameters = new[]
                {
                    new SqlParameter("@ProjectId", id),
                    new SqlParameter("@IsActive", false),
                    new SqlParameter("@ModifiedBy", modifiedBy)
                };

                await _databaseService.ExecuteNonQueryAsync("usp_Project_SetActive", parameters);

                return Ok(new { Success = true, Message = "Project deleted (deactivated) successfully." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting project: {ProjectId}", id);
                return StatusCode(500, new { Success = false, Message = "An error occurred while deleting project." });
            }
        }

        private int GetCurrentUserId()
        {
            var userIdClaim = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            return int.TryParse(userIdClaim, out var userId) ? userId : 0;
        }

        private bool IsSuperAdmin()
        {
            var role = User.FindFirst(System.Security.Claims.ClaimTypes.Role)?.Value;
            return string.Equals(role, "Super Admin", StringComparison.OrdinalIgnoreCase);
        }

        private async Task<HashSet<int>> GetAssignedProjectIdsAsync()
        {
            var rows = await _databaseService.ExecuteStoredProcedureAsync<AssignedProjectIdDto>(
                "usp_UserProject_GetAssignedIds", new[] { new SqlParameter("@UserId", GetCurrentUserId()) });
            return rows.Select(r => r.ProjectId).ToHashSet();
        }

        private async Task<bool> HasProjectAccessAsync(int projectId)
        {
            return (await GetAssignedProjectIdsAsync()).Contains(projectId);
        }
    }
}

using System.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using ProjectManagement.Api.DTOs;
using ProjectManagement.Api.Authorization;
using ProjectManagement.Api.Services;

namespace ProjectManagement.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class PermissionController : ControllerBase
    {
        private readonly IDatabaseService _db;
        private readonly ILogger<PermissionController> _logger;
        public PermissionController(IDatabaseService db, ILogger<PermissionController> logger)
        { _db = db; _logger = logger; }

        public class PageDto { public int PageId { get; set; } public string PageName { get; set; } = ""; public string? PageDescription { get; set; } }
        public class SavePermissionsBulkRequest { public int UserId { get; set; } public List<SavePermissionRequest> Permissions { get; set; } = new(); }

        [RequirePermission("Permissions", "View")]
        [HttpGet("pages")]
        public async Task<IActionResult> GetPages()
        {
            var data = await _db.ExecuteStoredProcedureAsync<PageDto>("usp_Pages_GetAll");
            return Ok(new { success = true, data });
        }

        [RequirePermission("Permissions", "View")]
        [HttpGet("user/{userId}")]
        public async Task<IActionResult> GetUserPermissions(int userId)
        {
            // Admin has full access implicitly
            var role = User.FindFirst(System.Security.Claims.ClaimTypes.Role)?.Value;
            var p = new[] { new SqlParameter("@UserId", userId) };
            var data = await _db.ExecuteStoredProcedureAsync<UserPermissionDto>("usp_UserPermission_Get", p);
            return Ok(new { success = true, data, isAdmin = string.Equals(role, "Admin", StringComparison.OrdinalIgnoreCase) });
        }

        [RequirePermission("Permissions", "Edit")]
        [HttpPost("user/bulk")]
        public async Task<IActionResult> SaveBulk([FromBody] SavePermissionsBulkRequest req)
        {
            if (!IsAdmin()) return StatusCode(403, new { success = false, message = "Only Admin can manage permissions." });
            try
            {
                var target = await _db.ExecuteStoredProcedureAsync<UserDto>("usp_User_GetById", new[] { new SqlParameter("@UserId", req.UserId) });
                if (target.Count > 0 && string.Equals(target[0].RoleName, "Super Admin", StringComparison.OrdinalIgnoreCase))
                {
                    return StatusCode(403, new { success = false, message = "Super Admin has full access. Permissions cannot be modified." });
                }
                var me = CurrentUserId();
                foreach (var perm in req.Permissions)
                {
                    var p = new[]
                    {
                        new SqlParameter("@UserId", req.UserId),
                        new SqlParameter("@PageId", perm.PageId),
                        new SqlParameter("@CanView", perm.CanView),
                        new SqlParameter("@CanEdit", perm.CanEdit),
                        new SqlParameter("@CanDelete", perm.CanDelete),
                        new SqlParameter("@CanExport", perm.CanExport),
                        new SqlParameter("@ModifiedBy", me)
                    };
                    await _db.ExecuteNonQueryAsync("usp_UserPermission_Save", p);
                }
                return Ok(new { success = true, message = "Permissions saved successfully." });
            }
            catch (Exception ex) { _logger.LogError(ex, "Bulk permission save failed"); return StatusCode(500, new { success = false, message = "Failed to save permissions." }); }
        }

        [Authorize]
        [HttpGet("my-permissions")]
        public async Task<IActionResult> MyPermissions()
        {
            var role = User.FindFirst(System.Security.Claims.ClaimTypes.Role)?.Value;
            if (string.Equals(role, "Admin", StringComparison.OrdinalIgnoreCase)
                || string.Equals(role, "Super Admin", StringComparison.OrdinalIgnoreCase))
            {
                var pages = await _db.ExecuteStoredProcedureAsync<PageDto>("usp_Pages_GetAll");
                var full = pages.Select(p => new UserPermissionDto { PageId = p.PageId, PageName = p.PageName, CanView = true, CanEdit = true, CanDelete = true, CanExport = true }).ToList();
                return Ok(new { success = true, data = full });
            }
            var pars = new[] { new SqlParameter("@UserId", CurrentUserId()) };
            var data = await _db.ExecuteStoredProcedureAsync<UserPermissionDto>("usp_UserPermission_Get", pars);
            return Ok(new { success = true, data });
        }

        private int CurrentUserId() => int.TryParse(User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value, out var i) ? i : 0;
        private bool IsAdmin() => string.Equals(User.FindFirst(System.Security.Claims.ClaimTypes.Role)?.Value, "Admin", StringComparison.OrdinalIgnoreCase)
            || string.Equals(User.FindFirst(System.Security.Claims.ClaimTypes.Role)?.Value, "Super Admin", StringComparison.OrdinalIgnoreCase);
    }
}

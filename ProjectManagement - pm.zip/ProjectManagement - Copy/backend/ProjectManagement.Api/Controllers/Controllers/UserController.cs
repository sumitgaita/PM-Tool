using System.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using ProjectManagement.Api.DTOs;
using ProjectManagement.Api.Authorization;
using ProjectManagement.Api.Services;

namespace ProjectManagement.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class UserController : ControllerBase
    {
        private readonly IDatabaseService _databaseService;
        private readonly IAuthService _authService;
        private readonly ILogger<UserController> _logger;

        public UserController(IDatabaseService databaseService, IAuthService authService, ILogger<UserController> logger)
        {
            _databaseService = databaseService;
            _authService = authService;
            _logger = logger;
        }

        [RequirePermission("Users", "View")]
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                var users = await _databaseService.ExecuteStoredProcedureAsync<UserDto>("usp_User_GetAll");
                FillPasswords(users);
                return Ok(new { Success = true, Data = users });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting all users");
                return StatusCode(500, new { Success = false, Message = "An error occurred while fetching users." });
            }
        }

        [RequirePermission("Users", "View")]
        [HttpGet("paged")]
        public async Task<IActionResult> GetPaged(
            [FromQuery] string? searchText = null,
            [FromQuery] string? roleName = null,
            [FromQuery] int pageNumber = 1,
            [FromQuery] int pageSize = 10,
            [FromQuery] string? sortBy = "fullName",
            [FromQuery] string? sortDir = "asc")
        {
            try
            {
                if (pageNumber < 1) pageNumber = 1;
                if (pageSize < 1) pageSize = 10;
                if (pageSize > 100) pageSize = 100;

                var allowedSortBy = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
                {
                    "userId", "username", "fullName",
                    "email", "mobileNumber", "roleName", "createdDate"
                };
                if (string.IsNullOrWhiteSpace(sortBy) || !allowedSortBy.Contains(sortBy)) sortBy = "fullName";
                sortDir = string.Equals(sortDir, "desc", StringComparison.OrdinalIgnoreCase) ? "desc" : "asc";

                var parameters = new[]
                {
                    new SqlParameter("@SearchText", (object?)searchText ?? DBNull.Value),
                    new SqlParameter("@RoleName", (object?)roleName ?? DBNull.Value),
                    new SqlParameter("@PageNumber", pageNumber),
                    new SqlParameter("@PageSize", pageSize),
                    new SqlParameter("@SortBy", sortBy),
                    new SqlParameter("@SortDir", sortDir),
                    new SqlParameter("@TotalRecords", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };

                var (users, outputs) = await _databaseService.ExecuteStoredProcedureWithOutputsAsync<UserDto>("usp_User_GetPaged", parameters);
                FillPasswords(users);
                var totalRecords = outputs.TryGetValue("TotalRecords", out var total) && total != null
                    ? Convert.ToInt32(total)
                    : users.Count;
                var totalPages = (int)Math.Ceiling(totalRecords / (double)pageSize);

                return Ok(new { Success = true, Data = users, PageNumber = pageNumber, PageSize = pageSize, TotalRecords = totalRecords, TotalPages = totalPages });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting paged users");
                return StatusCode(500, new { Success = false, Message = "An error occurred while fetching users." });
            }
        }

        [RequirePermission("Users", "View")]
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            try
            {
                var parameters = new[] { new SqlParameter("@UserId", id) };
                var users = await _databaseService.ExecuteStoredProcedureAsync<UserDto>("usp_User_GetById", parameters);

                if (users.Count == 0)
                {
                    return NotFound(new { Success = false, Message = "User not found." });
                }

                if (!IsSuperAdmin(User))
                {
                    users[0].PasswordHash = string.Empty;
                }
                else
                {
                    users[0].Password = _authService.DecryptPassword(users[0].PasswordEnc) ?? string.Empty;
                }
                return Ok(new { Success = true, Data = users[0] });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting user by id: {UserId}", id);
                return StatusCode(500, new { Success = false, Message = "An error occurred while fetching user." });
            }
        }

        [RequirePermission("Users", "Edit")]
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateUserRequest request)
        {
            try
            {
                if (await IsSuperAdminRoleAsync(request.RoleId) && await SuperAdminExistsAsync())
                {
                    return BadRequest(new { Success = false, Message = "Only one Super Admin user is allowed in the system." });
                }

                var passwordHash = _authService.HashPassword(request.Password);
                var createdBy = GetCurrentUserId();

                var parameters = new[]
                {
                    new SqlParameter("@Username", request.Username),
                    new SqlParameter("@FullName", request.FullName),
                    new SqlParameter("@Email", request.Email),
                    new SqlParameter("@MobileNumber", (object?)request.MobileNumber ?? DBNull.Value),
                    new SqlParameter("@PasswordHash", passwordHash),
                    new SqlParameter("@PasswordEnc", (object?)_authService.EncryptPassword(request.Password) ?? DBNull.Value),
                    new SqlParameter("@RoleId", request.RoleId),
                    new SqlParameter("@CreatedBy", createdBy),
                    new SqlParameter("@UserId", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };

                await _databaseService.ExecuteNonQueryAsync("usp_User_Insert", parameters);

                return Ok(new { Success = true, Message = "User created successfully." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating user");
                return StatusCode(500, new { Success = false, Message = "An error occurred while creating user." });
            }
        }

        [RequirePermission("Users", "Edit")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateUserRequest request)
        {
            try
            {
                if (!IsSuperAdmin(User))
                {
                    return StatusCode(403, new { Success = false, Message = "Only Super Admin can edit users." });
                }
                if (await IsSuperAdminRoleAsync(request.RoleId) && await SuperAdminExistsAsync(id))
                {
                    return BadRequest(new { Success = false, Message = "Only one Super Admin user is allowed in the system." });
                }

                var modifiedBy = GetCurrentUserId();

                var parameters = new[]
                {
                    new SqlParameter("@UserId", id),
                    new SqlParameter("@FullName", request.FullName),
                    new SqlParameter("@Email", request.Email),
                    new SqlParameter("@MobileNumber", (object?)request.MobileNumber ?? DBNull.Value),
                    new SqlParameter("@RoleId", request.RoleId),
                    new SqlParameter("@ModifiedBy", modifiedBy)
                };

                await _databaseService.ExecuteNonQueryAsync("usp_User_Update", parameters);

                return Ok(new { Success = true, Message = "User updated successfully." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating user: {UserId}", id);
                return StatusCode(500, new { Success = false, Message = "An error occurred while updating user." });
            }
        }

        [RequirePermission("Users", "Edit")]
        [HttpPost("{id}/activate")]
        public async Task<IActionResult> Activate(int id)
        {
            try
            {
                var modifiedBy = GetCurrentUserId();
                var parameters = new[]
                {
                    new SqlParameter("@UserId", id),
                    new SqlParameter("@ModifiedBy", modifiedBy)
                };

                await _databaseService.ExecuteNonQueryAsync("usp_User_Activate", parameters);

                return Ok(new { Success = true, Message = "User activated successfully." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error activating user: {UserId}", id);
                return StatusCode(500, new { Success = false, Message = "An error occurred while activating user." });
            }
        }

        [RequirePermission("Users", "Edit")]
        [HttpPost("{id}/deactivate")]
        public async Task<IActionResult> Deactivate(int id)
        {
            try
            {
                var existing = await _databaseService.ExecuteStoredProcedureAsync<UserDto>(
                    "usp_User_GetById", new[] { new SqlParameter("@UserId", id) });
                if (existing.Count > 0 && string.Equals(existing[0].RoleName, "Super Admin", StringComparison.OrdinalIgnoreCase))
                {
                    return BadRequest(new { Success = false, Message = "Super Admin cannot be deactivated." });
                }

                var modifiedBy = GetCurrentUserId();
                var parameters = new[]
                {
                    new SqlParameter("@UserId", id),
                    new SqlParameter("@ModifiedBy", modifiedBy)
                };

                await _databaseService.ExecuteNonQueryAsync("usp_User_Deactivate", parameters);

                return Ok(new { Success = true, Message = "User deactivated successfully." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deactivating user: {UserId}", id);
                return StatusCode(500, new { Success = false, Message = "An error occurred while deactivating user." });
            }
        }

        [RequirePermission("Users", "Delete")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                // User management is Super-Admin-only (consistent with Update).
                if (!IsSuperAdmin(User))
                {
                    return StatusCode(403, new { Success = false, Message = "Only Super Admin can delete users." });
                }
                var callerId = GetCurrentUserId();
                if (id == callerId)
                {
                    return BadRequest(new { Success = false, Message = "You cannot delete your own account." });
                }
                var existing = await _databaseService.ExecuteStoredProcedureAsync<UserDto>(
                    "usp_User_GetById", new[] { new SqlParameter("@UserId", id) });
                if (existing.Count == 0)
                {
                    return NotFound(new { Success = false, Message = "User not found." });
                }
                if (string.Equals(existing[0].RoleName, "Super Admin", StringComparison.OrdinalIgnoreCase))
                {
                    return BadRequest(new { Success = false, Message = "Super Admin cannot be deleted." });
                }
                await _databaseService.ExecuteNonQueryAsync("usp_User_Deactivate", new[]
                {
                    new SqlParameter("@UserId", id),
                    new SqlParameter("@ModifiedBy", callerId)
                });
                return Ok(new { Success = true, Message = "User deleted (deactivated) successfully." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting user: {UserId}", id);
                return StatusCode(500, new { Success = false, Message = "An error occurred while deleting user." });
            }
        }

        [RequirePermission("Users", "View")]
        [HttpGet("{id}/permissions")]
        public async Task<IActionResult> GetPermissions(int id)
        {
            try
            {
                var parameters = new[] { new SqlParameter("@UserId", id) };
                var permissions = await _databaseService.ExecuteStoredProcedureAsync<UserPermissionDto>("usp_UserPermission_Get", parameters);

                return Ok(new { Success = true, Data = permissions });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting permissions for user: {UserId}", id);
                return StatusCode(500, new { Success = false, Message = "An error occurred while fetching permissions." });
            }
        }

        [RequirePermission("Users", "Edit")]
        [HttpPost("permissions")]
        public async Task<IActionResult> SavePermission([FromBody] SavePermissionRequest request)
        {
            try
            {
                var target = await _databaseService.ExecuteStoredProcedureAsync<UserDto>("usp_User_GetById", new[] { new SqlParameter("@UserId", request.UserId) });
                if (target.Count > 0 && string.Equals(target[0].RoleName, "Super Admin", StringComparison.OrdinalIgnoreCase))
                {
                    return StatusCode(403, new { Success = false, Message = "Super Admin has full access. Permissions cannot be modified." });
                }

                var callerRole = User.FindFirst(System.Security.Claims.ClaimTypes.Role)?.Value;
                if (!string.Equals(callerRole, "Admin", StringComparison.OrdinalIgnoreCase)
                    && !string.Equals(callerRole, "Super Admin", StringComparison.OrdinalIgnoreCase))
                {
                    return StatusCode(403, new { Success = false, Message = "Only Admin can manage permissions." });
                }

                var modifiedBy = GetCurrentUserId();

                var parameters = new[]
                {
                    new SqlParameter("@UserId", request.UserId),
                    new SqlParameter("@PageId", request.PageId),
                    new SqlParameter("@CanView", request.CanView),
                    new SqlParameter("@CanEdit", request.CanEdit),
                    new SqlParameter("@CanDelete", request.CanDelete),
                    new SqlParameter("@CanExport", request.CanExport),
                    new SqlParameter("@ModifiedBy", modifiedBy)
                };

                await _databaseService.ExecuteNonQueryAsync("usp_UserPermission_Save", parameters);

                return Ok(new { Success = true, Message = "Permission saved successfully." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error saving permission");
                return StatusCode(500, new { Success = false, Message = "An error occurred while saving permission." });
            }
        }

        [RequirePermission("Users", "Edit")]
        [HttpPost("{id}/reset-password")]
        public async Task<IActionResult> ResetPassword(int id, [FromBody] ResetPasswordRequest request)
        {
            try
            {
                if (!IsSuperAdmin(User))
                {
                    return StatusCode(403, new { Success = false, Message = "Only Super Admin can update passwords." });
                }
                if (string.IsNullOrWhiteSpace(request.NewPassword) || request.NewPassword.Length < 6)
                {
                    return BadRequest(new { Success = false, Message = "Password must be at least 6 characters." });
                }

                var passwordHash = _authService.HashPassword(request.NewPassword);
                var modifiedBy = GetCurrentUserId();
                var parameters = new[]
                {
                    new SqlParameter("@UserId", id),
                    new SqlParameter("@NewPasswordHash", passwordHash),
                    new SqlParameter("@NewPasswordEnc", (object?)_authService.EncryptPassword(request.NewPassword) ?? DBNull.Value),
                    new SqlParameter("@ModifiedBy", modifiedBy)
                };

                await _databaseService.ExecuteNonQueryAsync("usp_User_ChangePassword", parameters);

                return Ok(new { Success = true, Message = "Password updated successfully." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error resetting password for user: {UserId}", id);
                return StatusCode(500, new { Success = false, Message = "An error occurred while updating password." });
            }
        }

        private int GetCurrentUserId()
        {
            var userIdClaim = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            return int.TryParse(userIdClaim, out var userId) ? userId : 0;
        }

        private void FillPasswords(List<UserDto> users)
        {
            var isSuperAdmin = IsSuperAdmin(User);
            foreach (var u in users)
            {
                if (isSuperAdmin)
                {
                    u.Password = _authService.DecryptPassword(u.PasswordEnc) ?? string.Empty;
                }
                else
                {
                    u.PasswordHash = string.Empty;
                    u.Password = string.Empty;
                }
            }
        }

        private static bool IsSuperAdmin(System.Security.Claims.ClaimsPrincipal principal)
        {
            var role = principal.FindFirst(System.Security.Claims.ClaimTypes.Role)?.Value;
            return string.Equals(role, "Super Admin", StringComparison.OrdinalIgnoreCase);
        }

        private async Task<bool> IsSuperAdminRoleAsync(int roleId)
        {
            await using var conn = await _databaseService.GetConnectionAsync();
            await using var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT RoleName FROM Roles WHERE RoleId = @R";
            cmd.Parameters.Add(new SqlParameter("@R", roleId));
            var result = await cmd.ExecuteScalarAsync();
            return result != null && result != DBNull.Value
                && string.Equals(result.ToString(), "Super Admin", StringComparison.OrdinalIgnoreCase);
        }

        private async Task<bool> SuperAdminExistsAsync(int? excludeUserId = null)
        {
            var users = await _databaseService.ExecuteStoredProcedureAsync<UserDto>("usp_User_GetAll");
            return users.Any(u => string.Equals(u.RoleName, "Super Admin", StringComparison.OrdinalIgnoreCase)
                && (!excludeUserId.HasValue || u.UserId != excludeUserId.Value));
        }
    }
}

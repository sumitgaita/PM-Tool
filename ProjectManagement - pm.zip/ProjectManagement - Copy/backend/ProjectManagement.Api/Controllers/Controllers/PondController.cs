using System.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using ProjectManagement.Api.DTOs;
using ProjectManagement.Api.Authorization;
using ProjectManagement.Api.Services;

namespace ProjectManagement.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class PondController : ControllerBase
    {
        private const string Page = "Fish Ponds";
        private readonly IDatabaseService _db;
        private readonly ILogger<PondController> _logger;
        public PondController(IDatabaseService db, ILogger<PondController> logger)
        { _db = db; _logger = logger; }

        [RequirePermission(Page, "View")]
        [HttpGet("paged")]
        public async Task<IActionResult> GetPaged(
            [FromQuery] int? projectId = null,
            [FromQuery] string? searchText = null,
            [FromQuery] int pageNumber = 1,
            [FromQuery] int pageSize = 10,
            [FromQuery] string? sortBy = "pondCode",
            [FromQuery] string? sortDir = "asc")
        {
            try
            {
                if (await ProjectAccessHelper.QueryProjectDeniedAsync(User, _db, projectId)) return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
                if (pageNumber < 1) pageNumber = 1;
                if (pageSize < 1) pageSize = 10;
                if (pageSize > 100) pageSize = 100;
                var allowed = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
                    { "pondId", "pondCode", "pondName", "area", "status", "createdDate" };
                if (string.IsNullOrWhiteSpace(sortBy) || !allowed.Contains(sortBy)) sortBy = "pondCode";
                sortDir = string.Equals(sortDir, "desc", StringComparison.OrdinalIgnoreCase) ? "desc" : "asc";
                var p = new[]
                {
                    new SqlParameter("@ProjectId", (object?)projectId ?? DBNull.Value),
                    new SqlParameter("@UserId", AuditHelper.CurrentUserId(User)),
                    new SqlParameter("@SearchText", (object?)searchText ?? DBNull.Value),
                    new SqlParameter("@PageNumber", pageNumber),
                    new SqlParameter("@PageSize", pageSize),
                    new SqlParameter("@SortBy", sortBy),
                    new SqlParameter("@SortDir", sortDir),
                    new SqlParameter("@TotalRecords", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };
                var (data, outputs) = await _db.ExecuteStoredProcedureWithOutputsAsync<PondDto>("usp_Pond_GetPaged", p);
                var total = outputs.TryGetValue("TotalRecords", out var t) && t != null ? Convert.ToInt32(t) : data.Count;
                return Ok(new { success = true, data, pageNumber, pageSize, totalRecords = total, totalPages = (int)Math.Ceiling(total / (double)pageSize) });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "Pond paged fetch failed"); }
        }

        [RequirePermission(Page, "Edit")]
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreatePondRequest req)
        {
            try
            {
                if (!await ProjectAccessHelper.HasProjectAccessAsync(User, _db, req.ProjectId)) return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
                if (req.ProjectId <= 0) return BadRequest(new { success = false, message = "Project is required." });
                if (string.IsNullOrWhiteSpace(req.PondCode)) return BadRequest(new { success = false, message = "Pond code is required." });
                if (string.IsNullOrWhiteSpace(req.PondName)) return BadRequest(new { success = false, message = "Pond name is required." });
                var me = AuditHelper.CurrentUserId(User);
                var p = new[]
                {
                    new SqlParameter("@ProjectId", req.ProjectId),
                    new SqlParameter("@PondCode", req.PondCode.Trim()),
                    new SqlParameter("@PondName", req.PondName.Trim()),
                    new SqlParameter("@Area", (object?)req.Area ?? DBNull.Value),
                    new SqlParameter("@AreaUnit", (object?)req.AreaUnit ?? DBNull.Value),
                    new SqlParameter("@Depth", (object?)req.Depth ?? DBNull.Value),
                    new SqlParameter("@WaterCapacity", (object?)req.WaterCapacity ?? DBNull.Value),
                    new SqlParameter("@PondType", (object?)req.PondType ?? DBNull.Value),
                    new SqlParameter("@Status", (object?)req.Status ?? "Active"),
                    new SqlParameter("@CreatedBy", me),
                    new SqlParameter("@PondId", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };
                await _db.ExecuteNonQueryAsync("usp_Pond_Insert", p);
                await AuditHelper.LogAsync(_db, _logger, me, "Pond Created", Page, req.PondCode);
                return Ok(new { success = true, message = "Pond created successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "Pond insert failed"); }
        }

        [RequirePermission(Page, "Edit")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdatePondRequest req)
        {
            try
            {
                if (!await ProjectAccessHelper.HasEntityAccessAsync(User, _db, "Pond", id)) return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
                if (string.IsNullOrWhiteSpace(req.PondCode)) return BadRequest(new { success = false, message = "Pond code is required." });
                if (string.IsNullOrWhiteSpace(req.PondName)) return BadRequest(new { success = false, message = "Pond name is required." });
                var me = AuditHelper.CurrentUserId(User);
                var p = new[]
                {
                    new SqlParameter("@PondId", id),
                    new SqlParameter("@PondCode", req.PondCode.Trim()),
                    new SqlParameter("@PondName", req.PondName.Trim()),
                    new SqlParameter("@Area", (object?)req.Area ?? DBNull.Value),
                    new SqlParameter("@AreaUnit", (object?)req.AreaUnit ?? DBNull.Value),
                    new SqlParameter("@Depth", (object?)req.Depth ?? DBNull.Value),
                    new SqlParameter("@WaterCapacity", (object?)req.WaterCapacity ?? DBNull.Value),
                    new SqlParameter("@PondType", (object?)req.PondType ?? DBNull.Value),
                    new SqlParameter("@Status", (object?)req.Status ?? DBNull.Value),
                    new SqlParameter("@ModifiedBy", me)
                };
                await _db.ExecuteNonQueryAsync("usp_Pond_Update", p);
                await AuditHelper.LogAsync(_db, _logger, me, "Pond Updated", Page, id);
                return Ok(new { success = true, message = "Pond updated successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "Pond update failed"); }
        }

        [RequirePermission(Page, "Delete")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                if (!await ProjectAccessHelper.HasEntityAccessAsync(User, _db, "Pond", id)) return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
                var me = AuditHelper.CurrentUserId(User);
                await _db.ExecuteNonQueryAsync("usp_Pond_Delete", new[] { new SqlParameter("@PondId", id) });
                await AuditHelper.LogAsync(_db, _logger, me, "Pond Deleted", Page, id);
                return Ok(new { success = true, message = "Pond deleted successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "Pond delete failed"); }
        }

        [RequirePermission(Page, "Edit")]
        [HttpPost("{id}/activate")]
        public async Task<IActionResult> Activate(int id)
        {
            if (!await ProjectAccessHelper.HasEntityAccessAsync(User, _db, "Pond", id)) return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
            return await SetActive(id, true);
        }

        [RequirePermission(Page, "Edit")]
        [HttpPost("{id}/deactivate")]
        public async Task<IActionResult> Deactivate(int id)
        {
            if (!await ProjectAccessHelper.HasEntityAccessAsync(User, _db, "Pond", id)) return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
            return await SetActive(id, false);
        }

        private async Task<IActionResult> SetActive(int id, bool active)
        {
            try
            {
                if (!await ProjectAccessHelper.HasEntityAccessAsync(User, _db, "Pond", id)) return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
                var me = AuditHelper.CurrentUserId(User);
                await _db.ExecuteNonQueryAsync("usp_Pond_SetActive", new[]
                {
                    new SqlParameter("@PondId", id),
                    new SqlParameter("@IsActive", active),
                    new SqlParameter("@ModifiedBy", me)
                });
                return Ok(new { success = true, message = active ? "Pond activated successfully." : "Pond deactivated successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "Pond status change failed"); }
        }
    }
}

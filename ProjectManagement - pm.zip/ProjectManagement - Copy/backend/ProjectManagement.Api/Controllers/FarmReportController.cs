using System.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using ProjectManagement.Api.DTOs;
using ProjectManagement.Api.Authorization;
using ProjectManagement.Api.Services;

namespace ProjectManagement.Api.Controllers
{
    // §100 farm reports + §95 profitability + §101 farm cost-vs-budget.
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class FarmReportController : ControllerBase
    {
        private readonly IDatabaseService _db;
        private readonly ILogger<FarmReportController> _logger;
        public FarmReportController(IDatabaseService db, ILogger<FarmReportController> logger)
        { _db = db; _logger = logger; }

        private static (int pageNumber, int pageSize) Page(int pageNumber, int pageSize)
        {
            if (pageNumber < 1) pageNumber = 1;
            if (pageSize < 1) pageSize = 10;
            if (pageSize > 100) pageSize = 100;
            return (pageNumber, pageSize);
        }

        private static SqlParameter TotalParam() =>
            new("@TotalRecords", SqlDbType.Int) { Direction = ParameterDirection.Output };

        private IActionResult Paged(object? data, int pageNumber, int pageSize, Dictionary<string, object?> outputs)
        {
            var total = outputs.TryGetValue("TotalRecords", out var t) && t != null ? Convert.ToInt32(t) : 0;
            return Ok(new { success = true, data, pageNumber, pageSize, totalRecords = total, totalPages = (int)Math.Ceiling(total / (double)pageSize) });
        }

        [RequirePermission("Farm Reports", "View")]
        [HttpGet("farmwise")]
        public async Task<IActionResult> FarmWise(
            [FromQuery] string? farmType = null, [FromQuery] int? projectId = null,
            [FromQuery] int pageNumber = 1, [FromQuery] int pageSize = 10)
        {
            try
            {
                (pageNumber, pageSize) = Page(pageNumber, pageSize);
                var p = new[]
                {
                    new SqlParameter("@FarmType", (object?)farmType ?? DBNull.Value),
                    new SqlParameter("@ProjectId", (object?)projectId ?? DBNull.Value),
                    new SqlParameter("@PageNumber", pageNumber),
                    new SqlParameter("@PageSize", pageSize),
                    TotalParam()
                };
                var (data, outputs) = await _db.ExecuteStoredProcedureWithOutputsAsync<FarmWiseReportDto>("usp_Report_FarmWise", p);
                return Paged(data, pageNumber, pageSize, outputs);
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "Farm-wise report failed"); }
        }

        [RequirePermission("Farm Reports", "View")]
        [HttpGet("fish")]
        public async Task<IActionResult> Fish(
            [FromQuery] int? projectId = null, [FromQuery] int? pondId = null, [FromQuery] int? fishTypeId = null,
            [FromQuery] int pageNumber = 1, [FromQuery] int pageSize = 10)
        {
            try
            {
                (pageNumber, pageSize) = Page(pageNumber, pageSize);
                var p = new[]
                {
                    new SqlParameter("@ProjectId", (object?)projectId ?? DBNull.Value),
                    new SqlParameter("@PondId", (object?)pondId ?? DBNull.Value),
                    new SqlParameter("@FishTypeId", (object?)fishTypeId ?? DBNull.Value),
                    new SqlParameter("@PageNumber", pageNumber),
                    new SqlParameter("@PageSize", pageSize),
                    TotalParam()
                };
                var (data, outputs) = await _db.ExecuteStoredProcedureWithOutputsAsync<FishReportDto>("usp_Report_Fish", p);
                return Paged(data, pageNumber, pageSize, outputs);
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "Fish report failed"); }
        }

        [RequirePermission("Farm Reports", "View")]
        [HttpGet("poultry")]
        public async Task<IActionResult> Poultry(
            [FromQuery] int? projectId = null, [FromQuery] int? shedId = null, [FromQuery] int? batchId = null,
            [FromQuery] int pageNumber = 1, [FromQuery] int pageSize = 10)
        {
            try
            {
                (pageNumber, pageSize) = Page(pageNumber, pageSize);
                var p = new[]
                {
                    new SqlParameter("@ProjectId", (object?)projectId ?? DBNull.Value),
                    new SqlParameter("@ShedId", (object?)shedId ?? DBNull.Value),
                    new SqlParameter("@BatchId", (object?)batchId ?? DBNull.Value),
                    new SqlParameter("@PageNumber", pageNumber),
                    new SqlParameter("@PageSize", pageSize),
                    TotalParam()
                };
                var (data, outputs) = await _db.ExecuteStoredProcedureWithOutputsAsync<PoultryReportDto>("usp_Report_Poultry", p);
                return Paged(data, pageNumber, pageSize, outputs);
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "Poultry report failed"); }
        }

        [RequirePermission("Farm Reports", "View")]
        [HttpGet("feed")]
        public async Task<IActionResult> Feed(
            [FromQuery] string? farmType = null, [FromQuery] int? projectId = null,
            [FromQuery] int? pondId = null, [FromQuery] int? batchId = null,
            [FromQuery] string? feedType = null,
            [FromQuery] DateTime? fromDate = null, [FromQuery] DateTime? toDate = null)
        {
            try
            {
                var p = new[]
                {
                    new SqlParameter("@FarmType", (object?)farmType ?? DBNull.Value),
                    new SqlParameter("@ProjectId", (object?)projectId ?? DBNull.Value),
                    new SqlParameter("@PondId", (object?)pondId ?? DBNull.Value),
                    new SqlParameter("@BatchId", (object?)batchId ?? DBNull.Value),
                    new SqlParameter("@FeedType", (object?)feedType ?? DBNull.Value),
                    new SqlParameter("@FromDate", (object?)fromDate ?? DBNull.Value),
                    new SqlParameter("@ToDate", (object?)toDate ?? DBNull.Value)
                };
                var data = await _db.ExecuteStoredProcedureAsync<FeedReportDto>("usp_Report_Feed", p);
                return Ok(new { success = true, data });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "Feed report failed"); }
        }

        [RequirePermission("Farm Reports", "View")]
        [HttpGet("mortality")]
        public async Task<IActionResult> Mortality(
            [FromQuery] string? farmType = null, [FromQuery] int? projectId = null,
            [FromQuery] int? pondId = null, [FromQuery] int? batchId = null,
            [FromQuery] DateTime? fromDate = null, [FromQuery] DateTime? toDate = null)
        {
            try
            {
                var p = new[]
                {
                    new SqlParameter("@FarmType", (object?)farmType ?? DBNull.Value),
                    new SqlParameter("@ProjectId", (object?)projectId ?? DBNull.Value),
                    new SqlParameter("@PondId", (object?)pondId ?? DBNull.Value),
                    new SqlParameter("@BatchId", (object?)batchId ?? DBNull.Value),
                    new SqlParameter("@FromDate", (object?)fromDate ?? DBNull.Value),
                    new SqlParameter("@ToDate", (object?)toDate ?? DBNull.Value)
                };
                var data = await _db.ExecuteStoredProcedureAsync<MortalityReportDto>("usp_Report_Mortality", p);
                return Ok(new { success = true, data });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "Mortality report failed"); }
        }

        [RequirePermission("Profitability", "View")]
        [HttpGet("profitability")]
        public async Task<IActionResult> Profitability(
            [FromQuery] int? projectId = null, [FromQuery] string? farmType = null,
            [FromQuery] DateTime? fromDate = null, [FromQuery] DateTime? toDate = null)
        {
            try
            {
                var p = new[]
                {
                    new SqlParameter("@ProjectId", (object?)projectId ?? DBNull.Value),
                    new SqlParameter("@FarmType", (object?)farmType ?? DBNull.Value),
                    new SqlParameter("@FromDate", (object?)fromDate ?? DBNull.Value),
                    new SqlParameter("@ToDate", (object?)toDate ?? DBNull.Value)
                };
                var data = await _db.ExecuteStoredProcedureAsync<ProfitabilityDto>("usp_Report_Profitability", p);
                return Ok(new { success = true, data = data.FirstOrDefault() });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "Profitability failed"); }
        }

        [RequirePermission("Farm Reports", "View")]
        [HttpGet("farm-costvsbudget")]
        public async Task<IActionResult> FarmCostVsBudget(
            [FromQuery] int? projectId = null, [FromQuery] string? farmType = null,
            [FromQuery] int? pondId = null, [FromQuery] int? batchId = null,
            [FromQuery] DateTime? fromDate = null, [FromQuery] DateTime? toDate = null)
        {
            try
            {
                var p = new[]
                {
                    new SqlParameter("@ProjectId", (object?)projectId ?? DBNull.Value),
                    new SqlParameter("@FarmType", (object?)farmType ?? DBNull.Value),
                    new SqlParameter("@PondId", (object?)pondId ?? DBNull.Value),
                    new SqlParameter("@BatchId", (object?)batchId ?? DBNull.Value),
                    new SqlParameter("@FromDate", (object?)fromDate ?? DBNull.Value),
                    new SqlParameter("@ToDate", (object?)toDate ?? DBNull.Value)
                };
                var data = await _db.ExecuteStoredProcedureAsync<FarmCostVsBudgetDto>("usp_Report_FarmCostVsBudget", p);
                return Ok(new { success = true, data });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "Farm cost-vs-budget failed"); }
        }
    }
}

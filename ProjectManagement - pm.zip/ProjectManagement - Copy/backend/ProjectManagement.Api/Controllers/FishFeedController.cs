using System.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using ProjectManagement.Api.DTOs;
using ProjectManagement.Api.Authorization;
using ProjectManagement.Api.Services;

namespace ProjectManagement.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class FishFeedController : ControllerBase
    {
        private const string Page = "Fish Feed";
        private readonly IDatabaseService _db;
        private readonly ILogger<FishFeedController> _logger;
        public FishFeedController(IDatabaseService db, ILogger<FishFeedController> logger)
        { _db = db; _logger = logger; }

        [RequirePermission(Page, "View")]
        [HttpGet("paged")]
        public async Task<IActionResult> GetPaged(
            [FromQuery] int? projectId = null,
            [FromQuery] int? pondId = null,
            [FromQuery] string? searchText = null,
            [FromQuery] DateTime? fromDate = null,
            [FromQuery] DateTime? toDate = null,
            [FromQuery] int pageNumber = 1,
            [FromQuery] int pageSize = 10,
            [FromQuery] string? sortBy = "feedDate",
            [FromQuery] string? sortDir = "desc")
        {
            try
            {
                if (pageNumber < 1) pageNumber = 1;
                if (pageSize < 1) pageSize = 10;
                if (pageSize > 100) pageSize = 100;
                var allowed = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
                    { "feedId", "feedDate", "pondCode", "feedType", "quantity", "totalCost" };
                if (string.IsNullOrWhiteSpace(sortBy) || !allowed.Contains(sortBy)) sortBy = "feedDate";
                sortDir = string.Equals(sortDir, "asc", StringComparison.OrdinalIgnoreCase) ? "asc" : "desc";
                var p = new[]
                {
                    new SqlParameter("@ProjectId", (object?)projectId ?? DBNull.Value),
                    new SqlParameter("@PondId", (object?)pondId ?? DBNull.Value),
                    new SqlParameter("@SearchText", (object?)searchText ?? DBNull.Value),
                    new SqlParameter("@FromDate", (object?)fromDate ?? DBNull.Value),
                    new SqlParameter("@ToDate", (object?)toDate ?? DBNull.Value),
                    new SqlParameter("@PageNumber", pageNumber),
                    new SqlParameter("@PageSize", pageSize),
                    new SqlParameter("@SortBy", sortBy),
                    new SqlParameter("@SortDir", sortDir),
                    new SqlParameter("@TotalRecords", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };
                var (data, outputs) = await _db.ExecuteStoredProcedureWithOutputsAsync<FishFeedDto>("usp_FishFeed_GetPaged", p);
                var total = outputs.TryGetValue("TotalRecords", out var t) && t != null ? Convert.ToInt32(t) : data.Count;
                return Ok(new { success = true, data, pageNumber, pageSize, totalRecords = total, totalPages = (int)Math.Ceiling(total / (double)pageSize) });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "FishFeed paged fetch failed"); }
        }

        [RequirePermission(Page, "Edit")]
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateFishFeedRequest req)
        {
            try
            {
                if (req.PondId <= 0) return BadRequest(new { success = false, message = "Pond is required." });
                if (string.IsNullOrWhiteSpace(req.FeedType)) return BadRequest(new { success = false, message = "Feed type is required." });
                if (req.Quantity <= 0) return BadRequest(new { success = false, message = "Quantity must be greater than zero." });
                var me = AuditHelper.CurrentUserId(User);
                var p = new[]
                {
                    new SqlParameter("@PondId", req.PondId),
                    new SqlParameter("@FeedDate", req.FeedDate),
                    new SqlParameter("@FeedType", req.FeedType.Trim()),
                    new SqlParameter("@Quantity", req.Quantity),
                    new SqlParameter("@Unit", (object?)req.Unit ?? DBNull.Value),
                    new SqlParameter("@Rate", (object?)req.Rate ?? DBNull.Value),
                    new SqlParameter("@TotalCost", (object?)req.TotalCost ?? DBNull.Value),
                    new SqlParameter("@Remarks", (object?)req.Remarks ?? DBNull.Value),
                    new SqlParameter("@CreatedBy", me),
                    new SqlParameter("@ExpProjectId", (object?)req.ExpProjectId ?? DBNull.Value),
                    new SqlParameter("@ExpBudgetCodeId", (object?)req.ExpBudgetCodeId ?? DBNull.Value),
                    new SqlParameter("@ExpResourceId", (object?)req.ExpResourceId ?? DBNull.Value),
                    new SqlParameter("@FishFeedId", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };
                await _db.ExecuteNonQueryAsync("usp_FishFeed_Insert", p);
                await AuditHelper.LogAsync(_db, _logger, me, "Fish Feed Added", Page, null);
                return Ok(new { success = true, message = "Fish feed recorded successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "FishFeed insert failed"); }
        }

        [RequirePermission(Page, "Edit")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateFishFeedRequest req)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(req.FeedType)) return BadRequest(new { success = false, message = "Feed type is required." });
                if (req.Quantity <= 0) return BadRequest(new { success = false, message = "Quantity must be greater than zero." });
                var me = AuditHelper.CurrentUserId(User);
                var p = new[]
                {
                    new SqlParameter("@FishFeedId", id),
                    new SqlParameter("@FeedDate", req.FeedDate),
                    new SqlParameter("@FeedType", req.FeedType.Trim()),
                    new SqlParameter("@Quantity", req.Quantity),
                    new SqlParameter("@Unit", (object?)req.Unit ?? DBNull.Value),
                    new SqlParameter("@Rate", (object?)req.Rate ?? DBNull.Value),
                    new SqlParameter("@TotalCost", (object?)req.TotalCost ?? DBNull.Value),
                    new SqlParameter("@Remarks", (object?)req.Remarks ?? DBNull.Value),
                    new SqlParameter("@ModifiedBy", me)
                };
                await _db.ExecuteNonQueryAsync("usp_FishFeed_Update", p);
                await AuditHelper.LogAsync(_db, _logger, me, "Fish Feed Updated", Page, id);
                return Ok(new { success = true, message = "Fish feed updated successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "FishFeed update failed"); }
        }

        [RequirePermission(Page, "Delete")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var me = AuditHelper.CurrentUserId(User);
                await _db.ExecuteNonQueryAsync("usp_FishFeed_Delete", new[] { new SqlParameter("@FishFeedId", id) });
                await AuditHelper.LogAsync(_db, _logger, me, "Fish Feed Deleted", Page, id);
                return Ok(new { success = true, message = "Fish feed deleted successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "FishFeed delete failed"); }
        }
    }
}

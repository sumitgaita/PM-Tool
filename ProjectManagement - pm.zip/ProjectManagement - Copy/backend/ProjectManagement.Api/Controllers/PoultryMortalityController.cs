using System.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using ProjectManagement.Api.DTOs;
using ProjectManagement.Api.Authorization;
using ProjectManagement.Api.Services;

namespace ProjectManagement.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class PoultryMortalityController : ControllerBase
    {
        private const string Page = "Poultry Mortality";
        private readonly IDatabaseService _db;
        private readonly ILogger<PoultryMortalityController> _logger;
        public PoultryMortalityController(IDatabaseService db, ILogger<PoultryMortalityController> logger)
        { _db = db; _logger = logger; }

        [RequirePermission(Page, "View")]
        [HttpGet("paged")]
        public async Task<IActionResult> GetPaged(
            [FromQuery] int? projectId = null,
            [FromQuery] int? batchId = null,
            [FromQuery] DateTime? fromDate = null,
            [FromQuery] DateTime? toDate = null,
            [FromQuery] int pageNumber = 1,
            [FromQuery] int pageSize = 10,
            [FromQuery] string? sortBy = "mortalityDate",
            [FromQuery] string? sortDir = "desc")
        {
            try
            {
                if (pageNumber < 1) pageNumber = 1;
                if (pageSize < 1) pageSize = 10;
                if (pageSize > 100) pageSize = 100;
                var allowed = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
                    { "mortalityId", "mortalityDate", "batchCode", "quantity" };
                if (string.IsNullOrWhiteSpace(sortBy) || !allowed.Contains(sortBy)) sortBy = "mortalityDate";
                sortDir = string.Equals(sortDir, "asc", StringComparison.OrdinalIgnoreCase) ? "asc" : "desc";
                var p = new[]
                {
                    new SqlParameter("@ProjectId", (object?)projectId ?? DBNull.Value),
                    new SqlParameter("@BatchId", (object?)batchId ?? DBNull.Value),
                    new SqlParameter("@FromDate", (object?)fromDate ?? DBNull.Value),
                    new SqlParameter("@ToDate", (object?)toDate ?? DBNull.Value),
                    new SqlParameter("@PageNumber", pageNumber),
                    new SqlParameter("@PageSize", pageSize),
                    new SqlParameter("@SortBy", sortBy),
                    new SqlParameter("@SortDir", sortDir),
                    new SqlParameter("@TotalRecords", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };
                var (data, outputs) = await _db.ExecuteStoredProcedureWithOutputsAsync<PoultryMortalityDto>("usp_PoultryMortality_GetPaged", p);
                var total = outputs.TryGetValue("TotalRecords", out var t) && t != null ? Convert.ToInt32(t) : data.Count;
                return Ok(new { success = true, data, pageNumber, pageSize, totalRecords = total, totalPages = (int)Math.Ceiling(total / (double)pageSize) });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "PoultryMortality paged fetch failed"); }
        }

        [RequirePermission(Page, "Edit")]
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreatePoultryMortalityRequest req)
        {
            try
            {
                if (req.BatchId <= 0) return BadRequest(new { success = false, message = "Batch is required." });
                if (req.Quantity <= 0) return BadRequest(new { success = false, message = "Quantity must be greater than zero." });
                var me = AuditHelper.CurrentUserId(User);
                var p = new[]
                {
                    new SqlParameter("@BatchId", req.BatchId),
                    new SqlParameter("@MortalityDate", req.MortalityDate),
                    new SqlParameter("@Quantity", req.Quantity),
                    new SqlParameter("@Reason", (object?)req.Reason ?? DBNull.Value),
                    new SqlParameter("@Remarks", (object?)req.Remarks ?? DBNull.Value),
                    new SqlParameter("@CreatedBy", me),
                    new SqlParameter("@MortalityId", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };
                await _db.ExecuteNonQueryAsync("usp_PoultryMortality_Insert", p);
                await AuditHelper.LogAsync(_db, _logger, me, "Poultry Mortality Added", Page, null);
                return Ok(new { success = true, message = "Mortality recorded successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "PoultryMortality insert failed"); }
        }

        [RequirePermission(Page, "Edit")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdatePoultryMortalityRequest req)
        {
            try
            {
                if (req.Quantity <= 0) return BadRequest(new { success = false, message = "Quantity must be greater than zero." });
                var me = AuditHelper.CurrentUserId(User);
                var p = new[]
                {
                    new SqlParameter("@MortalityId", id),
                    new SqlParameter("@MortalityDate", req.MortalityDate),
                    new SqlParameter("@Quantity", req.Quantity),
                    new SqlParameter("@Reason", (object?)req.Reason ?? DBNull.Value),
                    new SqlParameter("@Remarks", (object?)req.Remarks ?? DBNull.Value),
                    new SqlParameter("@ModifiedBy", me)
                };
                await _db.ExecuteNonQueryAsync("usp_PoultryMortality_Update", p);
                await AuditHelper.LogAsync(_db, _logger, me, "Poultry Mortality Updated", Page, id);
                return Ok(new { success = true, message = "Mortality updated successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "PoultryMortality update failed"); }
        }

        [RequirePermission(Page, "Delete")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var me = AuditHelper.CurrentUserId(User);
                await _db.ExecuteNonQueryAsync("usp_PoultryMortality_Delete", new[] { new SqlParameter("@MortalityId", id) });
                await AuditHelper.LogAsync(_db, _logger, me, "Poultry Mortality Deleted", Page, id);
                return Ok(new { success = true, message = "Mortality deleted successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "PoultryMortality delete failed"); }
        }
    }
}

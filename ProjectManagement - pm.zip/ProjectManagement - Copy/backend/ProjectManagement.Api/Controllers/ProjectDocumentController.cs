using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProjectManagement.Api.Authorization;
using ProjectManagement.Api.DTOs;
using ProjectManagement.Api.Services;

namespace ProjectManagement.Api.Controllers
{
    // Project-wise document management. Page permission mapping:
    // View = view/download, Edit(Add) = upload, Delete = delete.
    // Every action additionally requires access to the target project
    // (Project Permissions assignments; Super Admin sees all).
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class ProjectDocumentController : ControllerBase
    {
        private const string Page = "Project Document";
        private readonly IDocumentService _documents;
        private readonly IDatabaseService _databaseService;
        private readonly ILogger<ProjectDocumentController> _logger;

        public ProjectDocumentController(
            IDocumentService documents, IDatabaseService databaseService, ILogger<ProjectDocumentController> logger)
        {
            _documents = documents;
            _databaseService = databaseService;
            _logger = logger;
        }

        private async Task<IActionResult?> DenyUnlessProjectAccessAsync(int projectId)
        {
            if (!await ProjectAccessHelper.HasProjectAccessAsync(User, _databaseService, projectId))
            {
                return StatusCode(403, new { success = false, message = ProjectAccessHelper.DeniedMessage });
            }
            return null;
        }

        [RequirePermission(Page, "View")]
        [HttpGet("projects")]
        public async Task<IActionResult> GetProjects()
        {
            try
            {
                var data = await _documents.GetAccessibleProjectsAsync(User);
                return Ok(new { success = true, data });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error listing document projects.");
                return StatusCode(500, new { success = false, message = "Unable to load projects." });
            }
        }

        [RequirePermission(Page, "View")]
        [HttpGet]
        public async Task<IActionResult> GetDocuments([FromQuery] int projectId)
        {
            try
            {
                var denied = await DenyUnlessProjectAccessAsync(projectId);
                if (denied is not null) return denied;
                var folder = await _documents.ResolveProjectFolderAsync(User, projectId);
                var data = _documents.ListDocuments(folder);
                return Ok(new { success = true, data });
            }
            catch (UnauthorizedAccessException ex)
            {
                return StatusCode(403, new { success = false, message = ex.Message });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error listing project documents for project {ProjectId}.", projectId);
                return StatusCode(500, new { success = false, message = "Unable to load documents." });
            }
        }

        [RequirePermission(Page, "View")]
        [HttpGet("download")]
        public async Task<IActionResult> Download([FromQuery] int projectId, [FromQuery] string fileName)
        {
            try
            {
                var denied = await DenyUnlessProjectAccessAsync(projectId);
                if (denied is not null) return denied;
                var folder = await _documents.ResolveProjectFolderAsync(User, projectId);
                var fullPath = _documents.ResolveDocumentPath(folder, fileName);
                var bytes = await System.IO.File.ReadAllBytesAsync(fullPath);
                return File(bytes, _documents.GetContentType(fullPath), Path.GetFileName(fullPath));
            }
            catch (UnauthorizedAccessException ex)
            {
                return StatusCode(403, new { success = false, message = ex.Message });
            }
            catch (FileNotFoundException)
            {
                return NotFound(new { success = false, message = "Document not found." });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { success = false, message = ex.Message });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error downloading document for project {ProjectId}.", projectId);
                return StatusCode(500, new { success = false, message = "Unable to download the document." });
            }
        }

        [RequirePermission(Page, "Edit")]
        [HttpPost("upload")]
        [RequestSizeLimit(26214400)]
        public async Task<IActionResult> Upload([FromForm] int projectId, [FromForm] IFormFile? file)
        {
            try
            {
                var denied = await DenyUnlessProjectAccessAsync(projectId);
                if (denied is not null) return denied;
                if (file is null || file.Length == 0)
                {
                    return BadRequest(new { success = false, message = "Please select a file to upload." });
                }

                var folder = await _documents.ResolveProjectFolderAsync(User, projectId);
                await using var stream = file.OpenReadStream();
                var saved = await _documents.SaveDocumentAsync(folder, file.FileName, stream, file.Length);
                return Ok(new { success = true, message = $"Document '{saved.FileName}' uploaded.", data = saved });
            }
            catch (UnauthorizedAccessException ex)
            {
                return StatusCode(403, new { success = false, message = ex.Message });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { success = false, message = ex.Message });
            }
            catch (IOException ex)
            {
                _logger.LogError(ex, "Error saving uploaded document for project {ProjectId}.", projectId);
                return StatusCode(500, new { success = false, message = "Unable to save the uploaded file." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error uploading document for project {ProjectId}.", projectId);
                return StatusCode(500, new { success = false, message = "An error occurred while uploading." });
            }
        }

        [RequirePermission(Page, "Delete")]
        [HttpDelete]
        public async Task<IActionResult> Delete([FromQuery] int projectId, [FromQuery] string fileName)
        {
            try
            {
                var denied = await DenyUnlessProjectAccessAsync(projectId);
                if (denied is not null) return denied;
                var folder = await _documents.ResolveProjectFolderAsync(User, projectId);
                var fullPath = _documents.ResolveDocumentPath(folder, fileName);
                System.IO.File.Delete(fullPath);
                _logger.LogInformation("Project document deleted: {File}", fullPath);
                return Ok(new { success = true, message = "Document deleted successfully." });
            }
            catch (UnauthorizedAccessException ex)
            {
                return StatusCode(403, new { success = false, message = ex.Message });
            }
            catch (FileNotFoundException)
            {
                return NotFound(new { success = false, message = "Document not found." });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { success = false, message = ex.Message });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting document for project {ProjectId}.", projectId);
                return StatusCode(500, new { success = false, message = "Unable to delete the document." });
            }
        }
    }
}

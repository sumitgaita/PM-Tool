using System.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using ProjectManagement.Api.DTOs;
using ProjectManagement.Api.Authorization;
using ProjectManagement.Api.Services;

namespace ProjectManagement.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class FishHarvestController : ControllerBase
    {
        private const string Page = "Fish Harvest";
        private readonly IDatabaseService _db;
        private readonly ILogger<FishHarvestController> _logger;
        public FishHarvestController(IDatabaseService db, ILogger<FishHarvestController> logger)
        { _db = db; _logger = logger; }

        [RequirePermission(Page, "View")]
        [HttpGet("paged")]
        public async Task<IActionResult> GetPaged(
            [FromQuery] int? projectId = null,
            [FromQuery] int? pondId = null,
            [FromQuery] int? fishTypeId = null,
            [FromQuery] DateTime? fromDate = null,
            [FromQuery] DateTime? toDate = null,
            [FromQuery] int pageNumber = 1,
            [FromQuery] int pageSize = 10,
            [FromQuery] string? sortBy = "harvestDate",
            [FromQuery] string? sortDir = "desc")
        {
            try
            {
                if (pageNumber < 1) pageNumber = 1;
                if (pageSize < 1) pageSize = 10;
                if (pageSize > 100) pageSize = 100;
                var allowed = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
                    { "harvestId", "harvestDate", "pondCode", "fishName", "quantity", "totalWeight" };
                if (string.IsNullOrWhiteSpace(sortBy) || !allowed.Contains(sortBy)) sortBy = "harvestDate";
                sortDir = string.Equals(sortDir, "asc", StringComparison.OrdinalIgnoreCase) ? "asc" : "desc";
                var p = new[]
                {
                    new SqlParameter("@ProjectId", (object?)projectId ?? DBNull.Value),
                    new SqlParameter("@PondId", (object?)pondId ?? DBNull.Value),
                    new SqlParameter("@FishTypeId", (object?)fishTypeId ?? DBNull.Value),
                    new SqlParameter("@FromDate", (object?)fromDate ?? DBNull.Value),
                    new SqlParameter("@ToDate", (object?)toDate ?? DBNull.Value),
                    new SqlParameter("@PageNumber", pageNumber),
                    new SqlParameter("@PageSize", pageSize),
                    new SqlParameter("@SortBy", sortBy),
                    new SqlParameter("@SortDir", sortDir),
                    new SqlParameter("@TotalRecords", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };
                var (data, outputs) = await _db.ExecuteStoredProcedureWithOutputsAsync<FishHarvestDto>("usp_FishHarvest_GetPaged", p);
                var total = outputs.TryGetValue("TotalRecords", out var t) && t != null ? Convert.ToInt32(t) : data.Count;
                return Ok(new { success = true, data, pageNumber, pageSize, totalRecords = total, totalPages = (int)Math.Ceiling(total / (double)pageSize) });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "FishHarvest paged fetch failed"); }
        }

        [RequirePermission(Page, "Edit")]
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateFishHarvestRequest req)
        {
            try
            {
                if (req.PondId <= 0) return BadRequest(new { success = false, message = "Pond is required." });
                if (req.FishTypeId <= 0) return BadRequest(new { success = false, message = "Fish type is required." });
                if (req.Quantity <= 0) return BadRequest(new { success = false, message = "Quantity must be greater than zero." });
                var me = AuditHelper.CurrentUserId(User);
                var p = new[]
                {
                    new SqlParameter("@PondId", req.PondId),
                    new SqlParameter("@FishTypeId", req.FishTypeId),
                    new SqlParameter("@HarvestDate", req.HarvestDate),
                    new SqlParameter("@Quantity", req.Quantity),
                    new SqlParameter("@TotalWeight", (object?)req.TotalWeight ?? DBNull.Value),
                    new SqlParameter("@HarvestCost", (object?)req.HarvestCost ?? DBNull.Value),
                    new SqlParameter("@Remarks", (object?)req.Remarks ?? DBNull.Value),
                    new SqlParameter("@CreatedBy", me),
                    new SqlParameter("@HarvestId", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };
                await _db.ExecuteNonQueryAsync("usp_FishHarvest_Insert", p);
                await AuditHelper.LogAsync(_db, _logger, me, "Fish Harvest Added", Page, null);
                return Ok(new { success = true, message = "Fish harvest recorded successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "FishHarvest insert failed"); }
        }

        [RequirePermission(Page, "Edit")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateFishHarvestRequest req)
        {
            try
            {
                if (req.Quantity <= 0) return BadRequest(new { success = false, message = "Quantity must be greater than zero." });
                var me = AuditHelper.CurrentUserId(User);
                var p = new[]
                {
                    new SqlParameter("@HarvestId", id),
                    new SqlParameter("@HarvestDate", req.HarvestDate),
                    new SqlParameter("@Quantity", req.Quantity),
                    new SqlParameter("@TotalWeight", (object?)req.TotalWeight ?? DBNull.Value),
                    new SqlParameter("@HarvestCost", (object?)req.HarvestCost ?? DBNull.Value),
                    new SqlParameter("@Remarks", (object?)req.Remarks ?? DBNull.Value),
                    new SqlParameter("@ModifiedBy", me)
                };
                await _db.ExecuteNonQueryAsync("usp_FishHarvest_Update", p);
                await AuditHelper.LogAsync(_db, _logger, me, "Fish Harvest Updated", Page, id);
                return Ok(new { success = true, message = "Fish harvest updated successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "FishHarvest update failed"); }
        }

        [RequirePermission(Page, "Delete")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var me = AuditHelper.CurrentUserId(User);
                await _db.ExecuteNonQueryAsync("usp_FishHarvest_Delete", new[] { new SqlParameter("@HarvestId", id) });
                await AuditHelper.LogAsync(_db, _logger, me, "Fish Harvest Deleted", Page, id);
                return Ok(new { success = true, message = "Fish harvest deleted successfully." });
            }
            catch (Exception ex) { return FarmErrors.Handle(_logger, ex, "FishHarvest delete failed"); }
        }
    }
}

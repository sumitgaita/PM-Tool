using System.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using ProjectManagement.Api.DTOs;
using ProjectManagement.Api.Authorization;
using ProjectManagement.Api.Services;

namespace ProjectManagement.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class ProjectBudgetController : ControllerBase
    {
        private readonly IDatabaseService _db;
        private readonly ILogger<ProjectBudgetController> _logger;
        public ProjectBudgetController(IDatabaseService db, ILogger<ProjectBudgetController> logger)
        { _db = db; _logger = logger; }

        [RequirePermission("Project Budgets", "View")]
        [HttpGet]
        public async Task<IActionResult> Get(
            [FromQuery] int? projectId = null,
            [FromQuery] int? budgetCodeId = null,
            [FromQuery] string? searchText = null,
            [FromQuery] int pageNumber = 1,
            [FromQuery] int pageSize = 10,
            [FromQuery] string? sortBy = "projectName",
            [FromQuery] string? sortDir = "asc")
        {
            try
            {
                if (pageNumber < 1) pageNumber = 1;
                if (pageSize < 1) pageSize = 10;
                if (pageSize > 100) pageSize = 100;

                var allowedSortBy = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
                {
                    "projectBudgetId", "projectCode", "projectName",
                    "budgetCode", "budgetCodeName", "budgetAmount", "effectiveFrom"
                };
                if (string.IsNullOrWhiteSpace(sortBy) || !allowedSortBy.Contains(sortBy)) sortBy = "projectName";
                sortDir = string.Equals(sortDir, "desc", StringComparison.OrdinalIgnoreCase) ? "desc" : "asc";
                if (string.IsNullOrWhiteSpace(searchText)) searchText = null;
                else if (searchText.Length > 100) searchText = searchText.Substring(0, 100);

                var p = new[]
                {
                    new SqlParameter("@ProjectId", (object?)projectId ?? DBNull.Value),
                    new SqlParameter("@BudgetCodeId", (object?)budgetCodeId ?? DBNull.Value),
                    new SqlParameter("@SearchText", (object?)searchText ?? DBNull.Value),
                    new SqlParameter("@PageNumber", pageNumber),
                    new SqlParameter("@PageSize", pageSize),
                    new SqlParameter("@SortBy", sortBy),
                    new SqlParameter("@SortDir", sortDir),
                    new SqlParameter("@TotalRecords", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };
                var (data, outputs) = await _db.ExecuteStoredProcedureWithOutputsAsync<ProjectBudgetDto>("usp_ProjectBudget_Get", p);
                var totalRecords = outputs.TryGetValue("TotalRecords", out var total) && total != null
                    ? Convert.ToInt32(total)
                    : data.Count;
                var totalPages = (int)Math.Ceiling(totalRecords / (double)pageSize);
                return Ok(new { success = true, data, pageNumber, pageSize, totalRecords, totalPages });
            }
            catch (Exception ex) { _logger.LogError(ex, "ProjectBudget Get failed"); return StatusCode(500, new { success = false, message = "Failed to fetch project budgets." }); }
        }

        [RequirePermission("Project Budgets", "Edit")]
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateProjectBudgetRequest req)
        {
            if (req.BudgetAmount <= 0) return BadRequest(new { success = false, message = "Validation failed.", errors = new[] { "Budget amount must be greater than zero." } });
            try
            {
                var p = new[]
                {
                    new SqlParameter("@ProjectId", req.ProjectId),
                    new SqlParameter("@BudgetCodeId", req.BudgetCodeId),
                    new SqlParameter("@BudgetAmount", req.BudgetAmount),
                    new SqlParameter("@EffectiveFrom", req.EffectiveFrom),
                    new SqlParameter("@EffectiveTo", (object?)req.EffectiveTo ?? DBNull.Value),
                    new SqlParameter("@CreatedBy", CurrentUserId()),
                    new SqlParameter("@ProjectBudgetId", SqlDbType.Int) { Direction = ParameterDirection.Output }
                };
                await _db.ExecuteNonQueryAsync("usp_ProjectBudget_Insert", p);
                return Ok(new { success = true, message = "Project budget saved successfully." });
            }
            catch (Exception ex) { _logger.LogError(ex, "ProjectBudget insert failed"); return StatusCode(500, new { success = false, message = "Failed to save project budget." }); }
        }

        [RequirePermission("Project Budgets", "Edit")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateProjectBudgetRequest req)
        {
            if (req.BudgetAmount <= 0) return BadRequest(new { success = false, message = "Validation failed.", errors = new[] { "Budget amount must be greater than zero." } });
            try
            {
                var p = new[]
                {
                    new SqlParameter("@ProjectBudgetId", id),
                    new SqlParameter("@BudgetAmount", req.BudgetAmount),
                    new SqlParameter("@EffectiveFrom", req.EffectiveFrom),
                    new SqlParameter("@EffectiveTo", (object?)req.EffectiveTo ?? DBNull.Value),
                    new SqlParameter("@ModifiedBy", CurrentUserId())
                };
                await _db.ExecuteNonQueryAsync("usp_ProjectBudget_Update", p);
                return Ok(new { success = true, message = "Project budget updated successfully." });
            }
            catch (Exception ex) { _logger.LogError(ex, "ProjectBudget update failed"); return StatusCode(500, new { success = false, message = "Failed to update project budget." }); }
        }

        [RequirePermission("Project Budgets", "Delete")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var p = new[] { new SqlParameter("@ProjectBudgetId", id), new SqlParameter("@ModifiedBy", CurrentUserId()) };
                await _db.ExecuteNonQueryAsync("usp_ProjectBudget_Delete", p);
                return Ok(new { success = true, message = "Project budget deleted successfully." });
            }
            catch (Exception ex) { _logger.LogError(ex, "ProjectBudget delete failed"); return StatusCode(500, new { success = false, message = "Failed to delete project budget." }); }
        }

        private int CurrentUserId() => int.TryParse(User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value, out var i) ? i : 0;
    }
}

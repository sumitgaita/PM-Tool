using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProjectManagement.Api.DTOs;
using ProjectManagement.Api.Services;

namespace ProjectManagement.Api.Controllers
{
    // Super Admin only. Every action re-checks the caller's role claim;
    // the page/permission system is intentionally bypassed, mirroring the
    // Super Admin-only user-management endpoints.
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class DatabaseBackupController : ControllerBase
    {
        private readonly IBackupService _backupService;
        private readonly ILogger<DatabaseBackupController> _logger;

        public DatabaseBackupController(IBackupService backupService, ILogger<DatabaseBackupController> logger)
        {
            _backupService = backupService;
            _logger = logger;
        }

        private static bool IsSuperAdmin(System.Security.Claims.ClaimsPrincipal principal)
        {
            var role = principal.FindFirst(System.Security.Claims.ClaimTypes.Role)?.Value;
            return string.Equals(role, "Super Admin", StringComparison.OrdinalIgnoreCase);
        }

        private IActionResult? ForbidUnlessSuperAdmin()
        {
            if (!IsSuperAdmin(User))
            {
                return StatusCode(403, new { success = false, message = "Only Super Admin can manage database backups." });
            }
            return null;
        }

        [HttpGet]
        public IActionResult GetBackups()
        {
            var forbidden = ForbidUnlessSuperAdmin();
            if (forbidden is not null) return forbidden;
            try
            {
                var data = _backupService.ListBackups();
                return Ok(new { success = true, data });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error listing database backups.");
                return StatusCode(500, new { success = false, message = "Unable to list database backups." });
            }
        }

        [HttpGet("download/{fileName}")]
        public IActionResult Download(string fileName)
        {
            var forbidden = ForbidUnlessSuperAdmin();
            if (forbidden is not null) return forbidden;
            try
            {
                var fullPath = _backupService.ResolveBackupPath(fileName);
                var bytes = System.IO.File.ReadAllBytes(fullPath);
                return File(bytes, "application/octet-stream", Path.GetFileName(fullPath));
            }
            catch (FileNotFoundException)
            {
                return NotFound(new { success = false, message = "Backup file not found." });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { success = false, message = ex.Message });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error downloading database backup: {File}", fileName);
                return StatusCode(500, new { success = false, message = "Unable to download the backup file." });
            }
        }

        [HttpPost("restore")]
        public async Task<IActionResult> Restore([FromBody] RestoreBackupRequest request)
        {
            var forbidden = ForbidUnlessSuperAdmin();
            if (forbidden is not null) return forbidden;
            try
            {
                if (request is null || string.IsNullOrWhiteSpace(request.FileName))
                {
                    return BadRequest(new { success = false, message = "Please select a backup file to restore." });
                }

                var result = await _backupService.RestoreAsync(request.FileName);
                if (!result.Success)
                {
                    return BadRequest(new { success = false, message = result.Message });
                }
                return Ok(new { success = true, message = result.Message });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error restoring database backup.");
                return StatusCode(500, new { success = false, message = "An error occurred while restoring the database." });
            }
        }

        [HttpPost("create-database")]
        public async Task<IActionResult> CreateDatabase([FromBody] CreateDatabaseRequest request)
        {
            var forbidden = ForbidUnlessSuperAdmin();
            if (forbidden is not null) return forbidden;
            try
            {
                if (request is null || string.IsNullOrWhiteSpace(request.FileName))
                {
                    return BadRequest(new { success = false, message = "Please select a backup file." });
                }
                if (string.IsNullOrWhiteSpace(request.NewDatabaseName))
                {
                    return BadRequest(new { success = false, message = "Please enter a name for the new database." });
                }

                var result = await _backupService.CreateDatabaseAsync(request.FileName, request.NewDatabaseName);
                if (!result.Success)
                {
                    return BadRequest(new { success = false, message = result.Message });
                }
                return Ok(new { success = true, message = result.Message, data = new { databaseName = result.FileName } });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating database from backup.");
                return StatusCode(500, new { success = false, message = "An error occurred while creating the database." });
            }
        }
    }
}

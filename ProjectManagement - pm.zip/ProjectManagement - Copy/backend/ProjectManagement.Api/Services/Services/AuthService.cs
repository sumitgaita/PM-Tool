using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Data.SqlClient;
using Microsoft.IdentityModel.Tokens;
using ProjectManagement.Api.DTOs;

namespace ProjectManagement.Api.Services
{
    public interface IAuthService
    {
        Task<LoginResponse> LoginAsync(LoginRequest request);
        Task<bool> ChangePasswordAsync(ChangePasswordRequest request);
        string HashPassword(string password);
        string? EncryptPassword(string password);
        string? DecryptPassword(string? cipherText);
        string GenerateToken(UserDto user);
    }

    public class AuthService : IAuthService
    {
        private readonly IDatabaseService _databaseService;
        private readonly IConfiguration _configuration;
        private readonly ILogger<AuthService> _logger;

        public AuthService(IDatabaseService databaseService, IConfiguration configuration, ILogger<AuthService> logger)
        {
            _databaseService = databaseService;
            _configuration = configuration;
            _logger = logger;
        }

        public async Task<LoginResponse> LoginAsync(LoginRequest request)
        {
            try
            {
                var passwordHash = HashPassword(request.Password);
                var parameters = new[]
                {
                    new SqlParameter("@Username", request.Username),
                    new SqlParameter("@PasswordHash", passwordHash)
                };

                var users = await _databaseService.ExecuteStoredProcedureAsync<UserDto>("usp_User_Login", parameters);

                if (users.Count == 0)
                {
                    return new LoginResponse
                    {
                        Success = false,
                        Message = "Invalid username or password."
                    };
                }

                var user = users[0];
                var token = GenerateToken(user);

                return new LoginResponse
                {
                    Success = true,
                    Message = "Login successful.",
                    Token = token,
                    User = user
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during login for user: {Username}", request.Username);
                return new LoginResponse
                {
                    Success = false,
                    Message = "An error occurred during login. Please try again."
                };
            }
        }

        public async Task<bool> ChangePasswordAsync(ChangePasswordRequest request)
        {
            try
            {
                var currentPasswordHash = HashPassword(request.CurrentPassword);
                var newPasswordHash = HashPassword(request.NewPassword);

                var parameters = new[]
                {
                    new SqlParameter("@UserId", request.UserId),
                    new SqlParameter("@NewPasswordHash", newPasswordHash),
                    new SqlParameter("@NewPasswordEnc", (object?)EncryptPassword(request.NewPassword) ?? DBNull.Value),
                    new SqlParameter("@ModifiedBy", request.UserId)
                };

                await _databaseService.ExecuteNonQueryAsync("usp_User_ChangePassword", parameters);
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error changing password for user: {UserId}", request.UserId);
                return false;
            }
        }

        public string HashPassword(string password)
        {
            using var sha256 = SHA256.Create();
            var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
            return Convert.ToHexString(hashedBytes).ToLower();
        }

        public string? EncryptPassword(string password)
        {
            try
            {
                var key = PasswordCrypto.GetKey(_configuration);
                if (key is null) return null;
                return PasswordCrypto.Encrypt(password, key);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error encrypting password");
                return null;
            }
        }

        public string? DecryptPassword(string? cipherText)
        {
            var key = PasswordCrypto.GetKey(_configuration);
            return PasswordCrypto.TryDecrypt(cipherText, key, out var plain) ? plain : null;
        }

        public string GenerateToken(UserDto user)
        {
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]!));
            var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
                new Claim(ClaimTypes.NameIdentifier, user.UserId.ToString()),
                new Claim(ClaimTypes.Name, user.Username),
                new Claim(ClaimTypes.Email, user.Email),
                new Claim(ClaimTypes.Role, user.RoleName),
                new Claim("FullName", user.FullName)
            };

            var token = new JwtSecurityToken(
                issuer: _configuration["Jwt:Issuer"],
                audience: _configuration["Jwt:Audience"],
                claims: claims,
                expires: DateTime.Now.AddMinutes(Convert.ToDouble(_configuration["Jwt:ExpiryInMinutes"])),
                signingCredentials: credentials
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}

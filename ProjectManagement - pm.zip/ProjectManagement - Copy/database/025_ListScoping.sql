USE ProjectManagementDB;
GO

-- =============================================
-- 025: Scope list endpoints to assigned projects.
-- New helper fn_CanAccessProject(@UserId, @ProjectId):
-- NULL user = unscoped (back-compat), Super Admin = all,
-- else UserProjects assignment.
-- Adds @UserId to 8 list procs (count + page queries).
-- Controllers pass the current user id; Super Admin sees all.
-- =============================================
IF OBJECT_ID('dbo.fn_CanAccessProject', 'FN') IS NOT NULL
    DROP FUNCTION dbo.fn_CanAccessProject;
GO

CREATE FUNCTION dbo.fn_CanAccessProject
(
    @UserId INT,
    @ProjectId INT
)
RETURNS BIT
AS
BEGIN
    IF (@UserId IS NULL) RETURN 1;
    IF EXISTS (
        SELECT 1
        FROM Users u
        INNER JOIN Roles r ON r.RoleId = u.RoleId
        WHERE u.UserId = @UserId AND r.RoleName = 'Super Admin'
    ) RETURN 1;
    IF EXISTS (SELECT 1 FROM UserProjects WHERE UserId = @UserId AND ProjectId = @ProjectId) RETURN 1;
    RETURN 0;
END
GO

-- =============================================
-- usp_ProjectBudget_Get + @UserId
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_ProjectBudget_Get')
    DROP PROCEDURE usp_ProjectBudget_Get;
GO

CREATE PROCEDURE usp_ProjectBudget_Get
    @ProjectId INT = NULL,
    @UserId INT = NULL,
    @BudgetCodeId INT = NULL,
    @SearchText NVARCHAR(100) = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @SortBy NVARCHAR(50) = 'projectName',
    @SortDir NVARCHAR(4) = 'asc',
    @TotalRecords INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@PageNumber IS NULL OR @PageNumber < 1) SET @PageNumber = 1;
    IF (@PageSize IS NULL OR @PageSize < 1) SET @PageSize = 10;
    IF (@PageSize > 100) SET @PageSize = 100;
    SET @SearchText = NULLIF(LTRIM(RTRIM(ISNULL(@SearchText, ''))), '');
    SET @SortBy = LOWER(LTRIM(RTRIM(ISNULL(@SortBy, 'projectName'))));
    IF (@SortBy NOT IN ('projectbudgetid', 'projectcode', 'projectname', 'budgetcode', 'budgetcodename', 'budgetamount', 'effectivefrom'))
        SET @SortBy = 'projectname';
    SET @SortDir = LOWER(LTRIM(RTRIM(ISNULL(@SortDir, 'asc'))));
    IF (@SortDir NOT IN ('asc', 'desc'))
        SET @SortDir = 'asc';

    SELECT @TotalRecords = COUNT(*)
    FROM ProjectBudgets pb
    INNER JOIN Projects p ON pb.ProjectId = p.ProjectId
    INNER JOIN BudgetCodes bc ON pb.BudgetCodeId = bc.BudgetCodeId
    WHERE (@ProjectId IS NULL OR pb.ProjectId = @ProjectId)
    AND (@BudgetCodeId IS NULL OR pb.BudgetCodeId = @BudgetCodeId)
    AND (@SearchText IS NULL OR p.ProjectCode LIKE '%' + @SearchText + '%' OR p.ProjectName LIKE '%' + @SearchText + '%')
    AND dbo.fn_CanAccessProject(@UserId, pb.ProjectId) = 1;

    SELECT
        pb.ProjectBudgetId,
        pb.ProjectId,
        p.ProjectCode,
        p.ProjectName,
        pb.BudgetCodeId,
        bc.BudgetCode,
        bc.BudgetCodeName,
        pb.BudgetAmount,
        pb.EffectiveFrom,
        pb.EffectiveTo,
        pb.IsActive,
        pb.CreatedBy,
        pb.CreatedDate,
        pb.ModifiedBy,
        pb.ModifiedDate
    FROM ProjectBudgets pb
    INNER JOIN Projects p ON pb.ProjectId = p.ProjectId
    INNER JOIN BudgetCodes bc ON pb.BudgetCodeId = bc.BudgetCodeId
    WHERE (@ProjectId IS NULL OR pb.ProjectId = @ProjectId)
    AND (@BudgetCodeId IS NULL OR pb.BudgetCodeId = @BudgetCodeId)
    AND (@SearchText IS NULL OR p.ProjectCode LIKE '%' + @SearchText + '%' OR p.ProjectName LIKE '%' + @SearchText + '%')
    AND dbo.fn_CanAccessProject(@UserId, pb.ProjectId) = 1
    ORDER BY
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'projectbudgetid' THEN pb.ProjectBudgetId END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'projectbudgetid' THEN pb.ProjectBudgetId END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'projectcode' THEN p.ProjectCode END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'projectcode' THEN p.ProjectCode END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'projectname' THEN p.ProjectName END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'projectname' THEN p.ProjectName END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'budgetcode' THEN bc.BudgetCode END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'budgetcode' THEN bc.BudgetCode END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'budgetcodename' THEN bc.BudgetCodeName END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'budgetcodename' THEN bc.BudgetCodeName END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'budgetamount' THEN pb.BudgetAmount END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'budgetamount' THEN pb.BudgetAmount END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'effectivefrom' THEN pb.EffectiveFrom END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'effectivefrom' THEN pb.EffectiveFrom END DESC,
        pb.ProjectBudgetId ASC
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

-- =============================================
-- usp_ProjectResource_Get + @UserId
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_ProjectResource_Get')
    DROP PROCEDURE usp_ProjectResource_Get;
GO

CREATE PROCEDURE usp_ProjectResource_Get
    @ProjectId INT = NULL,
    @UserId INT = NULL,
    @ResourceId INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        pr.ProjectResourceId,
        pr.ProjectId,
        p.ProjectCode,
        p.ProjectName,
        pr.ResourceId,
        r.ResourceCode,
        r.ResourceName,
        r.ResourceType,
        pr.AssignedFrom,
        pr.AssignedTo,
        pr.IsActive,
        pr.CreatedBy,
        pr.CreatedDate,
        pr.ModifiedBy,
        pr.ModifiedDate
    FROM ProjectResources pr
    INNER JOIN Projects p ON pr.ProjectId = p.ProjectId
    INNER JOIN Resources r ON pr.ResourceId = r.ResourceId
    WHERE (@ProjectId IS NULL OR pr.ProjectId = @ProjectId)
    AND (@ResourceId IS NULL OR pr.ResourceId = @ResourceId)
    AND dbo.fn_CanAccessProject(@UserId, pr.ProjectId) = 1
    ORDER BY p.ProjectCode, r.ResourceCode;
END
GO

-- =============================================
-- usp_Expense_GetByDate + @UserId
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Expense_GetByDate')
    DROP PROCEDURE usp_Expense_GetByDate;
GO

CREATE PROCEDURE usp_Expense_GetByDate
    @ExpenseDate DATE,
    @UserId INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        e.ExpenseId, e.ExpenseDate, e.ProjectId,
        p.ProjectCode, p.ProjectName,
        e.BudgetCodeId, bc.BudgetCode, bc.BudgetCodeName,
        e.ResourceId, r.ResourceCode, r.ResourceName,
        e.Amount, e.Description, e.ReferenceNo, e.Remarks,
        e.FarmType, e.FarmEntityType, e.FarmEntityId,
        e.CreatedBy, e.CreatedDate
    FROM Expenses e
    INNER JOIN Projects p ON e.ProjectId = p.ProjectId
    INNER JOIN BudgetCodes bc ON e.BudgetCodeId = bc.BudgetCodeId
    INNER JOIN Resources r ON e.ResourceId = r.ResourceId
    WHERE e.ExpenseDate = @ExpenseDate AND e.IsDeleted = 0
    AND dbo.fn_CanAccessProject(@UserId, e.ProjectId) = 1;
END
GO

-- =============================================
-- usp_Expense_GetByDateRange + @UserId
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Expense_GetByDateRange')
    DROP PROCEDURE usp_Expense_GetByDateRange;
GO

CREATE PROCEDURE usp_Expense_GetByDateRange
    @FromDate DATE,
    @ToDate DATE,
    @ProjectId INT = NULL,
    @UserId INT = NULL,
    @BudgetCodeId INT = NULL,
    @ResourceId INT = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @SortBy NVARCHAR(50) = 'expenseDate',
    @SortDir NVARCHAR(4) = 'desc',
    @TotalRecords INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@PageNumber IS NULL OR @PageNumber < 1) SET @PageNumber = 1;
    IF (@PageSize IS NULL OR @PageSize < 1) SET @PageSize = 10;
    IF (@PageSize > 100) SET @PageSize = 100;
    SET @SortBy = LOWER(LTRIM(RTRIM(ISNULL(@SortBy, 'expenseDate'))));
    IF (@SortBy NOT IN ('expenseid', 'expensedate', 'projectcode', 'projectname', 'budgetcode', 'budgetcodename', 'resourcename', 'amount', 'createddate'))
        SET @SortBy = 'expenseDate';
    SET @SortDir = LOWER(LTRIM(RTRIM(ISNULL(@SortDir, 'desc'))));
    IF (@SortDir NOT IN ('asc', 'desc'))
        SET @SortDir = 'desc';

    SELECT @TotalRecords = COUNT(*)
    FROM Expenses e
    WHERE e.ExpenseDate BETWEEN @FromDate AND @ToDate
    AND e.IsDeleted = 0
    AND (@ProjectId IS NULL OR e.ProjectId = @ProjectId)
    AND (@BudgetCodeId IS NULL OR e.BudgetCodeId = @BudgetCodeId)
    AND (@ResourceId IS NULL OR e.ResourceId = @ResourceId)
    AND dbo.fn_CanAccessProject(@UserId, e.ProjectId) = 1;

    SELECT
        e.ExpenseId, e.ExpenseDate, e.ProjectId,
        p.ProjectCode, p.ProjectName,
        e.BudgetCodeId, bc.BudgetCode, bc.BudgetCodeName,
        e.ResourceId, r.ResourceCode, r.ResourceName,
        e.Amount, e.Description, e.ReferenceNo, e.Remarks,
        e.FarmType, e.FarmEntityType, e.FarmEntityId,
        e.CreatedBy, e.CreatedDate
    FROM Expenses e
    INNER JOIN Projects p ON e.ProjectId = p.ProjectId
    INNER JOIN BudgetCodes bc ON e.BudgetCodeId = bc.BudgetCodeId
    INNER JOIN Resources r ON e.ResourceId = r.ResourceId
    WHERE e.ExpenseDate BETWEEN @FromDate AND @ToDate
    AND e.IsDeleted = 0
    AND (@ProjectId IS NULL OR e.ProjectId = @ProjectId)
    AND (@BudgetCodeId IS NULL OR e.BudgetCodeId = @BudgetCodeId)
    AND (@ResourceId IS NULL OR e.ResourceId = @ResourceId)
    AND dbo.fn_CanAccessProject(@UserId, e.ProjectId) = 1
    ORDER BY
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'expenseid' THEN e.ExpenseId END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'expenseid' THEN e.ExpenseId END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'expensedate' THEN e.ExpenseDate END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'expensedate' THEN e.ExpenseDate END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'projectcode' THEN p.ProjectCode END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'projectcode' THEN p.ProjectCode END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'projectname' THEN p.ProjectName END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'projectname' THEN p.ProjectName END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'budgetcode' THEN bc.BudgetCode END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'budgetcode' THEN bc.BudgetCode END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'budgetcodename' THEN bc.BudgetCodeName END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'budgetcodename' THEN bc.BudgetCodeName END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'resourcename' THEN r.ResourceName END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'resourcename' THEN r.ResourceName END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'amount' THEN e.Amount END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'amount' THEN e.Amount END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'createddate' THEN e.CreatedDate END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'createddate' THEN e.CreatedDate END DESC,
        e.ExpenseDate DESC,
        e.CreatedDate DESC
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

-- =============================================
-- usp_Revenue_GetPaged + @UserId
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Revenue_GetPaged')
    DROP PROCEDURE usp_Revenue_GetPaged;
GO

CREATE PROCEDURE usp_Revenue_GetPaged
    @ProjectId INT = NULL,
    @UserId INT = NULL,
    @FarmType NVARCHAR(50) = NULL,
    @RevenueType NVARCHAR(50) = NULL,
    @FromDate DATE = NULL,
    @ToDate DATE = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @SortBy NVARCHAR(50) = 'revenueDate',
    @SortDir NVARCHAR(4) = 'desc',
    @TotalRecords INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@PageNumber IS NULL OR @PageNumber < 1) SET @PageNumber = 1;
    IF (@PageSize IS NULL OR @PageSize < 1) SET @PageSize = 10;
    IF (@PageSize > 100) SET @PageSize = 100;
    SET @SortBy = LOWER(LTRIM(RTRIM(ISNULL(@SortBy, 'revenuedate'))));
    IF (@SortBy NOT IN ('revenueid', 'revenuedate', 'revenuetype', 'customername', 'amount'))
        SET @SortBy = 'revenuedate';
    SET @SortDir = LOWER(LTRIM(RTRIM(ISNULL(@SortDir, 'desc'))));
    IF (@SortDir NOT IN ('asc', 'desc')) SET @SortDir = 'desc';
    IF (LTRIM(RTRIM(ISNULL(@FarmType, ''))) = '') SET @FarmType = NULL;
    IF (LTRIM(RTRIM(ISNULL(@RevenueType, ''))) = '') SET @RevenueType = NULL;

    SELECT @TotalRecords = COUNT(*)
    FROM Revenue r
    WHERE r.IsDeleted = 0
    AND (@ProjectId IS NULL OR r.ProjectId = @ProjectId)
    AND (@FarmType IS NULL OR r.FarmType = @FarmType)
    AND (@RevenueType IS NULL OR r.RevenueType = @RevenueType)
    AND (@FromDate IS NULL OR r.RevenueDate >= @FromDate)
    AND (@ToDate IS NULL OR r.RevenueDate <= @ToDate)
    AND dbo.fn_CanAccessProject(@UserId, r.ProjectId) = 1;

    SELECT r.RevenueId, r.RevenueDate, r.ProjectId, p.ProjectCode, p.ProjectName,
        r.FarmType, r.RevenueType, r.ReferenceId, r.CustomerName,
        r.Quantity, r.Weight, r.Rate, r.Amount, r.PaymentStatus, r.Remarks,
        r.CreatedBy, r.CreatedDate, r.ModifiedBy, r.ModifiedDate
    FROM Revenue r
    INNER JOIN Projects p ON r.ProjectId = p.ProjectId
    WHERE r.IsDeleted = 0
    AND (@ProjectId IS NULL OR r.ProjectId = @ProjectId)
    AND (@FarmType IS NULL OR r.FarmType = @FarmType)
    AND (@RevenueType IS NULL OR r.RevenueType = @RevenueType)
    AND (@FromDate IS NULL OR r.RevenueDate >= @FromDate)
    AND (@ToDate IS NULL OR r.RevenueDate <= @ToDate)
    AND dbo.fn_CanAccessProject(@UserId, r.ProjectId) = 1
    ORDER BY
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'revenuedate' THEN r.RevenueDate END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'revenuedate' THEN r.RevenueDate END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'revenuetype' THEN r.RevenueType END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'revenuetype' THEN r.RevenueType END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'customername' THEN r.CustomerName END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'customername' THEN r.CustomerName END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'amount' THEN r.Amount END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'amount' THEN r.Amount END DESC,
        r.RevenueDate DESC, r.RevenueId DESC
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

-- =============================================
-- usp_Pond_GetPaged + @UserId
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Pond_GetPaged')
    DROP PROCEDURE usp_Pond_GetPaged;
GO

CREATE PROCEDURE usp_Pond_GetPaged
    @ProjectId INT = NULL,
    @UserId INT = NULL,
    @SearchText NVARCHAR(100) = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @SortBy NVARCHAR(50) = 'pondCode',
    @SortDir NVARCHAR(4) = 'asc',
    @TotalRecords INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@PageNumber IS NULL OR @PageNumber < 1) SET @PageNumber = 1;
    IF (@PageSize IS NULL OR @PageSize < 1) SET @PageSize = 10;
    IF (@PageSize > 100) SET @PageSize = 100;
    SET @SortBy = LOWER(LTRIM(RTRIM(ISNULL(@SortBy, 'pondcode'))));
    IF (@SortBy NOT IN ('pondid', 'pondcode', 'pondname', 'area', 'status', 'createddate'))
        SET @SortBy = 'pondcode';
    SET @SortDir = LOWER(LTRIM(RTRIM(ISNULL(@SortDir, 'asc'))));
    IF (@SortDir NOT IN ('asc', 'desc')) SET @SortDir = 'asc';
    IF (LTRIM(RTRIM(ISNULL(@SearchText, ''))) = '') SET @SearchText = NULL;

    SELECT @TotalRecords = COUNT(*)
    FROM Ponds p
    WHERE (@ProjectId IS NULL OR p.ProjectId = @ProjectId)
    AND (@SearchText IS NULL OR p.PondCode LIKE '%' + @SearchText + '%' OR p.PondName LIKE '%' + @SearchText + '%')
    AND dbo.fn_CanAccessProject(@UserId, p.ProjectId) = 1;

    SELECT p.PondId, p.ProjectId, pr.ProjectCode, pr.ProjectName,
        p.PondCode, p.PondName, p.Area, p.AreaUnit, p.Depth, p.WaterCapacity,
        p.PondType, p.Status, p.IsActive,
        p.CreatedBy, p.CreatedDate, p.ModifiedBy, p.ModifiedDate
    FROM Ponds p
    INNER JOIN Projects pr ON p.ProjectId = pr.ProjectId
    WHERE (@ProjectId IS NULL OR p.ProjectId = @ProjectId)
    AND (@SearchText IS NULL OR p.PondCode LIKE '%' + @SearchText + '%' OR p.PondName LIKE '%' + @SearchText + '%')
    AND dbo.fn_CanAccessProject(@UserId, p.ProjectId) = 1
    ORDER BY
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'pondcode' THEN p.PondCode END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'pondcode' THEN p.PondCode END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'pondname' THEN p.PondName END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'pondname' THEN p.PondName END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'area' THEN p.Area END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'area' THEN p.Area END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'status' THEN p.Status END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'status' THEN p.Status END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'createddate' THEN p.CreatedDate END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'createddate' THEN p.CreatedDate END DESC,
        p.PondCode ASC
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

-- =============================================
-- usp_PoultryShed_GetPaged + @UserId
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultryShed_GetPaged')
    DROP PROCEDURE usp_PoultryShed_GetPaged;
GO

CREATE PROCEDURE usp_PoultryShed_GetPaged
    @ProjectId INT = NULL,
    @UserId INT = NULL,
    @SearchText NVARCHAR(100) = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @SortBy NVARCHAR(50) = 'shedCode',
    @SortDir NVARCHAR(4) = 'asc',
    @TotalRecords INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@PageNumber IS NULL OR @PageNumber < 1) SET @PageNumber = 1;
    IF (@PageSize IS NULL OR @PageSize < 1) SET @PageSize = 10;
    IF (@PageSize > 100) SET @PageSize = 100;
    SET @SortBy = LOWER(LTRIM(RTRIM(ISNULL(@SortBy, 'shedcode'))));
    IF (@SortBy NOT IN ('shedid', 'shedcode', 'shedname', 'capacity', 'status', 'createddate'))
        SET @SortBy = 'shedcode';
    SET @SortDir = LOWER(LTRIM(RTRIM(ISNULL(@SortDir, 'asc'))));
    IF (@SortDir NOT IN ('asc', 'desc')) SET @SortDir = 'asc';
    IF (LTRIM(RTRIM(ISNULL(@SearchText, ''))) = '') SET @SearchText = NULL;

    SELECT @TotalRecords = COUNT(*)
    FROM PoultrySheds s
    WHERE (@ProjectId IS NULL OR s.ProjectId = @ProjectId)
    AND (@SearchText IS NULL OR s.ShedCode LIKE '%' + @SearchText + '%' OR s.ShedName LIKE '%' + @SearchText + '%')
    AND dbo.fn_CanAccessProject(@UserId, s.ProjectId) = 1;

    SELECT s.ShedId, s.ProjectId, pr.ProjectCode, pr.ProjectName,
        s.ShedCode, s.ShedName, s.Capacity, s.CapacityUnit, s.ShedType, s.Status, s.IsActive,
        s.CreatedBy, s.CreatedDate, s.ModifiedBy, s.ModifiedDate
    FROM PoultrySheds s
    INNER JOIN Projects pr ON s.ProjectId = pr.ProjectId
    WHERE (@ProjectId IS NULL OR s.ProjectId = @ProjectId)
    AND (@SearchText IS NULL OR s.ShedCode LIKE '%' + @SearchText + '%' OR s.ShedName LIKE '%' + @SearchText + '%')
    AND dbo.fn_CanAccessProject(@UserId, s.ProjectId) = 1
    ORDER BY
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'shedcode' THEN s.ShedCode END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'shedcode' THEN s.ShedCode END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'shedname' THEN s.ShedName END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'shedname' THEN s.ShedName END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'capacity' THEN s.Capacity END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'capacity' THEN s.Capacity END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'status' THEN s.Status END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'status' THEN s.Status END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'createddate' THEN s.CreatedDate END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'createddate' THEN s.CreatedDate END DESC,
        s.ShedCode ASC
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

-- =============================================
-- usp_PoultryBatch_GetPaged + @UserId
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultryBatch_GetPaged')
    DROP PROCEDURE usp_PoultryBatch_GetPaged;
GO

CREATE PROCEDURE usp_PoultryBatch_GetPaged
    @ProjectId INT = NULL,
    @UserId INT = NULL,
    @ShedId INT = NULL,
    @SearchText NVARCHAR(100) = NULL,
    @Status NVARCHAR(20) = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @SortBy NVARCHAR(50) = 'startDate',
    @SortDir NVARCHAR(4) = 'desc',
    @TotalRecords INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@PageNumber IS NULL OR @PageNumber < 1) SET @PageNumber = 1;
    IF (@PageSize IS NULL OR @PageSize < 1) SET @PageSize = 10;
    IF (@PageSize > 100) SET @PageSize = 100;
    SET @SortBy = LOWER(LTRIM(RTRIM(ISNULL(@SortBy, 'startdate'))));
    IF (@SortBy NOT IN ('batchid', 'batchcode', 'startdate', 'initialquantity', 'status'))
        SET @SortBy = 'startdate';
    SET @SortDir = LOWER(LTRIM(RTRIM(ISNULL(@SortDir, 'desc'))));
    IF (@SortDir NOT IN ('asc', 'desc')) SET @SortDir = 'desc';
    IF (LTRIM(RTRIM(ISNULL(@SearchText, ''))) = '') SET @SearchText = NULL;
    IF (LTRIM(RTRIM(ISNULL(@Status, ''))) = '') SET @Status = NULL;

    SELECT @TotalRecords = COUNT(*)
    FROM PoultryBatches b
    WHERE (@ProjectId IS NULL OR b.ProjectId = @ProjectId)
    AND (@ShedId IS NULL OR b.ShedId = @ShedId)
    AND (@Status IS NULL OR b.Status = @Status)
    AND (@SearchText IS NULL OR b.BatchCode LIKE '%' + @SearchText + '%')
    AND dbo.fn_CanAccessProject(@UserId, b.ProjectId) = 1;

    SELECT b.BatchId, b.ProjectId, pr.ProjectCode, pr.ProjectName,
        b.ShedId, s.ShedCode, s.ShedName,
        b.BatchCode, b.BirdType, b.StartDate, b.ExpectedSaleDate,
        b.InitialQuantity, b.PurchaseCost, b.Status, b.Remarks,
        b.CreatedBy, b.CreatedDate, b.ModifiedBy, b.ModifiedDate
    FROM PoultryBatches b
    INNER JOIN Projects pr ON b.ProjectId = pr.ProjectId
    INNER JOIN PoultrySheds s ON b.ShedId = s.ShedId
    WHERE (@ProjectId IS NULL OR b.ProjectId = @ProjectId)
    AND (@ShedId IS NULL OR b.ShedId = @ShedId)
    AND (@Status IS NULL OR b.Status = @Status)
    AND (@SearchText IS NULL OR b.BatchCode LIKE '%' + @SearchText + '%')
    AND dbo.fn_CanAccessProject(@UserId, b.ProjectId) = 1
    ORDER BY
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'startdate' THEN b.StartDate END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'startdate' THEN b.StartDate END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'batchcode' THEN b.BatchCode END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'batchcode' THEN b.BatchCode END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'initialquantity' THEN b.InitialQuantity END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'initialquantity' THEN b.InitialQuantity END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'status' THEN b.Status END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'status' THEN b.Status END DESC,
        b.StartDate DESC, b.BatchId DESC
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

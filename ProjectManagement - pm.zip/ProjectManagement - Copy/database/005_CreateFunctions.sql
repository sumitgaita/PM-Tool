USE ProjectManagementDB;
GO

-- =============================================
-- Function: fn_GetBudgetUtilization
-- =============================================
IF EXISTS (SELECT * FROM sys.objects WHERE name = 'fn_GetBudgetUtilization' AND type = 'FN')
    DROP FUNCTION fn_GetBudgetUtilization;
GO

CREATE FUNCTION fn_GetBudgetUtilization
(
    @BudgetAmount DECIMAL(18,2),
    @ActualCost DECIMAL(18,2)
)
RETURNS DECIMAL(18,2)
AS
BEGIN
    DECLARE @Utilization DECIMAL(18,2);

    IF @BudgetAmount = 0 OR @BudgetAmount IS NULL
        SET @Utilization = 0;
    ELSE
        SET @Utilization = (@ActualCost / @BudgetAmount) * 100;

    RETURN @Utilization;
END
GO

-- =============================================
-- Function: fn_GetRemainingBudget
-- =============================================
IF EXISTS (SELECT * FROM sys.objects WHERE name = 'fn_GetRemainingBudget' AND type = 'FN')
    DROP FUNCTION fn_GetRemainingBudget;
GO

CREATE FUNCTION fn_GetRemainingBudget
(
    @BudgetAmount DECIMAL(18,2),
    @ActualCost DECIMAL(18,2)
)
RETURNS DECIMAL(18,2)
AS
BEGIN
    DECLARE @Remaining DECIMAL(18,2);

    SET @Remaining = ISNULL(@BudgetAmount, 0) - ISNULL(@ActualCost, 0);

    RETURN @Remaining;
END
GO

-- =============================================
-- Function: fn_FormatIndianCurrency
-- =============================================
IF EXISTS (SELECT * FROM sys.objects WHERE name = 'fn_FormatIndianCurrency' AND type = 'FN')
    DROP FUNCTION fn_FormatIndianCurrency;
GO

CREATE FUNCTION fn_FormatIndianCurrency
(
    @Amount DECIMAL(18,2)
)
RETURNS NVARCHAR(50)
AS
BEGIN
    DECLARE @Formatted NVARCHAR(50);
    DECLARE @AmountStr NVARCHAR(50);
    DECLARE @DecimalPart NVARCHAR(10);
    DECLARE @IntegerPart NVARCHAR(50);
    DECLARE @Len INT;
    DECLARE @Result NVARCHAR(50);
    DECLARE @i INT;
    DECLARE @Count INT;

    SET @AmountStr = CAST(ROUND(@Amount, 2) AS NVARCHAR(50));

    IF CHARINDEX('.', @AmountStr) > 0
    BEGIN
        SET @DecimalPart = SUBSTRING(@AmountStr, CHARINDEX('.', @AmountStr), LEN(@AmountStr));
        SET @IntegerPart = SUBSTRING(@AmountStr, 1, CHARINDEX('.', @AmountStr) - 1);
    END
    ELSE
    BEGIN
        SET @DecimalPart = '.00';
        SET @IntegerPart = @AmountStr;
    END

    SET @Len = LEN(@IntegerPart);
    SET @Result = '';
    SET @Count = 0;

    IF @Len <= 3
    BEGIN
        SET @Result = @IntegerPart;
    END
    ELSE
    BEGIN
        SET @Result = RIGHT(@IntegerPart, 3);
        SET @IntegerPart = LEFT(@IntegerPart, @Len - 3);
        SET @Len = LEN(@IntegerPart);

        WHILE @Len > 0
        BEGIN
            IF @Len >= 2
            BEGIN
                SET @Result = RIGHT(@IntegerPart, 2) + ',' + @Result;
                SET @IntegerPart = LEFT(@IntegerPart, @Len - 2);
                SET @Len = LEN(@IntegerPart);
            END
            ELSE
            BEGIN
                SET @Result = @IntegerPart + ',' + @Result;
                SET @Len = 0;
            END
        END
    END

    SET @Result = '₹' + @Result + @DecimalPart;

    RETURN @Result;
END
GO

-- =============================================
-- Function: fn_GetUserPermissions
-- =============================================
IF EXISTS (SELECT * FROM sys.objects WHERE name = 'fn_GetUserPermissions' AND type = 'IF')
    DROP FUNCTION fn_GetUserPermissions;
GO

CREATE FUNCTION fn_GetUserPermissions
(
    @UserId INT
)
RETURNS TABLE
AS
RETURN
(
    SELECT
        p.PageId,
        p.PageName,
        ISNULL(up.CanView, 0) AS CanView,
        ISNULL(up.CanEdit, 0) AS CanEdit,
        ISNULL(up.CanDelete, 0) AS CanDelete,
        ISNULL(up.CanExport, 0) AS CanExport
    FROM Pages p
    LEFT JOIN UserPermissions up ON p.PageId = up.PageId AND up.UserId = @UserId
    WHERE EXISTS (
        SELECT 1 FROM Users u
        INNER JOIN Roles r ON u.RoleId = r.RoleId
        WHERE u.UserId = @UserId AND r.RoleName IN ('Admin', 'Super Admin')
    )
    OR EXISTS (
        SELECT 1 FROM UserPermissions up2
        WHERE up2.UserId = @UserId AND up2.PageId = p.PageId
    )
);
GO

USE ProjectManagementDB;
GO

-- =============================================
-- Stored Procedure: usp_User_GetPaged
-- Server-side pagination + search for Users grid.
-- @SearchText matches Username OR FullName OR Email OR MobileNumber.
-- @RoleName filters exact role; NULL/empty = all roles.
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_User_GetPaged')
    DROP PROCEDURE usp_User_GetPaged;
GO

CREATE PROCEDURE usp_User_GetPaged
    @SearchText NVARCHAR(100) = NULL,
    @RoleName NVARCHAR(50) = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @SortBy NVARCHAR(50) = 'fullName',
    @SortDir NVARCHAR(4) = 'asc',
    @TotalRecords INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@PageNumber IS NULL OR @PageNumber < 1) SET @PageNumber = 1;
    IF (@PageSize IS NULL OR @PageSize < 1) SET @PageSize = 10;
    IF (@PageSize > 100) SET @PageSize = 100;
    SET @SortBy = LOWER(LTRIM(RTRIM(ISNULL(@SortBy, 'fullname'))));
    IF (@SortBy NOT IN ('userid', 'username', 'fullname', 'email', 'mobilenumber', 'rolename', 'createddate'))
        SET @SortBy = 'fullname';
    SET @SortDir = LOWER(LTRIM(RTRIM(ISNULL(@SortDir, 'asc'))));
    IF (@SortDir NOT IN ('asc', 'desc'))
        SET @SortDir = 'asc';
    IF (LTRIM(RTRIM(ISNULL(@SearchText, ''))) = '') SET @SearchText = NULL;
    IF (LTRIM(RTRIM(ISNULL(@RoleName, ''))) = '') SET @RoleName = NULL;

    SELECT @TotalRecords = COUNT(*)
    FROM Users u
    INNER JOIN Roles r ON u.RoleId = r.RoleId
    WHERE (@SearchText IS NULL
        OR u.Username LIKE '%' + @SearchText + '%'
        OR u.FullName LIKE '%' + @SearchText + '%'
        OR u.Email LIKE '%' + @SearchText + '%'
        OR u.MobileNumber LIKE '%' + @SearchText + '%')
    AND (@RoleName IS NULL OR r.RoleName = @RoleName);

    SELECT
        u.UserId,
        u.Username,
        u.FullName,
        u.Email,
        u.MobileNumber,
        u.RoleId,
        r.RoleName,
        u.IsActive,
        u.CreatedDate,
        u.CreatedBy,
        u.ModifiedDate,
        u.ModifiedBy,
        u.PasswordHash,
        u.PasswordEnc
    FROM Users u
    INNER JOIN Roles r ON u.RoleId = r.RoleId
    WHERE (@SearchText IS NULL
        OR u.Username LIKE '%' + @SearchText + '%'
        OR u.FullName LIKE '%' + @SearchText + '%'
        OR u.Email LIKE '%' + @SearchText + '%'
        OR u.MobileNumber LIKE '%' + @SearchText + '%')
    AND (@RoleName IS NULL OR r.RoleName = @RoleName)
    ORDER BY
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'userid' THEN u.UserId END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'userid' THEN u.UserId END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'username' THEN u.Username END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'username' THEN u.Username END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'fullname' THEN u.FullName END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'fullname' THEN u.FullName END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'email' THEN u.Email END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'email' THEN u.Email END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'mobilenumber' THEN u.MobileNumber END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'mobilenumber' THEN u.MobileNumber END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'rolename' THEN r.RoleName END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'rolename' THEN r.RoleName END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'createddate' THEN u.CreatedDate END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'createddate' THEN u.CreatedDate END DESC,
        u.FullName ASC
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

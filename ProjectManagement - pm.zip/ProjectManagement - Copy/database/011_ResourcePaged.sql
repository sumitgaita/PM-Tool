USE ProjectManagementDB;
GO

-- =============================================
-- Stored Procedure: usp_Resource_GetPaged
-- Server-side pagination + search for Resources grid.
-- @SearchText matches ResourceName (case-insensitive).
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Resource_GetPaged')
    DROP PROCEDURE usp_Resource_GetPaged;
GO

CREATE PROCEDURE usp_Resource_GetPaged
    @SearchText NVARCHAR(100) = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @SortBy NVARCHAR(50) = 'resourceCode',
    @SortDir NVARCHAR(4) = 'asc',
    @TotalRecords INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@PageNumber IS NULL OR @PageNumber < 1) SET @PageNumber = 1;
    IF (@PageSize IS NULL OR @PageSize < 1) SET @PageSize = 10;
    IF (@PageSize > 100) SET @PageSize = 100;
    SET @SortBy = LOWER(LTRIM(RTRIM(ISNULL(@SortBy, 'resourcecode'))));
    IF (@SortBy NOT IN ('resourceid', 'resourcecode', 'resourcename', 'resourcetype', 'department', 'createddate'))
        SET @SortBy = 'resourcecode';
    SET @SortDir = LOWER(LTRIM(RTRIM(ISNULL(@SortDir, 'asc'))));
    IF (@SortDir NOT IN ('asc', 'desc'))
        SET @SortDir = 'asc';
    IF (LTRIM(RTRIM(ISNULL(@SearchText, ''))) = '') SET @SearchText = NULL;

    SELECT @TotalRecords = COUNT(*)
    FROM Resources r
    WHERE (@SearchText IS NULL OR r.ResourceName LIKE '%' + @SearchText + '%');

    SELECT
        r.ResourceId,
        r.ResourceCode,
        r.ResourceName,
        r.ResourceType,
        r.Email,
        r.Phone,
        r.Department,
        r.IsActive,
        r.CreatedBy,
        r.CreatedDate,
        r.ModifiedBy,
        r.ModifiedDate
    FROM Resources r
    WHERE (@SearchText IS NULL OR r.ResourceName LIKE '%' + @SearchText + '%')
    ORDER BY
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'resourceid' THEN r.ResourceId END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'resourceid' THEN r.ResourceId END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'resourcecode' THEN r.ResourceCode END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'resourcecode' THEN r.ResourceCode END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'resourcename' THEN r.ResourceName END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'resourcename' THEN r.ResourceName END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'resourcetype' THEN r.ResourceType END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'resourcetype' THEN r.ResourceType END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'department' THEN r.Department END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'department' THEN r.Department END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'createddate' THEN r.CreatedDate END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'createddate' THEN r.CreatedDate END DESC,
        r.ResourceCode ASC
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

USE ProjectManagementDB;
GO

-- =============================================
-- View: vw_ProjectBudgetSummary
-- =============================================
IF EXISTS (SELECT * FROM sys.views WHERE name = 'vw_ProjectBudgetSummary')
    DROP VIEW vw_ProjectBudgetSummary;
GO

CREATE VIEW vw_ProjectBudgetSummary AS
SELECT
    p.ProjectId,
    p.ProjectCode,
    p.ProjectName,
    p.IsActive AS ProjectIsActive,
    bc.BudgetCodeId,
    bc.BudgetCode,
    bc.BudgetCodeName,
    pb.BudgetAmount,
    pb.EffectiveFrom,
    pb.EffectiveTo,
    pb.IsActive AS BudgetIsActive
FROM Projects p
INNER JOIN ProjectBudgets pb ON p.ProjectId = pb.ProjectId
INNER JOIN BudgetCodes bc ON pb.BudgetCodeId = bc.BudgetCodeId
WHERE p.IsActive = 1 AND pb.IsActive = 1;
GO

-- =============================================
-- View: vw_ProjectExpenseSummary
-- =============================================
IF EXISTS (SELECT * FROM sys.views WHERE name = 'vw_ProjectExpenseSummary')
    DROP VIEW vw_ProjectExpenseSummary;
GO

CREATE VIEW vw_ProjectExpenseSummary AS
SELECT
    p.ProjectId,
    p.ProjectCode,
    p.ProjectName,
    SUM(e.Amount) AS TotalExpense,
    COUNT(e.ExpenseId) AS ExpenseCount
FROM Projects p
LEFT JOIN Expenses e ON p.ProjectId = e.ProjectId AND e.IsDeleted = 0
WHERE p.IsActive = 1
GROUP BY p.ProjectId, p.ProjectCode, p.ProjectName;
GO

-- =============================================
-- View: vw_CostVsBudget
-- =============================================
IF EXISTS (SELECT * FROM sys.views WHERE name = 'vw_CostVsBudget')
    DROP VIEW vw_CostVsBudget;
GO

CREATE VIEW vw_CostVsBudget AS
SELECT
    p.ProjectId,
    p.ProjectCode,
    p.ProjectName,
    bc.BudgetCodeId,
    bc.BudgetCode,
    bc.BudgetCodeName,
    ISNULL(pb.BudgetAmount, 0) AS BudgetAmount,
    ISNULL(e.ActualCost, 0) AS ActualCost,
    ISNULL(pb.BudgetAmount, 0) - ISNULL(e.ActualCost, 0) AS RemainingBudget,
    CASE
        WHEN ISNULL(pb.BudgetAmount, 0) = 0 THEN 0
        ELSE (ISNULL(e.ActualCost, 0) / pb.BudgetAmount) * 100
    END AS UtilizationPercent,
    CASE
        WHEN ISNULL(pb.BudgetAmount, 0) = 0 THEN 0
        ELSE ISNULL(pb.BudgetAmount, 0) - ISNULL(e.ActualCost, 0)
    END AS Variance
FROM Projects p
INNER JOIN ProjectBudgets pb ON p.ProjectId = pb.ProjectId AND pb.IsActive = 1
INNER JOIN BudgetCodes bc ON pb.BudgetCodeId = bc.BudgetCodeId
LEFT JOIN (
    SELECT ProjectId, BudgetCodeId, SUM(Amount) AS ActualCost
    FROM Expenses
    WHERE IsDeleted = 0
    GROUP BY ProjectId, BudgetCodeId
) e ON p.ProjectId = e.ProjectId AND bc.BudgetCodeId = e.BudgetCodeId
WHERE p.IsActive = 1;
GO

-- =============================================
-- View: vw_ExpenseDetails
-- =============================================
IF EXISTS (SELECT * FROM sys.views WHERE name = 'vw_ExpenseDetails')
    DROP VIEW vw_ExpenseDetails;
GO

CREATE VIEW vw_ExpenseDetails AS
SELECT
    e.ExpenseId,
    e.ExpenseDate,
    e.ProjectId,
    p.ProjectCode,
    p.ProjectName,
    e.BudgetCodeId,
    bc.BudgetCode,
    bc.BudgetCodeName,
    e.ResourceId,
    r.ResourceCode,
    r.ResourceName,
    r.ResourceType,
    e.Amount,
    e.Description,
    e.ReferenceNo,
    e.Remarks,
    e.CreatedBy,
    u.FullName AS CreatedByName,
    e.CreatedDate,
    e.ModifiedBy,
    e.ModifiedDate
FROM Expenses e
INNER JOIN Projects p ON e.ProjectId = p.ProjectId
INNER JOIN BudgetCodes bc ON e.BudgetCodeId = bc.BudgetCodeId
INNER JOIN Resources r ON e.ResourceId = r.ResourceId
LEFT JOIN Users u ON e.CreatedBy = u.UserId
WHERE e.IsDeleted = 0;
GO

-- =============================================
-- View: vw_MonthlyExpenseSummary
-- =============================================
IF EXISTS (SELECT * FROM sys.views WHERE name = 'vw_MonthlyExpenseSummary')
    DROP VIEW vw_MonthlyExpenseSummary;
GO

CREATE VIEW vw_MonthlyExpenseSummary AS
SELECT
    YEAR(ExpenseDate) AS ExpenseYear,
    MONTH(ExpenseDate) AS ExpenseMonth,
    DATENAME(MONTH, ExpenseDate) AS MonthName,
    SUM(Amount) AS TotalExpense,
    COUNT(ExpenseId) AS ExpenseCount
FROM Expenses
WHERE IsDeleted = 0
GROUP BY YEAR(ExpenseDate), MONTH(ExpenseDate), DATENAME(MONTH, ExpenseDate);
GO

-- =============================================
-- View: vw_BudgetCodeExpenseSummary
-- =============================================
IF EXISTS (SELECT * FROM sys.views WHERE name = 'vw_BudgetCodeExpenseSummary')
    DROP VIEW vw_BudgetCodeExpenseSummary;
GO

CREATE VIEW vw_BudgetCodeExpenseSummary AS
SELECT
    bc.BudgetCodeId,
    bc.BudgetCode,
    bc.BudgetCodeName,
    SUM(e.Amount) AS TotalExpense,
    COUNT(e.ExpenseId) AS ExpenseCount
FROM BudgetCodes bc
LEFT JOIN Expenses e ON bc.BudgetCodeId = e.BudgetCodeId AND e.IsDeleted = 0
WHERE bc.IsActive = 1
GROUP BY bc.BudgetCodeId, bc.BudgetCode, bc.BudgetCodeName;
GO

-- =============================================
-- View: vw_ResourceExpenseSummary
-- =============================================
IF EXISTS (SELECT * FROM sys.views WHERE name = 'vw_ResourceExpenseSummary')
    DROP VIEW vw_ResourceExpenseSummary;
GO

CREATE VIEW vw_ResourceExpenseSummary AS
SELECT
    r.ResourceId,
    r.ResourceCode,
    r.ResourceName,
    r.ResourceType,
    SUM(e.Amount) AS TotalExpense,
    COUNT(e.ExpenseId) AS ExpenseCount
FROM Resources r
LEFT JOIN Expenses e ON r.ResourceId = e.ResourceId AND e.IsDeleted = 0
WHERE r.IsActive = 1
GROUP BY r.ResourceId, r.ResourceCode, r.ResourceName, r.ResourceType;
GO

-- =============================================
-- View: vw_YearlyExpenseSummary
-- =============================================
IF EXISTS (SELECT * FROM sys.views WHERE name = 'vw_YearlyExpenseSummary')
    DROP VIEW vw_YearlyExpenseSummary;
GO

CREATE VIEW vw_YearlyExpenseSummary AS
SELECT
    YEAR(ExpenseDate) AS ExpenseYear,
    SUM(Amount) AS TotalExpense,
    COUNT(ExpenseId) AS ExpenseCount
FROM Expenses
WHERE IsDeleted = 0
GROUP BY YEAR(ExpenseDate);
GO

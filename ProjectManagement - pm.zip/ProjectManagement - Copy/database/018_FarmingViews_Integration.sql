USE ProjectManagementDB;
GO

-- =============================================
-- §105 Farming views + project/expense integration updates.
-- Project procs recreated with FarmType; expense procs extended
-- with optional FarmType/FarmEntityType/FarmEntityId (additive,
-- existing callers unaffected) and GETs return the new columns.
-- =============================================

-- ---------- usp_Project_GetAll (+FarmType) ----------
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Project_GetAll')
    DROP PROCEDURE usp_Project_GetAll;
GO

CREATE PROCEDURE usp_Project_GetAll
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        p.ProjectId, p.ProjectCode, p.ProjectName, p.Description, p.ClientName,
        p.StartDate, p.EndDate, p.TotalBudget, p.Status, p.FarmType, p.IsActive,
        p.CreatedBy, p.CreatedDate, p.ModifiedBy, p.ModifiedDate
    FROM Projects p
    ORDER BY p.ProjectCode;
END
GO

-- ---------- usp_Project_GetById (+FarmType) ----------
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Project_GetById')
    DROP PROCEDURE usp_Project_GetById;
GO

CREATE PROCEDURE usp_Project_GetById
    @ProjectId INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        p.ProjectId, p.ProjectCode, p.ProjectName, p.Description, p.ClientName,
        p.StartDate, p.EndDate, p.TotalBudget, p.Status, p.FarmType, p.IsActive,
        p.CreatedBy, p.CreatedDate, p.ModifiedBy, p.ModifiedDate
    FROM Projects p
    WHERE p.ProjectId = @ProjectId;
END
GO

-- ---------- usp_Project_GetPaged (+FarmType filter) ----------
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Project_GetPaged')
    DROP PROCEDURE usp_Project_GetPaged;
GO

CREATE PROCEDURE usp_Project_GetPaged
    @SearchText NVARCHAR(100) = NULL,
    @Status NVARCHAR(20) = NULL,
    @FarmType NVARCHAR(50) = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @SortBy NVARCHAR(50) = 'projectCode',
    @SortDir NVARCHAR(4) = 'asc',
    @TotalRecords INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@PageNumber IS NULL OR @PageNumber < 1) SET @PageNumber = 1;
    IF (@PageSize IS NULL OR @PageSize < 1) SET @PageSize = 10;
    IF (@PageSize > 100) SET @PageSize = 100;
    SET @SortBy = LOWER(LTRIM(RTRIM(ISNULL(@SortBy, 'projectcode'))));
    IF (@SortBy NOT IN ('projectid', 'projectcode', 'projectname', 'clientname', 'status', 'totalbudget', 'createddate'))
        SET @SortBy = 'projectcode';
    SET @SortDir = LOWER(LTRIM(RTRIM(ISNULL(@SortDir, 'asc'))));
    IF (@SortDir NOT IN ('asc', 'desc')) SET @SortDir = 'asc';
    IF (LTRIM(RTRIM(ISNULL(@SearchText, ''))) = '') SET @SearchText = NULL;
    IF (LTRIM(RTRIM(ISNULL(@Status, ''))) = '') SET @Status = NULL;
    IF (LTRIM(RTRIM(ISNULL(@FarmType, ''))) = '') SET @FarmType = NULL;

    SELECT @TotalRecords = COUNT(*)
    FROM Projects p
    WHERE (@SearchText IS NULL OR p.ProjectCode LIKE '%' + @SearchText + '%' OR p.ProjectName LIKE '%' + @SearchText + '%')
    AND (@Status IS NULL OR p.Status = @Status)
    AND (@FarmType IS NULL OR p.FarmType = @FarmType);

    SELECT
        p.ProjectId, p.ProjectCode, p.ProjectName, p.Description, p.ClientName,
        p.StartDate, p.EndDate, p.TotalBudget, p.Status, p.FarmType, p.IsActive,
        p.CreatedBy, p.CreatedDate, p.ModifiedBy, p.ModifiedDate
    FROM Projects p
    WHERE (@SearchText IS NULL OR p.ProjectCode LIKE '%' + @SearchText + '%' OR p.ProjectName LIKE '%' + @SearchText + '%')
    AND (@Status IS NULL OR p.Status = @Status)
    AND (@FarmType IS NULL OR p.FarmType = @FarmType)
    ORDER BY
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'projectid' THEN p.ProjectId END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'projectid' THEN p.ProjectId END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'projectcode' THEN p.ProjectCode END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'projectcode' THEN p.ProjectCode END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'projectname' THEN p.ProjectName END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'projectname' THEN p.ProjectName END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'clientname' THEN p.ClientName END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'clientname' THEN p.ClientName END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'status' THEN p.Status END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'status' THEN p.Status END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'totalbudget' THEN p.TotalBudget END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'totalbudget' THEN p.TotalBudget END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'createddate' THEN p.CreatedDate END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'createddate' THEN p.CreatedDate END DESC,
        p.ProjectCode ASC
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

-- ---------- usp_Project_Insert (+FarmType) ----------
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Project_Insert')
    DROP PROCEDURE usp_Project_Insert;
GO

CREATE PROCEDURE usp_Project_Insert
    @ProjectCode NVARCHAR(20),
    @ProjectName NVARCHAR(200),
    @Description NVARCHAR(500),
    @ClientName NVARCHAR(200),
    @StartDate DATE,
    @EndDate DATE,
    @TotalBudget DECIMAL(18,2),
    @Status NVARCHAR(20),
    @FarmType NVARCHAR(50) = NULL,
    @CreatedBy INT,
    @ProjectId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO Projects (ProjectCode, ProjectName, Description, ClientName, StartDate, EndDate, TotalBudget, Status, FarmType, IsActive, CreatedBy, CreatedDate)
    VALUES (@ProjectCode, @ProjectName, @Description, @ClientName, @StartDate, @EndDate, @TotalBudget, @Status, @FarmType, 1, @CreatedBy, GETDATE());

    SET @ProjectId = SCOPE_IDENTITY();
END
GO

-- ---------- usp_Project_Update (+FarmType) ----------
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Project_Update')
    DROP PROCEDURE usp_Project_Update;
GO

CREATE PROCEDURE usp_Project_Update
    @ProjectId INT,
    @ProjectName NVARCHAR(200),
    @Description NVARCHAR(500),
    @ClientName NVARCHAR(200),
    @StartDate DATE,
    @EndDate DATE,
    @TotalBudget DECIMAL(18,2),
    @Status NVARCHAR(20),
    @FarmType NVARCHAR(50) = NULL,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE Projects
    SET ProjectName = @ProjectName,
        Description = @Description,
        ClientName = @ClientName,
        StartDate = @StartDate,
        EndDate = @EndDate,
        TotalBudget = @TotalBudget,
        Status = @Status,
        FarmType = @FarmType,
        ModifiedBy = @ModifiedBy,
        ModifiedDate = GETDATE()
    WHERE ProjectId = @ProjectId;
END
GO

-- ---------- usp_Expense_Insert (+farming reference, optional) ----------
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Expense_Insert')
    DROP PROCEDURE usp_Expense_Insert;
GO

CREATE PROCEDURE usp_Expense_Insert
    @ExpenseDate DATE,
    @ProjectId INT,
    @BudgetCodeId INT,
    @ResourceId INT,
    @Amount DECIMAL(18,2),
    @Description NVARCHAR(500),
    @ReferenceNo NVARCHAR(50),
    @Remarks NVARCHAR(500),
    @CreatedBy INT,
    @FarmType NVARCHAR(50) = NULL,
    @FarmEntityType NVARCHAR(30) = NULL,
    @FarmEntityId INT = NULL,
    @ExpenseId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO Expenses (ExpenseDate, ProjectId, BudgetCodeId, ResourceId, Amount, Description, ReferenceNo, Remarks, FarmType, FarmEntityType, FarmEntityId, IsDeleted, CreatedBy, CreatedDate)
    VALUES (@ExpenseDate, @ProjectId, @BudgetCodeId, @ResourceId, @Amount, @Description, @ReferenceNo, @Remarks, @FarmType, @FarmEntityType, @FarmEntityId, 0, @CreatedBy, GETDATE());

    SET @ExpenseId = SCOPE_IDENTITY();
END
GO

-- ---------- usp_Expense_Update (+farming reference, optional) ----------
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Expense_Update')
    DROP PROCEDURE usp_Expense_Update;
GO

CREATE PROCEDURE usp_Expense_Update
    @ExpenseId INT,
    @ExpenseDate DATE,
    @ProjectId INT,
    @BudgetCodeId INT,
    @ResourceId INT,
    @Amount DECIMAL(18,2),
    @Description NVARCHAR(500),
    @ReferenceNo NVARCHAR(50),
    @Remarks NVARCHAR(500),
    @ModifiedBy INT,
    @FarmType NVARCHAR(50) = NULL,
    @FarmEntityType NVARCHAR(30) = NULL,
    @FarmEntityId INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE Expenses
    SET ExpenseDate = @ExpenseDate,
        ProjectId = @ProjectId,
        BudgetCodeId = @BudgetCodeId,
        ResourceId = @ResourceId,
        Amount = @Amount,
        Description = @Description,
        ReferenceNo = @ReferenceNo,
        Remarks = @Remarks,
        FarmType = @FarmType,
        FarmEntityType = @FarmEntityType,
        FarmEntityId = @FarmEntityId,
        ModifiedBy = @ModifiedBy,
        ModifiedDate = GETDATE()
    WHERE ExpenseId = @ExpenseId;
END
GO

-- ---------- usp_Expense_GetById (+farming columns) ----------
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Expense_GetById')
    DROP PROCEDURE usp_Expense_GetById;
GO

CREATE PROCEDURE usp_Expense_GetById
    @ExpenseId INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        e.ExpenseId, e.ExpenseDate, e.ProjectId,
        p.ProjectCode, p.ProjectName,
        e.BudgetCodeId, bc.BudgetCode, bc.BudgetCodeName,
        e.ResourceId, r.ResourceCode, r.ResourceName,
        e.Amount, e.Description, e.ReferenceNo, e.Remarks,
        e.FarmType, e.FarmEntityType, e.FarmEntityId,
        e.IsDeleted, e.CreatedBy, e.CreatedDate, e.ModifiedBy, e.ModifiedDate
    FROM Expenses e
    INNER JOIN Projects p ON e.ProjectId = p.ProjectId
    INNER JOIN BudgetCodes bc ON e.BudgetCodeId = bc.BudgetCodeId
    INNER JOIN Resources r ON e.ResourceId = r.ResourceId
    WHERE e.ExpenseId = @ExpenseId;
END
GO

-- ---------- usp_Expense_GetByDate (+farming columns) ----------
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Expense_GetByDate')
    DROP PROCEDURE usp_Expense_GetByDate;
GO

CREATE PROCEDURE usp_Expense_GetByDate
    @ExpenseDate DATE
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        e.ExpenseId, e.ExpenseDate, e.ProjectId,
        p.ProjectCode, p.ProjectName,
        e.BudgetCodeId, bc.BudgetCode, bc.BudgetCodeName,
        e.ResourceId, r.ResourceCode, r.ResourceName,
        e.Amount, e.Description, e.ReferenceNo, e.Remarks,
        e.FarmType, e.FarmEntityType, e.FarmEntityId,
        e.CreatedBy, e.CreatedDate
    FROM Expenses e
    INNER JOIN Projects p ON e.ProjectId = p.ProjectId
    INNER JOIN BudgetCodes bc ON e.BudgetCodeId = bc.BudgetCodeId
    INNER JOIN Resources r ON e.ResourceId = r.ResourceId
    WHERE e.ExpenseDate = @ExpenseDate AND e.IsDeleted = 0;
END
GO

-- ---------- usp_Expense_GetByDateRange (+farming columns) ----------
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Expense_GetByDateRange')
    DROP PROCEDURE usp_Expense_GetByDateRange;
GO

CREATE PROCEDURE usp_Expense_GetByDateRange
    @FromDate DATE,
    @ToDate DATE,
    @ProjectId INT = NULL,
    @BudgetCodeId INT = NULL,
    @ResourceId INT = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @SortBy NVARCHAR(50) = 'expenseDate',
    @SortDir NVARCHAR(4) = 'desc',
    @TotalRecords INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@PageNumber IS NULL OR @PageNumber < 1) SET @PageNumber = 1;
    IF (@PageSize IS NULL OR @PageSize < 1) SET @PageSize = 10;
    IF (@PageSize > 100) SET @PageSize = 100;
    SET @SortBy = LOWER(LTRIM(RTRIM(ISNULL(@SortBy, 'expenseDate'))));
    IF (@SortBy NOT IN ('expenseid', 'expensedate', 'projectcode', 'projectname', 'budgetcode', 'budgetcodename', 'resourcename', 'amount', 'createddate'))
        SET @SortBy = 'expenseDate';
    SET @SortDir = LOWER(LTRIM(RTRIM(ISNULL(@SortDir, 'desc'))));
    IF (@SortDir NOT IN ('asc', 'desc'))
        SET @SortDir = 'desc';

    SELECT @TotalRecords = COUNT(*)
    FROM Expenses e
    WHERE e.ExpenseDate BETWEEN @FromDate AND @ToDate
    AND e.IsDeleted = 0
    AND (@ProjectId IS NULL OR e.ProjectId = @ProjectId)
    AND (@BudgetCodeId IS NULL OR e.BudgetCodeId = @BudgetCodeId)
    AND (@ResourceId IS NULL OR e.ResourceId = @ResourceId);

    SELECT
        e.ExpenseId, e.ExpenseDate, e.ProjectId,
        p.ProjectCode, p.ProjectName,
        e.BudgetCodeId, bc.BudgetCode, bc.BudgetCodeName,
        e.ResourceId, r.ResourceCode, r.ResourceName,
        e.Amount, e.Description, e.ReferenceNo, e.Remarks,
        e.FarmType, e.FarmEntityType, e.FarmEntityId,
        e.CreatedBy, e.CreatedDate
    FROM Expenses e
    INNER JOIN Projects p ON e.ProjectId = p.ProjectId
    INNER JOIN BudgetCodes bc ON e.BudgetCodeId = bc.BudgetCodeId
    INNER JOIN Resources r ON e.ResourceId = r.ResourceId
    WHERE e.ExpenseDate BETWEEN @FromDate AND @ToDate
    AND e.IsDeleted = 0
    AND (@ProjectId IS NULL OR e.ProjectId = @ProjectId)
    AND (@BudgetCodeId IS NULL OR e.BudgetCodeId = @BudgetCodeId)
    AND (@ResourceId IS NULL OR e.ResourceId = @ResourceId)
    ORDER BY
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'expenseid' THEN e.ExpenseId END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'expenseid' THEN e.ExpenseId END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'expensedate' THEN e.ExpenseDate END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'expensedate' THEN e.ExpenseDate END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'projectcode' THEN p.ProjectCode END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'projectcode' THEN p.ProjectCode END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'projectname' THEN p.ProjectName END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'projectname' THEN p.ProjectName END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'budgetcode' THEN bc.BudgetCode END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'budgetcode' THEN bc.BudgetCode END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'budgetcodename' THEN bc.BudgetCodeName END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'budgetcodename' THEN bc.BudgetCodeName END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'resourcename' THEN r.ResourceName END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'resourcename' THEN r.ResourceName END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'amount' THEN e.Amount END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'amount' THEN e.Amount END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'createddate' THEN e.CreatedDate END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'createddate' THEN e.CreatedDate END DESC,
        e.ExpenseDate DESC,
        e.CreatedDate DESC
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

-- =============================================
-- §105 Reporting views
-- =============================================

-- vw_FishCurrentStock: Stocked - Mortality - Harvest per pond + fish type.
IF OBJECT_ID('vw_FishCurrentStock', 'V') IS NOT NULL DROP VIEW vw_FishCurrentStock;
GO
CREATE VIEW vw_FishCurrentStock AS
SELECT p.ProjectId, s.PondId, s.FishTypeId,
    SUM(s.Quantity) AS StockedQuantity,
    ISNULL((SELECT SUM(Quantity) FROM FishMortality m WHERE m.PondId = s.PondId AND m.FishTypeId = s.FishTypeId), 0) AS MortalityQuantity,
    ISNULL((SELECT SUM(Quantity) FROM FishHarvest h WHERE h.PondId = s.PondId AND h.FishTypeId = s.FishTypeId), 0) AS HarvestQuantity,
    SUM(s.Quantity)
        - ISNULL((SELECT SUM(Quantity) FROM FishMortality m WHERE m.PondId = s.PondId AND m.FishTypeId = s.FishTypeId), 0)
        - ISNULL((SELECT SUM(Quantity) FROM FishHarvest h WHERE h.PondId = s.PondId AND h.FishTypeId = s.FishTypeId), 0) AS CurrentStock
FROM FishStocking s
INNER JOIN Ponds p ON s.PondId = p.PondId
GROUP BY p.ProjectId, s.PondId, s.FishTypeId;
GO

-- vw_FishPondSummary: per-pond operational + financial rollup.
IF OBJECT_ID('vw_FishPondSummary', 'V') IS NOT NULL DROP VIEW vw_FishPondSummary;
GO
CREATE VIEW vw_FishPondSummary AS
SELECT p.PondId, p.ProjectId, p.PondCode, p.PondName, p.Status, p.IsActive,
    ISNULL((SELECT SUM(Quantity) FROM FishStocking s WHERE s.PondId = p.PondId), 0) AS StockedQuantity,
    ISNULL((SELECT SUM(Quantity) FROM FishMortality m WHERE m.PondId = p.PondId), 0) AS MortalityQuantity,
    ISNULL((SELECT SUM(Quantity) FROM FishHarvest h WHERE h.PondId = p.PondId), 0) AS HarvestQuantity,
    ISNULL((SELECT SUM(TotalWeight) FROM FishHarvest h WHERE h.PondId = p.PondId), 0) AS HarvestWeight,
    ISNULL((SELECT SUM(TotalCost) FROM FishStocking s WHERE s.PondId = p.PondId), 0)
    + ISNULL((SELECT SUM(TotalCost) FROM FishFeed f WHERE f.PondId = p.PondId), 0)
    + ISNULL((SELECT SUM(Cost) FROM FishTreatment t WHERE t.PondId = p.PondId), 0)
    + ISNULL((SELECT SUM(HarvestCost) FROM FishHarvest h WHERE h.PondId = p.PondId), 0) AS OperationalCost,
    ISNULL((SELECT SUM(Amount) FROM Expenses e WHERE e.FarmEntityType = 'Pond' AND e.FarmEntityId = p.PondId AND e.IsDeleted = 0), 0) AS LinkedExpense
FROM Ponds p;
GO

-- vw_FishHarvestSummary
IF OBJECT_ID('vw_FishHarvestSummary', 'V') IS NOT NULL DROP VIEW vw_FishHarvestSummary;
GO
CREATE VIEW vw_FishHarvestSummary AS
SELECT h.PondId, h.FishTypeId,
    SUM(h.Quantity) AS HarvestQuantity,
    SUM(h.TotalWeight) AS HarvestWeight,
    SUM(h.HarvestCost) AS HarvestCost
FROM FishHarvest h
GROUP BY h.PondId, h.FishTypeId;
GO

-- vw_FishSalesSummary
IF OBJECT_ID('vw_FishSalesSummary', 'V') IS NOT NULL DROP VIEW vw_FishSalesSummary;
GO
CREATE VIEW vw_FishSalesSummary AS
SELECT s.ProjectId, s.FishTypeId,
    SUM(s.Quantity) AS SaleQuantity,
    SUM(s.TotalWeight) AS SaleWeight,
    SUM(s.TotalAmount) AS SaleAmount
FROM FishSales s
GROUP BY s.ProjectId, s.FishTypeId;
GO

-- vw_FishExpenseSummary: operational + linked expenses per project.
IF OBJECT_ID('vw_FishExpenseSummary', 'V') IS NOT NULL DROP VIEW vw_FishExpenseSummary;
GO
CREATE VIEW vw_FishExpenseSummary AS
SELECT pr.ProjectId,
    ISNULL((SELECT SUM(s.TotalCost) FROM FishStocking s INNER JOIN Ponds p ON s.PondId = p.PondId WHERE p.ProjectId = pr.ProjectId), 0)
    + ISNULL((SELECT SUM(f.TotalCost) FROM FishFeed f INNER JOIN Ponds p ON f.PondId = p.PondId WHERE p.ProjectId = pr.ProjectId), 0)
    + ISNULL((SELECT SUM(t.Cost) FROM FishTreatment t INNER JOIN Ponds p ON t.PondId = p.PondId WHERE p.ProjectId = pr.ProjectId), 0)
    + ISNULL((SELECT SUM(h.HarvestCost) FROM FishHarvest h INNER JOIN Ponds p ON h.PondId = p.PondId WHERE p.ProjectId = pr.ProjectId), 0) AS OperationalCost,
    ISNULL((SELECT SUM(e.Amount) FROM Expenses e WHERE e.ProjectId = pr.ProjectId AND e.FarmType = 'Fish Farming' AND e.IsDeleted = 0), 0) AS LinkedExpense
FROM Projects pr;
GO

-- vw_PoultryCurrentStock: Initial - Mortality - Sold per batch.
IF OBJECT_ID('vw_PoultryCurrentStock', 'V') IS NOT NULL DROP VIEW vw_PoultryCurrentStock;
GO
CREATE VIEW vw_PoultryCurrentStock AS
SELECT b.BatchId, b.ProjectId, b.ShedId, b.InitialQuantity,
    ISNULL((SELECT SUM(Quantity) FROM PoultryMortality m WHERE m.BatchId = b.BatchId), 0) AS MortalityQuantity,
    ISNULL((SELECT SUM(BirdQuantity) FROM PoultrySales s WHERE s.BatchId = b.BatchId), 0) AS SoldQuantity,
    b.InitialQuantity
        - ISNULL((SELECT SUM(Quantity) FROM PoultryMortality m WHERE m.BatchId = b.BatchId), 0)
        - ISNULL((SELECT SUM(BirdQuantity) FROM PoultrySales s WHERE s.BatchId = b.BatchId), 0) AS CurrentBirds
FROM PoultryBatches b;
GO

-- vw_PoultryBatchSummary
IF OBJECT_ID('vw_PoultryBatchSummary', 'V') IS NOT NULL DROP VIEW vw_PoultryBatchSummary;
GO
CREATE VIEW vw_PoultryBatchSummary AS
SELECT b.BatchId, b.ProjectId, b.ShedId, b.BatchCode, b.BirdType, b.Status,
    b.InitialQuantity,
    ISNULL((SELECT SUM(Quantity) FROM PoultryMortality m WHERE m.BatchId = b.BatchId), 0) AS MortalityQuantity,
    ISNULL((SELECT SUM(BirdQuantity) FROM PoultrySales s WHERE s.BatchId = b.BatchId), 0) AS SoldQuantity,
    b.InitialQuantity
        - ISNULL((SELECT SUM(Quantity) FROM PoultryMortality m WHERE m.BatchId = b.BatchId), 0)
        - ISNULL((SELECT SUM(BirdQuantity) FROM PoultrySales s WHERE s.BatchId = b.BatchId), 0) AS CurrentBirds,
    ISNULL((SELECT SUM(TotalCost) FROM PoultryFeed f WHERE f.BatchId = b.BatchId), 0)
    + ISNULL((SELECT SUM(Cost) FROM PoultryTreatment t WHERE t.BatchId = b.BatchId), 0)
    + ISNULL((SELECT SUM(TotalAmount) FROM ChickPurchase c WHERE c.BatchId = b.BatchId), 0) AS OperationalCost,
    ISNULL((SELECT SUM(TotalEggs) FROM EggProduction e WHERE e.BatchId = b.BatchId), 0) AS TotalEggs
FROM PoultryBatches b;
GO

-- vw_PoultryMortalitySummary
IF OBJECT_ID('vw_PoultryMortalitySummary', 'V') IS NOT NULL DROP VIEW vw_PoultryMortalitySummary;
GO
CREATE VIEW vw_PoultryMortalitySummary AS
SELECT m.BatchId,
    SUM(m.Quantity) AS MortalityQuantity,
    COUNT(*) AS MortalityEvents
FROM PoultryMortality m
GROUP BY m.BatchId;
GO

-- vw_PoultryFeedSummary
IF OBJECT_ID('vw_PoultryFeedSummary', 'V') IS NOT NULL DROP VIEW vw_PoultryFeedSummary;
GO
CREATE VIEW vw_PoultryFeedSummary AS
SELECT f.BatchId,
    SUM(f.Quantity) AS FeedQuantity,
    SUM(f.TotalCost) AS FeedCost
FROM PoultryFeed f
GROUP BY f.BatchId;
GO

-- vw_PoultryEggProductionSummary
IF OBJECT_ID('vw_PoultryEggProductionSummary', 'V') IS NOT NULL DROP VIEW vw_PoultryEggProductionSummary;
GO
CREATE VIEW vw_PoultryEggProductionSummary AS
SELECT e.BatchId,
    SUM(e.GoodEggs) AS GoodEggs,
    SUM(e.BrokenEggs) AS BrokenEggs,
    SUM(e.TotalEggs) AS TotalEggs,
    COUNT(*) AS ProductionDays
FROM EggProduction e
GROUP BY e.BatchId;
GO

-- vw_PoultrySalesSummary
IF OBJECT_ID('vw_PoultrySalesSummary', 'V') IS NOT NULL DROP VIEW vw_PoultrySalesSummary;
GO
CREATE VIEW vw_PoultrySalesSummary AS
SELECT s.ProjectId, s.BatchId,
    SUM(s.BirdQuantity) AS BirdQuantity,
    SUM(s.TotalWeight) AS SaleWeight,
    SUM(s.TotalAmount) AS SaleAmount
FROM PoultrySales s
GROUP BY s.ProjectId, s.BatchId;
GO

-- vw_FarmRevenueExpense: revenue vs expense per project (§95 input).
IF OBJECT_ID('vw_FarmRevenueExpense', 'V') IS NOT NULL DROP VIEW vw_FarmRevenueExpense;
GO
CREATE VIEW vw_FarmRevenueExpense AS
SELECT pr.ProjectId, pr.ProjectCode, pr.ProjectName, pr.FarmType,
    ISNULL((SELECT SUM(Amount) FROM Revenue r WHERE r.ProjectId = pr.ProjectId AND r.IsDeleted = 0), 0) AS TotalRevenue,
    ISNULL((SELECT SUM(Amount) FROM Expenses e WHERE e.ProjectId = pr.ProjectId AND e.IsDeleted = 0), 0) AS TotalExpense
FROM Projects pr;
GO

-- vw_FarmProfitability: Revenue - Expense = Gross Profit + Profit %.
IF OBJECT_ID('vw_FarmProfitability', 'V') IS NOT NULL DROP VIEW vw_FarmProfitability;
GO
CREATE VIEW vw_FarmProfitability AS
SELECT ProjectId, ProjectCode, ProjectName, FarmType, TotalRevenue, TotalExpense,
    (TotalRevenue - TotalExpense) AS GrossProfit,
    CASE WHEN TotalRevenue = 0 THEN 0
         ELSE ((TotalRevenue - TotalExpense) / TotalRevenue) * 100 END AS ProfitPercent
FROM vw_FarmRevenueExpense;
GO

-- vw_FarmCostVsBudget: budget vs actual (operational + linked expenses).
IF OBJECT_ID('vw_FarmCostVsBudget', 'V') IS NOT NULL DROP VIEW vw_FarmCostVsBudget;
GO
CREATE VIEW vw_FarmCostVsBudget AS
SELECT pr.ProjectId, pr.ProjectCode, pr.ProjectName, pr.FarmType,
    ISNULL((SELECT SUM(BudgetAmount) FROM ProjectBudgets b WHERE b.ProjectId = pr.ProjectId AND b.IsActive = 1), 0) AS TotalBudget,
    ISNULL((SELECT SUM(Amount) FROM Expenses e WHERE e.ProjectId = pr.ProjectId AND e.IsDeleted = 0), 0) AS ActualExpense
FROM Projects pr;
GO

USE ProjectManagementDB;
GO

-- =============================================
-- 027: Project Document page (Administration > Document section).
-- Idempotent page seed so it appears in Permissions management
-- and the RequirePermission("Project Document", ...) checks resolve.
-- Permission mapping: View = view/download, Edit = add/upload,
-- Delete = delete. Admin and Super Admin bypass via role claim.
-- =============================================
IF NOT EXISTS (SELECT 1 FROM Pages WHERE PageName = 'Project Document')
    INSERT INTO Pages (PageName, PageDescription)
    VALUES ('Project Document', 'Project-wise document management');
GO

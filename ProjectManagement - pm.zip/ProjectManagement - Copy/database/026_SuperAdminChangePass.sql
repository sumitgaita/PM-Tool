USE ProjectManagementDB;
GO

-- =============================================
-- 026: Super Admin password reset via security questions.
-- New table: SecurityQuestions (question text + SHA256 answer hash).
-- Answer normalization (must match backend): Trim + lowercase,
-- hashed with SHA256 hex lowercase (same as user password hashes).
-- Seed expression below is the SQL equivalent of the C# hash for
-- the configured answers. Answers are NEVER returned by any proc.
-- =============================================

-- =============================================
-- Table: SecurityQuestions
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'SecurityQuestions')
BEGIN
    CREATE TABLE SecurityQuestions (
        QuestionId INT IDENTITY(1,1) PRIMARY KEY,
        QuestionCode NVARCHAR(50) NOT NULL UNIQUE,
        QuestionText NVARCHAR(500) NOT NULL,
        AnswerHash NVARCHAR(500) NOT NULL,
        IsActive BIT NOT NULL DEFAULT 1,
        CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE(),
        ModifiedDate DATETIME2 NULL
    );
END
GO

-- =============================================
-- Seed: predefined Super Admin security questions.
-- Q1: What is the best name? / sumit
-- Q2: What is your location? / gaita
-- Idempotent: insert missing codes, refresh text/active flag only.
-- Answer hashes are written once and never overwritten here.
-- =============================================
IF NOT EXISTS (SELECT 1 FROM SecurityQuestions WHERE QuestionCode = 'BEST_NAME')
BEGIN
    INSERT INTO SecurityQuestions (QuestionCode, QuestionText, AnswerHash, IsActive)
    VALUES ('BEST_NAME', 'What is the best name?',
            LOWER(CONVERT(NVARCHAR(64), HASHBYTES('SHA2_256', LOWER(LTRIM(RTRIM('sumit')))), 2)), 1);
END
ELSE
BEGIN
    UPDATE SecurityQuestions
    SET QuestionText = 'What is the best name?', IsActive = 1, ModifiedDate = GETDATE()
    WHERE QuestionCode = 'BEST_NAME';
END
GO

IF NOT EXISTS (SELECT 1 FROM SecurityQuestions WHERE QuestionCode = 'LOCATION')
BEGIN
    INSERT INTO SecurityQuestions (QuestionCode, QuestionText, AnswerHash, IsActive)
    VALUES ('LOCATION', 'What is your location?',
            LOWER(CONVERT(NVARCHAR(64), HASHBYTES('SHA2_256', LOWER(LTRIM(RTRIM('gaita')))), 2)), 1);
END
ELSE
BEGIN
    UPDATE SecurityQuestions
    SET QuestionText = 'What is your location?', IsActive = 1, ModifiedDate = GETDATE()
    WHERE QuestionCode = 'LOCATION';
END
GO

-- =============================================
-- Stored Procedure: usp_SecurityQuestion_GetActive
-- Returns active questions WITHOUT answer hashes.
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_SecurityQuestion_GetActive')
    DROP PROCEDURE usp_SecurityQuestion_GetActive;
GO

CREATE PROCEDURE usp_SecurityQuestion_GetActive
AS
BEGIN
    SET NOCOUNT ON;

    SELECT QuestionId, QuestionCode, QuestionText
    FROM SecurityQuestions
    WHERE IsActive = 1
    ORDER BY QuestionId;
END
GO

-- =============================================
-- Stored Procedure: usp_SecurityQuestion_Validate
-- Validates caller-supplied (QuestionId, AnswerHash) pairs.
-- Returns single row: IsValid = 1 only if EVERY supplied pair
-- matches an active question. Never returns hashes.
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_SecurityQuestion_Validate')
    DROP PROCEDURE usp_SecurityQuestion_Validate;
GO

CREATE PROCEDURE usp_SecurityQuestion_Validate
    @QuestionId1 INT,
    @AnswerHash1 NVARCHAR(500),
    @QuestionId2 INT,
    @AnswerHash2 NVARCHAR(500)
AS
BEGIN
    SET NOCOUNT ON;

    SELECT CAST(CASE WHEN
        EXISTS (SELECT 1 FROM SecurityQuestions WHERE QuestionId = @QuestionId1 AND AnswerHash = @AnswerHash1 AND IsActive = 1)
        AND EXISTS (SELECT 1 FROM SecurityQuestions WHERE QuestionId = @QuestionId2 AND AnswerHash = @AnswerHash2 AND IsActive = 1)
        AND @QuestionId1 <> @QuestionId2
        THEN 1 ELSE 0 END AS BIT) AS IsValid;
END
GO

-- =============================================
-- Stored Procedure: usp_SuperAdmin_ResetPassword
-- Updates the password of the ONE active Super Admin account.
-- No username/user-id parameter: no other account can be touched.
-- Returns single row: Success + Message (never any hash).
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_SuperAdmin_ResetPassword')
    DROP PROCEDURE usp_SuperAdmin_ResetPassword;
GO

CREATE PROCEDURE usp_SuperAdmin_ResetPassword
    @NewPasswordHash NVARCHAR(500),
    @NewPasswordEnc NVARCHAR(1000) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @SuperAdminId INT = NULL;

    SELECT @SuperAdminId = u.UserId
    FROM Users u
    INNER JOIN Roles r ON r.RoleId = u.RoleId
    WHERE r.RoleName = 'Super Admin' AND u.IsActive = 1;

    IF @SuperAdminId IS NULL
    BEGIN
        SELECT CAST(0 AS BIT) AS Success, 'Super Admin account not found.' AS Message;
        RETURN;
    END

    IF (SELECT COUNT(*) FROM Users u
        INNER JOIN Roles r ON r.RoleId = u.RoleId
        WHERE r.RoleName = 'Super Admin' AND u.IsActive = 1) <> 1
    BEGIN
        SELECT CAST(0 AS BIT) AS Success, 'Super Admin account is ambiguous. Password not changed.' AS Message;
        RETURN;
    END

    UPDATE Users
    SET PasswordHash = @NewPasswordHash,
        PasswordEnc = @NewPasswordEnc,
        ModifiedBy = @SuperAdminId,
        ModifiedDate = GETDATE()
    WHERE UserId = @SuperAdminId;

    SELECT CAST(1 AS BIT) AS Success, 'Super Admin password updated successfully.' AS Message;
END
GO

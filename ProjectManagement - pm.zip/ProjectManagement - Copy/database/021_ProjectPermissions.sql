USE ProjectManagementDB;
GO

-- =============================================
-- 021: Project-level permissions (Super Admin managed)
-- New table: UserProjects (which projects an Admin/User may access).
-- Super Admin users bypass scoping implicitly (no rows required).
-- =============================================

-- =============================================
-- Table: UserProjects
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'UserProjects')
BEGIN
    CREATE TABLE UserProjects (
        UserProjectId INT IDENTITY(1,1) PRIMARY KEY,
        UserId INT NOT NULL,
        ProjectId INT NOT NULL,
        CreatedBy INT NULL,
        CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE(),
        CONSTRAINT FK_UserProjects_Users FOREIGN KEY (UserId) REFERENCES Users(UserId),
        CONSTRAINT FK_UserProjects_Projects FOREIGN KEY (ProjectId) REFERENCES Projects(ProjectId),
        CONSTRAINT FK_UserProjects_CreatedBy FOREIGN KEY (CreatedBy) REFERENCES Users(UserId),
        CONSTRAINT UQ_UserProjects_User_Project UNIQUE (UserId, ProjectId)
    );
END
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_UserProjects_UserId' AND object_id = OBJECT_ID('UserProjects'))
BEGIN
    CREATE INDEX IX_UserProjects_UserId ON UserProjects (UserId);
END
GO

-- =============================================
-- Stored Procedure: usp_UserProject_GetByUser
-- All projects with assignment flag for one user (management grid).
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_UserProject_GetByUser')
    DROP PROCEDURE usp_UserProject_GetByUser;
GO

CREATE PROCEDURE usp_UserProject_GetByUser
    @UserId INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        p.ProjectId,
        p.ProjectCode,
        p.ProjectName,
        p.Status,
        p.FarmType,
        p.IsActive,
        CAST(CASE WHEN up.UserProjectId IS NULL THEN 0 ELSE 1 END AS BIT) AS IsAssigned,
        up.CreatedDate AS AssignedDate
    FROM Projects p
    LEFT JOIN UserProjects up ON up.ProjectId = p.ProjectId AND up.UserId = @UserId
    WHERE p.IsActive = 1 AND p.Status = 'Active'
    ORDER BY p.ProjectCode;
END
GO

-- =============================================
-- Stored Procedure: usp_UserProject_GetAssignedIds
-- ProjectIds assigned to a user (enforcement helper).
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_UserProject_GetAssignedIds')
    DROP PROCEDURE usp_UserProject_GetAssignedIds;
GO

CREATE PROCEDURE usp_UserProject_GetAssignedIds
    @UserId INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT up.ProjectId
    FROM UserProjects up
    INNER JOIN Projects p ON p.ProjectId = up.ProjectId
    WHERE up.UserId = @UserId;
END
GO

-- =============================================
-- Stored Procedure: usp_UserProject_GetMyProjects
-- Assigned projects in ProjectDto shape (non-Super-Admin listing).
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_UserProject_GetMyProjects')
    DROP PROCEDURE usp_UserProject_GetMyProjects;
GO

CREATE PROCEDURE usp_UserProject_GetMyProjects
    @UserId INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        p.ProjectId,
        p.ProjectCode,
        p.ProjectName,
        p.Description,
        p.ClientName,
        p.StartDate,
        p.EndDate,
        p.TotalBudget,
        p.Status,
        p.FarmType,
        p.IsActive,
        p.CreatedBy,
        p.CreatedDate,
        p.ModifiedBy,
        p.ModifiedDate
    FROM Projects p
    INNER JOIN UserProjects up ON up.ProjectId = p.ProjectId AND up.UserId = @UserId
    ORDER BY p.ProjectCode;
END
GO

-- =============================================
-- Stored Procedure: usp_UserProject_Save
-- Grant (@IsAssigned=1) or revoke (@IsAssigned=0) one assignment.
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_UserProject_Save')
    DROP PROCEDURE usp_UserProject_Save;
GO

CREATE PROCEDURE usp_UserProject_Save
    @UserId INT,
    @ProjectId INT,
    @IsAssigned BIT,
    @CreatedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS (SELECT 1 FROM Users WHERE UserId = @UserId)
    BEGIN
        RAISERROR('User not found.', 16, 1);
        RETURN;
    END
    IF NOT EXISTS (SELECT 1 FROM Projects WHERE ProjectId = @ProjectId)
    BEGIN
        RAISERROR('Project not found.', 16, 1);
        RETURN;
    END

    IF (@IsAssigned = 1)
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM UserProjects WHERE UserId = @UserId AND ProjectId = @ProjectId)
        BEGIN
            INSERT INTO UserProjects (UserId, ProjectId, CreatedBy, CreatedDate)
            VALUES (@UserId, @ProjectId, @CreatedBy, GETDATE());
        END
    END
    ELSE
    BEGIN
        DELETE FROM UserProjects WHERE UserId = @UserId AND ProjectId = @ProjectId;
    END
END
GO

-- =============================================
-- Stored Procedure: usp_UserProject_Clear
-- Remove all assignments for a user (used by bulk replace).
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_UserProject_Clear')
    DROP PROCEDURE usp_UserProject_Clear;
GO

CREATE PROCEDURE usp_UserProject_Clear
    @UserId INT
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM UserProjects WHERE UserId = @UserId;
END
GO

-- =============================================
-- Stored Procedure: usp_Project_GetPagedAuthorized
-- Mirrors usp_Project_GetPaged + @FarmType, scoped to assigned
-- projects unless the caller is Super Admin (checked by role name).
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Project_GetPagedAuthorized')
    DROP PROCEDURE usp_Project_GetPagedAuthorized;
GO

CREATE PROCEDURE usp_Project_GetPagedAuthorized
    @UserId INT,
    @SearchText NVARCHAR(100) = NULL,
    @Status NVARCHAR(20) = NULL,
    @FarmType NVARCHAR(50) = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @SortBy NVARCHAR(50) = 'projectCode',
    @SortDir NVARCHAR(4) = 'asc',
    @TotalRecords INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@PageNumber IS NULL OR @PageNumber < 1) SET @PageNumber = 1;
    IF (@PageSize IS NULL OR @PageSize < 1) SET @PageSize = 10;
    IF (@PageSize > 100) SET @PageSize = 100;
    SET @SortBy = LOWER(LTRIM(RTRIM(ISNULL(@SortBy, 'projectcode'))));
    IF (@SortBy NOT IN ('projectid', 'projectcode', 'projectname', 'clientname', 'status', 'totalbudget', 'createddate'))
        SET @SortBy = 'projectcode';
    SET @SortDir = LOWER(LTRIM(RTRIM(ISNULL(@SortDir, 'asc'))));
    IF (@SortDir NOT IN ('asc', 'desc'))
        SET @SortDir = 'asc';
    IF (LTRIM(RTRIM(ISNULL(@SearchText, ''))) = '') SET @SearchText = NULL;
    IF (LTRIM(RTRIM(ISNULL(@Status, ''))) = '') SET @Status = NULL;
    IF (LTRIM(RTRIM(ISNULL(@FarmType, ''))) = '') SET @FarmType = NULL;

    DECLARE @IsSuperAdmin BIT = 0;
    IF EXISTS (
        SELECT 1
        FROM Users u
        INNER JOIN Roles r ON r.RoleId = u.RoleId
        WHERE u.UserId = @UserId AND r.RoleName = 'Super Admin'
    )
        SET @IsSuperAdmin = 1;

    SELECT @TotalRecords = COUNT(*)
    FROM Projects p
    WHERE (@SearchText IS NULL OR p.ProjectCode LIKE '%' + @SearchText + '%' OR p.ProjectName LIKE '%' + @SearchText + '%')
    AND (@Status IS NULL OR p.Status = @Status)
    AND (@FarmType IS NULL OR p.FarmType = @FarmType)
    AND (@IsSuperAdmin = 1 OR EXISTS (SELECT 1 FROM UserProjects up WHERE up.UserId = @UserId AND up.ProjectId = p.ProjectId));

    SELECT
        p.ProjectId,
        p.ProjectCode,
        p.ProjectName,
        p.Description,
        p.ClientName,
        p.StartDate,
        p.EndDate,
        p.TotalBudget,
        p.Status,
        p.FarmType,
        p.IsActive,
        p.CreatedBy,
        p.CreatedDate,
        p.ModifiedBy,
        p.ModifiedDate
    FROM Projects p
    WHERE (@SearchText IS NULL OR p.ProjectCode LIKE '%' + @SearchText + '%' OR p.ProjectName LIKE '%' + @SearchText + '%')
    AND (@Status IS NULL OR p.Status = @Status)
    AND (@FarmType IS NULL OR p.FarmType = @FarmType)
    AND (@IsSuperAdmin = 1 OR EXISTS (SELECT 1 FROM UserProjects up WHERE up.UserId = @UserId AND up.ProjectId = p.ProjectId))
    ORDER BY
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'projectid' THEN p.ProjectId END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'projectid' THEN p.ProjectId END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'projectcode' THEN p.ProjectCode END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'projectcode' THEN p.ProjectCode END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'projectname' THEN p.ProjectName END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'projectname' THEN p.ProjectName END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'clientname' THEN p.ClientName END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'clientname' THEN p.ClientName END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'status' THEN p.Status END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'status' THEN p.Status END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'totalbudget' THEN p.TotalBudget END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'totalbudget' THEN p.TotalBudget END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'createddate' THEN p.CreatedDate END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'createddate' THEN p.CreatedDate END DESC,
        p.ProjectCode ASC
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

-- =============================================
-- Seed: Project Permissions page (Super-Admin-only UI page)
-- =============================================
IF NOT EXISTS (SELECT 1 FROM Pages WHERE PageName = 'Project Permissions')
BEGIN
    INSERT INTO Pages (PageName, PageDescription)
    VALUES ('Project Permissions', 'Assign projects to Admin and Normal User accounts (Super Admin only).');
END
GO

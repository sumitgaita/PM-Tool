USE ProjectManagementDB;
GO

-- =============================================
-- §103 Fish Farming stored procedures.
-- Conventions match 006: DROP IF EXISTS + CREATE, SET NOCOUNT ON,
-- paging via OFFSET/FETCH with @TotalRecords OUTPUT, RAISERROR on
-- business-rule violations. Feed/stocking/treatment inserts can
-- optionally post a linked Expense row in the same statement
-- (@ExpProjectId/@ExpBudgetCodeId/@ExpResourceId); sales auto-post
-- Revenue rows transactionally (single write path, no double count).
-- =============================================

-- =============================================
-- usp_Pond_GetPaged
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Pond_GetPaged')
    DROP PROCEDURE usp_Pond_GetPaged;
GO

CREATE PROCEDURE usp_Pond_GetPaged
    @ProjectId INT = NULL,
    @SearchText NVARCHAR(100) = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @SortBy NVARCHAR(50) = 'pondCode',
    @SortDir NVARCHAR(4) = 'asc',
    @TotalRecords INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@PageNumber IS NULL OR @PageNumber < 1) SET @PageNumber = 1;
    IF (@PageSize IS NULL OR @PageSize < 1) SET @PageSize = 10;
    IF (@PageSize > 100) SET @PageSize = 100;
    SET @SortBy = LOWER(LTRIM(RTRIM(ISNULL(@SortBy, 'pondcode'))));
    IF (@SortBy NOT IN ('pondid', 'pondcode', 'pondname', 'area', 'status', 'createddate'))
        SET @SortBy = 'pondcode';
    SET @SortDir = LOWER(LTRIM(RTRIM(ISNULL(@SortDir, 'asc'))));
    IF (@SortDir NOT IN ('asc', 'desc')) SET @SortDir = 'asc';
    IF (LTRIM(RTRIM(ISNULL(@SearchText, ''))) = '') SET @SearchText = NULL;

    SELECT @TotalRecords = COUNT(*)
    FROM Ponds p
    WHERE (@ProjectId IS NULL OR p.ProjectId = @ProjectId)
    AND (@SearchText IS NULL OR p.PondCode LIKE '%' + @SearchText + '%' OR p.PondName LIKE '%' + @SearchText + '%');

    SELECT p.PondId, p.ProjectId, pr.ProjectCode, pr.ProjectName,
        p.PondCode, p.PondName, p.Area, p.AreaUnit, p.Depth, p.WaterCapacity,
        p.PondType, p.Status, p.IsActive,
        p.CreatedBy, p.CreatedDate, p.ModifiedBy, p.ModifiedDate
    FROM Ponds p
    INNER JOIN Projects pr ON p.ProjectId = pr.ProjectId
    WHERE (@ProjectId IS NULL OR p.ProjectId = @ProjectId)
    AND (@SearchText IS NULL OR p.PondCode LIKE '%' + @SearchText + '%' OR p.PondName LIKE '%' + @SearchText + '%')
    ORDER BY
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'pondcode' THEN p.PondCode END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'pondcode' THEN p.PondCode END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'pondname' THEN p.PondName END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'pondname' THEN p.PondName END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'area' THEN p.Area END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'area' THEN p.Area END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'status' THEN p.Status END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'status' THEN p.Status END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'createddate' THEN p.CreatedDate END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'createddate' THEN p.CreatedDate END DESC,
        p.PondCode ASC
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

-- =============================================
-- usp_Pond_GetById
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Pond_GetById')
    DROP PROCEDURE usp_Pond_GetById;
GO

CREATE PROCEDURE usp_Pond_GetById
    @PondId INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT p.PondId, p.ProjectId, pr.ProjectCode, pr.ProjectName,
        p.PondCode, p.PondName, p.Area, p.AreaUnit, p.Depth, p.WaterCapacity,
        p.PondType, p.Status, p.IsActive,
        p.CreatedBy, p.CreatedDate, p.ModifiedBy, p.ModifiedDate
    FROM Ponds p
    INNER JOIN Projects pr ON p.ProjectId = pr.ProjectId
    WHERE p.PondId = @PondId;
END
GO

-- =============================================
-- usp_Pond_Insert
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Pond_Insert')
    DROP PROCEDURE usp_Pond_Insert;
GO

CREATE PROCEDURE usp_Pond_Insert
    @ProjectId INT,
    @PondCode NVARCHAR(20),
    @PondName NVARCHAR(200),
    @Area DECIMAL(18,2) = NULL,
    @AreaUnit NVARCHAR(20) = NULL,
    @Depth NVARCHAR(50) = NULL,
    @WaterCapacity DECIMAL(18,2) = NULL,
    @PondType NVARCHAR(50) = NULL,
    @Status NVARCHAR(20) = 'Active',
    @CreatedBy INT,
    @PondId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (SELECT 1 FROM Ponds WHERE PondCode = @PondCode)
    BEGIN RAISERROR('Pond code already exists.', 16, 1); RETURN; END

    INSERT INTO Ponds (ProjectId, PondCode, PondName, Area, AreaUnit, Depth, WaterCapacity, PondType, Status, IsActive, CreatedBy, CreatedDate)
    VALUES (@ProjectId, @PondCode, @PondName, @Area, @AreaUnit, @Depth, @WaterCapacity, @PondType, ISNULL(@Status, 'Active'), 1, @CreatedBy, GETDATE());

    SET @PondId = SCOPE_IDENTITY();
END
GO

-- =============================================
-- usp_Pond_Update
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Pond_Update')
    DROP PROCEDURE usp_Pond_Update;
GO

CREATE PROCEDURE usp_Pond_Update
    @PondId INT,
    @PondCode NVARCHAR(20),
    @PondName NVARCHAR(200),
    @Area DECIMAL(18,2) = NULL,
    @AreaUnit NVARCHAR(20) = NULL,
    @Depth NVARCHAR(50) = NULL,
    @WaterCapacity DECIMAL(18,2) = NULL,
    @PondType NVARCHAR(50) = NULL,
    @Status NVARCHAR(20) = NULL,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (SELECT 1 FROM Ponds WHERE PondCode = @PondCode AND PondId <> @PondId)
    BEGIN RAISERROR('Pond code already exists.', 16, 1); RETURN; END

    UPDATE Ponds
    SET PondCode = @PondCode, PondName = @PondName, Area = @Area, AreaUnit = @AreaUnit,
        Depth = @Depth, WaterCapacity = @WaterCapacity, PondType = @PondType,
        Status = ISNULL(@Status, Status), ModifiedBy = @ModifiedBy, ModifiedDate = GETDATE()
    WHERE PondId = @PondId;
END
GO

-- =============================================
-- usp_Pond_Delete (blocked when operational rows exist)
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Pond_Delete')
    DROP PROCEDURE usp_Pond_Delete;
GO

CREATE PROCEDURE usp_Pond_Delete
    @PondId INT
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (SELECT 1 FROM FishStocking WHERE PondId = @PondId)
        OR EXISTS (SELECT 1 FROM FishFeed WHERE PondId = @PondId)
        OR EXISTS (SELECT 1 FROM FishTreatment WHERE PondId = @PondId)
        OR EXISTS (SELECT 1 FROM FishMortality WHERE PondId = @PondId)
        OR EXISTS (SELECT 1 FROM FishGrowth WHERE PondId = @PondId)
        OR EXISTS (SELECT 1 FROM FishHarvest WHERE PondId = @PondId)
    BEGIN RAISERROR('Pond has farming transactions and cannot be deleted. Deactivate it instead.', 16, 1); RETURN; END

    DELETE FROM Ponds WHERE PondId = @PondId;
END
GO

-- =============================================
-- usp_Pond_SetActive
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Pond_SetActive')
    DROP PROCEDURE usp_Pond_SetActive;
GO

CREATE PROCEDURE usp_Pond_SetActive
    @PondId INT,
    @IsActive BIT,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE Ponds
    SET IsActive = @IsActive, ModifiedBy = @ModifiedBy, ModifiedDate = GETDATE()
    WHERE PondId = @PondId;
END
GO

-- =============================================
-- FishTypes: GetAll / Insert / Update / Delete / SetActive
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FishType_GetAll')
    DROP PROCEDURE usp_FishType_GetAll;
GO

CREATE PROCEDURE usp_FishType_GetAll
AS
BEGIN
    SET NOCOUNT ON;

    SELECT FishTypeId, FishCode, FishName, ScientificName, Description, IsActive,
        CreatedBy, CreatedDate, ModifiedBy, ModifiedDate
    FROM FishTypes
    ORDER BY FishName;
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FishType_Insert')
    DROP PROCEDURE usp_FishType_Insert;
GO

CREATE PROCEDURE usp_FishType_Insert
    @FishCode NVARCHAR(20),
    @FishName NVARCHAR(100),
    @ScientificName NVARCHAR(200) = NULL,
    @Description NVARCHAR(500) = NULL,
    @CreatedBy INT,
    @FishTypeId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (SELECT 1 FROM FishTypes WHERE FishCode = @FishCode)
    BEGIN RAISERROR('Fish code already exists.', 16, 1); RETURN; END

    INSERT INTO FishTypes (FishCode, FishName, ScientificName, Description, IsActive, CreatedBy, CreatedDate)
    VALUES (@FishCode, @FishName, @ScientificName, @Description, 1, @CreatedBy, GETDATE());

    SET @FishTypeId = SCOPE_IDENTITY();
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FishType_Update')
    DROP PROCEDURE usp_FishType_Update;
GO

CREATE PROCEDURE usp_FishType_Update
    @FishTypeId INT,
    @FishCode NVARCHAR(20),
    @FishName NVARCHAR(100),
    @ScientificName NVARCHAR(200) = NULL,
    @Description NVARCHAR(500) = NULL,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (SELECT 1 FROM FishTypes WHERE FishCode = @FishCode AND FishTypeId <> @FishTypeId)
    BEGIN RAISERROR('Fish code already exists.', 16, 1); RETURN; END

    UPDATE FishTypes
    SET FishCode = @FishCode, FishName = @FishName, ScientificName = @ScientificName,
        Description = @Description, ModifiedBy = @ModifiedBy, ModifiedDate = GETDATE()
    WHERE FishTypeId = @FishTypeId;
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FishType_Delete')
    DROP PROCEDURE usp_FishType_Delete;
GO

CREATE PROCEDURE usp_FishType_Delete
    @FishTypeId INT
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (SELECT 1 FROM FishStocking WHERE FishTypeId = @FishTypeId)
        OR EXISTS (SELECT 1 FROM FishMortality WHERE FishTypeId = @FishTypeId)
        OR EXISTS (SELECT 1 FROM FishGrowth WHERE FishTypeId = @FishTypeId)
        OR EXISTS (SELECT 1 FROM FishHarvest WHERE FishTypeId = @FishTypeId)
        OR EXISTS (SELECT 1 FROM FishSales WHERE FishTypeId = @FishTypeId)
    BEGIN RAISERROR('Fish type is used in transactions and cannot be deleted. Deactivate it instead.', 16, 1); RETURN; END

    DELETE FROM FishTypes WHERE FishTypeId = @FishTypeId;
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FishType_SetActive')
    DROP PROCEDURE usp_FishType_SetActive;
GO

CREATE PROCEDURE usp_FishType_SetActive
    @FishTypeId INT,
    @IsActive BIT,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE FishTypes
    SET IsActive = @IsActive, ModifiedBy = @ModifiedBy, ModifiedDate = GETDATE()
    WHERE FishTypeId = @FishTypeId;
END
GO

-- =============================================
-- usp_FishStocking_GetPaged
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FishStocking_GetPaged')
    DROP PROCEDURE usp_FishStocking_GetPaged;
GO

CREATE PROCEDURE usp_FishStocking_GetPaged
    @ProjectId INT = NULL,
    @PondId INT = NULL,
    @FishTypeId INT = NULL,
    @SearchText NVARCHAR(100) = NULL,
    @FromDate DATE = NULL,
    @ToDate DATE = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @SortBy NVARCHAR(50) = 'stockingDate',
    @SortDir NVARCHAR(4) = 'desc',
    @TotalRecords INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@PageNumber IS NULL OR @PageNumber < 1) SET @PageNumber = 1;
    IF (@PageSize IS NULL OR @PageSize < 1) SET @PageSize = 10;
    IF (@PageSize > 100) SET @PageSize = 100;
    SET @SortBy = LOWER(LTRIM(RTRIM(ISNULL(@SortBy, 'stockingdate'))));
    IF (@SortBy NOT IN ('stockingid', 'stockingdate', 'pondcode', 'fishname', 'quantity', 'totalcost'))
        SET @SortBy = 'stockingdate';
    SET @SortDir = LOWER(LTRIM(RTRIM(ISNULL(@SortDir, 'desc'))));
    IF (@SortDir NOT IN ('asc', 'desc')) SET @SortDir = 'desc';
    IF (LTRIM(RTRIM(ISNULL(@SearchText, ''))) = '') SET @SearchText = NULL;

    SELECT @TotalRecords = COUNT(*)
    FROM FishStocking s
    INNER JOIN Ponds p ON s.PondId = p.PondId
    WHERE (@ProjectId IS NULL OR p.ProjectId = @ProjectId)
    AND (@PondId IS NULL OR s.PondId = @PondId)
    AND (@FishTypeId IS NULL OR s.FishTypeId = @FishTypeId)
    AND (@FromDate IS NULL OR s.StockingDate >= @FromDate)
    AND (@ToDate IS NULL OR s.StockingDate <= @ToDate)
    AND (@SearchText IS NULL OR s.Supplier LIKE '%' + @SearchText + '%' OR s.ReferenceNo LIKE '%' + @SearchText + '%');

    SELECT s.StockingId, s.PondId, p.PondCode, p.PondName, p.ProjectId,
        s.FishTypeId, f.FishCode, f.FishName,
        s.StockingDate, s.Quantity, s.AverageWeight, s.PurchaseRate, s.TotalCost,
        s.Supplier, s.ReferenceNo, s.Remarks,
        s.CreatedBy, s.CreatedDate, s.ModifiedBy, s.ModifiedDate
    FROM FishStocking s
    INNER JOIN Ponds p ON s.PondId = p.PondId
    INNER JOIN FishTypes f ON s.FishTypeId = f.FishTypeId
    WHERE (@ProjectId IS NULL OR p.ProjectId = @ProjectId)
    AND (@PondId IS NULL OR s.PondId = @PondId)
    AND (@FishTypeId IS NULL OR s.FishTypeId = @FishTypeId)
    AND (@FromDate IS NULL OR s.StockingDate >= @FromDate)
    AND (@ToDate IS NULL OR s.StockingDate <= @ToDate)
    AND (@SearchText IS NULL OR s.Supplier LIKE '%' + @SearchText + '%' OR s.ReferenceNo LIKE '%' + @SearchText + '%')
    ORDER BY
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'stockingdate' THEN s.StockingDate END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'stockingdate' THEN s.StockingDate END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'pondcode' THEN p.PondCode END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'pondcode' THEN p.PondCode END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'fishname' THEN f.FishName END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'fishname' THEN f.FishName END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'quantity' THEN s.Quantity END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'quantity' THEN s.Quantity END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'totalcost' THEN s.TotalCost END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'totalcost' THEN s.TotalCost END DESC,
        s.StockingDate DESC, s.StockingId DESC
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

-- =============================================
-- usp_FishStocking_Insert (optional linked expense via @Exp*)
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FishStocking_Insert')
    DROP PROCEDURE usp_FishStocking_Insert;
GO

CREATE PROCEDURE usp_FishStocking_Insert
    @PondId INT,
    @FishTypeId INT,
    @StockingDate DATE,
    @Quantity INT,
    @AverageWeight DECIMAL(18,2) = NULL,
    @PurchaseRate DECIMAL(18,2) = 0,
    @TotalCost DECIMAL(18,2) = NULL,
    @Supplier NVARCHAR(200) = NULL,
    @ReferenceNo NVARCHAR(50) = NULL,
    @Remarks NVARCHAR(500) = NULL,
    @CreatedBy INT,
    @ExpProjectId INT = NULL,
    @ExpBudgetCodeId INT = NULL,
    @ExpResourceId INT = NULL,
    @StockingId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@Quantity IS NULL OR @Quantity <= 0)
    BEGIN RAISERROR('Stocking quantity must be greater than zero.', 16, 1); RETURN; END
    IF NOT EXISTS (SELECT 1 FROM Ponds WHERE PondId = @PondId AND IsActive = 1)
    BEGIN RAISERROR('Pond must be active.', 16, 1); RETURN; END
    IF NOT EXISTS (SELECT 1 FROM FishTypes WHERE FishTypeId = @FishTypeId AND IsActive = 1)
    BEGIN RAISERROR('Fish type must be active.', 16, 1); RETURN; END
    IF (@TotalCost IS NULL) SET @TotalCost = CAST(@Quantity AS DECIMAL(18,2)) * ISNULL(@PurchaseRate, 0);
    IF (@TotalCost < 0)
    BEGIN RAISERROR('Cost must not be negative.', 16, 1); RETURN; END

    INSERT INTO FishStocking (PondId, FishTypeId, StockingDate, Quantity, AverageWeight, PurchaseRate, TotalCost, Supplier, ReferenceNo, Remarks, CreatedBy, CreatedDate)
    VALUES (@PondId, @FishTypeId, @StockingDate, @Quantity, @AverageWeight, ISNULL(@PurchaseRate, 0), @TotalCost, @Supplier, @ReferenceNo, @Remarks, @CreatedBy, GETDATE());

    SET @StockingId = SCOPE_IDENTITY();

    IF (@ExpProjectId IS NOT NULL AND @ExpBudgetCodeId IS NOT NULL AND @ExpResourceId IS NOT NULL AND @TotalCost > 0)
    BEGIN
        INSERT INTO Expenses (ExpenseDate, ProjectId, BudgetCodeId, ResourceId, Amount, Description, ReferenceNo, Remarks, FarmType, FarmEntityType, FarmEntityId, IsDeleted, CreatedBy, CreatedDate)
        VALUES (@StockingDate, @ExpProjectId, @ExpBudgetCodeId, @ExpResourceId, @TotalCost,
            'Fish stocking', @ReferenceNo, @Remarks, 'Fish Farming', 'Pond', @PondId, 0, @CreatedBy, GETDATE());
    END
END
GO

-- =============================================
-- usp_FishStocking_Update / Delete
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FishStocking_Update')
    DROP PROCEDURE usp_FishStocking_Update;
GO

CREATE PROCEDURE usp_FishStocking_Update
    @StockingId INT,
    @StockingDate DATE,
    @Quantity INT,
    @AverageWeight DECIMAL(18,2) = NULL,
    @PurchaseRate DECIMAL(18,2) = 0,
    @TotalCost DECIMAL(18,2) = NULL,
    @Supplier NVARCHAR(200) = NULL,
    @ReferenceNo NVARCHAR(50) = NULL,
    @Remarks NVARCHAR(500) = NULL,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@Quantity IS NULL OR @Quantity <= 0)
    BEGIN RAISERROR('Stocking quantity must be greater than zero.', 16, 1); RETURN; END
    IF (@TotalCost IS NULL) SET @TotalCost = CAST(@Quantity AS DECIMAL(18,2)) * ISNULL(@PurchaseRate, 0);
    IF (@TotalCost < 0)
    BEGIN RAISERROR('Cost must not be negative.', 16, 1); RETURN; END

    UPDATE FishStocking
    SET StockingDate = @StockingDate, Quantity = @Quantity, AverageWeight = @AverageWeight,
        PurchaseRate = ISNULL(@PurchaseRate, 0), TotalCost = @TotalCost,
        Supplier = @Supplier, ReferenceNo = @ReferenceNo, Remarks = @Remarks,
        ModifiedBy = @ModifiedBy, ModifiedDate = GETDATE()
    WHERE StockingId = @StockingId;
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FishStocking_Delete')
    DROP PROCEDURE usp_FishStocking_Delete;
GO

CREATE PROCEDURE usp_FishStocking_Delete
    @StockingId INT
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM FishStocking WHERE StockingId = @StockingId;
END
GO

-- =============================================
-- usp_FishFeed_GetPaged
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FishFeed_GetPaged')
    DROP PROCEDURE usp_FishFeed_GetPaged;
GO

CREATE PROCEDURE usp_FishFeed_GetPaged
    @ProjectId INT = NULL,
    @PondId INT = NULL,
    @SearchText NVARCHAR(100) = NULL,
    @FromDate DATE = NULL,
    @ToDate DATE = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @SortBy NVARCHAR(50) = 'feedDate',
    @SortDir NVARCHAR(4) = 'desc',
    @TotalRecords INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@PageNumber IS NULL OR @PageNumber < 1) SET @PageNumber = 1;
    IF (@PageSize IS NULL OR @PageSize < 1) SET @PageSize = 10;
    IF (@PageSize > 100) SET @PageSize = 100;
    SET @SortBy = LOWER(LTRIM(RTRIM(ISNULL(@SortBy, 'feeddate'))));
    IF (@SortBy NOT IN ('feedid', 'feeddate', 'pondcode', 'feedtype', 'quantity', 'totalcost'))
        SET @SortBy = 'feeddate';
    SET @SortDir = LOWER(LTRIM(RTRIM(ISNULL(@SortDir, 'desc'))));
    IF (@SortDir NOT IN ('asc', 'desc')) SET @SortDir = 'desc';
    IF (LTRIM(RTRIM(ISNULL(@SearchText, ''))) = '') SET @SearchText = NULL;

    SELECT @TotalRecords = COUNT(*)
    FROM FishFeed f
    INNER JOIN Ponds p ON f.PondId = p.PondId
    WHERE (@ProjectId IS NULL OR p.ProjectId = @ProjectId)
    AND (@PondId IS NULL OR f.PondId = @PondId)
    AND (@FromDate IS NULL OR f.FeedDate >= @FromDate)
    AND (@ToDate IS NULL OR f.FeedDate <= @ToDate)
    AND (@SearchText IS NULL OR f.FeedType LIKE '%' + @SearchText + '%');

    SELECT f.FishFeedId, f.PondId, p.PondCode, p.PondName, p.ProjectId,
        f.FeedDate, f.FeedType, f.Quantity, f.Unit, f.Rate, f.TotalCost, f.Remarks,
        f.CreatedBy, f.CreatedDate, f.ModifiedBy, f.ModifiedDate
    FROM FishFeed f
    INNER JOIN Ponds p ON f.PondId = p.PondId
    WHERE (@ProjectId IS NULL OR p.ProjectId = @ProjectId)
    AND (@PondId IS NULL OR f.PondId = @PondId)
    AND (@FromDate IS NULL OR f.FeedDate >= @FromDate)
    AND (@ToDate IS NULL OR f.FeedDate <= @ToDate)
    AND (@SearchText IS NULL OR f.FeedType LIKE '%' + @SearchText + '%')
    ORDER BY
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'feeddate' THEN f.FeedDate END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'feeddate' THEN f.FeedDate END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'pondcode' THEN p.PondCode END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'pondcode' THEN p.PondCode END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'feedtype' THEN f.FeedType END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'feedtype' THEN f.FeedType END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'quantity' THEN f.Quantity END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'quantity' THEN f.Quantity END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'totalcost' THEN f.TotalCost END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'totalcost' THEN f.TotalCost END DESC,
        f.FeedDate DESC, f.FishFeedId DESC
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

-- =============================================
-- usp_FishFeed_Insert / Update / Delete
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FishFeed_Insert')
    DROP PROCEDURE usp_FishFeed_Insert;
GO

CREATE PROCEDURE usp_FishFeed_Insert
    @PondId INT,
    @FeedDate DATE,
    @FeedType NVARCHAR(50),
    @Quantity DECIMAL(18,2),
    @Unit NVARCHAR(20) = NULL,
    @Rate DECIMAL(18,2) = 0,
    @TotalCost DECIMAL(18,2) = NULL,
    @Remarks NVARCHAR(500) = NULL,
    @CreatedBy INT,
    @ExpProjectId INT = NULL,
    @ExpBudgetCodeId INT = NULL,
    @ExpResourceId INT = NULL,
    @FishFeedId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@Quantity IS NULL OR @Quantity <= 0)
    BEGIN RAISERROR('Feed quantity must be greater than zero.', 16, 1); RETURN; END
    IF NOT EXISTS (SELECT 1 FROM Ponds WHERE PondId = @PondId AND IsActive = 1)
    BEGIN RAISERROR('Pond must be active.', 16, 1); RETURN; END
    IF (@TotalCost IS NULL) SET @TotalCost = @Quantity * ISNULL(@Rate, 0);
    IF (@TotalCost < 0)
    BEGIN RAISERROR('Cost must not be negative.', 16, 1); RETURN; END

    INSERT INTO FishFeed (PondId, FeedDate, FeedType, Quantity, Unit, Rate, TotalCost, Remarks, CreatedBy, CreatedDate)
    VALUES (@PondId, @FeedDate, @FeedType, @Quantity, @Unit, ISNULL(@Rate, 0), @TotalCost, @Remarks, @CreatedBy, GETDATE());

    SET @FishFeedId = SCOPE_IDENTITY();

    IF (@ExpProjectId IS NOT NULL AND @ExpBudgetCodeId IS NOT NULL AND @ExpResourceId IS NOT NULL AND @TotalCost > 0)
    BEGIN
        INSERT INTO Expenses (ExpenseDate, ProjectId, BudgetCodeId, ResourceId, Amount, Description, ReferenceNo, Remarks, FarmType, FarmEntityType, FarmEntityId, IsDeleted, CreatedBy, CreatedDate)
        VALUES (@FeedDate, @ExpProjectId, @ExpBudgetCodeId, @ExpResourceId, @TotalCost,
            'Fish feed (' + @FeedType + ')', NULL, @Remarks, 'Fish Farming', 'Pond', @PondId, 0, @CreatedBy, GETDATE());
    END
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FishFeed_Update')
    DROP PROCEDURE usp_FishFeed_Update;
GO

CREATE PROCEDURE usp_FishFeed_Update
    @FishFeedId INT,
    @FeedDate DATE,
    @FeedType NVARCHAR(50),
    @Quantity DECIMAL(18,2),
    @Unit NVARCHAR(20) = NULL,
    @Rate DECIMAL(18,2) = 0,
    @TotalCost DECIMAL(18,2) = NULL,
    @Remarks NVARCHAR(500) = NULL,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@Quantity IS NULL OR @Quantity <= 0)
    BEGIN RAISERROR('Feed quantity must be greater than zero.', 16, 1); RETURN; END
    IF (@TotalCost IS NULL) SET @TotalCost = @Quantity * ISNULL(@Rate, 0);
    IF (@TotalCost < 0)
    BEGIN RAISERROR('Cost must not be negative.', 16, 1); RETURN; END

    UPDATE FishFeed
    SET FeedDate = @FeedDate, FeedType = @FeedType, Quantity = @Quantity, Unit = @Unit,
        Rate = ISNULL(@Rate, 0), TotalCost = @TotalCost, Remarks = @Remarks,
        ModifiedBy = @ModifiedBy, ModifiedDate = GETDATE()
    WHERE FishFeedId = @FishFeedId;
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FishFeed_Delete')
    DROP PROCEDURE usp_FishFeed_Delete;
GO

CREATE PROCEDURE usp_FishFeed_Delete
    @FishFeedId INT
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM FishFeed WHERE FishFeedId = @FishFeedId;
END
GO

-- =============================================
-- usp_FishTreatment_GetPaged / Insert / Update / Delete
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FishTreatment_GetPaged')
    DROP PROCEDURE usp_FishTreatment_GetPaged;
GO

CREATE PROCEDURE usp_FishTreatment_GetPaged
    @ProjectId INT = NULL,
    @PondId INT = NULL,
    @SearchText NVARCHAR(100) = NULL,
    @FromDate DATE = NULL,
    @ToDate DATE = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @SortBy NVARCHAR(50) = 'treatmentDate',
    @SortDir NVARCHAR(4) = 'desc',
    @TotalRecords INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@PageNumber IS NULL OR @PageNumber < 1) SET @PageNumber = 1;
    IF (@PageSize IS NULL OR @PageSize < 1) SET @PageSize = 10;
    IF (@PageSize > 100) SET @PageSize = 100;
    SET @SortBy = LOWER(LTRIM(RTRIM(ISNULL(@SortBy, 'treatmentdate'))));
    IF (@SortBy NOT IN ('treatmentid', 'treatmentdate', 'pondcode', 'treatmenttype', 'cost'))
        SET @SortBy = 'treatmentdate';
    SET @SortDir = LOWER(LTRIM(RTRIM(ISNULL(@SortDir, 'desc'))));
    IF (@SortDir NOT IN ('asc', 'desc')) SET @SortDir = 'desc';
    IF (LTRIM(RTRIM(ISNULL(@SearchText, ''))) = '') SET @SearchText = NULL;

    SELECT @TotalRecords = COUNT(*)
    FROM FishTreatment t
    INNER JOIN Ponds p ON t.PondId = p.PondId
    WHERE (@ProjectId IS NULL OR p.ProjectId = @ProjectId)
    AND (@PondId IS NULL OR t.PondId = @PondId)
    AND (@FromDate IS NULL OR t.TreatmentDate >= @FromDate)
    AND (@ToDate IS NULL OR t.TreatmentDate <= @ToDate)
    AND (@SearchText IS NULL OR t.TreatmentType LIKE '%' + @SearchText + '%' OR t.Medicine LIKE '%' + @SearchText + '%');

    SELECT t.TreatmentId, t.PondId, p.PondCode, p.PondName, p.ProjectId,
        t.TreatmentDate, t.TreatmentType, t.Medicine, t.Quantity, t.Unit, t.Cost, t.Reason, t.Remarks,
        t.CreatedBy, t.CreatedDate, t.ModifiedBy, t.ModifiedDate
    FROM FishTreatment t
    INNER JOIN Ponds p ON t.PondId = p.PondId
    WHERE (@ProjectId IS NULL OR p.ProjectId = @ProjectId)
    AND (@PondId IS NULL OR t.PondId = @PondId)
    AND (@FromDate IS NULL OR t.TreatmentDate >= @FromDate)
    AND (@ToDate IS NULL OR t.TreatmentDate <= @ToDate)
    AND (@SearchText IS NULL OR t.TreatmentType LIKE '%' + @SearchText + '%' OR t.Medicine LIKE '%' + @SearchText + '%')
    ORDER BY
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'treatmentdate' THEN t.TreatmentDate END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'treatmentdate' THEN t.TreatmentDate END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'pondcode' THEN p.PondCode END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'pondcode' THEN p.PondCode END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'treatmenttype' THEN t.TreatmentType END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'treatmenttype' THEN t.TreatmentType END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'cost' THEN t.Cost END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'cost' THEN t.Cost END DESC,
        t.TreatmentDate DESC, t.TreatmentId DESC
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FishTreatment_Insert')
    DROP PROCEDURE usp_FishTreatment_Insert;
GO

CREATE PROCEDURE usp_FishTreatment_Insert
    @PondId INT,
    @TreatmentDate DATE,
    @TreatmentType NVARCHAR(50),
    @Medicine NVARCHAR(200) = NULL,
    @Quantity DECIMAL(18,2) = 0,
    @Unit NVARCHAR(20) = NULL,
    @Cost DECIMAL(18,2) = 0,
    @Reason NVARCHAR(500) = NULL,
    @Remarks NVARCHAR(500) = NULL,
    @CreatedBy INT,
    @ExpProjectId INT = NULL,
    @ExpBudgetCodeId INT = NULL,
    @ExpResourceId INT = NULL,
    @TreatmentId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS (SELECT 1 FROM Ponds WHERE PondId = @PondId AND IsActive = 1)
    BEGIN RAISERROR('Pond must be active.', 16, 1); RETURN; END
    IF (ISNULL(@Cost, 0) < 0)
    BEGIN RAISERROR('Cost must not be negative.', 16, 1); RETURN; END

    INSERT INTO FishTreatment (PondId, TreatmentDate, TreatmentType, Medicine, Quantity, Unit, Cost, Reason, Remarks, CreatedBy, CreatedDate)
    VALUES (@PondId, @TreatmentDate, @TreatmentType, @Medicine, ISNULL(@Quantity, 0), @Unit, ISNULL(@Cost, 0), @Reason, @Remarks, @CreatedBy, GETDATE());

    SET @TreatmentId = SCOPE_IDENTITY();

    IF (@ExpProjectId IS NOT NULL AND @ExpBudgetCodeId IS NOT NULL AND @ExpResourceId IS NOT NULL AND ISNULL(@Cost, 0) > 0)
    BEGIN
        INSERT INTO Expenses (ExpenseDate, ProjectId, BudgetCodeId, ResourceId, Amount, Description, ReferenceNo, Remarks, FarmType, FarmEntityType, FarmEntityId, IsDeleted, CreatedBy, CreatedDate)
        VALUES (@TreatmentDate, @ExpProjectId, @ExpBudgetCodeId, @ExpResourceId, @Cost,
            'Fish treatment (' + @TreatmentType + ')', NULL, @Reason, 'Fish Farming', 'Pond', @PondId, 0, @CreatedBy, GETDATE());
    END
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FishTreatment_Update')
    DROP PROCEDURE usp_FishTreatment_Update;
GO

CREATE PROCEDURE usp_FishTreatment_Update
    @TreatmentId INT,
    @TreatmentDate DATE,
    @TreatmentType NVARCHAR(50),
    @Medicine NVARCHAR(200) = NULL,
    @Quantity DECIMAL(18,2) = 0,
    @Unit NVARCHAR(20) = NULL,
    @Cost DECIMAL(18,2) = 0,
    @Reason NVARCHAR(500) = NULL,
    @Remarks NVARCHAR(500) = NULL,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    IF (ISNULL(@Cost, 0) < 0)
    BEGIN RAISERROR('Cost must not be negative.', 16, 1); RETURN; END

    UPDATE FishTreatment
    SET TreatmentDate = @TreatmentDate, TreatmentType = @TreatmentType, Medicine = @Medicine,
        Quantity = ISNULL(@Quantity, 0), Unit = @Unit, Cost = ISNULL(@Cost, 0),
        Reason = @Reason, Remarks = @Remarks, ModifiedBy = @ModifiedBy, ModifiedDate = GETDATE()
    WHERE TreatmentId = @TreatmentId;
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FishTreatment_Delete')
    DROP PROCEDURE usp_FishTreatment_Delete;
GO

CREATE PROCEDURE usp_FishTreatment_Delete
    @TreatmentId INT
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM FishTreatment WHERE TreatmentId = @TreatmentId;
END
GO

-- =============================================
-- usp_FishMortality_GetPaged / Insert / Update / Delete
-- §77 stock rule: mortality must not exceed available stock.
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FishMortality_GetPaged')
    DROP PROCEDURE usp_FishMortality_GetPaged;
GO

CREATE PROCEDURE usp_FishMortality_GetPaged
    @ProjectId INT = NULL,
    @PondId INT = NULL,
    @FishTypeId INT = NULL,
    @FromDate DATE = NULL,
    @ToDate DATE = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @SortBy NVARCHAR(50) = 'mortalityDate',
    @SortDir NVARCHAR(4) = 'desc',
    @TotalRecords INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@PageNumber IS NULL OR @PageNumber < 1) SET @PageNumber = 1;
    IF (@PageSize IS NULL OR @PageSize < 1) SET @PageSize = 10;
    IF (@PageSize > 100) SET @PageSize = 100;
    SET @SortBy = LOWER(LTRIM(RTRIM(ISNULL(@SortBy, 'mortalitydate'))));
    IF (@SortBy NOT IN ('mortalityid', 'mortalitydate', 'pondcode', 'fishname', 'quantity'))
        SET @SortBy = 'mortalitydate';
    SET @SortDir = LOWER(LTRIM(RTRIM(ISNULL(@SortDir, 'desc'))));
    IF (@SortDir NOT IN ('asc', 'desc')) SET @SortDir = 'desc';

    SELECT @TotalRecords = COUNT(*)
    FROM FishMortality m
    INNER JOIN Ponds p ON m.PondId = p.PondId
    WHERE (@ProjectId IS NULL OR p.ProjectId = @ProjectId)
    AND (@PondId IS NULL OR m.PondId = @PondId)
    AND (@FishTypeId IS NULL OR m.FishTypeId = @FishTypeId)
    AND (@FromDate IS NULL OR m.MortalityDate >= @FromDate)
    AND (@ToDate IS NULL OR m.MortalityDate <= @ToDate);

    SELECT m.MortalityId, m.PondId, p.PondCode, p.PondName, p.ProjectId,
        m.FishTypeId, f.FishCode, f.FishName,
        m.MortalityDate, m.Quantity, m.Reason, m.Remarks,
        m.CreatedBy, m.CreatedDate, m.ModifiedBy, m.ModifiedDate
    FROM FishMortality m
    INNER JOIN Ponds p ON m.PondId = p.PondId
    INNER JOIN FishTypes f ON m.FishTypeId = f.FishTypeId
    WHERE (@ProjectId IS NULL OR p.ProjectId = @ProjectId)
    AND (@PondId IS NULL OR m.PondId = @PondId)
    AND (@FishTypeId IS NULL OR m.FishTypeId = @FishTypeId)
    AND (@FromDate IS NULL OR m.MortalityDate >= @FromDate)
    AND (@ToDate IS NULL OR m.MortalityDate <= @ToDate)
    ORDER BY
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'mortalitydate' THEN m.MortalityDate END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'mortalitydate' THEN m.MortalityDate END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'pondcode' THEN p.PondCode END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'pondcode' THEN p.PondCode END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'fishname' THEN f.FishName END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'fishname' THEN f.FishName END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'quantity' THEN m.Quantity END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'quantity' THEN m.Quantity END DESC,
        m.MortalityDate DESC, m.MortalityId DESC
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FishMortality_Insert')
    DROP PROCEDURE usp_FishMortality_Insert;
GO

CREATE PROCEDURE usp_FishMortality_Insert
    @PondId INT,
    @FishTypeId INT,
    @MortalityDate DATE,
    @Quantity INT,
    @Reason NVARCHAR(500) = NULL,
    @Remarks NVARCHAR(500) = NULL,
    @CreatedBy INT,
    @MortalityId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@Quantity IS NULL OR @Quantity <= 0)
    BEGIN RAISERROR('Mortality quantity must be greater than zero.', 16, 1); RETURN; END

    DECLARE @Avail INT =
        ISNULL((SELECT SUM(Quantity) FROM FishStocking WHERE PondId = @PondId AND FishTypeId = @FishTypeId), 0)
        - ISNULL((SELECT SUM(Quantity) FROM FishMortality WHERE PondId = @PondId AND FishTypeId = @FishTypeId), 0)
        - ISNULL((SELECT SUM(Quantity) FROM FishHarvest WHERE PondId = @PondId AND FishTypeId = @FishTypeId), 0);
    IF (@Quantity > @Avail)
    BEGIN RAISERROR('Mortality quantity exceeds available stock (%d).', 16, 1, @Avail); RETURN; END

    INSERT INTO FishMortality (PondId, FishTypeId, MortalityDate, Quantity, Reason, Remarks, CreatedBy, CreatedDate)
    VALUES (@PondId, @FishTypeId, @MortalityDate, @Quantity, @Reason, @Remarks, @CreatedBy, GETDATE());

    SET @MortalityId = SCOPE_IDENTITY();
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FishMortality_Update')
    DROP PROCEDURE usp_FishMortality_Update;
GO

CREATE PROCEDURE usp_FishMortality_Update
    @MortalityId INT,
    @MortalityDate DATE,
    @Quantity INT,
    @Reason NVARCHAR(500) = NULL,
    @Remarks NVARCHAR(500) = NULL,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@Quantity IS NULL OR @Quantity <= 0)
    BEGIN RAISERROR('Mortality quantity must be greater than zero.', 16, 1); RETURN; END

    DECLARE @PondId INT, @FishTypeId INT;
    SELECT @PondId = PondId, @FishTypeId = FishTypeId FROM FishMortality WHERE MortalityId = @MortalityId;

    DECLARE @Avail INT =
        ISNULL((SELECT SUM(Quantity) FROM FishStocking WHERE PondId = @PondId AND FishTypeId = @FishTypeId), 0)
        - ISNULL((SELECT SUM(Quantity) FROM FishMortality WHERE PondId = @PondId AND FishTypeId = @FishTypeId AND MortalityId <> @MortalityId), 0)
        - ISNULL((SELECT SUM(Quantity) FROM FishHarvest WHERE PondId = @PondId AND FishTypeId = @FishTypeId), 0);
    IF (@Quantity > @Avail)
    BEGIN RAISERROR('Mortality quantity exceeds available stock (%d).', 16, 1, @Avail); RETURN; END

    UPDATE FishMortality
    SET MortalityDate = @MortalityDate, Quantity = @Quantity, Reason = @Reason, Remarks = @Remarks,
        ModifiedBy = @ModifiedBy, ModifiedDate = GETDATE()
    WHERE MortalityId = @MortalityId;
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FishMortality_Delete')
    DROP PROCEDURE usp_FishMortality_Delete;
GO

CREATE PROCEDURE usp_FishMortality_Delete
    @MortalityId INT
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM FishMortality WHERE MortalityId = @MortalityId;
END
GO

-- =============================================
-- usp_FishGrowth_GetPaged / Insert / Update / Delete
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FishGrowth_GetPaged')
    DROP PROCEDURE usp_FishGrowth_GetPaged;
GO

CREATE PROCEDURE usp_FishGrowth_GetPaged
    @ProjectId INT = NULL,
    @PondId INT = NULL,
    @FishTypeId INT = NULL,
    @FromDate DATE = NULL,
    @ToDate DATE = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @SortBy NVARCHAR(50) = 'samplingDate',
    @SortDir NVARCHAR(4) = 'desc',
    @TotalRecords INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@PageNumber IS NULL OR @PageNumber < 1) SET @PageNumber = 1;
    IF (@PageSize IS NULL OR @PageSize < 1) SET @PageSize = 10;
    IF (@PageSize > 100) SET @PageSize = 100;
    SET @SortBy = LOWER(LTRIM(RTRIM(ISNULL(@SortBy, 'samplingdate'))));
    IF (@SortBy NOT IN ('growthid', 'samplingdate', 'pondcode', 'fishname', 'averageweight'))
        SET @SortBy = 'samplingdate';
    SET @SortDir = LOWER(LTRIM(RTRIM(ISNULL(@SortDir, 'desc'))));
    IF (@SortDir NOT IN ('asc', 'desc')) SET @SortDir = 'desc';

    SELECT @TotalRecords = COUNT(*)
    FROM FishGrowth g
    INNER JOIN Ponds p ON g.PondId = p.PondId
    WHERE (@ProjectId IS NULL OR p.ProjectId = @ProjectId)
    AND (@PondId IS NULL OR g.PondId = @PondId)
    AND (@FishTypeId IS NULL OR g.FishTypeId = @FishTypeId)
    AND (@FromDate IS NULL OR g.SamplingDate >= @FromDate)
    AND (@ToDate IS NULL OR g.SamplingDate <= @ToDate);

    SELECT g.GrowthId, g.PondId, p.PondCode, p.PondName, p.ProjectId,
        g.FishTypeId, f.FishCode, f.FishName,
        g.SamplingDate, g.SampleQuantity, g.AverageWeight, g.Remarks,
        g.CreatedBy, g.CreatedDate, g.ModifiedBy, g.ModifiedDate
    FROM FishGrowth g
    INNER JOIN Ponds p ON g.PondId = p.PondId
    INNER JOIN FishTypes f ON g.FishTypeId = f.FishTypeId
    WHERE (@ProjectId IS NULL OR p.ProjectId = @ProjectId)
    AND (@PondId IS NULL OR g.PondId = @PondId)
    AND (@FishTypeId IS NULL OR g.FishTypeId = @FishTypeId)
    AND (@FromDate IS NULL OR g.SamplingDate >= @FromDate)
    AND (@ToDate IS NULL OR g.SamplingDate <= @ToDate)
    ORDER BY
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'samplingdate' THEN g.SamplingDate END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'samplingdate' THEN g.SamplingDate END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'pondcode' THEN p.PondCode END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'pondcode' THEN p.PondCode END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'fishname' THEN f.FishName END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'fishname' THEN f.FishName END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'averageweight' THEN g.AverageWeight END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'averageweight' THEN g.AverageWeight END DESC,
        g.SamplingDate DESC, g.GrowthId DESC
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FishGrowth_Insert')
    DROP PROCEDURE usp_FishGrowth_Insert;
GO

CREATE PROCEDURE usp_FishGrowth_Insert
    @PondId INT,
    @FishTypeId INT,
    @SamplingDate DATE,
    @SampleQuantity INT,
    @AverageWeight DECIMAL(18,2),
    @Remarks NVARCHAR(500) = NULL,
    @CreatedBy INT,
    @GrowthId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@SampleQuantity IS NULL OR @SampleQuantity <= 0)
    BEGIN RAISERROR('Sample quantity must be greater than zero.', 16, 1); RETURN; END

    INSERT INTO FishGrowth (PondId, FishTypeId, SamplingDate, SampleQuantity, AverageWeight, Remarks, CreatedBy, CreatedDate)
    VALUES (@PondId, @FishTypeId, @SamplingDate, @SampleQuantity, @AverageWeight, @Remarks, @CreatedBy, GETDATE());

    SET @GrowthId = SCOPE_IDENTITY();
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FishGrowth_Update')
    DROP PROCEDURE usp_FishGrowth_Update;
GO

CREATE PROCEDURE usp_FishGrowth_Update
    @GrowthId INT,
    @SamplingDate DATE,
    @SampleQuantity INT,
    @AverageWeight DECIMAL(18,2),
    @Remarks NVARCHAR(500) = NULL,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@SampleQuantity IS NULL OR @SampleQuantity <= 0)
    BEGIN RAISERROR('Sample quantity must be greater than zero.', 16, 1); RETURN; END

    UPDATE FishGrowth
    SET SamplingDate = @SamplingDate, SampleQuantity = @SampleQuantity, AverageWeight = @AverageWeight,
        Remarks = @Remarks, ModifiedBy = @ModifiedBy, ModifiedDate = GETDATE()
    WHERE GrowthId = @GrowthId;
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FishGrowth_Delete')
    DROP PROCEDURE usp_FishGrowth_Delete;
GO

CREATE PROCEDURE usp_FishGrowth_Delete
    @GrowthId INT
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM FishGrowth WHERE GrowthId = @GrowthId;
END
GO

-- =============================================
-- usp_FishHarvest_GetPaged / Insert / Update / Delete
-- §79: AverageWeight = TotalWeight / Quantity (guard divide-by-zero).
-- Harvest must not exceed available stock.
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FishHarvest_GetPaged')
    DROP PROCEDURE usp_FishHarvest_GetPaged;
GO

CREATE PROCEDURE usp_FishHarvest_GetPaged
    @ProjectId INT = NULL,
    @PondId INT = NULL,
    @FishTypeId INT = NULL,
    @FromDate DATE = NULL,
    @ToDate DATE = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @SortBy NVARCHAR(50) = 'harvestDate',
    @SortDir NVARCHAR(4) = 'desc',
    @TotalRecords INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@PageNumber IS NULL OR @PageNumber < 1) SET @PageNumber = 1;
    IF (@PageSize IS NULL OR @PageSize < 1) SET @PageSize = 10;
    IF (@PageSize > 100) SET @PageSize = 100;
    SET @SortBy = LOWER(LTRIM(RTRIM(ISNULL(@SortBy, 'harvestdate'))));
    IF (@SortBy NOT IN ('harvestid', 'harvestdate', 'pondcode', 'fishname', 'quantity', 'totalweight'))
        SET @SortBy = 'harvestdate';
    SET @SortDir = LOWER(LTRIM(RTRIM(ISNULL(@SortDir, 'desc'))));
    IF (@SortDir NOT IN ('asc', 'desc')) SET @SortDir = 'desc';

    SELECT @TotalRecords = COUNT(*)
    FROM FishHarvest h
    INNER JOIN Ponds p ON h.PondId = p.PondId
    WHERE (@ProjectId IS NULL OR p.ProjectId = @ProjectId)
    AND (@PondId IS NULL OR h.PondId = @PondId)
    AND (@FishTypeId IS NULL OR h.FishTypeId = @FishTypeId)
    AND (@FromDate IS NULL OR h.HarvestDate >= @FromDate)
    AND (@ToDate IS NULL OR h.HarvestDate <= @ToDate);

    SELECT h.HarvestId, h.PondId, p.PondCode, p.PondName, p.ProjectId,
        h.FishTypeId, f.FishCode, f.FishName,
        h.HarvestDate, h.Quantity, h.TotalWeight, h.AverageWeight, h.HarvestCost, h.Remarks,
        h.CreatedBy, h.CreatedDate, h.ModifiedBy, h.ModifiedDate
    FROM FishHarvest h
    INNER JOIN Ponds p ON h.PondId = p.PondId
    INNER JOIN FishTypes f ON h.FishTypeId = f.FishTypeId
    WHERE (@ProjectId IS NULL OR p.ProjectId = @ProjectId)
    AND (@PondId IS NULL OR h.PondId = @PondId)
    AND (@FishTypeId IS NULL OR h.FishTypeId = @FishTypeId)
    AND (@FromDate IS NULL OR h.HarvestDate >= @FromDate)
    AND (@ToDate IS NULL OR h.HarvestDate <= @ToDate)
    ORDER BY
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'harvestdate' THEN h.HarvestDate END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'harvestdate' THEN h.HarvestDate END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'pondcode' THEN p.PondCode END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'pondcode' THEN p.PondCode END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'fishname' THEN f.FishName END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'fishname' THEN f.FishName END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'quantity' THEN h.Quantity END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'quantity' THEN h.Quantity END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'totalweight' THEN h.TotalWeight END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'totalweight' THEN h.TotalWeight END DESC,
        h.HarvestDate DESC, h.HarvestId DESC
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FishHarvest_Insert')
    DROP PROCEDURE usp_FishHarvest_Insert;
GO

CREATE PROCEDURE usp_FishHarvest_Insert
    @PondId INT,
    @FishTypeId INT,
    @HarvestDate DATE,
    @Quantity INT,
    @TotalWeight DECIMAL(18,2) = 0,
    @HarvestCost DECIMAL(18,2) = 0,
    @Remarks NVARCHAR(500) = NULL,
    @CreatedBy INT,
    @HarvestId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@Quantity IS NULL OR @Quantity <= 0)
    BEGIN RAISERROR('Harvest quantity must be greater than zero.', 16, 1); RETURN; END

    DECLARE @Avail INT =
        ISNULL((SELECT SUM(Quantity) FROM FishStocking WHERE PondId = @PondId AND FishTypeId = @FishTypeId), 0)
        - ISNULL((SELECT SUM(Quantity) FROM FishMortality WHERE PondId = @PondId AND FishTypeId = @FishTypeId), 0)
        - ISNULL((SELECT SUM(Quantity) FROM FishHarvest WHERE PondId = @PondId AND FishTypeId = @FishTypeId), 0);
    IF (@Quantity > @Avail)
    BEGIN RAISERROR('Harvest quantity exceeds available stock (%d).', 16, 1, @Avail); RETURN; END

    DECLARE @Avg DECIMAL(18,2) = NULL;
    IF (@Quantity > 0 AND @TotalWeight IS NOT NULL)
        SET @Avg = @TotalWeight / CAST(@Quantity AS DECIMAL(18,2));

    INSERT INTO FishHarvest (PondId, FishTypeId, HarvestDate, Quantity, TotalWeight, AverageWeight, HarvestCost, Remarks, CreatedBy, CreatedDate)
    VALUES (@PondId, @FishTypeId, @HarvestDate, @Quantity, ISNULL(@TotalWeight, 0), @Avg, ISNULL(@HarvestCost, 0), @Remarks, @CreatedBy, GETDATE());

    SET @HarvestId = SCOPE_IDENTITY();
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FishHarvest_Update')
    DROP PROCEDURE usp_FishHarvest_Update;
GO

CREATE PROCEDURE usp_FishHarvest_Update
    @HarvestId INT,
    @HarvestDate DATE,
    @Quantity INT,
    @TotalWeight DECIMAL(18,2) = 0,
    @HarvestCost DECIMAL(18,2) = 0,
    @Remarks NVARCHAR(500) = NULL,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@Quantity IS NULL OR @Quantity <= 0)
    BEGIN RAISERROR('Harvest quantity must be greater than zero.', 16, 1); RETURN; END

    DECLARE @PondId INT, @FishTypeId INT;
    SELECT @PondId = PondId, @FishTypeId = FishTypeId FROM FishHarvest WHERE HarvestId = @HarvestId;

    DECLARE @Avail INT =
        ISNULL((SELECT SUM(Quantity) FROM FishStocking WHERE PondId = @PondId AND FishTypeId = @FishTypeId), 0)
        - ISNULL((SELECT SUM(Quantity) FROM FishMortality WHERE PondId = @PondId AND FishTypeId = @FishTypeId), 0)
        - ISNULL((SELECT SUM(Quantity) FROM FishHarvest WHERE PondId = @PondId AND FishTypeId = @FishTypeId AND HarvestId <> @HarvestId), 0);
    IF (@Quantity > @Avail)
    BEGIN RAISERROR('Harvest quantity exceeds available stock (%d).', 16, 1, @Avail); RETURN; END

    DECLARE @Avg DECIMAL(18,2) = NULL;
    IF (@Quantity > 0 AND @TotalWeight IS NOT NULL)
        SET @Avg = @TotalWeight / CAST(@Quantity AS DECIMAL(18,2));

    UPDATE FishHarvest
    SET HarvestDate = @HarvestDate, Quantity = @Quantity, TotalWeight = ISNULL(@TotalWeight, 0),
        AverageWeight = @Avg, HarvestCost = ISNULL(@HarvestCost, 0), Remarks = @Remarks,
        ModifiedBy = @ModifiedBy, ModifiedDate = GETDATE()
    WHERE HarvestId = @HarvestId;
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FishHarvest_Delete')
    DROP PROCEDURE usp_FishHarvest_Delete;
GO

CREATE PROCEDURE usp_FishHarvest_Delete
    @HarvestId INT
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (SELECT 1 FROM FishSales WHERE HarvestId = @HarvestId)
    BEGIN RAISERROR('Harvest is linked to a sale and cannot be deleted.', 16, 1); RETURN; END

    DELETE FROM FishHarvest WHERE HarvestId = @HarvestId;
END
GO

-- =============================================
-- usp_FishSales_GetPaged / Insert / Update / Delete
-- Sales auto-post Revenue (Fish Sale) transactionally.
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FishSales_GetPaged')
    DROP PROCEDURE usp_FishSales_GetPaged;
GO

CREATE PROCEDURE usp_FishSales_GetPaged
    @ProjectId INT = NULL,
    @FishTypeId INT = NULL,
    @PaymentStatus NVARCHAR(20) = NULL,
    @FromDate DATE = NULL,
    @ToDate DATE = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @SortBy NVARCHAR(50) = 'saleDate',
    @SortDir NVARCHAR(4) = 'desc',
    @TotalRecords INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@PageNumber IS NULL OR @PageNumber < 1) SET @PageNumber = 1;
    IF (@PageSize IS NULL OR @PageSize < 1) SET @PageSize = 10;
    IF (@PageSize > 100) SET @PageSize = 100;
    SET @SortBy = LOWER(LTRIM(RTRIM(ISNULL(@SortBy, 'saledate'))));
    IF (@SortBy NOT IN ('saleid', 'saledate', 'customername', 'quantity', 'totalamount'))
        SET @SortBy = 'saledate';
    SET @SortDir = LOWER(LTRIM(RTRIM(ISNULL(@SortDir, 'desc'))));
    IF (@SortDir NOT IN ('asc', 'desc')) SET @SortDir = 'desc';
    IF (LTRIM(RTRIM(ISNULL(@PaymentStatus, ''))) = '') SET @PaymentStatus = NULL;

    SELECT @TotalRecords = COUNT(*)
    FROM FishSales s
    WHERE (@ProjectId IS NULL OR s.ProjectId = @ProjectId)
    AND (@FishTypeId IS NULL OR s.FishTypeId = @FishTypeId)
    AND (@PaymentStatus IS NULL OR s.PaymentStatus = @PaymentStatus)
    AND (@FromDate IS NULL OR s.SaleDate >= @FromDate)
    AND (@ToDate IS NULL OR s.SaleDate <= @ToDate);

    SELECT s.SaleId, s.ProjectId, p.ProjectCode, p.ProjectName,
        s.HarvestId, s.FishTypeId, f.FishCode, f.FishName,
        s.SaleDate, s.CustomerName, s.Quantity, s.TotalWeight, s.Rate, s.TotalAmount,
        s.PaymentStatus, s.ReferenceNo, s.Remarks,
        s.CreatedBy, s.CreatedDate, s.ModifiedBy, s.ModifiedDate
    FROM FishSales s
    INNER JOIN Projects p ON s.ProjectId = p.ProjectId
    INNER JOIN FishTypes f ON s.FishTypeId = f.FishTypeId
    WHERE (@ProjectId IS NULL OR s.ProjectId = @ProjectId)
    AND (@FishTypeId IS NULL OR s.FishTypeId = @FishTypeId)
    AND (@PaymentStatus IS NULL OR s.PaymentStatus = @PaymentStatus)
    AND (@FromDate IS NULL OR s.SaleDate >= @FromDate)
    AND (@ToDate IS NULL OR s.SaleDate <= @ToDate)
    ORDER BY
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'saledate' THEN s.SaleDate END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'saledate' THEN s.SaleDate END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'customername' THEN s.CustomerName END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'customername' THEN s.CustomerName END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'quantity' THEN s.Quantity END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'quantity' THEN s.Quantity END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'totalamount' THEN s.TotalAmount END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'totalamount' THEN s.TotalAmount END DESC,
        s.SaleDate DESC, s.SaleId DESC
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FishSales_Insert')
    DROP PROCEDURE usp_FishSales_Insert;
GO

CREATE PROCEDURE usp_FishSales_Insert
    @ProjectId INT,
    @HarvestId INT = NULL,
    @FishTypeId INT,
    @SaleDate DATE,
    @CustomerName NVARCHAR(200),
    @Quantity INT,
    @TotalWeight DECIMAL(18,2) = 0,
    @Rate DECIMAL(18,2) = 0,
    @TotalAmount DECIMAL(18,2) = NULL,
    @PaymentStatus NVARCHAR(20) = 'Pending',
    @ReferenceNo NVARCHAR(50) = NULL,
    @Remarks NVARCHAR(500) = NULL,
    @CreatedBy INT,
    @SaleId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@Quantity IS NULL OR @Quantity <= 0)
    BEGIN RAISERROR('Sale quantity must be greater than zero.', 16, 1); RETURN; END
    IF (@TotalAmount IS NULL) SET @TotalAmount = CAST(@Quantity AS DECIMAL(18,2)) * ISNULL(@Rate, 0);
    IF (@TotalAmount < 0)
    BEGIN RAISERROR('Sale amount must not be negative.', 16, 1); RETURN; END

    BEGIN TRANSACTION;
    BEGIN TRY
        INSERT INTO FishSales (ProjectId, HarvestId, FishTypeId, SaleDate, CustomerName, Quantity, TotalWeight, Rate, TotalAmount, PaymentStatus, ReferenceNo, Remarks, CreatedBy, CreatedDate)
        VALUES (@ProjectId, @HarvestId, @FishTypeId, @SaleDate, @CustomerName, @Quantity, ISNULL(@TotalWeight, 0), ISNULL(@Rate, 0), @TotalAmount, ISNULL(@PaymentStatus, 'Pending'), @ReferenceNo, @Remarks, @CreatedBy, GETDATE());

        SET @SaleId = SCOPE_IDENTITY();

        INSERT INTO Revenue (RevenueDate, ProjectId, FarmType, RevenueType, ReferenceId, CustomerName, Quantity, Weight, Rate, Amount, PaymentStatus, Remarks, IsDeleted, CreatedBy, CreatedDate)
        VALUES (@SaleDate, @ProjectId, 'Fish Farming', 'Fish Sale', @SaleId, @CustomerName, @Quantity, ISNULL(@TotalWeight, 0), ISNULL(@Rate, 0), @TotalAmount, ISNULL(@PaymentStatus, 'Pending'), @Remarks, 0, @CreatedBy, GETDATE());

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FishSales_Update')
    DROP PROCEDURE usp_FishSales_Update;
GO

CREATE PROCEDURE usp_FishSales_Update
    @SaleId INT,
    @SaleDate DATE,
    @CustomerName NVARCHAR(200),
    @Quantity INT,
    @TotalWeight DECIMAL(18,2) = 0,
    @Rate DECIMAL(18,2) = 0,
    @TotalAmount DECIMAL(18,2) = NULL,
    @PaymentStatus NVARCHAR(20) = NULL,
    @ReferenceNo NVARCHAR(50) = NULL,
    @Remarks NVARCHAR(500) = NULL,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@Quantity IS NULL OR @Quantity <= 0)
    BEGIN RAISERROR('Sale quantity must be greater than zero.', 16, 1); RETURN; END
    IF (@TotalAmount IS NULL) SET @TotalAmount = CAST(@Quantity AS DECIMAL(18,2)) * ISNULL(@Rate, 0);
    IF (@TotalAmount < 0)
    BEGIN RAISERROR('Sale amount must not be negative.', 16, 1); RETURN; END

    BEGIN TRANSACTION;
    BEGIN TRY
        UPDATE FishSales
        SET SaleDate = @SaleDate, CustomerName = @CustomerName, Quantity = @Quantity,
            TotalWeight = ISNULL(@TotalWeight, 0), Rate = ISNULL(@Rate, 0), TotalAmount = @TotalAmount,
            PaymentStatus = ISNULL(@PaymentStatus, PaymentStatus),
            ReferenceNo = @ReferenceNo, Remarks = @Remarks,
            ModifiedBy = @ModifiedBy, ModifiedDate = GETDATE()
        WHERE SaleId = @SaleId;

        UPDATE Revenue
        SET RevenueDate = @SaleDate, CustomerName = @CustomerName, Quantity = @Quantity,
            Weight = ISNULL(@TotalWeight, 0), Rate = ISNULL(@Rate, 0), Amount = @TotalAmount,
            PaymentStatus = ISNULL(@PaymentStatus, PaymentStatus),
            Remarks = @Remarks, ModifiedBy = @ModifiedBy, ModifiedDate = GETDATE()
        WHERE RevenueType = 'Fish Sale' AND ReferenceId = @SaleId AND IsDeleted = 0;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FishSales_Delete')
    DROP PROCEDURE usp_FishSales_Delete;
GO

CREATE PROCEDURE usp_FishSales_Delete
    @SaleId INT
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRANSACTION;
    BEGIN TRY
        UPDATE Revenue SET IsDeleted = 1, ModifiedDate = GETDATE()
        WHERE RevenueType = 'Fish Sale' AND ReferenceId = @SaleId AND IsDeleted = 0;

        DELETE FROM FishSales WHERE SaleId = @SaleId;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END
GO

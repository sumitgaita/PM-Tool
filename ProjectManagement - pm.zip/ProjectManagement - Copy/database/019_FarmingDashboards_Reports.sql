﻿USE ProjectManagementDB;
GO

-- =============================================
-- Â§104 Dashboard + Â§100 Reports + Â§95 Profitability procedures.
-- All aggregation in SQL; Angular receives ready totals/series.
-- =============================================

-- =============================================
-- usp_FarmDashboard_Summary
-- Overall revenue/expense/profit + farming KPIs, date-filtered.
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FarmDashboard_Summary')
    DROP PROCEDURE usp_FarmDashboard_Summary;
GO

CREATE PROCEDURE usp_FarmDashboard_Summary
    @ProjectId INT = NULL,
    @FarmType NVARCHAR(50) = NULL,
    @FromDate DATE = NULL,
    @ToDate DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF (LTRIM(RTRIM(ISNULL(@FarmType, ''))) = '') SET @FarmType = NULL;

    SELECT
        ISNULL((SELECT SUM(r.Amount) FROM Revenue r
            INNER JOIN Projects p ON r.ProjectId = p.ProjectId
            WHERE r.IsDeleted = 0
            AND (@ProjectId IS NULL OR r.ProjectId = @ProjectId)
            AND (@FarmType IS NULL OR r.FarmType = @FarmType OR p.FarmType = @FarmType)
            AND (@FromDate IS NULL OR r.RevenueDate >= @FromDate)
            AND (@ToDate IS NULL OR r.RevenueDate <= @ToDate)), 0) AS TotalRevenue,
        ISNULL((SELECT SUM(e.Amount) FROM Expenses e
            INNER JOIN Projects p ON e.ProjectId = p.ProjectId
            WHERE e.IsDeleted = 0
            AND (@ProjectId IS NULL OR e.ProjectId = @ProjectId)
            AND (@FarmType IS NULL OR e.FarmType = @FarmType OR p.FarmType = @FarmType)
            AND (@FromDate IS NULL OR e.ExpenseDate >= @FromDate)
            AND (@ToDate IS NULL OR e.ExpenseDate <= @ToDate)), 0) AS TotalExpense,
        ISNULL((SELECT COUNT(*) FROM Ponds p
            INNER JOIN Projects pr ON p.ProjectId = pr.ProjectId
            WHERE (@ProjectId IS NULL OR p.ProjectId = @ProjectId)
            AND (@FarmType IS NULL OR @FarmType = 'Fish Farming' OR pr.FarmType = @FarmType)), 0) AS TotalPonds,
        ISNULL((SELECT COUNT(*) FROM Ponds p
            INNER JOIN Projects pr ON p.ProjectId = pr.ProjectId
            WHERE p.IsActive = 1
            AND (@ProjectId IS NULL OR p.ProjectId = @ProjectId)
            AND (@FarmType IS NULL OR @FarmType = 'Fish Farming' OR pr.FarmType = @FarmType)), 0) AS ActivePonds,
        ISNULL((SELECT COUNT(*) FROM PoultrySheds s
            INNER JOIN Projects pr ON s.ProjectId = pr.ProjectId
            WHERE (@ProjectId IS NULL OR s.ProjectId = @ProjectId)
            AND (@FarmType IS NULL OR @FarmType = 'Poultry Farming' OR pr.FarmType = @FarmType)), 0) AS TotalSheds,
        ISNULL((SELECT COUNT(*) FROM PoultryBatches b
            INNER JOIN Projects pr ON b.ProjectId = pr.ProjectId
            WHERE b.Status = 'Active'
            AND (@ProjectId IS NULL OR b.ProjectId = @ProjectId)
            AND (@FarmType IS NULL OR @FarmType = 'Poultry Farming' OR pr.FarmType = @FarmType)), 0) AS ActiveBatches;
END
GO

-- =============================================
-- usp_FishDashboard_Kpis (Â§96 fish KPIs)
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FishDashboard_Kpis')
    DROP PROCEDURE usp_FishDashboard_Kpis;
GO

CREATE PROCEDURE usp_FishDashboard_Kpis
    @ProjectId INT = NULL,
    @FromDate DATE = NULL,
    @ToDate DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        ISNULL((SELECT COUNT(*) FROM Ponds p WHERE p.IsActive = 1 AND (@ProjectId IS NULL OR p.ProjectId = @ProjectId)), 0) AS ActivePonds,
        ISNULL((SELECT SUM(s.Quantity) FROM FishStocking s INNER JOIN Ponds p ON s.PondId = p.PondId
            WHERE (@ProjectId IS NULL OR p.ProjectId = @ProjectId)
            AND (@FromDate IS NULL OR s.StockingDate >= @FromDate) AND (@ToDate IS NULL OR s.StockingDate <= @ToDate)), 0) AS TotalStocked,
        ISNULL((SELECT SUM(v.CurrentStock) FROM vw_FishCurrentStock v WHERE (@ProjectId IS NULL OR v.ProjectId = @ProjectId)), 0) AS CurrentStock,
        ISNULL((SELECT SUM(m.Quantity) FROM FishMortality m INNER JOIN Ponds p ON m.PondId = p.PondId
            WHERE (@ProjectId IS NULL OR p.ProjectId = @ProjectId)
            AND (@FromDate IS NULL OR m.MortalityDate >= @FromDate) AND (@ToDate IS NULL OR m.MortalityDate <= @ToDate)), 0) AS TotalMortality,
        ISNULL((SELECT SUM(h.Quantity) FROM FishHarvest h INNER JOIN Ponds p ON h.PondId = p.PondId
            WHERE (@ProjectId IS NULL OR p.ProjectId = @ProjectId)
            AND (@FromDate IS NULL OR h.HarvestDate >= @FromDate) AND (@ToDate IS NULL OR h.HarvestDate <= @ToDate)), 0) AS TotalHarvest,
        ISNULL((SELECT SUM(h.TotalWeight) FROM FishHarvest h INNER JOIN Ponds p ON h.PondId = p.PondId
            WHERE (@ProjectId IS NULL OR p.ProjectId = @ProjectId)
            AND (@FromDate IS NULL OR h.HarvestDate >= @FromDate) AND (@ToDate IS NULL OR h.HarvestDate <= @ToDate)), 0) AS TotalHarvestWeight,
        ISNULL((SELECT SUM(f.TotalCost) FROM FishFeed f INNER JOIN Ponds p ON f.PondId = p.PondId
            WHERE (@ProjectId IS NULL OR p.ProjectId = @ProjectId)
            AND (@FromDate IS NULL OR f.FeedDate >= @FromDate) AND (@ToDate IS NULL OR f.FeedDate <= @ToDate)), 0) AS FeedCost,
        ISNULL((SELECT SUM(t.Cost) FROM FishTreatment t INNER JOIN Ponds p ON t.PondId = p.PondId
            WHERE (@ProjectId IS NULL OR p.ProjectId = @ProjectId)
            AND (@FromDate IS NULL OR t.TreatmentDate >= @FromDate) AND (@ToDate IS NULL OR t.TreatmentDate <= @ToDate)), 0) AS TreatmentCost,
        ISNULL((SELECT SUM(s.TotalAmount) FROM FishSales s
            WHERE (@ProjectId IS NULL OR s.ProjectId = @ProjectId)
            AND (@FromDate IS NULL OR s.SaleDate >= @FromDate) AND (@ToDate IS NULL OR s.SaleDate <= @ToDate)), 0) AS FishRevenue;
END
GO

-- =============================================
-- usp_PoultryDashboard_Kpis (Â§96 poultry KPIs)
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultryDashboard_Kpis')
    DROP PROCEDURE usp_PoultryDashboard_Kpis;
GO

CREATE PROCEDURE usp_PoultryDashboard_Kpis
    @ProjectId INT = NULL,
    @FromDate DATE = NULL,
    @ToDate DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        ISNULL((SELECT COUNT(*) FROM PoultrySheds s WHERE s.IsActive = 1 AND (@ProjectId IS NULL OR s.ProjectId = @ProjectId)), 0) AS ActiveSheds,
        ISNULL((SELECT COUNT(*) FROM PoultryBatches b WHERE b.Status = 'Active' AND (@ProjectId IS NULL OR b.ProjectId = @ProjectId)), 0) AS ActiveBatches,
        ISNULL((SELECT SUM(b.InitialQuantity) FROM PoultryBatches b WHERE (@ProjectId IS NULL OR b.ProjectId = @ProjectId)), 0) AS TotalBirds,
        ISNULL((SELECT SUM(v.CurrentBirds) FROM vw_PoultryCurrentStock v INNER JOIN PoultryBatches b ON v.BatchId = b.BatchId WHERE (@ProjectId IS NULL OR b.ProjectId = @ProjectId)), 0) AS CurrentBirds,
        ISNULL((SELECT SUM(m.Quantity) FROM PoultryMortality m INNER JOIN PoultryBatches b ON m.BatchId = b.BatchId
            WHERE (@ProjectId IS NULL OR b.ProjectId = @ProjectId)
            AND (@FromDate IS NULL OR m.MortalityDate >= @FromDate) AND (@ToDate IS NULL OR m.MortalityDate <= @ToDate)), 0) AS TotalMortality,
        ISNULL((SELECT SUM(f.Quantity) FROM PoultryFeed f INNER JOIN PoultryBatches b ON f.BatchId = b.BatchId
            WHERE (@ProjectId IS NULL OR b.ProjectId = @ProjectId)
            AND (@FromDate IS NULL OR f.FeedDate >= @FromDate) AND (@ToDate IS NULL OR f.FeedDate <= @ToDate)), 0) AS TotalFeed,
        ISNULL((SELECT SUM(f.TotalCost) FROM PoultryFeed f INNER JOIN PoultryBatches b ON f.BatchId = b.BatchId
            WHERE (@ProjectId IS NULL OR b.ProjectId = @ProjectId)
            AND (@FromDate IS NULL OR f.FeedDate >= @FromDate) AND (@ToDate IS NULL OR f.FeedDate <= @ToDate)), 0) AS FeedCost,
        ISNULL((SELECT SUM(e.TotalEggs) FROM EggProduction e INNER JOIN PoultryBatches b ON e.BatchId = b.BatchId
            WHERE (@ProjectId IS NULL OR b.ProjectId = @ProjectId)
            AND (@FromDate IS NULL OR e.ProductionDate >= @FromDate) AND (@ToDate IS NULL OR e.ProductionDate <= @ToDate)), 0) AS TotalEggs,
        ISNULL((SELECT SUM(e.GoodEggs) FROM EggProduction e INNER JOIN PoultryBatches b ON e.BatchId = b.BatchId
            WHERE (@ProjectId IS NULL OR b.ProjectId = @ProjectId)
            AND (@FromDate IS NULL OR e.ProductionDate >= @FromDate) AND (@ToDate IS NULL OR e.ProductionDate <= @ToDate)), 0) AS GoodEggs,
        ISNULL((SELECT SUM(e.BrokenEggs) FROM EggProduction e INNER JOIN PoultryBatches b ON e.BatchId = b.BatchId
            WHERE (@ProjectId IS NULL OR b.ProjectId = @ProjectId)
            AND (@FromDate IS NULL OR e.ProductionDate >= @FromDate) AND (@ToDate IS NULL OR e.ProductionDate <= @ToDate)), 0) AS BrokenEggs,
        ISNULL((SELECT SUM(s.BirdQuantity) FROM PoultrySales s
            WHERE (@ProjectId IS NULL OR s.ProjectId = @ProjectId)
            AND (@FromDate IS NULL OR s.SaleDate >= @FromDate) AND (@ToDate IS NULL OR s.SaleDate <= @ToDate)), 0) AS BirdSales,
        ISNULL((SELECT SUM(s.TotalAmount) FROM PoultrySales s
            WHERE (@ProjectId IS NULL OR s.ProjectId = @ProjectId)
            AND (@FromDate IS NULL OR s.SaleDate >= @FromDate) AND (@ToDate IS NULL OR s.SaleDate <= @ToDate)), 0) AS PoultryRevenue;
END
GO

-- =============================================
-- usp_FarmDashboard_Monthly (revenue vs expense series)
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FarmDashboard_Monthly')
    DROP PROCEDURE usp_FarmDashboard_Monthly;
GO

CREATE PROCEDURE usp_FarmDashboard_Monthly
    @ProjectId INT = NULL,
    @FarmType NVARCHAR(50) = NULL,
    @FromDate DATE = NULL,
    @ToDate DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF (LTRIM(RTRIM(ISNULL(@FarmType, ''))) = '') SET @FarmType = NULL;

    ;WITH Months AS (
        SELECT FORMAT(DATEADD(MONTH, -n, EOMONTH(GETDATE())), 'yyyy-MM') AS YearMonth
        FROM (VALUES (0),(1),(2),(3),(4),(5)) AS N(n)
    )
    SELECT m.YearMonth,
        ISNULL((SELECT SUM(r.Amount) FROM Revenue r
            INNER JOIN Projects p ON r.ProjectId = p.ProjectId
            WHERE r.IsDeleted = 0 AND FORMAT(r.RevenueDate, 'yyyy-MM') = m.YearMonth
            AND (@ProjectId IS NULL OR r.ProjectId = @ProjectId)
            AND (@FarmType IS NULL OR r.FarmType = @FarmType OR p.FarmType = @FarmType)
            AND (@FromDate IS NULL OR r.RevenueDate >= @FromDate)
            AND (@ToDate IS NULL OR r.RevenueDate <= @ToDate)), 0) AS Revenue,
        ISNULL((SELECT SUM(e.Amount) FROM Expenses e
            INNER JOIN Projects p ON e.ProjectId = p.ProjectId
            WHERE e.IsDeleted = 0 AND FORMAT(e.ExpenseDate, 'yyyy-MM') = m.YearMonth
            AND (@ProjectId IS NULL OR e.ProjectId = @ProjectId)
            AND (@FarmType IS NULL OR e.FarmType = @FarmType OR p.FarmType = @FarmType)
            AND (@FromDate IS NULL OR e.ExpenseDate >= @FromDate)
            AND (@ToDate IS NULL OR e.ExpenseDate <= @ToDate)), 0) AS Expense
    FROM Months m
    ORDER BY m.YearMonth;
END
GO

-- =============================================
-- usp_FishDashboard_TypeWise (Â§98 Fish Type-wise Stock)
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FishDashboard_TypeWise')
    DROP PROCEDURE usp_FishDashboard_TypeWise;
GO

CREATE PROCEDURE usp_FishDashboard_TypeWise
    @ProjectId INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SELECT f.FishName,
        ISNULL(SUM(v.StockedQuantity), 0) AS StockedQuantity,
        ISNULL(SUM(v.MortalityQuantity), 0) AS MortalityQuantity,
        ISNULL(SUM(v.HarvestQuantity), 0) AS HarvestQuantity,
        ISNULL(SUM(v.CurrentStock), 0) AS CurrentStock
    FROM FishTypes f
    LEFT JOIN vw_FishCurrentStock v ON v.FishTypeId = f.FishTypeId
        AND (@ProjectId IS NULL OR v.ProjectId = @ProjectId)
    WHERE f.IsActive = 1
    GROUP BY f.FishName
    HAVING SUM(ISNULL(v.StockedQuantity, 0)) > 0
    ORDER BY f.FishName;
END
GO

-- =============================================
-- usp_FishDashboard_PondWise (Â§98 Pond-wise Expense)
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_FishDashboard_PondWise')
    DROP PROCEDURE usp_FishDashboard_PondWise;
GO

CREATE PROCEDURE usp_FishDashboard_PondWise
    @ProjectId INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SELECT p.PondCode, p.PondName,
        ISNULL((SELECT SUM(s.TotalCost) FROM FishStocking s WHERE s.PondId = p.PondId), 0)
        + ISNULL((SELECT SUM(f.TotalCost) FROM FishFeed f WHERE f.PondId = p.PondId), 0)
        + ISNULL((SELECT SUM(t.Cost) FROM FishTreatment t WHERE t.PondId = p.PondId), 0)
        + ISNULL((SELECT SUM(h.HarvestCost) FROM FishHarvest h WHERE h.PondId = p.PondId), 0) AS OperationalCost,
        ISNULL((SELECT SUM(e.Amount) FROM Expenses e WHERE e.FarmEntityType = 'Pond' AND e.FarmEntityId = p.PondId AND e.IsDeleted = 0), 0) AS LinkedExpense
    FROM Ponds p
    WHERE p.IsActive = 1
    AND (@ProjectId IS NULL OR p.ProjectId = @ProjectId)
    ORDER BY p.PondCode;
END
GO

-- =============================================
-- usp_PoultryDashboard_BatchWise (Â§99 batch charts input)
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultryDashboard_BatchWise')
    DROP PROCEDURE usp_PoultryDashboard_BatchWise;
GO

CREATE PROCEDURE usp_PoultryDashboard_BatchWise
    @ProjectId INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SELECT b.BatchCode, b.BirdType,
        b.InitialQuantity,
        ISNULL((SELECT SUM(Quantity) FROM PoultryMortality m WHERE m.BatchId = b.BatchId), 0) AS MortalityQuantity,
        ISNULL((SELECT SUM(BirdQuantity) FROM PoultrySales s WHERE s.BatchId = b.BatchId), 0) AS SoldQuantity,
        b.InitialQuantity
            - ISNULL((SELECT SUM(Quantity) FROM PoultryMortality m WHERE m.BatchId = b.BatchId), 0)
            - ISNULL((SELECT SUM(BirdQuantity) FROM PoultrySales s WHERE s.BatchId = b.BatchId), 0) AS CurrentBirds,
        ISNULL((SELECT SUM(TotalCost) FROM PoultryFeed f WHERE f.BatchId = b.BatchId), 0) AS FeedCost,
        ISNULL((SELECT SUM(TotalEggs) FROM EggProduction e WHERE e.BatchId = b.BatchId), 0) AS TotalEggs
    FROM PoultryBatches b
    WHERE (@ProjectId IS NULL OR b.ProjectId = @ProjectId)
    ORDER BY b.BatchCode;
END
GO

-- =============================================
-- usp_PoultryDashboard_Eggs (daily egg series)
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultryDashboard_Eggs')
    DROP PROCEDURE usp_PoultryDashboard_Eggs;
GO

CREATE PROCEDURE usp_PoultryDashboard_Eggs
    @ProjectId INT = NULL,
    @FromDate DATE = NULL,
    @ToDate DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SELECT e.ProductionDate,
        SUM(e.GoodEggs) AS GoodEggs,
        SUM(e.BrokenEggs) AS BrokenEggs,
        SUM(e.TotalEggs) AS TotalEggs
    FROM EggProduction e
    INNER JOIN PoultryBatches b ON e.BatchId = b.BatchId
    WHERE (@ProjectId IS NULL OR b.ProjectId = @ProjectId)
    AND (@FromDate IS NULL OR e.ProductionDate >= @FromDate)
    AND (@ToDate IS NULL OR e.ProductionDate <= @ToDate)
    GROUP BY e.ProductionDate
    ORDER BY e.ProductionDate;
END
GO

-- =============================================
-- usp_Report_FarmWise (Â§100 farm-wise, server-paged)
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Report_FarmWise')
    DROP PROCEDURE usp_Report_FarmWise;
GO

CREATE PROCEDURE usp_Report_FarmWise
    @FarmType NVARCHAR(50) = NULL,
    @ProjectId INT = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @TotalRecords INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@PageNumber IS NULL OR @PageNumber < 1) SET @PageNumber = 1;
    IF (@PageSize IS NULL OR @PageSize < 1) SET @PageSize = 10;
    IF (@PageSize > 100) SET @PageSize = 100;
    IF (LTRIM(RTRIM(ISNULL(@FarmType, ''))) = '') SET @FarmType = NULL;

    SELECT @TotalRecords = COUNT(*)
    FROM vw_FarmProfitability v
    WHERE (@FarmType IS NULL OR v.FarmType = @FarmType)
    AND (@ProjectId IS NULL OR v.ProjectId = @ProjectId);

    SELECT v.FarmType, v.ProjectId, p.ProjectCode, v.ProjectName,
        ISNULL((SELECT SUM(BudgetAmount) FROM ProjectBudgets b WHERE b.ProjectId = v.ProjectId AND b.IsActive = 1), 0) AS TotalBudget,
        v.TotalExpense, v.TotalRevenue,
        (v.TotalRevenue - v.TotalExpense) AS Profit,
        CASE WHEN v.TotalRevenue = 0 THEN 0 ELSE ((v.TotalRevenue - v.TotalExpense) / v.TotalRevenue) * 100 END AS ProfitPercent
    FROM vw_FarmProfitability v
    INNER JOIN Projects p ON v.ProjectId = p.ProjectId
    WHERE (@FarmType IS NULL OR v.FarmType = @FarmType)
    AND (@ProjectId IS NULL OR v.ProjectId = @ProjectId)
    ORDER BY v.ProjectName
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

-- =============================================
-- usp_Report_Fish (Â§100 fish farming report, server-paged)
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Report_Fish')
    DROP PROCEDURE usp_Report_Fish;
GO

CREATE PROCEDURE usp_Report_Fish
    @ProjectId INT = NULL,
    @PondId INT = NULL,
    @FishTypeId INT = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @TotalRecords INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@PageNumber IS NULL OR @PageNumber < 1) SET @PageNumber = 1;
    IF (@PageSize IS NULL OR @PageSize < 1) SET @PageSize = 10;
    IF (@PageSize > 100) SET @PageSize = 100;

        SELECT @TotalRecords = COUNT(*) FROM (
        SELECT s.PondId, s.FishTypeId
        FROM FishStocking s
        INNER JOIN Ponds p ON s.PondId = p.PondId
        WHERE (@ProjectId IS NULL OR p.ProjectId = @ProjectId)
        AND (@PondId IS NULL OR s.PondId = @PondId)
        AND (@FishTypeId IS NULL OR s.FishTypeId = @FishTypeId)
        GROUP BY s.PondId, s.FishTypeId
    ) AS B;

    SELECT b.ProjectId, b.ProjectCode, b.ProjectName, b.PondId, b.PondCode, b.PondName,
        b.FishTypeId, b.FishName,
        ISNULL((SELECT SUM(Quantity) FROM FishStocking s WHERE s.PondId = b.PondId AND s.FishTypeId = b.FishTypeId), 0) AS StockedQuantity,
        ISNULL((SELECT SUM(Quantity) FROM FishMortality m WHERE m.PondId = b.PondId AND m.FishTypeId = b.FishTypeId), 0) AS Mortality,
        ISNULL((SELECT SUM(Quantity) FROM FishStocking s WHERE s.PondId = b.PondId AND s.FishTypeId = b.FishTypeId), 0)
        - ISNULL((SELECT SUM(Quantity) FROM FishMortality m WHERE m.PondId = b.PondId AND m.FishTypeId = b.FishTypeId), 0)
        - ISNULL((SELECT SUM(Quantity) FROM FishHarvest h WHERE h.PondId = b.PondId AND h.FishTypeId = b.FishTypeId), 0) AS CurrentStock,
        ISNULL((SELECT SUM(Quantity) FROM FishHarvest h WHERE h.PondId = b.PondId AND h.FishTypeId = b.FishTypeId), 0) AS HarvestQuantity,
        ISNULL((SELECT SUM(TotalWeight) FROM FishHarvest h WHERE h.PondId = b.PondId AND h.FishTypeId = b.FishTypeId), 0) AS HarvestWeight,
        ISNULL((SELECT SUM(s2.TotalAmount) FROM FishSales s2 WHERE s2.ProjectId = b.ProjectId AND s2.FishTypeId = b.FishTypeId), 0) AS Sales,
        ISNULL((SELECT SUM(s3.TotalCost) FROM FishStocking s3 WHERE s3.PondId = b.PondId AND s3.FishTypeId = b.FishTypeId), 0)
        + ISNULL((SELECT SUM(f2.TotalCost) FROM FishFeed f2 WHERE f2.PondId = b.PondId), 0)
        + ISNULL((SELECT SUM(t2.Cost) FROM FishTreatment t2 WHERE t2.PondId = b.PondId), 0)
        + ISNULL((SELECT SUM(h2.HarvestCost) FROM FishHarvest h2 WHERE h2.PondId = b.PondId AND h2.FishTypeId = b.FishTypeId), 0) AS Expense
    FROM (
        SELECT p.ProjectId, pr.ProjectCode, pr.ProjectName,
            s.PondId, p.PondCode, p.PondName,
            s.FishTypeId, f.FishName
        FROM FishStocking s
        INNER JOIN Ponds p ON s.PondId = p.PondId
        INNER JOIN Projects pr ON p.ProjectId = pr.ProjectId
        INNER JOIN FishTypes f ON s.FishTypeId = f.FishTypeId
        WHERE (@ProjectId IS NULL OR p.ProjectId = @ProjectId)
        AND (@PondId IS NULL OR s.PondId = @PondId)
        AND (@FishTypeId IS NULL OR s.FishTypeId = @FishTypeId)
        GROUP BY p.ProjectId, pr.ProjectCode, pr.ProjectName, s.PondId, p.PondCode, p.PondName, s.FishTypeId, f.FishName
    ) AS b
    ORDER BY b.ProjectName, b.PondCode, b.FishName
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

-- =============================================
-- usp_Report_Poultry (Â§100 poultry report, server-paged)
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Report_Poultry')
    DROP PROCEDURE usp_Report_Poultry;
GO

CREATE PROCEDURE usp_Report_Poultry
    @ProjectId INT = NULL,
    @ShedId INT = NULL,
    @BatchId INT = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @TotalRecords INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@PageNumber IS NULL OR @PageNumber < 1) SET @PageNumber = 1;
    IF (@PageSize IS NULL OR @PageSize < 1) SET @PageSize = 10;
    IF (@PageSize > 100) SET @PageSize = 100;

    SELECT @TotalRecords = COUNT(*)
    FROM PoultryBatches b
    WHERE (@ProjectId IS NULL OR b.ProjectId = @ProjectId)
    AND (@ShedId IS NULL OR b.ShedId = @ShedId)
    AND (@BatchId IS NULL OR b.BatchId = @BatchId);

    SELECT b.ProjectId, pr.ProjectCode, pr.ProjectName,
        b.ShedId, s.ShedCode, s.ShedName,
        b.BatchId, b.BatchCode, b.BirdType,
        b.InitialQuantity,
        ISNULL((SELECT SUM(Quantity) FROM PoultryMortality m WHERE m.BatchId = b.BatchId), 0) AS Mortality,
        b.InitialQuantity
            - ISNULL((SELECT SUM(Quantity) FROM PoultryMortality m WHERE m.BatchId = b.BatchId), 0)
            - ISNULL((SELECT SUM(BirdQuantity) FROM PoultrySales ps WHERE ps.BatchId = b.BatchId), 0) AS CurrentBirds,
        ISNULL((SELECT SUM(TotalCost) FROM PoultryFeed f WHERE f.BatchId = b.BatchId), 0) AS FeedCost,
        (SELECT TOP 1 AverageWeight FROM PoultryGrowth g WHERE g.BatchId = b.BatchId ORDER BY g.SampleDate DESC, g.GrowthId DESC) AS LatestAvgWeight,
        ISNULL((SELECT SUM(TotalEggs) FROM EggProduction e WHERE e.BatchId = b.BatchId), 0) AS Eggs,
        ISNULL((SELECT SUM(BirdQuantity) FROM PoultrySales ps WHERE ps.BatchId = b.BatchId), 0) AS BirdSales,
        ISNULL((SELECT SUM(TotalAmount) FROM PoultrySales ps WHERE ps.BatchId = b.BatchId), 0) AS BirdRevenue,
        ISNULL((SELECT SUM(e.Amount) FROM Expenses e WHERE e.FarmEntityType = 'PoultryBatch' AND e.FarmEntityId = b.BatchId AND e.IsDeleted = 0), 0)
        + ISNULL((SELECT SUM(TotalAmount) FROM ChickPurchase c WHERE c.BatchId = b.BatchId), 0)
        + ISNULL((SELECT SUM(TotalCost) FROM PoultryFeed f WHERE f.BatchId = b.BatchId), 0)
        + ISNULL((SELECT SUM(Cost) FROM PoultryTreatment t WHERE t.BatchId = b.BatchId), 0) AS Expense
    FROM PoultryBatches b
    INNER JOIN Projects pr ON b.ProjectId = pr.ProjectId
    INNER JOIN PoultrySheds s ON b.ShedId = s.ShedId
    WHERE (@ProjectId IS NULL OR b.ProjectId = @ProjectId)
    AND (@ShedId IS NULL OR b.ShedId = @ShedId)
    AND (@BatchId IS NULL OR b.BatchId = @BatchId)
    ORDER BY pr.ProjectName, s.ShedCode, b.BatchCode
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

-- =============================================
-- usp_Report_Feed (Â§100 feed consumption, both farm types)
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Report_Feed')
    DROP PROCEDURE usp_Report_Feed;
GO

CREATE PROCEDURE usp_Report_Feed
    @FarmType NVARCHAR(50) = NULL,
    @ProjectId INT = NULL,
    @PondId INT = NULL,
    @BatchId INT = NULL,
    @FeedType NVARCHAR(50) = NULL,
    @FromDate DATE = NULL,
    @ToDate DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF (LTRIM(RTRIM(ISNULL(@FarmType, ''))) = '') SET @FarmType = NULL;
    IF (LTRIM(RTRIM(ISNULL(@FeedType, ''))) = '') SET @FeedType = NULL;

    SELECT 'Fish Farming' AS FarmType, p.ProjectId, pr.ProjectName, f.PondId AS EntityId,
        p.PondCode AS EntityCode, f.FeedDate AS TxnDate, f.FeedType, f.Quantity, f.Unit, f.Rate, f.TotalCost
    FROM FishFeed f
    INNER JOIN Ponds p ON f.PondId = p.PondId
    INNER JOIN Projects pr ON p.ProjectId = pr.ProjectId
    WHERE (@FarmType IS NULL OR @FarmType = 'Fish Farming')
    AND (@ProjectId IS NULL OR p.ProjectId = @ProjectId)
    AND (@PondId IS NULL OR f.PondId = @PondId)
    AND (@FeedType IS NULL OR f.FeedType = @FeedType)
    AND (@FromDate IS NULL OR f.FeedDate >= @FromDate)
    AND (@ToDate IS NULL OR f.FeedDate <= @ToDate)
    UNION ALL
    SELECT 'Poultry Farming' AS FarmType, b.ProjectId, pr.ProjectName, f.BatchId AS EntityId,
        b.BatchCode AS EntityCode, f.FeedDate AS TxnDate, f.FeedType, f.Quantity, f.Unit, f.Rate, f.TotalCost
    FROM PoultryFeed f
    INNER JOIN PoultryBatches b ON f.BatchId = b.BatchId
    INNER JOIN Projects pr ON b.ProjectId = pr.ProjectId
    WHERE (@FarmType IS NULL OR @FarmType = 'Poultry Farming')
    AND (@ProjectId IS NULL OR b.ProjectId = @ProjectId)
    AND (@BatchId IS NULL OR f.BatchId = @BatchId)
    AND (@FeedType IS NULL OR f.FeedType = @FeedType)
    AND (@FromDate IS NULL OR f.FeedDate >= @FromDate)
    AND (@ToDate IS NULL OR f.FeedDate <= @ToDate)
    ORDER BY TxnDate DESC;
END
GO

-- =============================================
-- usp_Report_Mortality (Â§100 mortality, both farm types)
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Report_Mortality')
    DROP PROCEDURE usp_Report_Mortality;
GO

CREATE PROCEDURE usp_Report_Mortality
    @FarmType NVARCHAR(50) = NULL,
    @ProjectId INT = NULL,
    @PondId INT = NULL,
    @BatchId INT = NULL,
    @FromDate DATE = NULL,
    @ToDate DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF (LTRIM(RTRIM(ISNULL(@FarmType, ''))) = '') SET @FarmType = NULL;

    SELECT 'Fish Farming' AS FarmType, p.ProjectId, pr.ProjectName, m.PondId AS EntityId,
        p.PondCode AS EntityCode, f.FishName AS SubType, m.MortalityDate AS TxnDate, m.Quantity, m.Reason
    FROM FishMortality m
    INNER JOIN Ponds p ON m.PondId = p.PondId
    INNER JOIN Projects pr ON p.ProjectId = pr.ProjectId
    INNER JOIN FishTypes f ON m.FishTypeId = f.FishTypeId
    WHERE (@FarmType IS NULL OR @FarmType = 'Fish Farming')
    AND (@ProjectId IS NULL OR p.ProjectId = @ProjectId)
    AND (@PondId IS NULL OR m.PondId = @PondId)
    AND (@FromDate IS NULL OR m.MortalityDate >= @FromDate)
    AND (@ToDate IS NULL OR m.MortalityDate <= @ToDate)
    UNION ALL
    SELECT 'Poultry Farming' AS FarmType, b.ProjectId, pr.ProjectName, m.BatchId AS EntityId,
        b.BatchCode AS EntityCode, b.BirdType AS SubType, m.MortalityDate AS TxnDate, m.Quantity, m.Reason
    FROM PoultryMortality m
    INNER JOIN PoultryBatches b ON m.BatchId = b.BatchId
    INNER JOIN Projects pr ON b.ProjectId = pr.ProjectId
    WHERE (@FarmType IS NULL OR @FarmType = 'Poultry Farming')
    AND (@ProjectId IS NULL OR b.ProjectId = @ProjectId)
    AND (@BatchId IS NULL OR m.BatchId = @BatchId)
    AND (@FromDate IS NULL OR m.MortalityDate >= @FromDate)
    AND (@ToDate IS NULL OR m.MortalityDate <= @ToDate)
    ORDER BY TxnDate DESC;
END
GO

-- =============================================
-- usp_Report_Profitability (Â§95)
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Report_Profitability')
    DROP PROCEDURE usp_Report_Profitability;
GO

CREATE PROCEDURE usp_Report_Profitability
    @ProjectId INT = NULL,
    @FarmType NVARCHAR(50) = NULL,
    @FromDate DATE = NULL,
    @ToDate DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF (LTRIM(RTRIM(ISNULL(@FarmType, ''))) = '') SET @FarmType = NULL;

    SELECT
        ISNULL((SELECT SUM(r.Amount) FROM Revenue r
            INNER JOIN Projects p ON r.ProjectId = p.ProjectId
            WHERE r.IsDeleted = 0
            AND (@ProjectId IS NULL OR r.ProjectId = @ProjectId)
            AND (@FarmType IS NULL OR r.FarmType = @FarmType OR p.FarmType = @FarmType)
            AND (@FromDate IS NULL OR r.RevenueDate >= @FromDate)
            AND (@ToDate IS NULL OR r.RevenueDate <= @ToDate)), 0) AS TotalRevenue,
        ISNULL((SELECT SUM(e.Amount) FROM Expenses e
            INNER JOIN Projects p ON e.ProjectId = p.ProjectId
            WHERE e.IsDeleted = 0
            AND (@ProjectId IS NULL OR e.ProjectId = @ProjectId)
            AND (@FarmType IS NULL OR e.FarmType = @FarmType OR p.FarmType = @FarmType)
            AND (@FromDate IS NULL OR e.ExpenseDate >= @FromDate)
            AND (@ToDate IS NULL OR e.ExpenseDate <= @ToDate)), 0) AS TotalExpense,
        ISNULL((SELECT SUM(r.Amount) FROM Revenue r
            INNER JOIN Projects p ON r.ProjectId = p.ProjectId
            WHERE r.IsDeleted = 0 AND r.RevenueType = 'Fish Sale'
            AND (@ProjectId IS NULL OR r.ProjectId = @ProjectId)
            AND (@FarmType IS NULL OR @FarmType = 'Fish Farming' OR p.FarmType = @FarmType)
            AND (@FromDate IS NULL OR r.RevenueDate >= @FromDate)
            AND (@ToDate IS NULL OR r.RevenueDate <= @ToDate)), 0) AS FishRevenue,
        ISNULL((SELECT SUM(r.Amount) FROM Revenue r
            INNER JOIN Projects p ON r.ProjectId = p.ProjectId
            WHERE r.IsDeleted = 0 AND r.RevenueType = 'Poultry Sale'
            AND (@ProjectId IS NULL OR r.ProjectId = @ProjectId)
            AND (@FarmType IS NULL OR @FarmType = 'Poultry Farming' OR p.FarmType = @FarmType)
            AND (@FromDate IS NULL OR r.RevenueDate >= @FromDate)
            AND (@ToDate IS NULL OR r.RevenueDate <= @ToDate)), 0) AS PoultryRevenue,
        ISNULL((SELECT SUM(r.Amount) FROM Revenue r
            INNER JOIN Projects p ON r.ProjectId = p.ProjectId
            WHERE r.IsDeleted = 0 AND r.RevenueType = 'Egg Sale'
            AND (@ProjectId IS NULL OR r.ProjectId = @ProjectId)
            AND (@FromDate IS NULL OR r.RevenueDate >= @FromDate)
            AND (@ToDate IS NULL OR r.RevenueDate <= @ToDate)), 0) AS EggRevenue;
END
GO

-- =============================================
-- usp_Report_FarmCostVsBudget (Â§101)
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Report_FarmCostVsBudget')
    DROP PROCEDURE usp_Report_FarmCostVsBudget;
GO

CREATE PROCEDURE usp_Report_FarmCostVsBudget
    @ProjectId INT = NULL,
    @FarmType NVARCHAR(50) = NULL,
    @PondId INT = NULL,
    @BatchId INT = NULL,
    @FromDate DATE = NULL,
    @ToDate DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF (LTRIM(RTRIM(ISNULL(@FarmType, ''))) = '') SET @FarmType = NULL;

    SELECT pr.ProjectId, pr.ProjectCode, pr.ProjectName, pr.FarmType,
        ISNULL((SELECT SUM(BudgetAmount) FROM ProjectBudgets b WHERE b.ProjectId = pr.ProjectId AND b.IsActive = 1), 0) AS TotalBudget,
        ISNULL((SELECT SUM(e.Amount) FROM Expenses e
            WHERE e.ProjectId = pr.ProjectId AND e.IsDeleted = 0
            AND (@FromDate IS NULL OR e.ExpenseDate >= @FromDate)
            AND (@ToDate IS NULL OR e.ExpenseDate <= @ToDate)), 0) AS ActualExpense,
        ISNULL((SELECT SUM(s.TotalCost) FROM FishStocking s INNER JOIN Ponds p ON s.PondId = p.PondId
            WHERE p.ProjectId = pr.ProjectId AND (@PondId IS NULL OR s.PondId = @PondId)), 0)
        + ISNULL((SELECT SUM(f.TotalCost) FROM FishFeed f INNER JOIN Ponds p ON f.PondId = p.PondId
            WHERE p.ProjectId = pr.ProjectId AND (@PondId IS NULL OR f.PondId = @PondId)
            AND (@FromDate IS NULL OR f.FeedDate >= @FromDate) AND (@ToDate IS NULL OR f.FeedDate <= @ToDate)), 0)
        + ISNULL((SELECT SUM(t.Cost) FROM FishTreatment t INNER JOIN Ponds p ON t.PondId = p.PondId
            WHERE p.ProjectId = pr.ProjectId AND (@PondId IS NULL OR t.PondId = @PondId)
            AND (@FromDate IS NULL OR t.TreatmentDate >= @FromDate) AND (@ToDate IS NULL OR t.TreatmentDate <= @ToDate)), 0)
        + ISNULL((SELECT SUM(c.TotalAmount) FROM ChickPurchase c INNER JOIN PoultryBatches b ON c.BatchId = b.BatchId
            WHERE b.ProjectId = pr.ProjectId AND (@BatchId IS NULL OR c.BatchId = @BatchId)), 0)
        + ISNULL((SELECT SUM(f.TotalCost) FROM PoultryFeed f INNER JOIN PoultryBatches b ON f.BatchId = b.BatchId
            WHERE b.ProjectId = pr.ProjectId AND (@BatchId IS NULL OR f.BatchId = @BatchId)
            AND (@FromDate IS NULL OR f.FeedDate >= @FromDate) AND (@ToDate IS NULL OR f.FeedDate <= @ToDate)), 0)
        + ISNULL((SELECT SUM(t.Cost) FROM PoultryTreatment t INNER JOIN PoultryBatches b ON t.BatchId = b.BatchId
            WHERE b.ProjectId = pr.ProjectId AND (@BatchId IS NULL OR t.BatchId = @BatchId)
            AND (@FromDate IS NULL OR t.TreatmentDate >= @FromDate) AND (@ToDate IS NULL OR t.TreatmentDate <= @ToDate)), 0) AS OperationalCost
    FROM Projects pr
    WHERE (@ProjectId IS NULL OR pr.ProjectId = @ProjectId)
    AND (@FarmType IS NULL OR pr.FarmType = @FarmType)
    ORDER BY pr.ProjectCode;
END
GO

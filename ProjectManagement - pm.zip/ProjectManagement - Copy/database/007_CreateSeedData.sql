USE ProjectManagementDB;
GO

-- =============================================
-- Seed Data: Roles
-- =============================================
IF NOT EXISTS (SELECT 1 FROM Roles WHERE RoleName = 'Admin')
    INSERT INTO Roles (RoleName, Description) VALUES ('Admin', 'Administrator with full access');

IF NOT EXISTS (SELECT 1 FROM Roles WHERE RoleName = 'User')
    INSERT INTO Roles (RoleName, Description) VALUES ('User', 'Normal user with permission-based access');

IF NOT EXISTS (SELECT 1 FROM Roles WHERE RoleName = 'Super Admin')
    INSERT INTO Roles (RoleName, Description) VALUES ('Super Admin', 'Super administrator with full access. Only one user can hold this role and it cannot be deactivated.');
GO

-- =============================================
-- Seed Data: Pages
-- =============================================
IF NOT EXISTS (SELECT 1 FROM Pages WHERE PageName = 'Dashboard')
    INSERT INTO Pages (PageName, PageDescription) VALUES ('Dashboard', 'Dashboard and analytics');

IF NOT EXISTS (SELECT 1 FROM Pages WHERE PageName = 'Projects')
    INSERT INTO Pages (PageName, PageDescription) VALUES ('Projects', 'Project management');

IF NOT EXISTS (SELECT 1 FROM Pages WHERE PageName = 'Budget Codes')
    INSERT INTO Pages (PageName, PageDescription) VALUES ('Budget Codes', 'Budget code management');

IF NOT EXISTS (SELECT 1 FROM Pages WHERE PageName = 'Project Budgets')
    INSERT INTO Pages (PageName, PageDescription) VALUES ('Project Budgets', 'Project budget management');

IF NOT EXISTS (SELECT 1 FROM Pages WHERE PageName = 'Resources')
    INSERT INTO Pages (PageName, PageDescription) VALUES ('Resources', 'Resource management');

IF NOT EXISTS (SELECT 1 FROM Pages WHERE PageName = 'Project Resources')
    INSERT INTO Pages (PageName, PageDescription) VALUES ('Project Resources', 'Project resource assignment');

IF NOT EXISTS (SELECT 1 FROM Pages WHERE PageName = 'Expenses')
    INSERT INTO Pages (PageName, PageDescription) VALUES ('Expenses', 'Daily expense management');

IF NOT EXISTS (SELECT 1 FROM Pages WHERE PageName = 'Cost Vs Budget')
    INSERT INTO Pages (PageName, PageDescription) VALUES ('Cost Vs Budget', 'Cost vs budget analysis');

IF NOT EXISTS (SELECT 1 FROM Pages WHERE PageName = 'Reports')
    INSERT INTO Pages (PageName, PageDescription) VALUES ('Reports', 'Reports and exports');

IF NOT EXISTS (SELECT 1 FROM Pages WHERE PageName = 'Users')
    INSERT INTO Pages (PageName, PageDescription) VALUES ('Users', 'User management');

IF NOT EXISTS (SELECT 1 FROM Pages WHERE PageName = 'Permissions')
    INSERT INTO Pages (PageName, PageDescription) VALUES ('Permissions', 'Permission management');
GO

-- =============================================
-- Seed Data: Budget Codes
-- =============================================
IF NOT EXISTS (SELECT 1 FROM BudgetCodes WHERE BudgetCode = 'BC001')
    INSERT INTO BudgetCodes (BudgetCode, BudgetCodeName, Description, IsActive, CreatedBy, CreatedDate)
    VALUES ('BC001', 'Travel', 'Travel expenses including airfare, taxi, etc.', 1, 1, GETDATE());

IF NOT EXISTS (SELECT 1 FROM BudgetCodes WHERE BudgetCode = 'BC002')
    INSERT INTO BudgetCodes (BudgetCode, BudgetCodeName, Description, IsActive, CreatedBy, CreatedDate)
    VALUES ('BC002', 'Accommodation', 'Hotel and accommodation expenses', 1, 1, GETDATE());

IF NOT EXISTS (SELECT 1 FROM BudgetCodes WHERE BudgetCode = 'BC003')
    INSERT INTO BudgetCodes (BudgetCode, BudgetCodeName, Description, IsActive, CreatedBy, CreatedDate)
    VALUES ('BC003', 'Food', 'Food and meal expenses', 1, 1, GETDATE());

IF NOT EXISTS (SELECT 1 FROM BudgetCodes WHERE BudgetCode = 'BC004')
    INSERT INTO BudgetCodes (BudgetCode, BudgetCodeName, Description, IsActive, CreatedBy, CreatedDate)
    VALUES ('BC004', 'Material', 'Material and supply expenses', 1, 1, GETDATE());

IF NOT EXISTS (SELECT 1 FROM BudgetCodes WHERE BudgetCode = 'BC005')
    INSERT INTO BudgetCodes (BudgetCode, BudgetCodeName, Description, IsActive, CreatedBy, CreatedDate)
    VALUES ('BC005', 'Transportation', 'Local transportation expenses', 1, 1, GETDATE());

IF NOT EXISTS (SELECT 1 FROM BudgetCodes WHERE BudgetCode = 'BC006')
    INSERT INTO BudgetCodes (BudgetCode, BudgetCodeName, Description, IsActive, CreatedBy, CreatedDate)
    VALUES ('BC006', 'Software', 'Software and license expenses', 1, 1, GETDATE());

IF NOT EXISTS (SELECT 1 FROM BudgetCodes WHERE BudgetCode = 'BC007')
    INSERT INTO BudgetCodes (BudgetCode, BudgetCodeName, Description, IsActive, CreatedBy, CreatedDate)
    VALUES ('BC007', 'Hardware', 'Hardware and equipment expenses', 1, 1, GETDATE());

IF NOT EXISTS (SELECT 1 FROM BudgetCodes WHERE BudgetCode = 'BC008')
    INSERT INTO BudgetCodes (BudgetCode, BudgetCodeName, Description, IsActive, CreatedBy, CreatedDate)
    VALUES ('BC008', 'Miscellaneous', 'Other miscellaneous expenses', 1, 1, GETDATE());
GO

-- =============================================
-- Seed Data: Resources
-- =============================================
IF NOT EXISTS (SELECT 1 FROM Resources WHERE ResourceCode = 'RES001')
    INSERT INTO Resources (ResourceCode, ResourceName, ResourceType, Email, Phone, Department, IsActive, CreatedBy, CreatedDate)
    VALUES ('RES001', 'Resource One', 'Employee', 'resource1@example.com', '1234567890', 'IT', 1, 1, GETDATE());

IF NOT EXISTS (SELECT 1 FROM Resources WHERE ResourceCode = 'RES002')
    INSERT INTO Resources (ResourceCode, ResourceName, ResourceType, Email, Phone, Department, IsActive, CreatedBy, CreatedDate)
    VALUES ('RES002', 'Resource Two', 'Contractor', 'resource2@example.com', '1234567891', 'Finance', 1, 1, GETDATE());

IF NOT EXISTS (SELECT 1 FROM Resources WHERE ResourceCode = 'RES003')
    INSERT INTO Resources (ResourceCode, ResourceName, ResourceType, Email, Phone, Department, IsActive, CreatedBy, CreatedDate)
    VALUES ('RES003', 'Resource Three', 'Vendor', 'resource3@example.com', '1234567892', 'Operations', 1, 1, GETDATE());
GO

-- =============================================
-- Seed Data: Projects
-- =============================================
IF NOT EXISTS (SELECT 1 FROM Projects WHERE ProjectCode = 'PRJ001')
    INSERT INTO Projects (ProjectCode, ProjectName, Description, ClientName, StartDate, EndDate, TotalBudget, Status, IsActive, CreatedBy, CreatedDate)
    VALUES ('PRJ001', 'Project Alpha', 'First sample project for testing', 'Client A', '2026-01-01', '2026-12-31', 100000.00, 'Active', 1, 1, GETDATE());

IF NOT EXISTS (SELECT 1 FROM Projects WHERE ProjectCode = 'PRJ002')
    INSERT INTO Projects (ProjectCode, ProjectName, Description, ClientName, StartDate, EndDate, TotalBudget, Status, IsActive, CreatedBy, CreatedDate)
    VALUES ('PRJ002', 'Project Beta', 'Second sample project for testing', 'Client B', '2026-02-01', '2026-11-30', 150000.00, 'Active', 1, 1, GETDATE());

IF NOT EXISTS (SELECT 1 FROM Projects WHERE ProjectCode = 'PRJ003')
    INSERT INTO Projects (ProjectCode, ProjectName, Description, ClientName, StartDate, EndDate, TotalBudget, Status, IsActive, CreatedBy, CreatedDate)
    VALUES ('PRJ003', 'Project Gamma', 'Third sample project for testing', 'Client C', '2026-03-01', '2026-10-31', 200000.00, 'Planning', 1, 1, GETDATE());
GO

-- =============================================
-- Seed Data: Project Budgets (ID-agnostic via code lookups)
-- =============================================
DECLARE @P1 INT = (SELECT TOP 1 ProjectId FROM Projects WHERE ProjectCode='PRJ001');
DECLARE @P2 INT = (SELECT TOP 1 ProjectId FROM Projects WHERE ProjectCode='PRJ002');
DECLARE @P3 INT = (SELECT TOP 1 ProjectId FROM Projects WHERE ProjectCode='PRJ003');
DECLARE @B1 INT = (SELECT TOP 1 BudgetCodeId FROM BudgetCodes WHERE BudgetCode='BC001');
DECLARE @B2 INT = (SELECT TOP 1 BudgetCodeId FROM BudgetCodes WHERE BudgetCode='BC002');
DECLARE @B3 INT = (SELECT TOP 1 BudgetCodeId FROM BudgetCodes WHERE BudgetCode='BC003');
DECLARE @B4 INT = (SELECT TOP 1 BudgetCodeId FROM BudgetCodes WHERE BudgetCode='BC004');
DECLARE @B5 INT = (SELECT TOP 1 BudgetCodeId FROM BudgetCodes WHERE BudgetCode='BC005');
DECLARE @R1 INT = (SELECT TOP 1 ResourceId FROM Resources WHERE ResourceCode='RES001');
DECLARE @R2 INT = (SELECT TOP 1 ResourceId FROM Resources WHERE ResourceCode='RES002');
DECLARE @R3 INT = (SELECT TOP 1 ResourceId FROM Resources WHERE ResourceCode='RES003');

IF @P1 IS NOT NULL AND @B1 IS NOT NULL AND NOT EXISTS (SELECT 1 FROM ProjectBudgets WHERE ProjectId=@P1 AND BudgetCodeId=@B1)
    INSERT INTO ProjectBudgets (ProjectId, BudgetCodeId, BudgetAmount, EffectiveFrom, EffectiveTo, IsActive, CreatedBy, CreatedDate)
    VALUES (@P1, @B1, 20000.00, '2026-01-01', '2026-12-31', 1, 1, GETDATE());

IF @P1 IS NOT NULL AND @B2 IS NOT NULL AND NOT EXISTS (SELECT 1 FROM ProjectBudgets WHERE ProjectId=@P1 AND BudgetCodeId=@B2)
    INSERT INTO ProjectBudgets (ProjectId, BudgetCodeId, BudgetAmount, EffectiveFrom, EffectiveTo, IsActive, CreatedBy, CreatedDate)
    VALUES (@P1, @B2, 15000.00, '2026-01-01', '2026-12-31', 1, 1, GETDATE());

IF @P1 IS NOT NULL AND @B3 IS NOT NULL AND NOT EXISTS (SELECT 1 FROM ProjectBudgets WHERE ProjectId=@P1 AND BudgetCodeId=@B3)
    INSERT INTO ProjectBudgets (ProjectId, BudgetCodeId, BudgetAmount, EffectiveFrom, EffectiveTo, IsActive, CreatedBy, CreatedDate)
    VALUES (@P1, @B3, 10000.00, '2026-01-01', '2026-12-31', 1, 1, GETDATE());

IF @P2 IS NOT NULL AND @B1 IS NOT NULL AND NOT EXISTS (SELECT 1 FROM ProjectBudgets WHERE ProjectId=@P2 AND BudgetCodeId=@B1)
    INSERT INTO ProjectBudgets (ProjectId, BudgetCodeId, BudgetAmount, EffectiveFrom, EffectiveTo, IsActive, CreatedBy, CreatedDate)
    VALUES (@P2, @B1, 25000.00, '2026-02-01', '2026-11-30', 1, 1, GETDATE());

IF @P2 IS NOT NULL AND @B4 IS NOT NULL AND NOT EXISTS (SELECT 1 FROM ProjectBudgets WHERE ProjectId=@P2 AND BudgetCodeId=@B4)
    INSERT INTO ProjectBudgets (ProjectId, BudgetCodeId, BudgetAmount, EffectiveFrom, EffectiveTo, IsActive, CreatedBy, CreatedDate)
    VALUES (@P2, @B4, 30000.00, '2026-02-01', '2026-11-30', 1, 1, GETDATE());

IF @P3 IS NOT NULL AND @B5 IS NOT NULL AND NOT EXISTS (SELECT 1 FROM ProjectBudgets WHERE ProjectId=@P3 AND BudgetCodeId=@B5)
    INSERT INTO ProjectBudgets (ProjectId, BudgetCodeId, BudgetAmount, EffectiveFrom, EffectiveTo, IsActive, CreatedBy, CreatedDate)
    VALUES (@P3, @B5, 40000.00, '2026-03-01', '2026-10-31', 1, 1, GETDATE());
GO

-- =============================================
-- Seed Data: Project Resources (ID-agnostic)
-- =============================================
DECLARE @PP1 INT = (SELECT TOP 1 ProjectId FROM Projects WHERE ProjectCode='PRJ001');
DECLARE @PP2 INT = (SELECT TOP 1 ProjectId FROM Projects WHERE ProjectCode='PRJ002');
DECLARE @PP3 INT = (SELECT TOP 1 ProjectId FROM Projects WHERE ProjectCode='PRJ003');
DECLARE @RR1 INT = (SELECT TOP 1 ResourceId FROM Resources WHERE ResourceCode='RES001');
DECLARE @RR2 INT = (SELECT TOP 1 ResourceId FROM Resources WHERE ResourceCode='RES002');
DECLARE @RR3 INT = (SELECT TOP 1 ResourceId FROM Resources WHERE ResourceCode='RES003');

IF @PP1 IS NOT NULL AND @RR1 IS NOT NULL AND NOT EXISTS (SELECT 1 FROM ProjectResources WHERE ProjectId=@PP1 AND ResourceId=@RR1)
    INSERT INTO ProjectResources (ProjectId, ResourceId, AssignedFrom, AssignedTo, IsActive, CreatedBy, CreatedDate)
    VALUES (@PP1, @RR1, '2026-01-01', '2026-12-31', 1, 1, GETDATE());

IF @PP1 IS NOT NULL AND @RR2 IS NOT NULL AND NOT EXISTS (SELECT 1 FROM ProjectResources WHERE ProjectId=@PP1 AND ResourceId=@RR2)
    INSERT INTO ProjectResources (ProjectId, ResourceId, AssignedFrom, AssignedTo, IsActive, CreatedBy, CreatedDate)
    VALUES (@PP1, @RR2, '2026-01-01', '2026-12-31', 1, 1, GETDATE());

IF @PP2 IS NOT NULL AND @RR2 IS NOT NULL AND NOT EXISTS (SELECT 1 FROM ProjectResources WHERE ProjectId=@PP2 AND ResourceId=@RR2)
    INSERT INTO ProjectResources (ProjectId, ResourceId, AssignedFrom, AssignedTo, IsActive, CreatedBy, CreatedDate)
    VALUES (@PP2, @RR2, '2026-02-01', '2026-11-30', 1, 1, GETDATE());

IF @PP2 IS NOT NULL AND @RR3 IS NOT NULL AND NOT EXISTS (SELECT 1 FROM ProjectResources WHERE ProjectId=@PP2 AND ResourceId=@RR3)
    INSERT INTO ProjectResources (ProjectId, ResourceId, AssignedFrom, AssignedTo, IsActive, CreatedBy, CreatedDate)
    VALUES (@PP2, @RR3, '2026-02-01', '2026-11-30', 1, 1, GETDATE());

IF @PP3 IS NOT NULL AND @RR1 IS NOT NULL AND NOT EXISTS (SELECT 1 FROM ProjectResources WHERE ProjectId=@PP3 AND ResourceId=@RR1)
    INSERT INTO ProjectResources (ProjectId, ResourceId, AssignedFrom, AssignedTo, IsActive, CreatedBy, CreatedDate)
    VALUES (@PP3, @RR1, '2026-03-01', '2026-10-31', 1, 1, GETDATE());
GO

-- =============================================
-- Seed Data: Sample Expenses (ID-agnostic, keyed by ReferenceNo)
-- =============================================
DECLARE @EP1 INT = (SELECT TOP 1 ProjectId FROM Projects WHERE ProjectCode='PRJ001');
DECLARE @EP2 INT = (SELECT TOP 1 ProjectId FROM Projects WHERE ProjectCode='PRJ002');
DECLARE @EP3 INT = (SELECT TOP 1 ProjectId FROM Projects WHERE ProjectCode='PRJ003');
DECLARE @EB1 INT = (SELECT TOP 1 BudgetCodeId FROM BudgetCodes WHERE BudgetCode='BC001');
DECLARE @EB2 INT = (SELECT TOP 1 BudgetCodeId FROM BudgetCodes WHERE BudgetCode='BC002');
DECLARE @EB3 INT = (SELECT TOP 1 BudgetCodeId FROM BudgetCodes WHERE BudgetCode='BC003');
DECLARE @EB4 INT = (SELECT TOP 1 BudgetCodeId FROM BudgetCodes WHERE BudgetCode='BC004');
DECLARE @EB5 INT = (SELECT TOP 1 BudgetCodeId FROM BudgetCodes WHERE BudgetCode='BC005');
DECLARE @ER1 INT = (SELECT TOP 1 ResourceId FROM Resources WHERE ResourceCode='RES001');
DECLARE @ER2 INT = (SELECT TOP 1 ResourceId FROM Resources WHERE ResourceCode='RES002');
DECLARE @ER3 INT = (SELECT TOP 1 ResourceId FROM Resources WHERE ResourceCode='RES003');

IF NOT EXISTS (SELECT 1 FROM Expenses WHERE ReferenceNo='REF001')
    INSERT INTO Expenses (ExpenseDate, ProjectId, BudgetCodeId, ResourceId, Amount, Description, ReferenceNo, Remarks, IsDeleted, CreatedBy, CreatedDate)
    VALUES ('2026-09-01', @EP1, @EB1, @ER1, 5000.00, 'Flight tickets for client meeting', 'REF001', 'Business class tickets', 0, 1, GETDATE());

IF NOT EXISTS (SELECT 1 FROM Expenses WHERE ReferenceNo='REF002')
    INSERT INTO Expenses (ExpenseDate, ProjectId, BudgetCodeId, ResourceId, Amount, Description, ReferenceNo, Remarks, IsDeleted, CreatedBy, CreatedDate)
    VALUES ('2026-09-02', @EP1, @EB2, @ER1, 3000.00, 'Hotel accommodation for 2 nights', 'REF002', '5-star hotel', 0, 1, GETDATE());

IF NOT EXISTS (SELECT 1 FROM Expenses WHERE ReferenceNo='REF003')
    INSERT INTO Expenses (ExpenseDate, ProjectId, BudgetCodeId, ResourceId, Amount, Description, ReferenceNo, Remarks, IsDeleted, CreatedBy, CreatedDate)
    VALUES ('2026-09-03', @EP1, @EB3, @ER2, 1500.00, 'Team dinner', 'REF003', 'Client entertainment', 0, 1, GETDATE());

IF NOT EXISTS (SELECT 1 FROM Expenses WHERE ReferenceNo='REF004')
    INSERT INTO Expenses (ExpenseDate, ProjectId, BudgetCodeId, ResourceId, Amount, Description, ReferenceNo, Remarks, IsDeleted, CreatedBy, CreatedDate)
    VALUES ('2026-09-05', @EP2, @EB1, @ER2, 8000.00, 'Train tickets for site visit', 'REF004', 'First class', 0, 1, GETDATE());

IF NOT EXISTS (SELECT 1 FROM Expenses WHERE ReferenceNo='REF005')
    INSERT INTO Expenses (ExpenseDate, ProjectId, BudgetCodeId, ResourceId, Amount, Description, ReferenceNo, Remarks, IsDeleted, CreatedBy, CreatedDate)
    VALUES ('2026-09-06', @EP2, @EB4, @ER3, 12000.00, 'Construction materials', 'REF005', 'Cement and steel', 0, 1, GETDATE());

IF NOT EXISTS (SELECT 1 FROM Expenses WHERE ReferenceNo='REF006')
    INSERT INTO Expenses (ExpenseDate, ProjectId, BudgetCodeId, ResourceId, Amount, Description, ReferenceNo, Remarks, IsDeleted, CreatedBy, CreatedDate)
    VALUES ('2026-09-10', @EP3, @EB5, @ER1, 6000.00, 'Vehicle rental for transportation', 'REF006', 'One week rental', 0, 1, GETDATE());
GO

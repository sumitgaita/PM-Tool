USE ProjectManagementDB;
GO

-- =============================================
-- 022: Completed Projects listing (inactive projects only)
-- Mirrors usp_Project_GetPaged (+ @FarmType as deployed), fixed to
-- IsActive = 0, scoped to assigned projects unless Super Admin.
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Project_GetPagedInactive')
    DROP PROCEDURE usp_Project_GetPagedInactive;
GO

CREATE PROCEDURE usp_Project_GetPagedInactive
    @UserId INT,
    @SearchText NVARCHAR(100) = NULL,
    @Status NVARCHAR(20) = NULL,
    @FarmType NVARCHAR(50) = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @SortBy NVARCHAR(50) = 'projectCode',
    @SortDir NVARCHAR(4) = 'asc',
    @TotalRecords INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@PageNumber IS NULL OR @PageNumber < 1) SET @PageNumber = 1;
    IF (@PageSize IS NULL OR @PageSize < 1) SET @PageSize = 10;
    IF (@PageSize > 100) SET @PageSize = 100;
    SET @SortBy = LOWER(LTRIM(RTRIM(ISNULL(@SortBy, 'projectcode'))));
    IF (@SortBy NOT IN ('projectid', 'projectcode', 'projectname', 'clientname', 'status', 'totalbudget', 'createddate'))
        SET @SortBy = 'projectcode';
    SET @SortDir = LOWER(LTRIM(RTRIM(ISNULL(@SortDir, 'asc'))));
    IF (@SortDir NOT IN ('asc', 'desc'))
        SET @SortDir = 'asc';
    IF (LTRIM(RTRIM(ISNULL(@SearchText, ''))) = '') SET @SearchText = NULL;
    IF (LTRIM(RTRIM(ISNULL(@Status, ''))) = '') SET @Status = NULL;
    IF (LTRIM(RTRIM(ISNULL(@FarmType, ''))) = '') SET @FarmType = NULL;

    DECLARE @IsSuperAdmin BIT = 0;
    IF EXISTS (
        SELECT 1
        FROM Users u
        INNER JOIN Roles r ON r.RoleId = u.RoleId
        WHERE u.UserId = @UserId AND r.RoleName = 'Super Admin'
    )
        SET @IsSuperAdmin = 1;

    SELECT @TotalRecords = COUNT(*)
    FROM Projects p
    WHERE p.IsActive = 0
    AND (@SearchText IS NULL OR p.ProjectCode LIKE '%' + @SearchText + '%' OR p.ProjectName LIKE '%' + @SearchText + '%')
    AND (@Status IS NULL OR p.Status = @Status)
    AND (@FarmType IS NULL OR p.FarmType = @FarmType)
    AND (@IsSuperAdmin = 1 OR EXISTS (SELECT 1 FROM UserProjects up WHERE up.UserId = @UserId AND up.ProjectId = p.ProjectId));

    SELECT
        p.ProjectId,
        p.ProjectCode,
        p.ProjectName,
        p.Description,
        p.ClientName,
        p.StartDate,
        p.EndDate,
        p.TotalBudget,
        p.Status,
        p.FarmType,
        p.IsActive,
        p.CreatedBy,
        p.CreatedDate,
        p.ModifiedBy,
        p.ModifiedDate
    FROM Projects p
    WHERE p.IsActive = 0
    AND (@SearchText IS NULL OR p.ProjectCode LIKE '%' + @SearchText + '%' OR p.ProjectName LIKE '%' + @SearchText + '%')
    AND (@Status IS NULL OR p.Status = @Status)
    AND (@FarmType IS NULL OR p.FarmType = @FarmType)
    AND (@IsSuperAdmin = 1 OR EXISTS (SELECT 1 FROM UserProjects up WHERE up.UserId = @UserId AND up.ProjectId = p.ProjectId))
    ORDER BY
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'projectid' THEN p.ProjectId END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'projectid' THEN p.ProjectId END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'projectcode' THEN p.ProjectCode END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'projectcode' THEN p.ProjectCode END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'projectname' THEN p.ProjectName END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'projectname' THEN p.ProjectName END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'clientname' THEN p.ClientName END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'clientname' THEN p.ClientName END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'status' THEN p.Status END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'status' THEN p.Status END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'totalbudget' THEN p.TotalBudget END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'totalbudget' THEN p.TotalBudget END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'createddate' THEN p.CreatedDate END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'createddate' THEN p.CreatedDate END DESC,
        p.ProjectCode ASC
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

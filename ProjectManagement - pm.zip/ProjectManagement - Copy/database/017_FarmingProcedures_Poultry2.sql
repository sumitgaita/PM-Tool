USE ProjectManagementDB;
GO

-- =============================================
-- Poultry mortality/growth/eggs/sales + Revenue (§103-§104, §87-§90, §94).
-- Continues 016. Bird-stock rules enforced; sales auto-post Revenue.
-- =============================================

-- =============================================
-- usp_PoultryMortality_Insert / Update / Delete
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultryMortality_Insert')
    DROP PROCEDURE usp_PoultryMortality_Insert;
GO

CREATE PROCEDURE usp_PoultryMortality_Insert
    @BatchId INT,
    @MortalityDate DATE,
    @Quantity INT,
    @Reason NVARCHAR(500) = NULL,
    @Remarks NVARCHAR(500) = NULL,
    @CreatedBy INT,
    @MortalityId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@Quantity IS NULL OR @Quantity <= 0)
    BEGIN RAISERROR('Mortality quantity must be greater than zero.', 16, 1); RETURN; END

    DECLARE @Initial INT;
    SELECT @Initial = InitialQuantity FROM PoultryBatches WHERE BatchId = @BatchId;
    DECLARE @Current INT = @Initial
        - ISNULL((SELECT SUM(Quantity) FROM PoultryMortality WHERE BatchId = @BatchId), 0)
        - ISNULL((SELECT SUM(BirdQuantity) FROM PoultrySales WHERE BatchId = @BatchId), 0);
    IF (@Quantity > @Current)
    BEGIN RAISERROR('Mortality quantity exceeds current birds (%d).', 16, 1, @Current); RETURN; END

    INSERT INTO PoultryMortality (BatchId, MortalityDate, Quantity, Reason, Remarks, CreatedBy, CreatedDate)
    VALUES (@BatchId, @MortalityDate, @Quantity, @Reason, @Remarks, @CreatedBy, GETDATE());

    SET @MortalityId = SCOPE_IDENTITY();
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultryMortality_Update')
    DROP PROCEDURE usp_PoultryMortality_Update;
GO

CREATE PROCEDURE usp_PoultryMortality_Update
    @MortalityId INT,
    @MortalityDate DATE,
    @Quantity INT,
    @Reason NVARCHAR(500) = NULL,
    @Remarks NVARCHAR(500) = NULL,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@Quantity IS NULL OR @Quantity <= 0)
    BEGIN RAISERROR('Mortality quantity must be greater than zero.', 16, 1); RETURN; END

    DECLARE @BatchId INT;
    SELECT @BatchId = BatchId FROM PoultryMortality WHERE MortalityId = @MortalityId;

    DECLARE @Initial INT;
    SELECT @Initial = InitialQuantity FROM PoultryBatches WHERE BatchId = @BatchId;
    DECLARE @Current INT = @Initial
        - ISNULL((SELECT SUM(Quantity) FROM PoultryMortality WHERE BatchId = @BatchId AND MortalityId <> @MortalityId), 0)
        - ISNULL((SELECT SUM(BirdQuantity) FROM PoultrySales WHERE BatchId = @BatchId), 0);
    IF (@Quantity > @Current)
    BEGIN RAISERROR('Mortality quantity exceeds current birds (%d).', 16, 1, @Current); RETURN; END

    UPDATE PoultryMortality
    SET MortalityDate = @MortalityDate, Quantity = @Quantity, Reason = @Reason, Remarks = @Remarks,
        ModifiedBy = @ModifiedBy, ModifiedDate = GETDATE()
    WHERE MortalityId = @MortalityId;
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultryMortality_Delete')
    DROP PROCEDURE usp_PoultryMortality_Delete;
GO

CREATE PROCEDURE usp_PoultryMortality_Delete
    @MortalityId INT
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM PoultryMortality WHERE MortalityId = @MortalityId;
END
GO

-- =============================================
-- PoultryGrowth: GetPaged / Insert / Update / Delete
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultryGrowth_GetPaged')
    DROP PROCEDURE usp_PoultryGrowth_GetPaged;
GO

CREATE PROCEDURE usp_PoultryGrowth_GetPaged
    @ProjectId INT = NULL,
    @BatchId INT = NULL,
    @FromDate DATE = NULL,
    @ToDate DATE = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @SortBy NVARCHAR(50) = 'sampleDate',
    @SortDir NVARCHAR(4) = 'desc',
    @TotalRecords INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@PageNumber IS NULL OR @PageNumber < 1) SET @PageNumber = 1;
    IF (@PageSize IS NULL OR @PageSize < 1) SET @PageSize = 10;
    IF (@PageSize > 100) SET @PageSize = 100;
    SET @SortBy = LOWER(LTRIM(RTRIM(ISNULL(@SortBy, 'sampledate'))));
    IF (@SortBy NOT IN ('growthid', 'sampledate', 'batchcode', 'averageweight'))
        SET @SortBy = 'sampledate';
    SET @SortDir = LOWER(LTRIM(RTRIM(ISNULL(@SortDir, 'desc'))));
    IF (@SortDir NOT IN ('asc', 'desc')) SET @SortDir = 'desc';

    SELECT @TotalRecords = COUNT(*)
    FROM PoultryGrowth g
    INNER JOIN PoultryBatches b ON g.BatchId = b.BatchId
    WHERE (@ProjectId IS NULL OR b.ProjectId = @ProjectId)
    AND (@BatchId IS NULL OR g.BatchId = @BatchId)
    AND (@FromDate IS NULL OR g.SampleDate >= @FromDate)
    AND (@ToDate IS NULL OR g.SampleDate <= @ToDate);

    SELECT g.GrowthId, g.BatchId, b.BatchCode, b.ProjectId,
        g.SampleDate, g.SampleQuantity, g.AverageWeight, g.Remarks,
        g.CreatedBy, g.CreatedDate, g.ModifiedBy, g.ModifiedDate
    FROM PoultryGrowth g
    INNER JOIN PoultryBatches b ON g.BatchId = b.BatchId
    WHERE (@ProjectId IS NULL OR b.ProjectId = @ProjectId)
    AND (@BatchId IS NULL OR g.BatchId = @BatchId)
    AND (@FromDate IS NULL OR g.SampleDate >= @FromDate)
    AND (@ToDate IS NULL OR g.SampleDate <= @ToDate)
    ORDER BY
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'sampledate' THEN g.SampleDate END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'sampledate' THEN g.SampleDate END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'batchcode' THEN b.BatchCode END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'batchcode' THEN b.BatchCode END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'averageweight' THEN g.AverageWeight END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'averageweight' THEN g.AverageWeight END DESC,
        g.SampleDate DESC, g.GrowthId DESC
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultryGrowth_Insert')
    DROP PROCEDURE usp_PoultryGrowth_Insert;
GO

CREATE PROCEDURE usp_PoultryGrowth_Insert
    @BatchId INT,
    @SampleDate DATE,
    @SampleQuantity INT,
    @AverageWeight DECIMAL(18,2),
    @Remarks NVARCHAR(500) = NULL,
    @CreatedBy INT,
    @GrowthId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@SampleQuantity IS NULL OR @SampleQuantity <= 0)
    BEGIN RAISERROR('Sample quantity must be greater than zero.', 16, 1); RETURN; END

    INSERT INTO PoultryGrowth (BatchId, SampleDate, SampleQuantity, AverageWeight, Remarks, CreatedBy, CreatedDate)
    VALUES (@BatchId, @SampleDate, @SampleQuantity, @AverageWeight, @Remarks, @CreatedBy, GETDATE());

    SET @GrowthId = SCOPE_IDENTITY();
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultryGrowth_Update')
    DROP PROCEDURE usp_PoultryGrowth_Update;
GO

CREATE PROCEDURE usp_PoultryGrowth_Update
    @GrowthId INT,
    @SampleDate DATE,
    @SampleQuantity INT,
    @AverageWeight DECIMAL(18,2),
    @Remarks NVARCHAR(500) = NULL,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@SampleQuantity IS NULL OR @SampleQuantity <= 0)
    BEGIN RAISERROR('Sample quantity must be greater than zero.', 16, 1); RETURN; END

    UPDATE PoultryGrowth
    SET SampleDate = @SampleDate, SampleQuantity = @SampleQuantity, AverageWeight = @AverageWeight,
        Remarks = @Remarks, ModifiedBy = @ModifiedBy, ModifiedDate = GETDATE()
    WHERE GrowthId = @GrowthId;
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultryGrowth_Delete')
    DROP PROCEDURE usp_PoultryGrowth_Delete;
GO

CREATE PROCEDURE usp_PoultryGrowth_Delete
    @GrowthId INT
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM PoultryGrowth WHERE GrowthId = @GrowthId;
END
GO

-- =============================================
-- EggProduction: GetPaged / Insert / Update / Delete
-- TotalEggs = GoodEggs + BrokenEggs (always computed).
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_EggProduction_GetPaged')
    DROP PROCEDURE usp_EggProduction_GetPaged;
GO

CREATE PROCEDURE usp_EggProduction_GetPaged
    @ProjectId INT = NULL,
    @BatchId INT = NULL,
    @FromDate DATE = NULL,
    @ToDate DATE = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @SortBy NVARCHAR(50) = 'productionDate',
    @SortDir NVARCHAR(4) = 'desc',
    @TotalRecords INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@PageNumber IS NULL OR @PageNumber < 1) SET @PageNumber = 1;
    IF (@PageSize IS NULL OR @PageSize < 1) SET @PageSize = 10;
    IF (@PageSize > 100) SET @PageSize = 100;
    SET @SortBy = LOWER(LTRIM(RTRIM(ISNULL(@SortBy, 'productiondate'))));
    IF (@SortBy NOT IN ('productionid', 'productiondate', 'batchcode', 'totaleggs'))
        SET @SortBy = 'productiondate';
    SET @SortDir = LOWER(LTRIM(RTRIM(ISNULL(@SortDir, 'desc'))));
    IF (@SortDir NOT IN ('asc', 'desc')) SET @SortDir = 'desc';

    SELECT @TotalRecords = COUNT(*)
    FROM EggProduction e
    INNER JOIN PoultryBatches b ON e.BatchId = b.BatchId
    WHERE (@ProjectId IS NULL OR b.ProjectId = @ProjectId)
    AND (@BatchId IS NULL OR e.BatchId = @BatchId)
    AND (@FromDate IS NULL OR e.ProductionDate >= @FromDate)
    AND (@ToDate IS NULL OR e.ProductionDate <= @ToDate);

    SELECT e.ProductionId, e.BatchId, b.BatchCode, b.ProjectId,
        e.ProductionDate, e.GoodEggs, e.BrokenEggs, e.TotalEggs, e.Remarks,
        e.CreatedBy, e.CreatedDate, e.ModifiedBy, e.ModifiedDate
    FROM EggProduction e
    INNER JOIN PoultryBatches b ON e.BatchId = b.BatchId
    WHERE (@ProjectId IS NULL OR b.ProjectId = @ProjectId)
    AND (@BatchId IS NULL OR e.BatchId = @BatchId)
    AND (@FromDate IS NULL OR e.ProductionDate >= @FromDate)
    AND (@ToDate IS NULL OR e.ProductionDate <= @ToDate)
    ORDER BY
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'productiondate' THEN e.ProductionDate END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'productiondate' THEN e.ProductionDate END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'batchcode' THEN b.BatchCode END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'batchcode' THEN b.BatchCode END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'totaleggs' THEN e.TotalEggs END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'totaleggs' THEN e.TotalEggs END DESC,
        e.ProductionDate DESC, e.ProductionId DESC
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_EggProduction_Insert')
    DROP PROCEDURE usp_EggProduction_Insert;
GO

CREATE PROCEDURE usp_EggProduction_Insert
    @BatchId INT,
    @ProductionDate DATE,
    @GoodEggs INT = 0,
    @BrokenEggs INT = 0,
    @Remarks NVARCHAR(500) = NULL,
    @CreatedBy INT,
    @ProductionId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (ISNULL(@GoodEggs, 0) < 0 OR ISNULL(@BrokenEggs, 0) < 0)
    BEGIN RAISERROR('Egg quantity cannot be negative.', 16, 1); RETURN; END

    INSERT INTO EggProduction (BatchId, ProductionDate, GoodEggs, BrokenEggs, TotalEggs, Remarks, CreatedBy, CreatedDate)
    VALUES (@BatchId, @ProductionDate, ISNULL(@GoodEggs, 0), ISNULL(@BrokenEggs, 0),
        ISNULL(@GoodEggs, 0) + ISNULL(@BrokenEggs, 0), @Remarks, @CreatedBy, GETDATE());

    SET @ProductionId = SCOPE_IDENTITY();
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_EggProduction_Update')
    DROP PROCEDURE usp_EggProduction_Update;
GO

CREATE PROCEDURE usp_EggProduction_Update
    @ProductionId INT,
    @ProductionDate DATE,
    @GoodEggs INT = 0,
    @BrokenEggs INT = 0,
    @Remarks NVARCHAR(500) = NULL,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    IF (ISNULL(@GoodEggs, 0) < 0 OR ISNULL(@BrokenEggs, 0) < 0)
    BEGIN RAISERROR('Egg quantity cannot be negative.', 16, 1); RETURN; END

    UPDATE EggProduction
    SET ProductionDate = @ProductionDate, GoodEggs = ISNULL(@GoodEggs, 0), BrokenEggs = ISNULL(@BrokenEggs, 0),
        TotalEggs = ISNULL(@GoodEggs, 0) + ISNULL(@BrokenEggs, 0),
        Remarks = @Remarks, ModifiedBy = @ModifiedBy, ModifiedDate = GETDATE()
    WHERE ProductionId = @ProductionId;
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_EggProduction_Delete')
    DROP PROCEDURE usp_EggProduction_Delete;
GO

CREATE PROCEDURE usp_EggProduction_Delete
    @ProductionId INT
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM EggProduction WHERE ProductionId = @ProductionId;
END
GO

-- =============================================
-- PoultrySales: GetPaged / Insert / Update / Delete
-- Sales auto-post Revenue (Poultry Sale) transactionally.
-- Sale quantity must not exceed current birds.
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultrySales_GetPaged')
    DROP PROCEDURE usp_PoultrySales_GetPaged;
GO

CREATE PROCEDURE usp_PoultrySales_GetPaged
    @ProjectId INT = NULL,
    @BatchId INT = NULL,
    @PaymentStatus NVARCHAR(20) = NULL,
    @FromDate DATE = NULL,
    @ToDate DATE = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @SortBy NVARCHAR(50) = 'saleDate',
    @SortDir NVARCHAR(4) = 'desc',
    @TotalRecords INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@PageNumber IS NULL OR @PageNumber < 1) SET @PageNumber = 1;
    IF (@PageSize IS NULL OR @PageSize < 1) SET @PageSize = 10;
    IF (@PageSize > 100) SET @PageSize = 100;
    SET @SortBy = LOWER(LTRIM(RTRIM(ISNULL(@SortBy, 'saledate'))));
    IF (@SortBy NOT IN ('saleid', 'saledate', 'customername', 'birdquantity', 'totalamount'))
        SET @SortBy = 'saledate';
    SET @SortDir = LOWER(LTRIM(RTRIM(ISNULL(@SortDir, 'desc'))));
    IF (@SortDir NOT IN ('asc', 'desc')) SET @SortDir = 'desc';
    IF (LTRIM(RTRIM(ISNULL(@PaymentStatus, ''))) = '') SET @PaymentStatus = NULL;

    SELECT @TotalRecords = COUNT(*)
    FROM PoultrySales s
    WHERE (@ProjectId IS NULL OR s.ProjectId = @ProjectId)
    AND (@BatchId IS NULL OR s.BatchId = @BatchId)
    AND (@PaymentStatus IS NULL OR s.PaymentStatus = @PaymentStatus)
    AND (@FromDate IS NULL OR s.SaleDate >= @FromDate)
    AND (@ToDate IS NULL OR s.SaleDate <= @ToDate);

    SELECT s.SaleId, s.ProjectId, p.ProjectCode, p.ProjectName,
        s.BatchId, b.BatchCode,
        s.SaleDate, s.CustomerName, s.BirdQuantity, s.TotalWeight, s.Rate, s.TotalAmount,
        s.PaymentStatus, s.ReferenceNo, s.Remarks,
        s.CreatedBy, s.CreatedDate, s.ModifiedBy, s.ModifiedDate
    FROM PoultrySales s
    INNER JOIN Projects p ON s.ProjectId = p.ProjectId
    LEFT JOIN PoultryBatches b ON s.BatchId = b.BatchId
    WHERE (@ProjectId IS NULL OR s.ProjectId = @ProjectId)
    AND (@BatchId IS NULL OR s.BatchId = @BatchId)
    AND (@PaymentStatus IS NULL OR s.PaymentStatus = @PaymentStatus)
    AND (@FromDate IS NULL OR s.SaleDate >= @FromDate)
    AND (@ToDate IS NULL OR s.SaleDate <= @ToDate)
    ORDER BY
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'saledate' THEN s.SaleDate END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'saledate' THEN s.SaleDate END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'customername' THEN s.CustomerName END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'customername' THEN s.CustomerName END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'birdquantity' THEN s.BirdQuantity END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'birdquantity' THEN s.BirdQuantity END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'totalamount' THEN s.TotalAmount END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'totalamount' THEN s.TotalAmount END DESC,
        s.SaleDate DESC, s.SaleId DESC
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultrySales_Insert')
    DROP PROCEDURE usp_PoultrySales_Insert;
GO

CREATE PROCEDURE usp_PoultrySales_Insert
    @ProjectId INT,
    @BatchId INT = NULL,
    @SaleDate DATE,
    @CustomerName NVARCHAR(200),
    @BirdQuantity INT,
    @TotalWeight DECIMAL(18,2) = 0,
    @Rate DECIMAL(18,2) = 0,
    @TotalAmount DECIMAL(18,2) = NULL,
    @PaymentStatus NVARCHAR(20) = 'Pending',
    @ReferenceNo NVARCHAR(50) = NULL,
    @Remarks NVARCHAR(500) = NULL,
    @CreatedBy INT,
    @SaleId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@BirdQuantity IS NULL OR @BirdQuantity <= 0)
    BEGIN RAISERROR('Sale quantity must be greater than zero.', 16, 1); RETURN; END
    IF (@BatchId IS NOT NULL)
    BEGIN
        DECLARE @Initial INT;
        SELECT @Initial = InitialQuantity FROM PoultryBatches WHERE BatchId = @BatchId;
        DECLARE @Current INT = @Initial
            - ISNULL((SELECT SUM(Quantity) FROM PoultryMortality WHERE BatchId = @BatchId), 0)
            - ISNULL((SELECT SUM(BirdQuantity) FROM PoultrySales WHERE BatchId = @BatchId), 0);
        IF (@BirdQuantity > @Current)
        BEGIN RAISERROR('Sale quantity exceeds current birds (%d).', 16, 1, @Current); RETURN; END
    END
    IF (@TotalAmount IS NULL) SET @TotalAmount = CAST(@BirdQuantity AS DECIMAL(18,2)) * ISNULL(@Rate, 0);
    IF (@TotalAmount < 0)
    BEGIN RAISERROR('Sale amount must not be negative.', 16, 1); RETURN; END

    BEGIN TRANSACTION;
    BEGIN TRY
        INSERT INTO PoultrySales (ProjectId, BatchId, SaleDate, CustomerName, BirdQuantity, TotalWeight, Rate, TotalAmount, PaymentStatus, ReferenceNo, Remarks, CreatedBy, CreatedDate)
        VALUES (@ProjectId, @BatchId, @SaleDate, @CustomerName, @BirdQuantity, ISNULL(@TotalWeight, 0), ISNULL(@Rate, 0), @TotalAmount, ISNULL(@PaymentStatus, 'Pending'), @ReferenceNo, @Remarks, @CreatedBy, GETDATE());

        SET @SaleId = SCOPE_IDENTITY();

        INSERT INTO Revenue (RevenueDate, ProjectId, FarmType, RevenueType, ReferenceId, CustomerName, Quantity, Weight, Rate, Amount, PaymentStatus, Remarks, IsDeleted, CreatedBy, CreatedDate)
        VALUES (@SaleDate, @ProjectId, 'Poultry Farming', 'Poultry Sale', @SaleId, @CustomerName, @BirdQuantity, ISNULL(@TotalWeight, 0), ISNULL(@Rate, 0), @TotalAmount, ISNULL(@PaymentStatus, 'Pending'), @Remarks, 0, @CreatedBy, GETDATE());

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultrySales_Update')
    DROP PROCEDURE usp_PoultrySales_Update;
GO

CREATE PROCEDURE usp_PoultrySales_Update
    @SaleId INT,
    @SaleDate DATE,
    @CustomerName NVARCHAR(200),
    @BirdQuantity INT,
    @TotalWeight DECIMAL(18,2) = 0,
    @Rate DECIMAL(18,2) = 0,
    @TotalAmount DECIMAL(18,2) = NULL,
    @PaymentStatus NVARCHAR(20) = NULL,
    @ReferenceNo NVARCHAR(50) = NULL,
    @Remarks NVARCHAR(500) = NULL,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@BirdQuantity IS NULL OR @BirdQuantity <= 0)
    BEGIN RAISERROR('Sale quantity must be greater than zero.', 16, 1); RETURN; END

    DECLARE @BatchId INT;
    SELECT @BatchId = BatchId FROM PoultrySales WHERE SaleId = @SaleId;
    IF (@BatchId IS NOT NULL)
    BEGIN
        DECLARE @Initial INT;
        SELECT @Initial = InitialQuantity FROM PoultryBatches WHERE BatchId = @BatchId;
        DECLARE @Current INT = @Initial
            - ISNULL((SELECT SUM(Quantity) FROM PoultryMortality WHERE BatchId = @BatchId), 0)
            - ISNULL((SELECT SUM(BirdQuantity) FROM PoultrySales WHERE BatchId = @BatchId AND SaleId <> @SaleId), 0);
        IF (@BirdQuantity > @Current)
        BEGIN RAISERROR('Sale quantity exceeds current birds (%d).', 16, 1, @Current); RETURN; END
    END
    IF (@TotalAmount IS NULL) SET @TotalAmount = CAST(@BirdQuantity AS DECIMAL(18,2)) * ISNULL(@Rate, 0);
    IF (@TotalAmount < 0)
    BEGIN RAISERROR('Sale amount must not be negative.', 16, 1); RETURN; END

    BEGIN TRANSACTION;
    BEGIN TRY
        UPDATE PoultrySales
        SET SaleDate = @SaleDate, CustomerName = @CustomerName, BirdQuantity = @BirdQuantity,
            TotalWeight = ISNULL(@TotalWeight, 0), Rate = ISNULL(@Rate, 0), TotalAmount = @TotalAmount,
            PaymentStatus = ISNULL(@PaymentStatus, PaymentStatus),
            ReferenceNo = @ReferenceNo, Remarks = @Remarks,
            ModifiedBy = @ModifiedBy, ModifiedDate = GETDATE()
        WHERE SaleId = @SaleId;

        UPDATE Revenue
        SET RevenueDate = @SaleDate, CustomerName = @CustomerName, Quantity = @BirdQuantity,
            Weight = ISNULL(@TotalWeight, 0), Rate = ISNULL(@Rate, 0), Amount = @TotalAmount,
            PaymentStatus = ISNULL(@PaymentStatus, PaymentStatus),
            Remarks = @Remarks, ModifiedBy = @ModifiedBy, ModifiedDate = GETDATE()
        WHERE RevenueType = 'Poultry Sale' AND ReferenceId = @SaleId AND IsDeleted = 0;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultrySales_Delete')
    DROP PROCEDURE usp_PoultrySales_Delete;
GO

CREATE PROCEDURE usp_PoultrySales_Delete
    @SaleId INT
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRANSACTION;
    BEGIN TRY
        UPDATE Revenue SET IsDeleted = 1, ModifiedDate = GETDATE()
        WHERE RevenueType = 'Poultry Sale' AND ReferenceId = @SaleId AND IsDeleted = 0;

        DELETE FROM PoultrySales WHERE SaleId = @SaleId;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END
GO

-- =============================================
-- Revenue: GetPaged / Insert / Update / Delete (§94)
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Revenue_GetPaged')
    DROP PROCEDURE usp_Revenue_GetPaged;
GO

CREATE PROCEDURE usp_Revenue_GetPaged
    @ProjectId INT = NULL,
    @FarmType NVARCHAR(50) = NULL,
    @RevenueType NVARCHAR(50) = NULL,
    @FromDate DATE = NULL,
    @ToDate DATE = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @SortBy NVARCHAR(50) = 'revenueDate',
    @SortDir NVARCHAR(4) = 'desc',
    @TotalRecords INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@PageNumber IS NULL OR @PageNumber < 1) SET @PageNumber = 1;
    IF (@PageSize IS NULL OR @PageSize < 1) SET @PageSize = 10;
    IF (@PageSize > 100) SET @PageSize = 100;
    SET @SortBy = LOWER(LTRIM(RTRIM(ISNULL(@SortBy, 'revenuedate'))));
    IF (@SortBy NOT IN ('revenueid', 'revenuedate', 'revenuetype', 'customername', 'amount'))
        SET @SortBy = 'revenuedate';
    SET @SortDir = LOWER(LTRIM(RTRIM(ISNULL(@SortDir, 'desc'))));
    IF (@SortDir NOT IN ('asc', 'desc')) SET @SortDir = 'desc';
    IF (LTRIM(RTRIM(ISNULL(@FarmType, ''))) = '') SET @FarmType = NULL;
    IF (LTRIM(RTRIM(ISNULL(@RevenueType, ''))) = '') SET @RevenueType = NULL;

    SELECT @TotalRecords = COUNT(*)
    FROM Revenue r
    WHERE r.IsDeleted = 0
    AND (@ProjectId IS NULL OR r.ProjectId = @ProjectId)
    AND (@FarmType IS NULL OR r.FarmType = @FarmType)
    AND (@RevenueType IS NULL OR r.RevenueType = @RevenueType)
    AND (@FromDate IS NULL OR r.RevenueDate >= @FromDate)
    AND (@ToDate IS NULL OR r.RevenueDate <= @ToDate);

    SELECT r.RevenueId, r.RevenueDate, r.ProjectId, p.ProjectCode, p.ProjectName,
        r.FarmType, r.RevenueType, r.ReferenceId, r.CustomerName,
        r.Quantity, r.Weight, r.Rate, r.Amount, r.PaymentStatus, r.Remarks,
        r.CreatedBy, r.CreatedDate, r.ModifiedBy, r.ModifiedDate
    FROM Revenue r
    INNER JOIN Projects p ON r.ProjectId = p.ProjectId
    WHERE r.IsDeleted = 0
    AND (@ProjectId IS NULL OR r.ProjectId = @ProjectId)
    AND (@FarmType IS NULL OR r.FarmType = @FarmType)
    AND (@RevenueType IS NULL OR r.RevenueType = @RevenueType)
    AND (@FromDate IS NULL OR r.RevenueDate >= @FromDate)
    AND (@ToDate IS NULL OR r.RevenueDate <= @ToDate)
    ORDER BY
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'revenuedate' THEN r.RevenueDate END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'revenuedate' THEN r.RevenueDate END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'revenuetype' THEN r.RevenueType END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'revenuetype' THEN r.RevenueType END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'customername' THEN r.CustomerName END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'customername' THEN r.CustomerName END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'amount' THEN r.Amount END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'amount' THEN r.Amount END DESC,
        r.RevenueDate DESC, r.RevenueId DESC
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Revenue_Insert')
    DROP PROCEDURE usp_Revenue_Insert;
GO

CREATE PROCEDURE usp_Revenue_Insert
    @RevenueDate DATE,
    @ProjectId INT,
    @FarmType NVARCHAR(50) = NULL,
    @RevenueType NVARCHAR(50),
    @ReferenceId INT = NULL,
    @CustomerName NVARCHAR(200) = NULL,
    @Quantity DECIMAL(18,2) = 0,
    @Weight DECIMAL(18,2) = 0,
    @Rate DECIMAL(18,2) = 0,
    @Amount DECIMAL(18,2),
    @PaymentStatus NVARCHAR(20) = 'Pending',
    @Remarks NVARCHAR(500) = NULL,
    @CreatedBy INT,
    @RevenueId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@Amount IS NULL OR @Amount < 0)
    BEGIN RAISERROR('Revenue amount must not be negative.', 16, 1); RETURN; END

    INSERT INTO Revenue (RevenueDate, ProjectId, FarmType, RevenueType, ReferenceId, CustomerName, Quantity, Weight, Rate, Amount, PaymentStatus, Remarks, IsDeleted, CreatedBy, CreatedDate)
    VALUES (@RevenueDate, @ProjectId, @FarmType, @RevenueType, @ReferenceId, @CustomerName,
        ISNULL(@Quantity, 0), ISNULL(@Weight, 0), ISNULL(@Rate, 0), @Amount,
        ISNULL(@PaymentStatus, 'Pending'), @Remarks, 0, @CreatedBy, GETDATE());

    SET @RevenueId = SCOPE_IDENTITY();
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Revenue_Update')
    DROP PROCEDURE usp_Revenue_Update;
GO

CREATE PROCEDURE usp_Revenue_Update
    @RevenueId INT,
    @RevenueDate DATE,
    @RevenueType NVARCHAR(50),
    @CustomerName NVARCHAR(200) = NULL,
    @Quantity DECIMAL(18,2) = 0,
    @Weight DECIMAL(18,2) = 0,
    @Rate DECIMAL(18,2) = 0,
    @Amount DECIMAL(18,2),
    @PaymentStatus NVARCHAR(20) = NULL,
    @Remarks NVARCHAR(500) = NULL,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@Amount IS NULL OR @Amount < 0)
    BEGIN RAISERROR('Revenue amount must not be negative.', 16, 1); RETURN; END
    -- Auto-posted sale rows stay in sync through their sale module; only manual rows are editable here.
    IF EXISTS (SELECT 1 FROM Revenue WHERE RevenueId = @RevenueId AND ReferenceId IS NOT NULL AND IsDeleted = 0)
    BEGIN RAISERROR('Sale-linked revenue must be edited through its sale record.', 16, 1); RETURN; END

    UPDATE Revenue
    SET RevenueDate = @RevenueDate, RevenueType = @RevenueType, CustomerName = @CustomerName,
        Quantity = ISNULL(@Quantity, 0), Weight = ISNULL(@Weight, 0), Rate = ISNULL(@Rate, 0),
        Amount = @Amount, PaymentStatus = ISNULL(@PaymentStatus, PaymentStatus),
        Remarks = @Remarks, ModifiedBy = @ModifiedBy, ModifiedDate = GETDATE()
    WHERE RevenueId = @RevenueId;
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Revenue_Delete')
    DROP PROCEDURE usp_Revenue_Delete;
GO

CREATE PROCEDURE usp_Revenue_Delete
    @RevenueId INT
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (SELECT 1 FROM Revenue WHERE RevenueId = @RevenueId AND ReferenceId IS NOT NULL AND IsDeleted = 0)
    BEGIN RAISERROR('Sale-linked revenue must be deleted through its sale record.', 16, 1); RETURN; END

    UPDATE Revenue SET IsDeleted = 1, ModifiedDate = GETDATE()
    WHERE RevenueId = @RevenueId;
END
GO

USE ProjectManagementDB;
GO

-- =============================================
-- Table: Roles
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Roles')
BEGIN
    CREATE TABLE Roles (
        RoleId INT IDENTITY(1,1) PRIMARY KEY,
        RoleName NVARCHAR(50) NOT NULL UNIQUE,
        Description NVARCHAR(200) NULL,
        CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE(),
        ModifiedDate DATETIME2 NULL
    );
END
GO

-- =============================================
-- Table: Users
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Users')
BEGIN
    CREATE TABLE Users (
        UserId INT IDENTITY(1,1) PRIMARY KEY,
        Username NVARCHAR(50) NOT NULL UNIQUE,
        FullName NVARCHAR(100) NOT NULL,
        Email NVARCHAR(100) NOT NULL,
        PasswordHash NVARCHAR(500) NOT NULL,
        PasswordEnc NVARCHAR(1000) NULL,
        RoleId INT NOT NULL,
        IsActive BIT NOT NULL DEFAULT 1,
        CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE(),
        CreatedBy INT NULL,
        ModifiedDate DATETIME2 NULL,
        ModifiedBy INT NULL,
        CONSTRAINT FK_Users_Roles FOREIGN KEY (RoleId) REFERENCES Roles(RoleId),
        CONSTRAINT FK_Users_CreatedBy FOREIGN KEY (CreatedBy) REFERENCES Users(UserId),
        CONSTRAINT FK_Users_ModifiedBy FOREIGN KEY (ModifiedBy) REFERENCES Users(UserId)
    );
END
GO

-- Idempotent upgrade: encrypted retrievable password for existing databases
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Users') AND name = 'PasswordEnc')
BEGIN
    ALTER TABLE Users ADD PasswordEnc NVARCHAR(1000) NULL;
END
GO

-- =============================================
-- Table: Pages
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Pages')
BEGIN
    CREATE TABLE Pages (
        PageId INT IDENTITY(1,1) PRIMARY KEY,
        PageName NVARCHAR(100) NOT NULL UNIQUE,
        PageDescription NVARCHAR(200) NULL,
        CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE(),
        ModifiedDate DATETIME2 NULL
    );
END
GO

-- =============================================
-- Table: UserPermissions
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'UserPermissions')
BEGIN
    CREATE TABLE UserPermissions (
        PermissionId INT IDENTITY(1,1) PRIMARY KEY,
        UserId INT NOT NULL,
        PageId INT NOT NULL,
        CanView BIT NOT NULL DEFAULT 0,
        CanEdit BIT NOT NULL DEFAULT 0,
        CanDelete BIT NOT NULL DEFAULT 0,
        CanExport BIT NOT NULL DEFAULT 0,
        CreatedBy INT NULL,
        CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE(),
        ModifiedBy INT NULL,
        ModifiedDate DATETIME2 NULL,
        CONSTRAINT FK_UserPermissions_Users FOREIGN KEY (UserId) REFERENCES Users(UserId),
        CONSTRAINT FK_UserPermissions_Pages FOREIGN KEY (PageId) REFERENCES Pages(PageId),
        CONSTRAINT FK_UserPermissions_CreatedBy FOREIGN KEY (CreatedBy) REFERENCES Users(UserId),
        CONSTRAINT FK_UserPermissions_ModifiedBy FOREIGN KEY (ModifiedBy) REFERENCES Users(UserId),
        CONSTRAINT UQ_UserPermissions_User_Page UNIQUE (UserId, PageId)
    );
END
GO
-- Idempotent upgrade: Export permission for existing databases
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('UserPermissions') AND name = 'CanExport')
BEGIN
    ALTER TABLE UserPermissions ADD CanExport BIT NOT NULL DEFAULT 0;
END
GO

-- =============================================
-- Table: Projects
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Projects')
BEGIN
    CREATE TABLE Projects (
        ProjectId INT IDENTITY(1,1) PRIMARY KEY,
        ProjectCode NVARCHAR(20) NOT NULL UNIQUE,
        ProjectName NVARCHAR(200) NOT NULL,
        Description NVARCHAR(500) NULL,
        ClientName NVARCHAR(200) NULL,
        StartDate DATE NULL,
        EndDate DATE NULL,
        TotalBudget DECIMAL(18,2) NULL DEFAULT 0,
        Status NVARCHAR(20) NOT NULL DEFAULT 'Planning',
        IsActive BIT NOT NULL DEFAULT 1,
        CreatedBy INT NULL,
        CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE(),
        ModifiedBy INT NULL,
        ModifiedDate DATETIME2 NULL,
        CONSTRAINT FK_Projects_CreatedBy FOREIGN KEY (CreatedBy) REFERENCES Users(UserId),
        CONSTRAINT FK_Projects_ModifiedBy FOREIGN KEY (ModifiedBy) REFERENCES Users(UserId),
        CONSTRAINT CHK_Projects_Status CHECK (Status IN ('Planning', 'Active', 'Completed', 'On Hold', 'Cancelled'))
    );
END
GO

-- =============================================
-- Table: BudgetCodes
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'BudgetCodes')
BEGIN
    CREATE TABLE BudgetCodes (
        BudgetCodeId INT IDENTITY(1,1) PRIMARY KEY,
        BudgetCode NVARCHAR(20) NOT NULL UNIQUE,
        BudgetCodeName NVARCHAR(100) NOT NULL,
        Description NVARCHAR(200) NULL,
        IsActive BIT NOT NULL DEFAULT 1,
        CreatedBy INT NULL,
        CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE(),
        ModifiedBy INT NULL,
        ModifiedDate DATETIME2 NULL,
        CONSTRAINT FK_BudgetCodes_CreatedBy FOREIGN KEY (CreatedBy) REFERENCES Users(UserId),
        CONSTRAINT FK_BudgetCodes_ModifiedBy FOREIGN KEY (ModifiedBy) REFERENCES Users(UserId)
    );
END
GO

-- =============================================
-- Table: ProjectBudgets
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'ProjectBudgets')
BEGIN
    CREATE TABLE ProjectBudgets (
        ProjectBudgetId INT IDENTITY(1,1) PRIMARY KEY,
        ProjectId INT NOT NULL,
        BudgetCodeId INT NOT NULL,
        BudgetAmount DECIMAL(18,2) NOT NULL,
        EffectiveFrom DATE NOT NULL,
        EffectiveTo DATE NULL,
        IsActive BIT NOT NULL DEFAULT 1,
        CreatedBy INT NULL,
        CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE(),
        ModifiedBy INT NULL,
        ModifiedDate DATETIME2 NULL,
        CONSTRAINT FK_ProjectBudgets_Projects FOREIGN KEY (ProjectId) REFERENCES Projects(ProjectId),
        CONSTRAINT FK_ProjectBudgets_BudgetCodes FOREIGN KEY (BudgetCodeId) REFERENCES BudgetCodes(BudgetCodeId),
        CONSTRAINT FK_ProjectBudgets_CreatedBy FOREIGN KEY (CreatedBy) REFERENCES Users(UserId),
        CONSTRAINT FK_ProjectBudgets_ModifiedBy FOREIGN KEY (ModifiedBy) REFERENCES Users(UserId),
        CONSTRAINT CHK_ProjectBudgets_Amount CHECK (BudgetAmount > 0)
    );
END
GO

-- =============================================
-- Table: Resources
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Resources')
BEGIN
    CREATE TABLE Resources (
        ResourceId INT IDENTITY(1,1) PRIMARY KEY,
        ResourceCode NVARCHAR(20) NOT NULL UNIQUE,
        ResourceName NVARCHAR(100) NOT NULL,
        ResourceType NVARCHAR(20) NOT NULL,
        Email NVARCHAR(100) NULL,
        Phone NVARCHAR(20) NULL,
        Department NVARCHAR(100) NULL,
        IsActive BIT NOT NULL DEFAULT 1,
        CreatedBy INT NULL,
        CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE(),
        ModifiedBy INT NULL,
        ModifiedDate DATETIME2 NULL,
        CONSTRAINT FK_Resources_CreatedBy FOREIGN KEY (CreatedBy) REFERENCES Users(UserId),
        CONSTRAINT FK_Resources_ModifiedBy FOREIGN KEY (ModifiedBy) REFERENCES Users(UserId),
        CONSTRAINT CHK_Resources_Type CHECK (ResourceType IN ('Employee', 'Contractor', 'Vendor', 'Consultant', 'Other'))
    );
END
GO

-- =============================================
-- Table: ProjectResources
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'ProjectResources')
BEGIN
    CREATE TABLE ProjectResources (
        ProjectResourceId INT IDENTITY(1,1) PRIMARY KEY,
        ProjectId INT NOT NULL,
        ResourceId INT NOT NULL,
        AssignedFrom DATE NOT NULL,
        AssignedTo DATE NULL,
        IsActive BIT NOT NULL DEFAULT 1,
        CreatedBy INT NULL,
        CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE(),
        ModifiedBy INT NULL,
        ModifiedDate DATETIME2 NULL,
        CONSTRAINT FK_ProjectResources_Projects FOREIGN KEY (ProjectId) REFERENCES Projects(ProjectId),
        CONSTRAINT FK_ProjectResources_Resources FOREIGN KEY (ResourceId) REFERENCES Resources(ResourceId),
        CONSTRAINT FK_ProjectResources_CreatedBy FOREIGN KEY (CreatedBy) REFERENCES Users(UserId),
        CONSTRAINT FK_ProjectResources_ModifiedBy FOREIGN KEY (ModifiedBy) REFERENCES Users(UserId)
    );
END
GO

-- =============================================
-- Table: Expenses
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Expenses')
BEGIN
    CREATE TABLE Expenses (
        ExpenseId INT IDENTITY(1,1) PRIMARY KEY,
        ExpenseDate DATE NOT NULL,
        ProjectId INT NOT NULL,
        BudgetCodeId INT NOT NULL,
        ResourceId INT NOT NULL,
        Amount DECIMAL(18,2) NOT NULL,
        Description NVARCHAR(500) NULL,
        ReferenceNo NVARCHAR(50) NULL,
        Remarks NVARCHAR(500) NULL,
        IsDeleted BIT NOT NULL DEFAULT 0,
        CreatedBy INT NULL,
        CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE(),
        ModifiedBy INT NULL,
        ModifiedDate DATETIME2 NULL,
        CONSTRAINT FK_Expenses_Projects FOREIGN KEY (ProjectId) REFERENCES Projects(ProjectId),
        CONSTRAINT FK_Expenses_BudgetCodes FOREIGN KEY (BudgetCodeId) REFERENCES BudgetCodes(BudgetCodeId),
        CONSTRAINT FK_Expenses_Resources FOREIGN KEY (ResourceId) REFERENCES Resources(ResourceId),
        CONSTRAINT FK_Expenses_CreatedBy FOREIGN KEY (CreatedBy) REFERENCES Users(UserId),
        CONSTRAINT FK_Expenses_ModifiedBy FOREIGN KEY (ModifiedBy) REFERENCES Users(UserId),
        CONSTRAINT CHK_Expenses_Amount CHECK (Amount > 0)
    );
END
GO

-- =============================================
-- Table: AuditLogs
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'AuditLogs')
BEGIN
    CREATE TABLE AuditLogs (
        AuditLogId INT IDENTITY(1,1) PRIMARY KEY,
        UserId INT NULL,
        Action NVARCHAR(100) NOT NULL,
        Module NVARCHAR(50) NOT NULL,
        RecordId NVARCHAR(50) NULL,
        OldValue NVARCHAR(MAX) NULL,
        NewValue NVARCHAR(MAX) NULL,
        IPAddress NVARCHAR(50) NULL,
        CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE(),
        CONSTRAINT FK_AuditLogs_Users FOREIGN KEY (UserId) REFERENCES Users(UserId)
    );
END
GO

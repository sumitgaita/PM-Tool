USE ProjectManagementDB;
GO

-- =============================================
-- Stored Procedure: usp_User_GetAll
-- Include MobileNumber so the Users grid/search can use it.
-- (Same shape as 006 plus u.MobileNumber.)
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_User_GetAll')
    DROP PROCEDURE usp_User_GetAll;
GO

CREATE PROCEDURE usp_User_GetAll
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        u.UserId,
        u.Username,
        u.FullName,
        u.Email,
        u.MobileNumber,
        u.RoleId,
        r.RoleName,
        u.IsActive,
        u.CreatedDate,
        u.CreatedBy,
        u.ModifiedDate,
        u.ModifiedBy,
        u.PasswordHash,
        u.PasswordEnc
    FROM Users u
    INNER JOIN Roles r ON u.RoleId = r.RoleId
    ORDER BY u.FullName;
END
GO

USE ProjectManagementDB;
GO

-- =============================================
-- Create Default Admin User
-- Password: Admin@123 (hashed with SHA256)
-- =============================================
IF NOT EXISTS (SELECT 1 FROM Users WHERE Username = 'admin')
BEGIN
    DECLARE @AdminRoleId INT;
    SELECT @AdminRoleId = RoleId FROM Roles WHERE RoleName = 'Admin';

    INSERT INTO Users (Username, FullName, Email, PasswordHash, RoleId, IsActive, CreatedBy, CreatedDate)
    VALUES ('admin', 'System Administrator', 'admin@example.com',
            '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9',
            @AdminRoleId, 1, 1, GETDATE());
END
GO

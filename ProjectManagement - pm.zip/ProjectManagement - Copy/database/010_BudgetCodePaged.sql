USE ProjectManagementDB;
GO

-- =============================================
-- Stored Procedure: usp_BudgetCode_GetPaged
-- Server-side pagination + search for Budget Codes grid.
-- @SearchText matches BudgetCode OR BudgetCodeName (case-insensitive).
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_BudgetCode_GetPaged')
    DROP PROCEDURE usp_BudgetCode_GetPaged;
GO

CREATE PROCEDURE usp_BudgetCode_GetPaged
    @SearchText NVARCHAR(100) = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @SortBy NVARCHAR(50) = 'budgetCode',
    @SortDir NVARCHAR(4) = 'asc',
    @TotalRecords INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@PageNumber IS NULL OR @PageNumber < 1) SET @PageNumber = 1;
    IF (@PageSize IS NULL OR @PageSize < 1) SET @PageSize = 10;
    IF (@PageSize > 100) SET @PageSize = 100;
    SET @SortBy = LOWER(LTRIM(RTRIM(ISNULL(@SortBy, 'budgetcode'))));
    IF (@SortBy NOT IN ('budgetcodeid', 'budgetcode', 'budgetcodename', 'description', 'createddate'))
        SET @SortBy = 'budgetcode';
    SET @SortDir = LOWER(LTRIM(RTRIM(ISNULL(@SortDir, 'asc'))));
    IF (@SortDir NOT IN ('asc', 'desc'))
        SET @SortDir = 'asc';
    IF (LTRIM(RTRIM(ISNULL(@SearchText, ''))) = '') SET @SearchText = NULL;

    SELECT @TotalRecords = COUNT(*)
    FROM BudgetCodes bc
    WHERE (@SearchText IS NULL OR bc.BudgetCode LIKE '%' + @SearchText + '%' OR bc.BudgetCodeName LIKE '%' + @SearchText + '%');

    SELECT
        bc.BudgetCodeId,
        bc.BudgetCode,
        bc.BudgetCodeName,
        bc.Description,
        bc.IsActive,
        bc.CreatedBy,
        bc.CreatedDate,
        bc.ModifiedBy,
        bc.ModifiedDate
    FROM BudgetCodes bc
    WHERE (@SearchText IS NULL OR bc.BudgetCode LIKE '%' + @SearchText + '%' OR bc.BudgetCodeName LIKE '%' + @SearchText + '%')
    ORDER BY
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'budgetcodeid' THEN bc.BudgetCodeId END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'budgetcodeid' THEN bc.BudgetCodeId END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'budgetcode' THEN bc.BudgetCode END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'budgetcode' THEN bc.BudgetCode END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'budgetcodename' THEN bc.BudgetCodeName END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'budgetcodename' THEN bc.BudgetCodeName END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'description' THEN bc.Description END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'description' THEN bc.Description END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'createddate' THEN bc.CreatedDate END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'createddate' THEN bc.CreatedDate END DESC,
        bc.BudgetCode ASC
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

USE ProjectManagementDB;
GO

-- =============================================
-- Stored Procedure: usp_User_Login
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_User_Login')
    DROP PROCEDURE usp_User_Login;
GO

CREATE PROCEDURE usp_User_Login
    @Username NVARCHAR(50),
    @PasswordHash NVARCHAR(500)
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        u.UserId,
        u.Username,
        u.FullName,
        u.Email,
        u.RoleId,
        r.RoleName,
        u.IsActive,
        u.CreatedDate
    FROM Users u
    INNER JOIN Roles r ON u.RoleId = r.RoleId
    WHERE u.Username = @Username
    AND u.PasswordHash = @PasswordHash
    AND u.IsActive = 1;
END
GO

-- =============================================
-- Stored Procedure: usp_User_GetById
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_User_GetById')
    DROP PROCEDURE usp_User_GetById;
GO

CREATE PROCEDURE usp_User_GetById
    @UserId INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        u.UserId,
        u.Username,
        u.FullName,
        u.Email,
        u.RoleId,
        r.RoleName,
        u.IsActive,
        u.CreatedDate,
        u.CreatedBy,
        u.ModifiedDate,
        u.ModifiedBy,
        u.PasswordHash,
        u.PasswordEnc
    FROM Users u
    INNER JOIN Roles r ON u.RoleId = r.RoleId
    WHERE u.UserId = @UserId;
END
GO

-- =============================================
-- Stored Procedure: usp_User_GetAll
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_User_GetAll')
    DROP PROCEDURE usp_User_GetAll;
GO

CREATE PROCEDURE usp_User_GetAll
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        u.UserId,
        u.Username,
        u.FullName,
        u.Email,
        u.RoleId,
        r.RoleName,
        u.IsActive,
        u.CreatedDate,
        u.CreatedBy,
        u.ModifiedDate,
        u.ModifiedBy,
        u.PasswordHash,
        u.PasswordEnc
    FROM Users u
    INNER JOIN Roles r ON u.RoleId = r.RoleId
    ORDER BY u.FullName;
END
GO

-- =============================================
-- Stored Procedure: usp_User_Insert
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_User_Insert')
    DROP PROCEDURE usp_User_Insert;
GO

CREATE PROCEDURE usp_User_Insert
    @Username NVARCHAR(50),
    @FullName NVARCHAR(100),
    @Email NVARCHAR(100),
    @PasswordHash NVARCHAR(500),
    @PasswordEnc NVARCHAR(1000) = NULL,
    @RoleId INT,
    @CreatedBy INT,
    @UserId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO Users (Username, FullName, Email, PasswordHash, PasswordEnc, RoleId, IsActive, CreatedBy, CreatedDate)
    VALUES (@Username, @FullName, @Email, @PasswordHash, @PasswordEnc, @RoleId, 1, @CreatedBy, GETDATE());

    SET @UserId = SCOPE_IDENTITY();
END
GO

-- =============================================
-- Stored Procedure: usp_User_Update
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_User_Update')
    DROP PROCEDURE usp_User_Update;
GO

CREATE PROCEDURE usp_User_Update
    @UserId INT,
    @FullName NVARCHAR(100),
    @Email NVARCHAR(100),
    @RoleId INT,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE Users
    SET FullName = @FullName,
        Email = @Email,
        RoleId = @RoleId,
        ModifiedBy = @ModifiedBy,
        ModifiedDate = GETDATE()
    WHERE UserId = @UserId;
END
GO

-- =============================================
-- Stored Procedure: usp_User_ChangePassword
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_User_ChangePassword')
    DROP PROCEDURE usp_User_ChangePassword;
GO

CREATE PROCEDURE usp_User_ChangePassword
    @UserId INT,
    @NewPasswordHash NVARCHAR(500),
    @NewPasswordEnc NVARCHAR(1000) = NULL,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE Users
    SET PasswordHash = @NewPasswordHash,
        PasswordEnc = @NewPasswordEnc,
        ModifiedBy = @ModifiedBy,
        ModifiedDate = GETDATE()
    WHERE UserId = @UserId;
END
GO

-- =============================================
-- Stored Procedure: usp_User_Activate
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_User_Activate')
    DROP PROCEDURE usp_User_Activate;
GO

CREATE PROCEDURE usp_User_Activate
    @UserId INT,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE Users
    SET IsActive = 1,
        ModifiedBy = @ModifiedBy,
        ModifiedDate = GETDATE()
    WHERE UserId = @UserId;
END
GO

-- =============================================
-- Stored Procedure: usp_User_Deactivate
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_User_Deactivate')
    DROP PROCEDURE usp_User_Deactivate;
GO

CREATE PROCEDURE usp_User_Deactivate
    @UserId INT,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (
        SELECT 1 FROM Users u
        INNER JOIN Roles r ON u.RoleId = r.RoleId
        WHERE u.UserId = @UserId AND r.RoleName = 'Super Admin'
    )
    BEGIN
        RAISERROR('Super Admin cannot be deactivated.', 16, 1);
        RETURN;
    END

    UPDATE Users
    SET IsActive = 0,
        ModifiedBy = @ModifiedBy,
        ModifiedDate = GETDATE()
    WHERE UserId = @UserId;
END
GO

-- =============================================
-- Stored Procedure: usp_UserPermission_Get
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_UserPermission_Get')
    DROP PROCEDURE usp_UserPermission_Get;
GO

CREATE PROCEDURE usp_UserPermission_Get
    @UserId INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        p.PageId,
        p.PageName,
        ISNULL(up.CanView, 0) AS CanView,
        ISNULL(up.CanEdit, 0) AS CanEdit,
        ISNULL(up.CanDelete, 0) AS CanDelete,
        ISNULL(up.CanExport, 0) AS CanExport
    FROM Pages p
    LEFT JOIN UserPermissions up ON p.PageId = up.PageId AND up.UserId = @UserId
    ORDER BY p.PageName;
END
GO

-- =============================================
-- Stored Procedure: usp_UserPermission_Save
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_UserPermission_Save')
    DROP PROCEDURE usp_UserPermission_Save;
GO

CREATE PROCEDURE usp_UserPermission_Save
    @UserId INT,
    @PageId INT,
    @CanView BIT,
    @CanEdit BIT,
    @CanDelete BIT,
    @CanExport BIT = 0,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (SELECT 1 FROM UserPermissions WHERE UserId = @UserId AND PageId = @PageId)
    BEGIN
        UPDATE UserPermissions
        SET CanView = @CanView,
            CanEdit = @CanEdit,
            CanDelete = @CanDelete,
            CanExport = @CanExport,
            ModifiedBy = @ModifiedBy,
            ModifiedDate = GETDATE()
        WHERE UserId = @UserId AND PageId = @PageId;
    END
    ELSE
    BEGIN
        INSERT INTO UserPermissions (UserId, PageId, CanView, CanEdit, CanDelete, CanExport, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate)
        VALUES (@UserId, @PageId, @CanView, @CanEdit, @CanDelete, @CanExport, @ModifiedBy, GETDATE(), @ModifiedBy, GETDATE());
    END
END
GO

-- =============================================
-- Stored Procedure: usp_Project_GetAll
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Project_GetAll')
    DROP PROCEDURE usp_Project_GetAll;
GO

CREATE PROCEDURE usp_Project_GetAll
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        p.ProjectId,
        p.ProjectCode,
        p.ProjectName,
        p.Description,
        p.ClientName,
        p.StartDate,
        p.EndDate,
        p.TotalBudget,
        p.Status,
        p.IsActive,
        p.CreatedBy,
        p.CreatedDate,
        p.ModifiedBy,
        p.ModifiedDate
    FROM Projects p
    ORDER BY p.ProjectCode;
END
GO

-- =============================================
-- Stored Procedure: usp_Project_GetById
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Project_GetById')
    DROP PROCEDURE usp_Project_GetById;
GO

CREATE PROCEDURE usp_Project_GetById
    @ProjectId INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        p.ProjectId,
        p.ProjectCode,
        p.ProjectName,
        p.Description,
        p.ClientName,
        p.StartDate,
        p.EndDate,
        p.TotalBudget,
        p.Status,
        p.IsActive,
        p.CreatedBy,
        p.CreatedDate,
        p.ModifiedBy,
        p.ModifiedDate
    FROM Projects p
    WHERE p.ProjectId = @ProjectId;
END
GO

-- =============================================
-- Stored Procedure: usp_Project_Insert
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Project_Insert')
    DROP PROCEDURE usp_Project_Insert;
GO

CREATE PROCEDURE usp_Project_Insert
    @ProjectCode NVARCHAR(20),
    @ProjectName NVARCHAR(200),
    @Description NVARCHAR(500),
    @ClientName NVARCHAR(200),
    @StartDate DATE,
    @EndDate DATE,
    @TotalBudget DECIMAL(18,2),
    @Status NVARCHAR(20),
    @CreatedBy INT,
    @ProjectId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO Projects (ProjectCode, ProjectName, Description, ClientName, StartDate, EndDate, TotalBudget, Status, IsActive, CreatedBy, CreatedDate)
    VALUES (@ProjectCode, @ProjectName, @Description, @ClientName, @StartDate, @EndDate, @TotalBudget, @Status, 1, @CreatedBy, GETDATE());

    SET @ProjectId = SCOPE_IDENTITY();
END
GO

-- =============================================
-- Stored Procedure: usp_Project_Update
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Project_Update')
    DROP PROCEDURE usp_Project_Update;
GO

CREATE PROCEDURE usp_Project_Update
    @ProjectId INT,
    @ProjectName NVARCHAR(200),
    @Description NVARCHAR(500),
    @ClientName NVARCHAR(200),
    @StartDate DATE,
    @EndDate DATE,
    @TotalBudget DECIMAL(18,2),
    @Status NVARCHAR(20),
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE Projects
    SET ProjectName = @ProjectName,
        Description = @Description,
        ClientName = @ClientName,
        StartDate = @StartDate,
        EndDate = @EndDate,
        TotalBudget = @TotalBudget,
        Status = @Status,
        ModifiedBy = @ModifiedBy,
        ModifiedDate = GETDATE()
    WHERE ProjectId = @ProjectId;
END
GO

-- =============================================
-- Stored Procedure: usp_Project_SetActive
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Project_SetActive')
    DROP PROCEDURE usp_Project_SetActive;
GO

CREATE PROCEDURE usp_Project_SetActive
    @ProjectId INT,
    @IsActive BIT,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE Projects
    SET IsActive = @IsActive,
        ModifiedBy = @ModifiedBy,
        ModifiedDate = GETDATE()
    WHERE ProjectId = @ProjectId;
END
GO

-- =============================================
-- Stored Procedure: usp_BudgetCode_GetAll
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_BudgetCode_GetAll')
    DROP PROCEDURE usp_BudgetCode_GetAll;
GO

CREATE PROCEDURE usp_BudgetCode_GetAll
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        bc.BudgetCodeId,
        bc.BudgetCode,
        bc.BudgetCodeName,
        bc.Description,
        bc.IsActive,
        bc.CreatedBy,
        bc.CreatedDate,
        bc.ModifiedBy,
        bc.ModifiedDate
    FROM BudgetCodes bc
    ORDER BY bc.BudgetCode;
END
GO

-- =============================================
-- Stored Procedure: usp_BudgetCode_Insert
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_BudgetCode_Insert')
    DROP PROCEDURE usp_BudgetCode_Insert;
GO

CREATE PROCEDURE usp_BudgetCode_Insert
    @BudgetCode NVARCHAR(20),
    @BudgetCodeName NVARCHAR(100),
    @Description NVARCHAR(200),
    @CreatedBy INT,
    @BudgetCodeId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO BudgetCodes (BudgetCode, BudgetCodeName, Description, IsActive, CreatedBy, CreatedDate)
    VALUES (@BudgetCode, @BudgetCodeName, @Description, 1, @CreatedBy, GETDATE());

    SET @BudgetCodeId = SCOPE_IDENTITY();
END
GO

-- =============================================
-- Stored Procedure: usp_BudgetCode_Update
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_BudgetCode_Update')
    DROP PROCEDURE usp_BudgetCode_Update;
GO

CREATE PROCEDURE usp_BudgetCode_Update
    @BudgetCodeId INT,
    @BudgetCodeName NVARCHAR(100),
    @Description NVARCHAR(200),
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE BudgetCodes
    SET BudgetCodeName = @BudgetCodeName,
        Description = @Description,
        ModifiedBy = @ModifiedBy,
        ModifiedDate = GETDATE()
    WHERE BudgetCodeId = @BudgetCodeId;
END
GO

-- =============================================
-- Stored Procedure: usp_BudgetCode_SetActive
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_BudgetCode_SetActive')
    DROP PROCEDURE usp_BudgetCode_SetActive;
GO

CREATE PROCEDURE usp_BudgetCode_SetActive
    @BudgetCodeId INT,
    @IsActive BIT,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE BudgetCodes
    SET IsActive = @IsActive,
        ModifiedBy = @ModifiedBy,
        ModifiedDate = GETDATE()
    WHERE BudgetCodeId = @BudgetCodeId;
END
GO

-- =============================================
-- Stored Procedure: usp_Resource_GetAll
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Resource_GetAll')
    DROP PROCEDURE usp_Resource_GetAll;
GO

CREATE PROCEDURE usp_Resource_GetAll
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        r.ResourceId,
        r.ResourceCode,
        r.ResourceName,
        r.ResourceType,
        r.Email,
        r.Phone,
        r.Department,
        r.IsActive,
        r.CreatedBy,
        r.CreatedDate,
        r.ModifiedBy,
        r.ModifiedDate
    FROM Resources r
    ORDER BY r.ResourceCode;
END
GO

-- =============================================
-- Stored Procedure: usp_Resource_Insert
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Resource_Insert')
    DROP PROCEDURE usp_Resource_Insert;
GO

CREATE PROCEDURE usp_Resource_Insert
    @ResourceCode NVARCHAR(20),
    @ResourceName NVARCHAR(100),
    @ResourceType NVARCHAR(20),
    @Email NVARCHAR(100),
    @Phone NVARCHAR(20),
    @Department NVARCHAR(100),
    @CreatedBy INT,
    @ResourceId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO Resources (ResourceCode, ResourceName, ResourceType, Email, Phone, Department, IsActive, CreatedBy, CreatedDate)
    VALUES (@ResourceCode, @ResourceName, @ResourceType, @Email, @Phone, @Department, 1, @CreatedBy, GETDATE());

    SET @ResourceId = SCOPE_IDENTITY();
END
GO

-- =============================================
-- Stored Procedure: usp_Resource_Update
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Resource_Update')
    DROP PROCEDURE usp_Resource_Update;
GO

CREATE PROCEDURE usp_Resource_Update
    @ResourceId INT,
    @ResourceName NVARCHAR(100),
    @ResourceType NVARCHAR(20),
    @Email NVARCHAR(100),
    @Phone NVARCHAR(20),
    @Department NVARCHAR(100),
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE Resources
    SET ResourceName = @ResourceName,
        ResourceType = @ResourceType,
        Email = @Email,
        Phone = @Phone,
        Department = @Department,
        ModifiedBy = @ModifiedBy,
        ModifiedDate = GETDATE()
    WHERE ResourceId = @ResourceId;
END
GO

-- =============================================
-- Stored Procedure: usp_Resource_SetActive
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Resource_SetActive')
    DROP PROCEDURE usp_Resource_SetActive;
GO

CREATE PROCEDURE usp_Resource_SetActive
    @ResourceId INT,
    @IsActive BIT,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE Resources
    SET IsActive = @IsActive,
        ModifiedBy = @ModifiedBy,
        ModifiedDate = GETDATE()
    WHERE ResourceId = @ResourceId;
END
GO

-- =============================================
-- Stored Procedure: usp_ProjectBudget_Get
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_ProjectBudget_Get')
    DROP PROCEDURE usp_ProjectBudget_Get;
GO

CREATE PROCEDURE usp_ProjectBudget_Get
    @ProjectId INT = NULL,
    @BudgetCodeId INT = NULL,
    @SearchText NVARCHAR(100) = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @SortBy NVARCHAR(50) = 'projectName',
    @SortDir NVARCHAR(4) = 'asc',
    @TotalRecords INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@PageNumber IS NULL OR @PageNumber < 1) SET @PageNumber = 1;
    IF (@PageSize IS NULL OR @PageSize < 1) SET @PageSize = 10;
    IF (@PageSize > 100) SET @PageSize = 100;
    SET @SearchText = NULLIF(LTRIM(RTRIM(ISNULL(@SearchText, ''))), '');
    SET @SortBy = LOWER(LTRIM(RTRIM(ISNULL(@SortBy, 'projectName'))));
    IF (@SortBy NOT IN ('projectbudgetid', 'projectcode', 'projectname', 'budgetcode', 'budgetcodename', 'budgetamount', 'effectivefrom'))
        SET @SortBy = 'projectname';
    SET @SortDir = LOWER(LTRIM(RTRIM(ISNULL(@SortDir, 'asc'))));
    IF (@SortDir NOT IN ('asc', 'desc'))
        SET @SortDir = 'asc';

    SELECT @TotalRecords = COUNT(*)
    FROM ProjectBudgets pb
    INNER JOIN Projects p ON pb.ProjectId = p.ProjectId
    INNER JOIN BudgetCodes bc ON pb.BudgetCodeId = bc.BudgetCodeId
    WHERE (@ProjectId IS NULL OR pb.ProjectId = @ProjectId)
    AND (@BudgetCodeId IS NULL OR pb.BudgetCodeId = @BudgetCodeId)
    AND (@SearchText IS NULL OR p.ProjectCode LIKE '%' + @SearchText + '%' OR p.ProjectName LIKE '%' + @SearchText + '%');

    SELECT
        pb.ProjectBudgetId,
        pb.ProjectId,
        p.ProjectCode,
        p.ProjectName,
        pb.BudgetCodeId,
        bc.BudgetCode,
        bc.BudgetCodeName,
        pb.BudgetAmount,
        pb.EffectiveFrom,
        pb.EffectiveTo,
        pb.IsActive,
        pb.CreatedBy,
        pb.CreatedDate,
        pb.ModifiedBy,
        pb.ModifiedDate
    FROM ProjectBudgets pb
    INNER JOIN Projects p ON pb.ProjectId = p.ProjectId
    INNER JOIN BudgetCodes bc ON pb.BudgetCodeId = bc.BudgetCodeId
    WHERE (@ProjectId IS NULL OR pb.ProjectId = @ProjectId)
    AND (@BudgetCodeId IS NULL OR pb.BudgetCodeId = @BudgetCodeId)
    AND (@SearchText IS NULL OR p.ProjectCode LIKE '%' + @SearchText + '%' OR p.ProjectName LIKE '%' + @SearchText + '%')
    ORDER BY
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'projectbudgetid' THEN pb.ProjectBudgetId END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'projectbudgetid' THEN pb.ProjectBudgetId END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'projectcode' THEN p.ProjectCode END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'projectcode' THEN p.ProjectCode END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'projectname' THEN p.ProjectName END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'projectname' THEN p.ProjectName END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'budgetcode' THEN bc.BudgetCode END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'budgetcode' THEN bc.BudgetCode END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'budgetcodename' THEN bc.BudgetCodeName END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'budgetcodename' THEN bc.BudgetCodeName END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'budgetamount' THEN pb.BudgetAmount END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'budgetamount' THEN pb.BudgetAmount END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'effectivefrom' THEN pb.EffectiveFrom END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'effectivefrom' THEN pb.EffectiveFrom END DESC,
        pb.ProjectBudgetId ASC
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

-- =============================================
-- Stored Procedure: usp_ProjectBudget_Insert
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_ProjectBudget_Insert')
    DROP PROCEDURE usp_ProjectBudget_Insert;
GO

CREATE PROCEDURE usp_ProjectBudget_Insert
    @ProjectId INT,
    @BudgetCodeId INT,
    @BudgetAmount DECIMAL(18,2),
    @EffectiveFrom DATE,
    @EffectiveTo DATE,
    @CreatedBy INT,
    @ProjectBudgetId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO ProjectBudgets (ProjectId, BudgetCodeId, BudgetAmount, EffectiveFrom, EffectiveTo, IsActive, CreatedBy, CreatedDate)
    VALUES (@ProjectId, @BudgetCodeId, @BudgetAmount, @EffectiveFrom, @EffectiveTo, 1, @CreatedBy, GETDATE());

    SET @ProjectBudgetId = SCOPE_IDENTITY();
END
GO

-- =============================================
-- Stored Procedure: usp_ProjectBudget_Update
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_ProjectBudget_Update')
    DROP PROCEDURE usp_ProjectBudget_Update;
GO

CREATE PROCEDURE usp_ProjectBudget_Update
    @ProjectBudgetId INT,
    @BudgetAmount DECIMAL(18,2),
    @EffectiveFrom DATE,
    @EffectiveTo DATE,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE ProjectBudgets
    SET BudgetAmount = @BudgetAmount,
        EffectiveFrom = @EffectiveFrom,
        EffectiveTo = @EffectiveTo,
        ModifiedBy = @ModifiedBy,
        ModifiedDate = GETDATE()
    WHERE ProjectBudgetId = @ProjectBudgetId;
END
GO

-- =============================================
-- Stored Procedure: usp_ProjectBudget_Delete
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_ProjectBudget_Delete')
    DROP PROCEDURE usp_ProjectBudget_Delete;
GO

CREATE PROCEDURE usp_ProjectBudget_Delete
    @ProjectBudgetId INT,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE ProjectBudgets
    SET IsActive = 0,
        ModifiedBy = @ModifiedBy,
        ModifiedDate = GETDATE()
    WHERE ProjectBudgetId = @ProjectBudgetId;
END
GO

-- =============================================
-- Stored Procedure: usp_ProjectResource_Get
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_ProjectResource_Get')
    DROP PROCEDURE usp_ProjectResource_Get;
GO

CREATE PROCEDURE usp_ProjectResource_Get
    @ProjectId INT = NULL,
    @ResourceId INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        pr.ProjectResourceId,
        pr.ProjectId,
        p.ProjectCode,
        p.ProjectName,
        pr.ResourceId,
        r.ResourceCode,
        r.ResourceName,
        r.ResourceType,
        pr.AssignedFrom,
        pr.AssignedTo,
        pr.IsActive,
        pr.CreatedBy,
        pr.CreatedDate,
        pr.ModifiedBy,
        pr.ModifiedDate
    FROM ProjectResources pr
    INNER JOIN Projects p ON pr.ProjectId = p.ProjectId
    INNER JOIN Resources r ON pr.ResourceId = r.ResourceId
    WHERE (@ProjectId IS NULL OR pr.ProjectId = @ProjectId)
    AND (@ResourceId IS NULL OR pr.ResourceId = @ResourceId)
    ORDER BY p.ProjectCode, r.ResourceCode;
END
GO

-- =============================================
-- Stored Procedure: usp_ProjectResource_Insert
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_ProjectResource_Insert')
    DROP PROCEDURE usp_ProjectResource_Insert;
GO

CREATE PROCEDURE usp_ProjectResource_Insert
    @ProjectId INT,
    @ResourceId INT,
    @AssignedFrom DATE,
    @AssignedTo DATE,
    @CreatedBy INT,
    @ProjectResourceId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO ProjectResources (ProjectId, ResourceId, AssignedFrom, AssignedTo, IsActive, CreatedBy, CreatedDate)
    VALUES (@ProjectId, @ResourceId, @AssignedFrom, @AssignedTo, 1, @CreatedBy, GETDATE());

    SET @ProjectResourceId = SCOPE_IDENTITY();
END
GO

-- =============================================
-- Stored Procedure: usp_ProjectResource_Update
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_ProjectResource_Update')
    DROP PROCEDURE usp_ProjectResource_Update;
GO

CREATE PROCEDURE usp_ProjectResource_Update
    @ProjectResourceId INT,
    @AssignedFrom DATE,
    @AssignedTo DATE,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE ProjectResources
    SET AssignedFrom = @AssignedFrom,
        AssignedTo = @AssignedTo,
        ModifiedBy = @ModifiedBy,
        ModifiedDate = GETDATE()
    WHERE ProjectResourceId = @ProjectResourceId;
END
GO

-- =============================================
-- Stored Procedure: usp_ProjectResource_Delete
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_ProjectResource_Delete')
    DROP PROCEDURE usp_ProjectResource_Delete;
GO

CREATE PROCEDURE usp_ProjectResource_Delete
    @ProjectResourceId INT,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE ProjectResources
    SET IsActive = 0,
        ModifiedBy = @ModifiedBy,
        ModifiedDate = GETDATE()
    WHERE ProjectResourceId = @ProjectResourceId;
END
GO

-- =============================================
-- Stored Procedure: usp_Expense_GetById
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Expense_GetById')
    DROP PROCEDURE usp_Expense_GetById;
GO

CREATE PROCEDURE usp_Expense_GetById
    @ExpenseId INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        e.ExpenseId,
        e.ExpenseDate,
        e.ProjectId,
        p.ProjectCode,
        p.ProjectName,
        e.BudgetCodeId,
        bc.BudgetCode,
        bc.BudgetCodeName,
        e.ResourceId,
        r.ResourceCode,
        r.ResourceName,
        e.Amount,
        e.Description,
        e.ReferenceNo,
        e.Remarks,
        e.IsDeleted,
        e.CreatedBy,
        e.CreatedDate,
        e.ModifiedBy,
        e.ModifiedDate
    FROM Expenses e
    INNER JOIN Projects p ON e.ProjectId = p.ProjectId
    INNER JOIN BudgetCodes bc ON e.BudgetCodeId = bc.BudgetCodeId
    INNER JOIN Resources r ON e.ResourceId = r.ResourceId
    WHERE e.ExpenseId = @ExpenseId;
END
GO

-- =============================================
-- Stored Procedure: usp_Expense_GetByDate
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Expense_GetByDate')
    DROP PROCEDURE usp_Expense_GetByDate;
GO

CREATE PROCEDURE usp_Expense_GetByDate
    @ExpenseDate DATE
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        e.ExpenseId,
        e.ExpenseDate,
        e.ProjectId,
        p.ProjectCode,
        p.ProjectName,
        e.BudgetCodeId,
        bc.BudgetCode,
        bc.BudgetCodeName,
        e.ResourceId,
        r.ResourceCode,
        r.ResourceName,
        e.Amount,
        e.Description,
        e.ReferenceNo,
        e.Remarks,
        e.CreatedBy,
        e.CreatedDate
    FROM Expenses e
    INNER JOIN Projects p ON e.ProjectId = p.ProjectId
    INNER JOIN BudgetCodes bc ON e.BudgetCodeId = bc.BudgetCodeId
    INNER JOIN Resources r ON e.ResourceId = r.ResourceId
    WHERE e.ExpenseDate = @ExpenseDate
    AND e.IsDeleted = 0
    ORDER BY e.CreatedDate DESC;
END
GO

-- =============================================
-- Stored Procedure: usp_Expense_GetByDateRange
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Expense_GetByDateRange')
    DROP PROCEDURE usp_Expense_GetByDateRange;
GO

CREATE PROCEDURE usp_Expense_GetByDateRange
    @FromDate DATE,
    @ToDate DATE,
    @ProjectId INT = NULL,
    @BudgetCodeId INT = NULL,
    @ResourceId INT = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @SortBy NVARCHAR(50) = 'expenseDate',
    @SortDir NVARCHAR(4) = 'desc',
    @TotalRecords INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@PageNumber IS NULL OR @PageNumber < 1) SET @PageNumber = 1;
    IF (@PageSize IS NULL OR @PageSize < 1) SET @PageSize = 10;
    IF (@PageSize > 100) SET @PageSize = 100;
    SET @SortBy = LOWER(LTRIM(RTRIM(ISNULL(@SortBy, 'expenseDate'))));
    IF (@SortBy NOT IN ('expenseid', 'expensedate', 'projectcode', 'projectname', 'budgetcode', 'budgetcodename', 'resourcename', 'amount', 'createddate'))
        SET @SortBy = 'expenseDate';
    SET @SortDir = LOWER(LTRIM(RTRIM(ISNULL(@SortDir, 'desc'))));
    IF (@SortDir NOT IN ('asc', 'desc'))
        SET @SortDir = 'desc';

    SELECT @TotalRecords = COUNT(*)
    FROM Expenses e
    WHERE e.ExpenseDate BETWEEN @FromDate AND @ToDate
    AND e.IsDeleted = 0
    AND (@ProjectId IS NULL OR e.ProjectId = @ProjectId)
    AND (@BudgetCodeId IS NULL OR e.BudgetCodeId = @BudgetCodeId)
    AND (@ResourceId IS NULL OR e.ResourceId = @ResourceId);

    SELECT
        e.ExpenseId,
        e.ExpenseDate,
        e.ProjectId,
        p.ProjectCode,
        p.ProjectName,
        e.BudgetCodeId,
        bc.BudgetCode,
        bc.BudgetCodeName,
        e.ResourceId,
        r.ResourceCode,
        r.ResourceName,
        e.Amount,
        e.Description,
        e.ReferenceNo,
        e.Remarks,
        e.CreatedBy,
        e.CreatedDate
    FROM Expenses e
    INNER JOIN Projects p ON e.ProjectId = p.ProjectId
    INNER JOIN BudgetCodes bc ON e.BudgetCodeId = bc.BudgetCodeId
    INNER JOIN Resources r ON e.ResourceId = r.ResourceId
    WHERE e.ExpenseDate BETWEEN @FromDate AND @ToDate
    AND e.IsDeleted = 0
    AND (@ProjectId IS NULL OR e.ProjectId = @ProjectId)
    AND (@BudgetCodeId IS NULL OR e.BudgetCodeId = @BudgetCodeId)
    AND (@ResourceId IS NULL OR e.ResourceId = @ResourceId)
    ORDER BY
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'expenseid' THEN e.ExpenseId END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'expenseid' THEN e.ExpenseId END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'expensedate' THEN e.ExpenseDate END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'expensedate' THEN e.ExpenseDate END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'projectcode' THEN p.ProjectCode END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'projectcode' THEN p.ProjectCode END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'projectname' THEN p.ProjectName END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'projectname' THEN p.ProjectName END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'budgetcode' THEN bc.BudgetCode END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'budgetcode' THEN bc.BudgetCode END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'budgetcodename' THEN bc.BudgetCodeName END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'budgetcodename' THEN bc.BudgetCodeName END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'resourcename' THEN r.ResourceName END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'resourcename' THEN r.ResourceName END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'amount' THEN e.Amount END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'amount' THEN e.Amount END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'createddate' THEN e.CreatedDate END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'createddate' THEN e.CreatedDate END DESC,
        e.ExpenseDate DESC,
        e.CreatedDate DESC
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

-- =============================================
-- Stored Procedure: usp_Expense_Insert
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Expense_Insert')
    DROP PROCEDURE usp_Expense_Insert;
GO

CREATE PROCEDURE usp_Expense_Insert
    @ExpenseDate DATE,
    @ProjectId INT,
    @BudgetCodeId INT,
    @ResourceId INT,
    @Amount DECIMAL(18,2),
    @Description NVARCHAR(500),
    @ReferenceNo NVARCHAR(50),
    @Remarks NVARCHAR(500),
    @CreatedBy INT,
    @ExpenseId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO Expenses (ExpenseDate, ProjectId, BudgetCodeId, ResourceId, Amount, Description, ReferenceNo, Remarks, IsDeleted, CreatedBy, CreatedDate)
    VALUES (@ExpenseDate, @ProjectId, @BudgetCodeId, @ResourceId, @Amount, @Description, @ReferenceNo, @Remarks, 0, @CreatedBy, GETDATE());

    SET @ExpenseId = SCOPE_IDENTITY();
END
GO

-- =============================================
-- Stored Procedure: usp_Expense_Update
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Expense_Update')
    DROP PROCEDURE usp_Expense_Update;
GO

CREATE PROCEDURE usp_Expense_Update
    @ExpenseId INT,
    @ExpenseDate DATE,
    @ProjectId INT,
    @BudgetCodeId INT,
    @ResourceId INT,
    @Amount DECIMAL(18,2),
    @Description NVARCHAR(500),
    @ReferenceNo NVARCHAR(50),
    @Remarks NVARCHAR(500),
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE Expenses
    SET ExpenseDate = @ExpenseDate,
        ProjectId = @ProjectId,
        BudgetCodeId = @BudgetCodeId,
        ResourceId = @ResourceId,
        Amount = @Amount,
        Description = @Description,
        ReferenceNo = @ReferenceNo,
        Remarks = @Remarks,
        ModifiedBy = @ModifiedBy,
        ModifiedDate = GETDATE()
    WHERE ExpenseId = @ExpenseId;
END
GO

-- =============================================
-- Stored Procedure: usp_Expense_Delete
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Expense_Delete')
    DROP PROCEDURE usp_Expense_Delete;
GO

CREATE PROCEDURE usp_Expense_Delete
    @ExpenseId INT,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE Expenses
    SET IsDeleted = 1,
        ModifiedBy = @ModifiedBy,
        ModifiedDate = GETDATE()
    WHERE ExpenseId = @ExpenseId;
END
GO

-- =============================================
-- Stored Procedure: usp_Expense_CopyFromDate
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Expense_CopyFromDate')
    DROP PROCEDURE usp_Expense_CopyFromDate;
GO

CREATE PROCEDURE usp_Expense_CopyFromDate
    @FromDate DATE,
    @ToDate DATE,
    @ProjectId INT = NULL,
    @ResourceId INT = NULL,
    @CreatedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO Expenses (ExpenseDate, ProjectId, BudgetCodeId, ResourceId, Amount, Description, ReferenceNo, Remarks, IsDeleted, CreatedBy, CreatedDate)
    SELECT
        @ToDate,
        e.ProjectId,
        e.BudgetCodeId,
        e.ResourceId,
        e.Amount,
        e.Description,
        e.ReferenceNo,
        e.Remarks,
        0,
        @CreatedBy,
        GETDATE()
    FROM Expenses e
    WHERE e.ExpenseDate = @FromDate
    AND e.IsDeleted = 0
    AND (@ProjectId IS NULL OR e.ProjectId = @ProjectId)
    AND (@ResourceId IS NULL OR e.ResourceId = @ResourceId);
END
GO

-- =============================================
-- Stored Procedure: usp_Dashboard_Summary
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Dashboard_Summary')
    DROP PROCEDURE usp_Dashboard_Summary;
GO

CREATE PROCEDURE usp_Dashboard_Summary
    @ProjectId INT = NULL,
    @BudgetCodeId INT = NULL,
    @FromDate DATE = NULL,
    @ToDate DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF @FromDate IS NULL
        SET @FromDate = DATEADD(MONTH, -6, GETDATE());
    IF @ToDate IS NULL
        SET @ToDate = GETDATE();

    SELECT
        (SELECT COUNT(*) FROM Projects WHERE IsActive = 1) AS TotalProjects,
        (SELECT COUNT(*) FROM Projects WHERE IsActive = 1 AND Status = 'Active') AS ActiveProjects,
        ISNULL((SELECT SUM(pb.BudgetAmount) FROM ProjectBudgets pb
                INNER JOIN Projects p ON pb.ProjectId = p.ProjectId
                WHERE pb.IsActive = 1 AND p.IsActive = 1
                AND (@ProjectId IS NULL OR pb.ProjectId = @ProjectId)
                AND (@BudgetCodeId IS NULL OR pb.BudgetCodeId = @BudgetCodeId)), 0) AS TotalBudget,
        ISNULL((SELECT SUM(e.Amount) FROM Expenses e
                WHERE e.IsDeleted = 0
                AND e.ExpenseDate BETWEEN @FromDate AND @ToDate
                AND (@ProjectId IS NULL OR e.ProjectId = @ProjectId)
                AND (@BudgetCodeId IS NULL OR e.BudgetCodeId = @BudgetCodeId)), 0) AS TotalExpense,
        (SELECT COUNT(*) FROM Resources WHERE IsActive = 1) AS ActiveResources;
END
GO

-- =============================================
-- Stored Procedure: usp_Dashboard_ProjectWise
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Dashboard_ProjectWise')
    DROP PROCEDURE usp_Dashboard_ProjectWise;
GO

CREATE PROCEDURE usp_Dashboard_ProjectWise
    @FromDate DATE = NULL,
    @ToDate DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF @FromDate IS NULL
        SET @FromDate = DATEADD(MONTH, -6, GETDATE());
    IF @ToDate IS NULL
        SET @ToDate = GETDATE();

    SELECT
        p.ProjectId,
        p.ProjectCode,
        p.ProjectName,
        ISNULL(SUM(e.Amount), 0) AS TotalExpense
    FROM Projects p
    LEFT JOIN Expenses e ON p.ProjectId = e.ProjectId AND e.IsDeleted = 0
        AND e.ExpenseDate BETWEEN @FromDate AND @ToDate
    WHERE p.IsActive = 1
    GROUP BY p.ProjectId, p.ProjectCode, p.ProjectName
    ORDER BY TotalExpense DESC;
END
GO

-- =============================================
-- Stored Procedure: usp_Dashboard_BudgetCodeWise
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Dashboard_BudgetCodeWise')
    DROP PROCEDURE usp_Dashboard_BudgetCodeWise;
GO

CREATE PROCEDURE usp_Dashboard_BudgetCodeWise
    @FromDate DATE = NULL,
    @ToDate DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF @FromDate IS NULL
        SET @FromDate = DATEADD(MONTH, -6, GETDATE());
    IF @ToDate IS NULL
        SET @ToDate = GETDATE();

    SELECT
        bc.BudgetCodeId,
        bc.BudgetCode,
        bc.BudgetCodeName,
        ISNULL(SUM(e.Amount), 0) AS TotalExpense
    FROM BudgetCodes bc
    LEFT JOIN Expenses e ON bc.BudgetCodeId = e.BudgetCodeId AND e.IsDeleted = 0
        AND e.ExpenseDate BETWEEN @FromDate AND @ToDate
    WHERE bc.IsActive = 1
    GROUP BY bc.BudgetCodeId, bc.BudgetCode, bc.BudgetCodeName
    ORDER BY TotalExpense DESC;
END
GO

-- =============================================
-- Stored Procedure: usp_Dashboard_Monthly
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Dashboard_Monthly')
    DROP PROCEDURE usp_Dashboard_Monthly;
GO

CREATE PROCEDURE usp_Dashboard_Monthly
    @FromDate DATE = NULL,
    @ToDate DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF @FromDate IS NULL
        SET @FromDate = DATEADD(MONTH, -6, GETDATE());
    IF @ToDate IS NULL
        SET @ToDate = GETDATE();

    SELECT
        YEAR(e.ExpenseDate) AS ExpenseYear,
        MONTH(e.ExpenseDate) AS ExpenseMonth,
        DATENAME(MONTH, e.ExpenseDate) AS MonthName,
        SUM(e.Amount) AS TotalExpense
    FROM Expenses e
    WHERE e.IsDeleted = 0
    AND e.ExpenseDate BETWEEN @FromDate AND @ToDate
    GROUP BY YEAR(e.ExpenseDate), MONTH(e.ExpenseDate), DATENAME(MONTH, e.ExpenseDate)
    ORDER BY YEAR(e.ExpenseDate), MONTH(e.ExpenseDate);
END
GO

-- =============================================
-- Stored Procedure: usp_Dashboard_YearWise
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Dashboard_YearWise')
    DROP PROCEDURE usp_Dashboard_YearWise;
GO

CREATE PROCEDURE usp_Dashboard_YearWise
    @Year INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF @Year IS NULL
        SET @Year = YEAR(GETDATE());

    SELECT
        YEAR(e.ExpenseDate) AS ExpenseYear,
        SUM(e.Amount) AS TotalExpense
    FROM Expenses e
    WHERE e.IsDeleted = 0
    AND YEAR(e.ExpenseDate) = @Year
    GROUP BY YEAR(e.ExpenseDate);
END
GO

-- =============================================
-- Stored Procedure: usp_Dashboard_ResourceWise
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Dashboard_ResourceWise')
    DROP PROCEDURE usp_Dashboard_ResourceWise;
GO

CREATE PROCEDURE usp_Dashboard_ResourceWise
    @FromDate DATE = NULL,
    @ToDate DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF @FromDate IS NULL
        SET @FromDate = DATEADD(MONTH, -6, GETDATE());
    IF @ToDate IS NULL
        SET @ToDate = GETDATE();

    SELECT
        r.ResourceId,
        r.ResourceCode,
        r.ResourceName,
        r.ResourceType,
        ISNULL(SUM(e.Amount), 0) AS TotalExpense
    FROM Resources r
    LEFT JOIN Expenses e ON r.ResourceId = e.ResourceId AND e.IsDeleted = 0
        AND e.ExpenseDate BETWEEN @FromDate AND @ToDate
    WHERE r.IsActive = 1
    GROUP BY r.ResourceId, r.ResourceCode, r.ResourceName, r.ResourceType
    ORDER BY TotalExpense DESC;
END
GO

-- =============================================
-- Stored Procedure: usp_Report_ProjectWise
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Report_ProjectWise')
    DROP PROCEDURE usp_Report_ProjectWise;
GO

CREATE PROCEDURE usp_Report_ProjectWise
    @ProjectId INT = NULL,
    @FromDate DATE = NULL,
    @ToDate DATE = NULL,
    @BudgetCodeId INT = NULL,
    @ResourceId INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        p.ProjectCode,
        p.ProjectName,
        bc.BudgetCode,
        bc.BudgetCodeName,
        r.ResourceCode,
        r.ResourceName,
        ISNULL(pb.BudgetAmount, 0) AS Budget,
        ISNULL(SUM(e.Amount), 0) AS Expense,
        ISNULL(pb.BudgetAmount, 0) - ISNULL(SUM(e.Amount), 0) AS Variance,
        CASE
            WHEN ISNULL(pb.BudgetAmount, 0) = 0 THEN 0
            ELSE (ISNULL(SUM(e.Amount), 0) / pb.BudgetAmount) * 100
        END AS UtilizationPercent
    FROM Projects p
    INNER JOIN ProjectBudgets pb ON p.ProjectId = pb.ProjectId AND pb.IsActive = 1
    INNER JOIN BudgetCodes bc ON pb.BudgetCodeId = bc.BudgetCodeId
    LEFT JOIN Expenses e ON p.ProjectId = e.ProjectId AND bc.BudgetCodeId = e.BudgetCodeId
        AND e.IsDeleted = 0
        AND (@FromDate IS NULL OR e.ExpenseDate >= @FromDate)
        AND (@ToDate IS NULL OR e.ExpenseDate <= @ToDate)
        AND (@ResourceId IS NULL OR e.ResourceId = @ResourceId)
    LEFT JOIN Resources r ON e.ResourceId = r.ResourceId
    WHERE p.IsActive = 1
    AND (@ProjectId IS NULL OR p.ProjectId = @ProjectId)
    AND (@BudgetCodeId IS NULL OR bc.BudgetCodeId = @BudgetCodeId)
    GROUP BY p.ProjectCode, p.ProjectName, bc.BudgetCode, bc.BudgetCodeName,
             r.ResourceCode, r.ResourceName, pb.BudgetAmount
    ORDER BY p.ProjectCode, bc.BudgetCode;
END
GO

-- =============================================
-- Stored Procedure: usp_Report_DateWise
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Report_DateWise')
    DROP PROCEDURE usp_Report_DateWise;
GO

CREATE PROCEDURE usp_Report_DateWise
    @ExpenseDate DATE
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        e.ExpenseDate,
        p.ProjectCode,
        p.ProjectName,
        bc.BudgetCode,
        bc.BudgetCodeName,
        r.ResourceCode,
        r.ResourceName,
        e.Amount,
        e.Description,
        e.Remarks
    FROM Expenses e
    INNER JOIN Projects p ON e.ProjectId = p.ProjectId
    INNER JOIN BudgetCodes bc ON e.BudgetCodeId = bc.BudgetCodeId
    INNER JOIN Resources r ON e.ResourceId = r.ResourceId
    WHERE e.ExpenseDate = @ExpenseDate
    AND e.IsDeleted = 0
    ORDER BY e.CreatedDate DESC;
END
GO

-- =============================================
-- Stored Procedure: usp_Report_DateRange
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Report_DateRange')
    DROP PROCEDURE usp_Report_DateRange;
GO

CREATE PROCEDURE usp_Report_DateRange
    @FromDate DATE,
    @ToDate DATE,
    @ProjectId INT = NULL,
    @BudgetCodeId INT = NULL,
    @ResourceId INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        e.ExpenseDate,
        p.ProjectCode,
        p.ProjectName,
        bc.BudgetCode,
        bc.BudgetCodeName,
        r.ResourceCode,
        r.ResourceName,
        e.Amount,
        e.Description,
        e.ReferenceNo,
        e.Remarks,
        e.CreatedBy,
        e.CreatedDate
    FROM Expenses e
    INNER JOIN Projects p ON e.ProjectId = p.ProjectId
    INNER JOIN BudgetCodes bc ON e.BudgetCodeId = bc.BudgetCodeId
    INNER JOIN Resources r ON e.ResourceId = r.ResourceId
    WHERE e.ExpenseDate BETWEEN @FromDate AND @ToDate
    AND e.IsDeleted = 0
    AND (@ProjectId IS NULL OR e.ProjectId = @ProjectId)
    AND (@BudgetCodeId IS NULL OR e.BudgetCodeId = @BudgetCodeId)
    AND (@ResourceId IS NULL OR e.ResourceId = @ResourceId)
    ORDER BY e.ExpenseDate DESC, e.CreatedDate DESC;
END
GO

-- =============================================
-- Stored Procedure: usp_Report_CostVsBudget
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_Report_CostVsBudget')
    DROP PROCEDURE usp_Report_CostVsBudget;
GO

CREATE PROCEDURE usp_Report_CostVsBudget
    @ProjectId INT = NULL,
    @BudgetCodeId INT = NULL,
    @FromDate DATE = NULL,
    @ToDate DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        p.ProjectCode,
        p.ProjectName,
        bc.BudgetCode,
        bc.BudgetCodeName,
        ISNULL(pb.BudgetAmount, 0) AS BudgetAmount,
        ISNULL(e.ActualCost, 0) AS ActualCost,
        ISNULL(pb.BudgetAmount, 0) - ISNULL(e.ActualCost, 0) AS RemainingBudget,
        CASE
            WHEN ISNULL(pb.BudgetAmount, 0) = 0 THEN 0
            ELSE (ISNULL(e.ActualCost, 0) / pb.BudgetAmount) * 100
        END AS UtilizationPercent,
        CASE
            WHEN ISNULL(pb.BudgetAmount, 0) = 0 THEN 0
            ELSE ISNULL(pb.BudgetAmount, 0) - ISNULL(e.ActualCost, 0)
        END AS Variance
    FROM Projects p
    INNER JOIN ProjectBudgets pb ON p.ProjectId = pb.ProjectId AND pb.IsActive = 1
    INNER JOIN BudgetCodes bc ON pb.BudgetCodeId = bc.BudgetCodeId
    LEFT JOIN (
        SELECT ProjectId, BudgetCodeId, SUM(Amount) AS ActualCost
        FROM Expenses
        WHERE IsDeleted = 0
        AND (@FromDate IS NULL OR ExpenseDate >= @FromDate)
        AND (@ToDate IS NULL OR ExpenseDate <= @ToDate)
        GROUP BY ProjectId, BudgetCodeId
    ) e ON p.ProjectId = e.ProjectId AND bc.BudgetCodeId = e.BudgetCodeId
    WHERE p.IsActive = 1
    AND (@ProjectId IS NULL OR p.ProjectId = @ProjectId)
    AND (@BudgetCodeId IS NULL OR bc.BudgetCodeId = @BudgetCodeId)
    ORDER BY p.ProjectCode, bc.BudgetCode;
END
GO

-- =============================================
-- Stored Procedure: usp_AuditLog_Insert
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_AuditLog_Insert')
    DROP PROCEDURE usp_AuditLog_Insert;
GO

CREATE PROCEDURE usp_AuditLog_Insert
    @UserId INT,
    @Action NVARCHAR(100),
    @Module NVARCHAR(50),
    @RecordId NVARCHAR(50),
    @OldValue NVARCHAR(MAX),
    @NewValue NVARCHAR(MAX),
    @IPAddress NVARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO AuditLogs (UserId, Action, Module, RecordId, OldValue, NewValue, IPAddress, CreatedDate)
    VALUES (@UserId, @Action, @Module, @RecordId, @OldValue, @NewValue, @IPAddress, GETDATE());
END
GO

-- usp_Pages_GetAll (added 2026-10-02 for PermissionController)
IF OBJECT_ID('usp_Pages_GetAll','P') IS NULL
    EXEC('CREATE PROCEDURE usp_Pages_GetAll AS BEGIN SET NOCOUNT ON; SELECT 1 AS Dummy; END');
GO
ALTER PROCEDURE usp_Pages_GetAll
AS
BEGIN
    SET NOCOUNT ON;
    SELECT PageId, PageName, PageDescription FROM Pages ORDER BY PageId;
END
GO


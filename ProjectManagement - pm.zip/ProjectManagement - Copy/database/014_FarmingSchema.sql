USE ProjectManagementDB;
GO

-- =============================================
-- §68-§102 Farming schema
-- Additive only: new tables + new nullable columns on Projects/Expenses.
-- Nothing existing is altered in a breaking way.
-- =============================================

-- Projects.FarmType (§69)
IF COL_LENGTH('Projects', 'FarmType') IS NULL
    ALTER TABLE Projects ADD FarmType NVARCHAR(50) NULL;
GO

-- Expenses farming reference (§92): optional link to Pond / PoultryBatch.
IF COL_LENGTH('Expenses', 'FarmType') IS NULL
    ALTER TABLE Expenses ADD FarmType NVARCHAR(50) NULL;
GO
IF COL_LENGTH('Expenses', 'FarmEntityType') IS NULL
    ALTER TABLE Expenses ADD FarmEntityType NVARCHAR(30) NULL;
GO
IF COL_LENGTH('Expenses', 'FarmEntityId') IS NULL
    ALTER TABLE Expenses ADD FarmEntityId INT NULL;
GO

-- =============================================
-- Table: Ponds (§72)
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Ponds')
BEGIN
    CREATE TABLE Ponds (
        PondId INT IDENTITY(1,1) PRIMARY KEY,
        ProjectId INT NOT NULL,
        PondCode NVARCHAR(20) NOT NULL UNIQUE,
        PondName NVARCHAR(200) NOT NULL,
        Area DECIMAL(18,2) NULL,
        AreaUnit NVARCHAR(20) NULL,
        Depth NVARCHAR(50) NULL,
        WaterCapacity DECIMAL(18,2) NULL,
        PondType NVARCHAR(50) NULL,
        Status NVARCHAR(20) NOT NULL DEFAULT 'Active',
        IsActive BIT NOT NULL DEFAULT 1,
        CreatedBy INT NULL,
        CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE(),
        ModifiedBy INT NULL,
        ModifiedDate DATETIME2 NULL,
        CONSTRAINT FK_Ponds_Projects FOREIGN KEY (ProjectId) REFERENCES Projects(ProjectId)
    );
    CREATE INDEX IX_Ponds_ProjectId ON Ponds(ProjectId);
END
GO

-- =============================================
-- Table: FishTypes (§73)
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'FishTypes')
BEGIN
    CREATE TABLE FishTypes (
        FishTypeId INT IDENTITY(1,1) PRIMARY KEY,
        FishCode NVARCHAR(20) NOT NULL UNIQUE,
        FishName NVARCHAR(100) NOT NULL,
        ScientificName NVARCHAR(200) NULL,
        Description NVARCHAR(500) NULL,
        IsActive BIT NOT NULL DEFAULT 1,
        CreatedBy INT NULL,
        CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE(),
        ModifiedBy INT NULL,
        ModifiedDate DATETIME2 NULL
    );
END
GO

-- =============================================
-- Table: FishStocking (§74)
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'FishStocking')
BEGIN
    CREATE TABLE FishStocking (
        StockingId INT IDENTITY(1,1) PRIMARY KEY,
        PondId INT NOT NULL,
        FishTypeId INT NOT NULL,
        StockingDate DATE NOT NULL,
        Quantity INT NOT NULL,
        AverageWeight DECIMAL(18,2) NULL,
        PurchaseRate DECIMAL(18,2) NOT NULL DEFAULT 0,
        TotalCost DECIMAL(18,2) NOT NULL DEFAULT 0,
        Supplier NVARCHAR(200) NULL,
        ReferenceNo NVARCHAR(50) NULL,
        Remarks NVARCHAR(500) NULL,
        CreatedBy INT NULL,
        CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE(),
        ModifiedBy INT NULL,
        ModifiedDate DATETIME2 NULL,
        CONSTRAINT FK_FishStocking_Ponds FOREIGN KEY (PondId) REFERENCES Ponds(PondId),
        CONSTRAINT FK_FishStocking_FishTypes FOREIGN KEY (FishTypeId) REFERENCES FishTypes(FishTypeId),
        CONSTRAINT CK_FishStocking_Quantity CHECK (Quantity > 0),
        CONSTRAINT CK_FishStocking_Cost CHECK (TotalCost >= 0)
    );
    CREATE INDEX IX_FishStocking_PondId ON FishStocking(PondId);
    CREATE INDEX IX_FishStocking_Date ON FishStocking(StockingDate);
END
GO

-- =============================================
-- Table: FishFeed (§75)
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'FishFeed')
BEGIN
    CREATE TABLE FishFeed (
        FishFeedId INT IDENTITY(1,1) PRIMARY KEY,
        PondId INT NOT NULL,
        FeedDate DATE NOT NULL,
        FeedType NVARCHAR(50) NOT NULL,
        Quantity DECIMAL(18,2) NOT NULL,
        Unit NVARCHAR(20) NULL,
        Rate DECIMAL(18,2) NOT NULL DEFAULT 0,
        TotalCost DECIMAL(18,2) NOT NULL DEFAULT 0,
        Remarks NVARCHAR(500) NULL,
        CreatedBy INT NULL,
        CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE(),
        ModifiedBy INT NULL,
        ModifiedDate DATETIME2 NULL,
        CONSTRAINT FK_FishFeed_Ponds FOREIGN KEY (PondId) REFERENCES Ponds(PondId),
        CONSTRAINT CK_FishFeed_Quantity CHECK (Quantity > 0)
    );
    CREATE INDEX IX_FishFeed_PondId ON FishFeed(PondId);
    CREATE INDEX IX_FishFeed_Date ON FishFeed(FeedDate);
END
GO

-- =============================================
-- Table: FishTreatment (§76)
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'FishTreatment')
BEGIN
    CREATE TABLE FishTreatment (
        TreatmentId INT IDENTITY(1,1) PRIMARY KEY,
        PondId INT NOT NULL,
        TreatmentDate DATE NOT NULL,
        TreatmentType NVARCHAR(50) NOT NULL,
        Medicine NVARCHAR(200) NULL,
        Quantity DECIMAL(18,2) NULL DEFAULT 0,
        Unit NVARCHAR(20) NULL,
        Cost DECIMAL(18,2) NOT NULL DEFAULT 0,
        Reason NVARCHAR(500) NULL,
        Remarks NVARCHAR(500) NULL,
        CreatedBy INT NULL,
        CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE(),
        ModifiedBy INT NULL,
        ModifiedDate DATETIME2 NULL,
        CONSTRAINT FK_FishTreatment_Ponds FOREIGN KEY (PondId) REFERENCES Ponds(PondId)
    );
    CREATE INDEX IX_FishTreatment_PondId ON FishTreatment(PondId);
    CREATE INDEX IX_FishTreatment_Date ON FishTreatment(TreatmentDate);
END
GO

-- =============================================
-- Table: FishMortality (§77)
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'FishMortality')
BEGIN
    CREATE TABLE FishMortality (
        MortalityId INT IDENTITY(1,1) PRIMARY KEY,
        PondId INT NOT NULL,
        FishTypeId INT NOT NULL,
        MortalityDate DATE NOT NULL,
        Quantity INT NOT NULL,
        Reason NVARCHAR(500) NULL,
        Remarks NVARCHAR(500) NULL,
        CreatedBy INT NULL,
        CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE(),
        ModifiedBy INT NULL,
        ModifiedDate DATETIME2 NULL,
        CONSTRAINT FK_FishMortality_Ponds FOREIGN KEY (PondId) REFERENCES Ponds(PondId),
        CONSTRAINT FK_FishMortality_FishTypes FOREIGN KEY (FishTypeId) REFERENCES FishTypes(FishTypeId),
        CONSTRAINT CK_FishMortality_Quantity CHECK (Quantity > 0)
    );
    CREATE INDEX IX_FishMortality_PondId ON FishMortality(PondId);
    CREATE INDEX IX_FishMortality_Date ON FishMortality(MortalityDate);
END
GO

-- =============================================
-- Table: FishGrowth (§78)
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'FishGrowth')
BEGIN
    CREATE TABLE FishGrowth (
        GrowthId INT IDENTITY(1,1) PRIMARY KEY,
        PondId INT NOT NULL,
        FishTypeId INT NOT NULL,
        SamplingDate DATE NOT NULL,
        SampleQuantity INT NOT NULL,
        AverageWeight DECIMAL(18,2) NOT NULL,
        Remarks NVARCHAR(500) NULL,
        CreatedBy INT NULL,
        CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE(),
        ModifiedBy INT NULL,
        ModifiedDate DATETIME2 NULL,
        CONSTRAINT FK_FishGrowth_Ponds FOREIGN KEY (PondId) REFERENCES Ponds(PondId),
        CONSTRAINT FK_FishGrowth_FishTypes FOREIGN KEY (FishTypeId) REFERENCES FishTypes(FishTypeId),
        CONSTRAINT CK_FishGrowth_Sample CHECK (SampleQuantity > 0)
    );
    CREATE INDEX IX_FishGrowth_PondId ON FishGrowth(PondId);
    CREATE INDEX IX_FishGrowth_Date ON FishGrowth(SamplingDate);
END
GO

-- =============================================
-- Table: FishHarvest (§79)
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'FishHarvest')
BEGIN
    CREATE TABLE FishHarvest (
        HarvestId INT IDENTITY(1,1) PRIMARY KEY,
        PondId INT NOT NULL,
        FishTypeId INT NOT NULL,
        HarvestDate DATE NOT NULL,
        Quantity INT NOT NULL,
        TotalWeight DECIMAL(18,2) NOT NULL DEFAULT 0,
        AverageWeight DECIMAL(18,2) NULL,
        HarvestCost DECIMAL(18,2) NOT NULL DEFAULT 0,
        Remarks NVARCHAR(500) NULL,
        CreatedBy INT NULL,
        CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE(),
        ModifiedBy INT NULL,
        ModifiedDate DATETIME2 NULL,
        CONSTRAINT FK_FishHarvest_Ponds FOREIGN KEY (PondId) REFERENCES Ponds(PondId),
        CONSTRAINT FK_FishHarvest_FishTypes FOREIGN KEY (FishTypeId) REFERENCES FishTypes(FishTypeId),
        CONSTRAINT CK_FishHarvest_Quantity CHECK (Quantity > 0)
    );
    CREATE INDEX IX_FishHarvest_PondId ON FishHarvest(PondId);
    CREATE INDEX IX_FishHarvest_Date ON FishHarvest(HarvestDate);
END
GO

-- =============================================
-- Table: FishSales (§80)
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'FishSales')
BEGIN
    CREATE TABLE FishSales (
        SaleId INT IDENTITY(1,1) PRIMARY KEY,
        ProjectId INT NOT NULL,
        HarvestId INT NULL,
        FishTypeId INT NOT NULL,
        SaleDate DATE NOT NULL,
        CustomerName NVARCHAR(200) NOT NULL,
        Quantity INT NOT NULL,
        TotalWeight DECIMAL(18,2) NOT NULL DEFAULT 0,
        Rate DECIMAL(18,2) NOT NULL DEFAULT 0,
        TotalAmount DECIMAL(18,2) NOT NULL DEFAULT 0,
        PaymentStatus NVARCHAR(20) NOT NULL DEFAULT 'Pending',
        ReferenceNo NVARCHAR(50) NULL,
        Remarks NVARCHAR(500) NULL,
        CreatedBy INT NULL,
        CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE(),
        ModifiedBy INT NULL,
        ModifiedDate DATETIME2 NULL,
        CONSTRAINT FK_FishSales_Projects FOREIGN KEY (ProjectId) REFERENCES Projects(ProjectId),
        CONSTRAINT FK_FishSales_Harvest FOREIGN KEY (HarvestId) REFERENCES FishHarvest(HarvestId),
        CONSTRAINT FK_FishSales_FishTypes FOREIGN KEY (FishTypeId) REFERENCES FishTypes(FishTypeId),
        CONSTRAINT CK_FishSales_Quantity CHECK (Quantity > 0),
        CONSTRAINT CK_FishSales_Amount CHECK (TotalAmount >= 0)
    );
    CREATE INDEX IX_FishSales_ProjectId ON FishSales(ProjectId);
    CREATE INDEX IX_FishSales_Date ON FishSales(SaleDate);
END
GO

-- =============================================
-- Table: PoultrySheds (§82)
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'PoultrySheds')
BEGIN
    CREATE TABLE PoultrySheds (
        ShedId INT IDENTITY(1,1) PRIMARY KEY,
        ProjectId INT NOT NULL,
        ShedCode NVARCHAR(20) NOT NULL UNIQUE,
        ShedName NVARCHAR(200) NOT NULL,
        Capacity INT NOT NULL DEFAULT 0,
        CapacityUnit NVARCHAR(20) NULL,
        ShedType NVARCHAR(50) NULL,
        Status NVARCHAR(20) NOT NULL DEFAULT 'Active',
        IsActive BIT NOT NULL DEFAULT 1,
        CreatedBy INT NULL,
        CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE(),
        ModifiedBy INT NULL,
        ModifiedDate DATETIME2 NULL,
        CONSTRAINT FK_PoultrySheds_Projects FOREIGN KEY (ProjectId) REFERENCES Projects(ProjectId),
        CONSTRAINT CK_PoultrySheds_Capacity CHECK (Capacity >= 0)
    );
    CREATE INDEX IX_PoultrySheds_ProjectId ON PoultrySheds(ProjectId);
END
GO

-- =============================================
-- Table: PoultryBatches (§83)
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'PoultryBatches')
BEGIN
    CREATE TABLE PoultryBatches (
        BatchId INT IDENTITY(1,1) PRIMARY KEY,
        ProjectId INT NOT NULL,
        ShedId INT NOT NULL,
        BatchCode NVARCHAR(20) NOT NULL UNIQUE,
        BirdType NVARCHAR(50) NOT NULL,
        StartDate DATE NOT NULL,
        ExpectedSaleDate DATE NULL,
        InitialQuantity INT NOT NULL,
        PurchaseCost DECIMAL(18,2) NOT NULL DEFAULT 0,
        Status NVARCHAR(20) NOT NULL DEFAULT 'Active',
        Remarks NVARCHAR(500) NULL,
        CreatedBy INT NULL,
        CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE(),
        ModifiedBy INT NULL,
        ModifiedDate DATETIME2 NULL,
        CONSTRAINT FK_PoultryBatches_Projects FOREIGN KEY (ProjectId) REFERENCES Projects(ProjectId),
        CONSTRAINT FK_PoultryBatches_Sheds FOREIGN KEY (ShedId) REFERENCES PoultrySheds(ShedId),
        CONSTRAINT CK_PoultryBatches_Quantity CHECK (InitialQuantity > 0)
    );
    CREATE INDEX IX_PoultryBatches_ShedId ON PoultryBatches(ShedId);
    CREATE INDEX IX_PoultryBatches_ProjectId ON PoultryBatches(ProjectId);
END
GO

-- =============================================
-- Table: ChickPurchase (§84)
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'ChickPurchase')
BEGIN
    CREATE TABLE ChickPurchase (
        PurchaseId INT IDENTITY(1,1) PRIMARY KEY,
        BatchId INT NOT NULL,
        PurchaseDate DATE NOT NULL,
        Supplier NVARCHAR(200) NULL,
        Quantity INT NOT NULL,
        Rate DECIMAL(18,2) NOT NULL DEFAULT 0,
        TotalAmount DECIMAL(18,2) NOT NULL DEFAULT 0,
        ReferenceNo NVARCHAR(50) NULL,
        Remarks NVARCHAR(500) NULL,
        CreatedBy INT NULL,
        CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE(),
        ModifiedBy INT NULL,
        ModifiedDate DATETIME2 NULL,
        CONSTRAINT FK_ChickPurchase_Batches FOREIGN KEY (BatchId) REFERENCES PoultryBatches(BatchId),
        CONSTRAINT CK_ChickPurchase_Quantity CHECK (Quantity > 0)
    );
    CREATE INDEX IX_ChickPurchase_BatchId ON ChickPurchase(BatchId);
    CREATE INDEX IX_ChickPurchase_Date ON ChickPurchase(PurchaseDate);
END
GO

-- =============================================
-- Table: PoultryFeed (§85)
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'PoultryFeed')
BEGIN
    CREATE TABLE PoultryFeed (
        FeedId INT IDENTITY(1,1) PRIMARY KEY,
        BatchId INT NOT NULL,
        FeedDate DATE NOT NULL,
        FeedType NVARCHAR(50) NOT NULL,
        Quantity DECIMAL(18,2) NOT NULL,
        Unit NVARCHAR(20) NULL,
        Rate DECIMAL(18,2) NOT NULL DEFAULT 0,
        TotalCost DECIMAL(18,2) NOT NULL DEFAULT 0,
        Remarks NVARCHAR(500) NULL,
        CreatedBy INT NULL,
        CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE(),
        ModifiedBy INT NULL,
        ModifiedDate DATETIME2 NULL,
        CONSTRAINT FK_PoultryFeed_Batches FOREIGN KEY (BatchId) REFERENCES PoultryBatches(BatchId),
        CONSTRAINT CK_PoultryFeed_Quantity CHECK (Quantity > 0)
    );
    CREATE INDEX IX_PoultryFeed_BatchId ON PoultryFeed(BatchId);
    CREATE INDEX IX_PoultryFeed_Date ON PoultryFeed(FeedDate);
END
GO

-- =============================================
-- Table: PoultryTreatment (§86)
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'PoultryTreatment')
BEGIN
    CREATE TABLE PoultryTreatment (
        TreatmentId INT IDENTITY(1,1) PRIMARY KEY,
        BatchId INT NOT NULL,
        TreatmentDate DATE NOT NULL,
        TreatmentType NVARCHAR(50) NOT NULL,
        Medicine NVARCHAR(200) NULL,
        Quantity DECIMAL(18,2) NULL DEFAULT 0,
        Cost DECIMAL(18,2) NOT NULL DEFAULT 0,
        Reason NVARCHAR(500) NULL,
        Remarks NVARCHAR(500) NULL,
        CreatedBy INT NULL,
        CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE(),
        ModifiedBy INT NULL,
        ModifiedDate DATETIME2 NULL,
        CONSTRAINT FK_PoultryTreatment_Batches FOREIGN KEY (BatchId) REFERENCES PoultryBatches(BatchId)
    );
    CREATE INDEX IX_PoultryTreatment_BatchId ON PoultryTreatment(BatchId);
    CREATE INDEX IX_PoultryTreatment_Date ON PoultryTreatment(TreatmentDate);
END
GO

-- =============================================
-- Table: PoultryMortality (§87)
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'PoultryMortality')
BEGIN
    CREATE TABLE PoultryMortality (
        MortalityId INT IDENTITY(1,1) PRIMARY KEY,
        BatchId INT NOT NULL,
        MortalityDate DATE NOT NULL,
        Quantity INT NOT NULL,
        Reason NVARCHAR(500) NULL,
        Remarks NVARCHAR(500) NULL,
        CreatedBy INT NULL,
        CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE(),
        ModifiedBy INT NULL,
        ModifiedDate DATETIME2 NULL,
        CONSTRAINT FK_PoultryMortality_Batches FOREIGN KEY (BatchId) REFERENCES PoultryBatches(BatchId),
        CONSTRAINT CK_PoultryMortality_Quantity CHECK (Quantity > 0)
    );
    CREATE INDEX IX_PoultryMortality_BatchId ON PoultryMortality(BatchId);
    CREATE INDEX IX_PoultryMortality_Date ON PoultryMortality(MortalityDate);
END
GO

-- =============================================
-- Table: PoultryGrowth (§88)
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'PoultryGrowth')
BEGIN
    CREATE TABLE PoultryGrowth (
        GrowthId INT IDENTITY(1,1) PRIMARY KEY,
        BatchId INT NOT NULL,
        SampleDate DATE NOT NULL,
        SampleQuantity INT NOT NULL,
        AverageWeight DECIMAL(18,2) NOT NULL,
        Remarks NVARCHAR(500) NULL,
        CreatedBy INT NULL,
        CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE(),
        ModifiedBy INT NULL,
        ModifiedDate DATETIME2 NULL,
        CONSTRAINT FK_PoultryGrowth_Batches FOREIGN KEY (BatchId) REFERENCES PoultryBatches(BatchId),
        CONSTRAINT CK_PoultryGrowth_Sample CHECK (SampleQuantity > 0)
    );
    CREATE INDEX IX_PoultryGrowth_BatchId ON PoultryGrowth(BatchId);
    CREATE INDEX IX_PoultryGrowth_Date ON PoultryGrowth(SampleDate);
END
GO

-- =============================================
-- Table: EggProduction (§89)
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'EggProduction')
BEGIN
    CREATE TABLE EggProduction (
        ProductionId INT IDENTITY(1,1) PRIMARY KEY,
        BatchId INT NOT NULL,
        ProductionDate DATE NOT NULL,
        GoodEggs INT NOT NULL DEFAULT 0,
        BrokenEggs INT NOT NULL DEFAULT 0,
        TotalEggs INT NOT NULL DEFAULT 0,
        Remarks NVARCHAR(500) NULL,
        CreatedBy INT NULL,
        CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE(),
        ModifiedBy INT NULL,
        ModifiedDate DATETIME2 NULL,
        CONSTRAINT FK_EggProduction_Batches FOREIGN KEY (BatchId) REFERENCES PoultryBatches(BatchId),
        CONSTRAINT CK_EggProduction_NonNegative CHECK (GoodEggs >= 0 AND BrokenEggs >= 0)
    );
    CREATE INDEX IX_EggProduction_BatchId ON EggProduction(BatchId);
    CREATE INDEX IX_EggProduction_Date ON EggProduction(ProductionDate);
END
GO

-- =============================================
-- Table: PoultrySales (§90)
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'PoultrySales')
BEGIN
    CREATE TABLE PoultrySales (
        SaleId INT IDENTITY(1,1) PRIMARY KEY,
        ProjectId INT NOT NULL,
        BatchId INT NULL,
        SaleDate DATE NOT NULL,
        CustomerName NVARCHAR(200) NOT NULL,
        BirdQuantity INT NOT NULL,
        TotalWeight DECIMAL(18,2) NULL DEFAULT 0,
        Rate DECIMAL(18,2) NOT NULL DEFAULT 0,
        TotalAmount DECIMAL(18,2) NOT NULL DEFAULT 0,
        PaymentStatus NVARCHAR(20) NOT NULL DEFAULT 'Pending',
        ReferenceNo NVARCHAR(50) NULL,
        Remarks NVARCHAR(500) NULL,
        CreatedBy INT NULL,
        CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE(),
        ModifiedBy INT NULL,
        ModifiedDate DATETIME2 NULL,
        CONSTRAINT FK_PoultrySales_Projects FOREIGN KEY (ProjectId) REFERENCES Projects(ProjectId),
        CONSTRAINT FK_PoultrySales_Batches FOREIGN KEY (BatchId) REFERENCES PoultryBatches(BatchId),
        CONSTRAINT CK_PoultrySales_Quantity CHECK (BirdQuantity > 0),
        CONSTRAINT CK_PoultrySales_Amount CHECK (TotalAmount >= 0)
    );
    CREATE INDEX IX_PoultrySales_ProjectId ON PoultrySales(ProjectId);
    CREATE INDEX IX_PoultrySales_Date ON PoultrySales(SaleDate);
END
GO

-- =============================================
-- Table: Revenue (§94) — manual / other farm revenue.
-- Fish & poultry sales auto-post rows here (RevenueType Fish Sale /
-- Poultry Sale, ReferenceId = SaleId) in the same SQL transaction,
-- so reporting reads ONE table and amounts are never doubled.
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Revenue')
BEGIN
    CREATE TABLE Revenue (
        RevenueId INT IDENTITY(1,1) PRIMARY KEY,
        RevenueDate DATE NOT NULL,
        ProjectId INT NOT NULL,
        FarmType NVARCHAR(50) NULL,
        RevenueType NVARCHAR(50) NOT NULL,
        ReferenceId INT NULL,
        CustomerName NVARCHAR(200) NULL,
        Quantity DECIMAL(18,2) NULL DEFAULT 0,
        Weight DECIMAL(18,2) NULL DEFAULT 0,
        Rate DECIMAL(18,2) NULL DEFAULT 0,
        Amount DECIMAL(18,2) NOT NULL DEFAULT 0,
        PaymentStatus NVARCHAR(20) NOT NULL DEFAULT 'Pending',
        Remarks NVARCHAR(500) NULL,
        IsDeleted BIT NOT NULL DEFAULT 0,
        CreatedBy INT NULL,
        CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE(),
        ModifiedBy INT NULL,
        ModifiedDate DATETIME2 NULL,
        CONSTRAINT FK_Revenue_Projects FOREIGN KEY (ProjectId) REFERENCES Projects(ProjectId),
        CONSTRAINT CK_Revenue_Amount CHECK (Amount >= 0)
    );
    CREATE INDEX IX_Revenue_ProjectId ON Revenue(ProjectId);
    CREATE INDEX IX_Revenue_Date ON Revenue(RevenueDate);
END
GO

-- =============================================
-- Seeds: FishTypes (§73)
-- =============================================
IF NOT EXISTS (SELECT 1 FROM FishTypes WHERE FishCode = 'FISH-ROHU')
    INSERT INTO FishTypes (FishCode, FishName, ScientificName, IsActive, CreatedBy, CreatedDate)
    VALUES ('FISH-ROHU', 'Rohu', 'Labeo rohita', 1, 1, GETDATE());
IF NOT EXISTS (SELECT 1 FROM FishTypes WHERE FishCode = 'FISH-CATLA')
    INSERT INTO FishTypes (FishCode, FishName, ScientificName, IsActive, CreatedBy, CreatedDate)
    VALUES ('FISH-CATLA', 'Catla', 'Catla catla', 1, 1, GETDATE());
IF NOT EXISTS (SELECT 1 FROM FishTypes WHERE FishCode = 'FISH-MRIGAL')
    INSERT INTO FishTypes (FishCode, FishName, ScientificName, IsActive, CreatedBy, CreatedDate)
    VALUES ('FISH-MRIGAL', 'Mrigal', 'Cirrhinus mrigala', 1, 1, GETDATE());
IF NOT EXISTS (SELECT 1 FROM FishTypes WHERE FishCode = 'FISH-GRASSCARP')
    INSERT INTO FishTypes (FishCode, FishName, ScientificName, IsActive, CreatedBy, CreatedDate)
    VALUES ('FISH-GRASSCARP', 'Grass Carp', 'Ctenopharyngodon idella', 1, 1, GETDATE());
IF NOT EXISTS (SELECT 1 FROM FishTypes WHERE FishCode = 'FISH-COMMONCARP')
    INSERT INTO FishTypes (FishCode, FishName, ScientificName, IsActive, CreatedBy, CreatedDate)
    VALUES ('FISH-COMMONCARP', 'Common Carp', 'Cyprinus carpio', 1, 1, GETDATE());
IF NOT EXISTS (SELECT 1 FROM FishTypes WHERE FishCode = 'FISH-TILAPIA')
    INSERT INTO FishTypes (FishCode, FishName, ScientificName, IsActive, CreatedBy, CreatedDate)
    VALUES ('FISH-TILAPIA', 'Tilapia', 'Oreochromis niloticus', 1, 1, GETDATE());
GO

-- =============================================
-- Seeds: Farming Budget Codes (§93)
-- =============================================
IF NOT EXISTS (SELECT 1 FROM BudgetCodes WHERE BudgetCode = 'FISH-FEED')
    INSERT INTO BudgetCodes (BudgetCode, BudgetCodeName, Description, IsActive, CreatedBy, CreatedDate)
    VALUES
    ('FISH-FEED', 'Fish Feed', 'Fish feed expenses', 1, 1, GETDATE()),
    ('FISH-SEED', 'Fish Seed', 'Fish seed / fingerling purchase', 1, 1, GETDATE()),
    ('FISH-MEDICINE', 'Fish Medicine', 'Fish medicine and treatment', 1, 1, GETDATE()),
    ('FISH-LABOUR', 'Fish Labour', 'Fish farm labour charges', 1, 1, GETDATE()),
    ('FISH-WATER', 'Fish Water', 'Water management expenses', 1, 1, GETDATE()),
    ('FISH-ELECTRICITY', 'Fish Electricity', 'Fish farm electricity', 1, 1, GETDATE()),
    ('FISH-MAINTENANCE', 'Fish Maintenance', 'Pond and equipment maintenance', 1, 1, GETDATE()),
    ('FISH-TRANSPORT', 'Fish Transport', 'Fish transport expenses', 1, 1, GETDATE()),
    ('FISH-HARVEST', 'Fish Harvest', 'Fish harvesting expenses', 1, 1, GETDATE()),
    ('FISH-OTHER', 'Fish Other', 'Other fish farm expenses', 1, 1, GETDATE());
IF NOT EXISTS (SELECT 1 FROM BudgetCodes WHERE BudgetCode = 'POULTRY-CHICK')
    INSERT INTO BudgetCodes (BudgetCode, BudgetCodeName, Description, IsActive, CreatedBy, CreatedDate)
    VALUES
    ('POULTRY-CHICK', 'Poultry Chick', 'Chick purchase', 1, 1, GETDATE()),
    ('POULTRY-FEED', 'Poultry Feed', 'Poultry feed expenses', 1, 1, GETDATE()),
    ('POULTRY-MEDICINE', 'Poultry Medicine', 'Poultry medicine expenses', 1, 1, GETDATE()),
    ('POULTRY-VACCINE', 'Poultry Vaccine', 'Vaccination expenses', 1, 1, GETDATE()),
    ('POULTRY-LABOUR', 'Poultry Labour', 'Poultry farm labour charges', 1, 1, GETDATE()),
    ('POULTRY-ELECTRICITY', 'Poultry Electricity', 'Poultry farm electricity', 1, 1, GETDATE()),
    ('POULTRY-MAINTENANCE', 'Poultry Maintenance', 'Shed and equipment maintenance', 1, 1, GETDATE()),
    ('POULTRY-TRANSPORT', 'Poultry Transport', 'Poultry transport expenses', 1, 1, GETDATE()),
    ('POULTRY-SALE', 'Poultry Sale', 'Bird/egg sale related expenses', 1, 1, GETDATE()),
    ('POULTRY-OTHER', 'Poultry Other', 'Other poultry farm expenses', 1, 1, GETDATE());
GO

-- =============================================
-- Seeds: Farming Pages (§106) — Super Admin assigns these to Admin/Users.
-- =============================================
IF NOT EXISTS (SELECT 1 FROM Pages WHERE PageName = 'Fish Ponds')
    INSERT INTO Pages (PageName, PageDescription) VALUES
    ('Fish Ponds', 'Pond management'),
    ('Fish Types', 'Fish type master'),
    ('Fish Stocking', 'Fish stocking management'),
    ('Fish Feed', 'Fish feed management'),
    ('Fish Treatment', 'Fish treatment management'),
    ('Fish Mortality', 'Fish mortality tracking'),
    ('Fish Growth', 'Fish growth sampling'),
    ('Fish Harvest', 'Fish harvest management'),
    ('Fish Sales', 'Fish sales management'),
    ('Poultry Sheds', 'Poultry shed management'),
    ('Poultry Batches', 'Poultry batch management'),
    ('Chick Purchase', 'Chick purchase management'),
    ('Poultry Feed', 'Poultry feed management'),
    ('Poultry Treatment', 'Poultry treatment and vaccination'),
    ('Poultry Mortality', 'Poultry mortality tracking'),
    ('Poultry Growth', 'Poultry growth tracking'),
    ('Egg Production', 'Egg production tracking'),
    ('Poultry Sales', 'Poultry sales management'),
    ('Revenue', 'Farm revenue management'),
    ('Profitability', 'Profitability analysis'),
    ('Farm Reports', 'Farm, fish and poultry reports');
GO

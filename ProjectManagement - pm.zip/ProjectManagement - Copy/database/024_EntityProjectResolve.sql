USE ProjectManagementDB;
GO

-- =============================================
-- 024: Resolve any project-linked entity to its ProjectId.
-- Used by project-permission enforcement for entity-id routes
-- (PUT/DELETE/GET {id}) whose DTOs carry no ProjectId.
-- Returns zero rows when the entity does not exist.
-- @Entity values: Project, ProjectBudget, ProjectResource, Expense,
-- Pond, PoultryShed, PoultryBatch, FishStocking, FishFeed,
-- FishTreatment, FishMortality, FishGrowth, FishHarvest, FishSale,
-- ChickPurchase, PoultryFeed, PoultryTreatment, PoultryMortality,
-- PoultryGrowth, EggProduction, PoultrySale, Revenue.
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_EntityProject_Resolve')
    DROP PROCEDURE usp_EntityProject_Resolve;
GO

CREATE PROCEDURE usp_EntityProject_Resolve
    @Entity NVARCHAR(50),
    @Id INT
AS
BEGIN
    SET NOCOUNT ON;

    SET @Entity = LOWER(LTRIM(RTRIM(ISNULL(@Entity, ''))));

    IF (@Entity = 'project')
        SELECT ProjectId FROM Projects WHERE ProjectId = @Id;
    ELSE IF (@Entity = 'projectbudget')
        SELECT ProjectId FROM ProjectBudgets WHERE ProjectBudgetId = @Id;
    ELSE IF (@Entity = 'projectresource')
        SELECT ProjectId FROM ProjectResources WHERE ProjectResourceId = @Id;
    ELSE IF (@Entity = 'expense')
        SELECT ProjectId FROM Expenses WHERE ExpenseId = @Id;
    ELSE IF (@Entity = 'pond')
        SELECT ProjectId FROM Ponds WHERE PondId = @Id;
    ELSE IF (@Entity = 'poultryshed')
        SELECT ProjectId FROM PoultrySheds WHERE ShedId = @Id;
    ELSE IF (@Entity = 'poultrybatch')
        SELECT ProjectId FROM PoultryBatches WHERE BatchId = @Id;
    ELSE IF (@Entity = 'fishstocking')
        SELECT p.ProjectId FROM FishStocking f INNER JOIN Ponds p ON p.PondId = f.PondId WHERE f.StockingId = @Id;
    ELSE IF (@Entity = 'fishfeed')
        SELECT p.ProjectId FROM FishFeed f INNER JOIN Ponds p ON p.PondId = f.PondId WHERE f.FishFeedId = @Id;
    ELSE IF (@Entity = 'fishtreatment')
        SELECT p.ProjectId FROM FishTreatment f INNER JOIN Ponds p ON p.PondId = f.PondId WHERE f.TreatmentId = @Id;
    ELSE IF (@Entity = 'fishmortality')
        SELECT p.ProjectId FROM FishMortality f INNER JOIN Ponds p ON p.PondId = f.PondId WHERE f.MortalityId = @Id;
    ELSE IF (@Entity = 'fishgrowth')
        SELECT p.ProjectId FROM FishGrowth f INNER JOIN Ponds p ON p.PondId = f.PondId WHERE f.GrowthId = @Id;
    ELSE IF (@Entity = 'fishharvest')
        SELECT p.ProjectId FROM FishHarvest f INNER JOIN Ponds p ON p.PondId = f.PondId WHERE f.HarvestId = @Id;
    ELSE IF (@Entity = 'fishsale')
        SELECT ProjectId FROM FishSales WHERE SaleId = @Id;
    ELSE IF (@Entity = 'chickpurchase')
        SELECT b.ProjectId FROM ChickPurchase c INNER JOIN PoultryBatches b ON b.BatchId = c.BatchId WHERE c.PurchaseId = @Id;
    ELSE IF (@Entity = 'poultryfeed')
        SELECT b.ProjectId FROM PoultryFeed f INNER JOIN PoultryBatches b ON b.BatchId = f.BatchId WHERE f.FeedId = @Id;
    ELSE IF (@Entity = 'poultrytreatment')
        SELECT b.ProjectId FROM PoultryTreatment f INNER JOIN PoultryBatches b ON b.BatchId = f.BatchId WHERE f.TreatmentId = @Id;
    ELSE IF (@Entity = 'poultrymortality')
        SELECT b.ProjectId FROM PoultryMortality f INNER JOIN PoultryBatches b ON b.BatchId = f.BatchId WHERE f.MortalityId = @Id;
    ELSE IF (@Entity = 'poultrygrowth')
        SELECT b.ProjectId FROM PoultryGrowth f INNER JOIN PoultryBatches b ON b.BatchId = f.BatchId WHERE f.GrowthId = @Id;
    ELSE IF (@Entity = 'eggproduction')
        SELECT b.ProjectId FROM EggProduction e INNER JOIN PoultryBatches b ON b.BatchId = e.BatchId WHERE e.ProductionId = @Id;
    ELSE IF (@Entity = 'poultrysale')
        SELECT ProjectId FROM PoultrySales WHERE SaleId = @Id;
    ELSE IF (@Entity = 'revenue')
        SELECT ProjectId FROM Revenue WHERE RevenueId = @Id;
END
GO

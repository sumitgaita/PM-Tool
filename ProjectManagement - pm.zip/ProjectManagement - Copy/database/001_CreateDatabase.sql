IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'ProjectManagementDB')
BEGIN
    CREATE DATABASE ProjectManagementDB;
END
GO

USE ProjectManagementDB;
GO

USE ProjectManagementDB;
GO

-- =============================================
-- Indexes for Users
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Users_RoleId')
    CREATE INDEX IX_Users_RoleId ON Users(RoleId);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Users_IsActive')
    CREATE INDEX IX_Users_IsActive ON Users(IsActive);

-- =============================================
-- Indexes for UserPermissions
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_UserPermissions_UserId')
    CREATE INDEX IX_UserPermissions_UserId ON UserPermissions(UserId);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_UserPermissions_PageId')
    CREATE INDEX IX_UserPermissions_PageId ON UserPermissions(PageId);

-- =============================================
-- Indexes for Projects
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Projects_IsActive')
    CREATE INDEX IX_Projects_IsActive ON Projects(IsActive);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Projects_Status')
    CREATE INDEX IX_Projects_Status ON Projects(Status);

-- =============================================
-- Indexes for BudgetCodes
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_BudgetCodes_IsActive')
    CREATE INDEX IX_BudgetCodes_IsActive ON BudgetCodes(IsActive);

-- =============================================
-- Indexes for ProjectBudgets
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_ProjectBudgets_ProjectId')
    CREATE INDEX IX_ProjectBudgets_ProjectId ON ProjectBudgets(ProjectId);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_ProjectBudgets_BudgetCodeId')
    CREATE INDEX IX_ProjectBudgets_BudgetCodeId ON ProjectBudgets(BudgetCodeId);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_ProjectBudgets_IsActive')
    CREATE INDEX IX_ProjectBudgets_IsActive ON ProjectBudgets(IsActive);

-- =============================================
-- Indexes for Resources
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Resources_IsActive')
    CREATE INDEX IX_Resources_IsActive ON Resources(IsActive);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Resources_ResourceType')
    CREATE INDEX IX_Resources_ResourceType ON Resources(ResourceType);

-- =============================================
-- Indexes for ProjectResources
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_ProjectResources_ProjectId')
    CREATE INDEX IX_ProjectResources_ProjectId ON ProjectResources(ProjectId);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_ProjectResources_ResourceId')
    CREATE INDEX IX_ProjectResources_ResourceId ON ProjectResources(ResourceId);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_ProjectResources_IsActive')
    CREATE INDEX IX_ProjectResources_IsActive ON ProjectResources(IsActive);

-- =============================================
-- Indexes for Expenses (Critical for performance)
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Expenses_ExpenseDate')
    CREATE INDEX IX_Expenses_ExpenseDate ON Expenses(ExpenseDate);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Expenses_ProjectId')
    CREATE INDEX IX_Expenses_ProjectId ON Expenses(ProjectId);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Expenses_BudgetCodeId')
    CREATE INDEX IX_Expenses_BudgetCodeId ON Expenses(BudgetCodeId);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Expenses_ResourceId')
    CREATE INDEX IX_Expenses_ResourceId ON Expenses(ResourceId);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Expenses_IsDeleted')
    CREATE INDEX IX_Expenses_IsDeleted ON Expenses(IsDeleted);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Expenses_ProjectId_BudgetCodeId')
    CREATE INDEX IX_Expenses_ProjectId_BudgetCodeId ON Expenses(ProjectId, BudgetCodeId);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Expenses_ExpenseDate_ProjectId')
    CREATE INDEX IX_Expenses_ExpenseDate_ProjectId ON Expenses(ExpenseDate, ProjectId);

-- =============================================
-- Indexes for AuditLogs
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_AuditLogs_UserId')
    CREATE INDEX IX_AuditLogs_UserId ON AuditLogs(UserId);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_AuditLogs_Module')
    CREATE INDEX IX_AuditLogs_Module ON AuditLogs(Module);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_AuditLogs_CreatedDate')
    CREATE INDEX IX_AuditLogs_CreatedDate ON AuditLogs(CreatedDate);
GO

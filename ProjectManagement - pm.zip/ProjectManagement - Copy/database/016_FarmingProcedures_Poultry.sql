﻿USE ProjectManagementDB;
GO

-- =============================================
-- Â§103 Poultry Farming + Revenue stored procedures.
-- Same conventions as 015. Bird-stock rules (Â§87-Â§88, Â§108):
-- mortality / sales must not exceed current birds
-- (Initial - Mortality - Sold, excluding the edited row on update).
-- Batch capacity (Â§83): active birds across other ACTIVE batches in
-- the same shed + new batch initial quantity must fit shed capacity.
-- Poultry sales auto-post Revenue (Poultry Sale) transactionally.
-- =============================================

-- =============================================
-- Sheds: GetPaged / GetById / Insert / Update / Delete / SetActive
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultryShed_GetPaged')
    DROP PROCEDURE usp_PoultryShed_GetPaged;
GO

CREATE PROCEDURE usp_PoultryShed_GetPaged
    @ProjectId INT = NULL,
    @SearchText NVARCHAR(100) = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @SortBy NVARCHAR(50) = 'shedCode',
    @SortDir NVARCHAR(4) = 'asc',
    @TotalRecords INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@PageNumber IS NULL OR @PageNumber < 1) SET @PageNumber = 1;
    IF (@PageSize IS NULL OR @PageSize < 1) SET @PageSize = 10;
    IF (@PageSize > 100) SET @PageSize = 100;
    SET @SortBy = LOWER(LTRIM(RTRIM(ISNULL(@SortBy, 'shedcode'))));
    IF (@SortBy NOT IN ('shedid', 'shedcode', 'shedname', 'capacity', 'status', 'createddate'))
        SET @SortBy = 'shedcode';
    SET @SortDir = LOWER(LTRIM(RTRIM(ISNULL(@SortDir, 'asc'))));
    IF (@SortDir NOT IN ('asc', 'desc')) SET @SortDir = 'asc';
    IF (LTRIM(RTRIM(ISNULL(@SearchText, ''))) = '') SET @SearchText = NULL;

    SELECT @TotalRecords = COUNT(*)
    FROM PoultrySheds s
    WHERE (@ProjectId IS NULL OR s.ProjectId = @ProjectId)
    AND (@SearchText IS NULL OR s.ShedCode LIKE '%' + @SearchText + '%' OR s.ShedName LIKE '%' + @SearchText + '%');

    SELECT s.ShedId, s.ProjectId, pr.ProjectCode, pr.ProjectName,
        s.ShedCode, s.ShedName, s.Capacity, s.CapacityUnit, s.ShedType, s.Status, s.IsActive,
        s.CreatedBy, s.CreatedDate, s.ModifiedBy, s.ModifiedDate
    FROM PoultrySheds s
    INNER JOIN Projects pr ON s.ProjectId = pr.ProjectId
    WHERE (@ProjectId IS NULL OR s.ProjectId = @ProjectId)
    AND (@SearchText IS NULL OR s.ShedCode LIKE '%' + @SearchText + '%' OR s.ShedName LIKE '%' + @SearchText + '%')
    ORDER BY
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'shedcode' THEN s.ShedCode END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'shedcode' THEN s.ShedCode END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'shedname' THEN s.ShedName END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'shedname' THEN s.ShedName END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'capacity' THEN s.Capacity END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'capacity' THEN s.Capacity END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'status' THEN s.Status END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'status' THEN s.Status END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'createddate' THEN s.CreatedDate END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'createddate' THEN s.CreatedDate END DESC,
        s.ShedCode ASC
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultryShed_GetById')
    DROP PROCEDURE usp_PoultryShed_GetById;
GO

CREATE PROCEDURE usp_PoultryShed_GetById
    @ShedId INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT s.ShedId, s.ProjectId, pr.ProjectCode, pr.ProjectName,
        s.ShedCode, s.ShedName, s.Capacity, s.CapacityUnit, s.ShedType, s.Status, s.IsActive,
        s.CreatedBy, s.CreatedDate, s.ModifiedBy, s.ModifiedDate
    FROM PoultrySheds s
    INNER JOIN Projects pr ON s.ProjectId = pr.ProjectId
    WHERE s.ShedId = @ShedId;
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultryShed_Insert')
    DROP PROCEDURE usp_PoultryShed_Insert;
GO

CREATE PROCEDURE usp_PoultryShed_Insert
    @ProjectId INT,
    @ShedCode NVARCHAR(20),
    @ShedName NVARCHAR(200),
    @Capacity INT = 0,
    @CapacityUnit NVARCHAR(20) = NULL,
    @ShedType NVARCHAR(50) = NULL,
    @Status NVARCHAR(20) = 'Active',
    @CreatedBy INT,
    @ShedId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (SELECT 1 FROM PoultrySheds WHERE ShedCode = @ShedCode)
    BEGIN RAISERROR('Shed code already exists.', 16, 1); RETURN; END
    IF (ISNULL(@Capacity, 0) < 0)
    BEGIN RAISERROR('Capacity must not be negative.', 16, 1); RETURN; END

    INSERT INTO PoultrySheds (ProjectId, ShedCode, ShedName, Capacity, CapacityUnit, ShedType, Status, IsActive, CreatedBy, CreatedDate)
    VALUES (@ProjectId, @ShedCode, @ShedName, ISNULL(@Capacity, 0), @CapacityUnit, @ShedType, ISNULL(@Status, 'Active'), 1, @CreatedBy, GETDATE());

    SET @ShedId = SCOPE_IDENTITY();
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultryShed_Update')
    DROP PROCEDURE usp_PoultryShed_Update;
GO

CREATE PROCEDURE usp_PoultryShed_Update
    @ShedId INT,
    @ShedCode NVARCHAR(20),
    @ShedName NVARCHAR(200),
    @Capacity INT = 0,
    @CapacityUnit NVARCHAR(20) = NULL,
    @ShedType NVARCHAR(50) = NULL,
    @Status NVARCHAR(20) = NULL,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (SELECT 1 FROM PoultrySheds WHERE ShedCode = @ShedCode AND ShedId <> @ShedId)
    BEGIN RAISERROR('Shed code already exists.', 16, 1); RETURN; END
    IF (ISNULL(@Capacity, 0) < 0)
    BEGIN RAISERROR('Capacity must not be negative.', 16, 1); RETURN; END

    UPDATE PoultrySheds
    SET ShedCode = @ShedCode, ShedName = @ShedName, Capacity = ISNULL(@Capacity, 0),
        CapacityUnit = @CapacityUnit, ShedType = @ShedType,
        Status = ISNULL(@Status, Status), ModifiedBy = @ModifiedBy, ModifiedDate = GETDATE()
    WHERE ShedId = @ShedId;
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultryShed_Delete')
    DROP PROCEDURE usp_PoultryShed_Delete;
GO

CREATE PROCEDURE usp_PoultryShed_Delete
    @ShedId INT
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (SELECT 1 FROM PoultryBatches WHERE ShedId = @ShedId)
    BEGIN RAISERROR('Shed has batches and cannot be deleted. Deactivate it instead.', 16, 1); RETURN; END

    DELETE FROM PoultrySheds WHERE ShedId = @ShedId;
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultryShed_SetActive')
    DROP PROCEDURE usp_PoultryShed_SetActive;
GO

CREATE PROCEDURE usp_PoultryShed_SetActive
    @ShedId INT,
    @IsActive BIT,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE PoultrySheds
    SET IsActive = @IsActive, ModifiedBy = @ModifiedBy, ModifiedDate = GETDATE()
    WHERE ShedId = @ShedId;
END
GO

-- =============================================
-- Batches: GetPaged / GetById / Insert / Update / Delete / SetActive
-- Capacity rule (Â§83) enforced on insert.
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultryBatch_GetPaged')
    DROP PROCEDURE usp_PoultryBatch_GetPaged;
GO

CREATE PROCEDURE usp_PoultryBatch_GetPaged
    @ProjectId INT = NULL,
    @ShedId INT = NULL,
    @SearchText NVARCHAR(100) = NULL,
    @Status NVARCHAR(20) = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @SortBy NVARCHAR(50) = 'startDate',
    @SortDir NVARCHAR(4) = 'desc',
    @TotalRecords INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@PageNumber IS NULL OR @PageNumber < 1) SET @PageNumber = 1;
    IF (@PageSize IS NULL OR @PageSize < 1) SET @PageSize = 10;
    IF (@PageSize > 100) SET @PageSize = 100;
    SET @SortBy = LOWER(LTRIM(RTRIM(ISNULL(@SortBy, 'startdate'))));
    IF (@SortBy NOT IN ('batchid', 'batchcode', 'startdate', 'initialquantity', 'status'))
        SET @SortBy = 'startdate';
    SET @SortDir = LOWER(LTRIM(RTRIM(ISNULL(@SortDir, 'desc'))));
    IF (@SortDir NOT IN ('asc', 'desc')) SET @SortDir = 'desc';
    IF (LTRIM(RTRIM(ISNULL(@SearchText, ''))) = '') SET @SearchText = NULL;
    IF (LTRIM(RTRIM(ISNULL(@Status, ''))) = '') SET @Status = NULL;

    SELECT @TotalRecords = COUNT(*)
    FROM PoultryBatches b
    WHERE (@ProjectId IS NULL OR b.ProjectId = @ProjectId)
    AND (@ShedId IS NULL OR b.ShedId = @ShedId)
    AND (@Status IS NULL OR b.Status = @Status)
    AND (@SearchText IS NULL OR b.BatchCode LIKE '%' + @SearchText + '%');

    SELECT b.BatchId, b.ProjectId, pr.ProjectCode, pr.ProjectName,
        b.ShedId, s.ShedCode, s.ShedName,
        b.BatchCode, b.BirdType, b.StartDate, b.ExpectedSaleDate,
        b.InitialQuantity, b.PurchaseCost, b.Status, b.Remarks,
        b.CreatedBy, b.CreatedDate, b.ModifiedBy, b.ModifiedDate
    FROM PoultryBatches b
    INNER JOIN Projects pr ON b.ProjectId = pr.ProjectId
    INNER JOIN PoultrySheds s ON b.ShedId = s.ShedId
    WHERE (@ProjectId IS NULL OR b.ProjectId = @ProjectId)
    AND (@ShedId IS NULL OR b.ShedId = @ShedId)
    AND (@Status IS NULL OR b.Status = @Status)
    AND (@SearchText IS NULL OR b.BatchCode LIKE '%' + @SearchText + '%')
    ORDER BY
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'startdate' THEN b.StartDate END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'startdate' THEN b.StartDate END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'batchcode' THEN b.BatchCode END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'batchcode' THEN b.BatchCode END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'initialquantity' THEN b.InitialQuantity END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'initialquantity' THEN b.InitialQuantity END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'status' THEN b.Status END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'status' THEN b.Status END DESC,
        b.StartDate DESC, b.BatchId DESC
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultryBatch_GetById')
    DROP PROCEDURE usp_PoultryBatch_GetById;
GO

CREATE PROCEDURE usp_PoultryBatch_GetById
    @BatchId INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT b.BatchId, b.ProjectId, pr.ProjectCode, pr.ProjectName,
        b.ShedId, s.ShedCode, s.ShedName,
        b.BatchCode, b.BirdType, b.StartDate, b.ExpectedSaleDate,
        b.InitialQuantity, b.PurchaseCost, b.Status, b.Remarks,
        b.CreatedBy, b.CreatedDate, b.ModifiedBy, b.ModifiedDate
    FROM PoultryBatches b
    INNER JOIN Projects pr ON b.ProjectId = pr.ProjectId
    INNER JOIN PoultrySheds s ON b.ShedId = s.ShedId
    WHERE b.BatchId = @BatchId;
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultryBatch_Insert')
    DROP PROCEDURE usp_PoultryBatch_Insert;
GO

CREATE PROCEDURE usp_PoultryBatch_Insert
    @ProjectId INT,
    @ShedId INT,
    @BatchCode NVARCHAR(20),
    @BirdType NVARCHAR(50),
    @StartDate DATE,
    @ExpectedSaleDate DATE = NULL,
    @InitialQuantity INT,
    @PurchaseCost DECIMAL(18,2) = 0,
    @Status NVARCHAR(20) = 'Active',
    @Remarks NVARCHAR(500) = NULL,
    @CreatedBy INT,
    @BatchId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (SELECT 1 FROM PoultryBatches WHERE BatchCode = @BatchCode)
    BEGIN RAISERROR('Batch code already exists.', 16, 1); RETURN; END
    IF (@InitialQuantity IS NULL OR @InitialQuantity <= 0)
    BEGIN RAISERROR('Initial birds must be greater than zero.', 16, 1); RETURN; END
    IF NOT EXISTS (SELECT 1 FROM PoultrySheds WHERE ShedId = @ShedId AND IsActive = 1)
    BEGIN RAISERROR('Shed must be active.', 16, 1); RETURN; END

    -- Â§83: overlapping active batches must fit shed capacity.
    DECLARE @Capacity INT, @Init INT, @Mort INT, @Sold INT, @Occupied INT;
    SELECT @Capacity = Capacity FROM PoultrySheds WHERE ShedId = @ShedId;
    SELECT @Init = ISNULL(SUM(InitialQuantity), 0) FROM PoultryBatches WHERE ShedId = @ShedId AND Status = 'Active';
    SELECT @Mort = ISNULL(SUM(m.Quantity), 0) FROM PoultryMortality m INNER JOIN PoultryBatches b ON m.BatchId = b.BatchId WHERE b.ShedId = @ShedId AND b.Status = 'Active';
    SELECT @Sold = ISNULL(SUM(s.BirdQuantity), 0) FROM PoultrySales s INNER JOIN PoultryBatches b ON s.BatchId = b.BatchId WHERE b.ShedId = @ShedId AND b.Status = 'Active';
    SET @Occupied = @Init - @Mort - @Sold;

    IF (@Occupied + @InitialQuantity > @Capacity)
    BEGIN RAISERROR('Shed capacity exceeded. Occupied: %d, Capacity: %d.', 16, 1, @Occupied, @Capacity); RETURN; END

    INSERT INTO PoultryBatches (ProjectId, ShedId, BatchCode, BirdType, StartDate, ExpectedSaleDate, InitialQuantity, PurchaseCost, Status, Remarks, CreatedBy, CreatedDate)
    VALUES (@ProjectId, @ShedId, @BatchCode, @BirdType, @StartDate, @ExpectedSaleDate, @InitialQuantity, ISNULL(@PurchaseCost, 0), ISNULL(@Status, 'Active'), @Remarks, @CreatedBy, GETDATE());

    SET @BatchId = SCOPE_IDENTITY();
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultryBatch_Update')
    DROP PROCEDURE usp_PoultryBatch_Update;
GO

CREATE PROCEDURE usp_PoultryBatch_Update
    @BatchId INT,
    @BatchCode NVARCHAR(20),
    @BirdType NVARCHAR(50),
    @StartDate DATE,
    @ExpectedSaleDate DATE = NULL,
    @PurchaseCost DECIMAL(18,2) = 0,
    @Status NVARCHAR(20) = NULL,
    @Remarks NVARCHAR(500) = NULL,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (SELECT 1 FROM PoultryBatches WHERE BatchCode = @BatchCode AND BatchId <> @BatchId)
    BEGIN RAISERROR('Batch code already exists.', 16, 1); RETURN; END

    UPDATE PoultryBatches
    SET BatchCode = @BatchCode, BirdType = @BirdType, StartDate = @StartDate,
        ExpectedSaleDate = @ExpectedSaleDate, PurchaseCost = ISNULL(@PurchaseCost, 0),
        Status = ISNULL(@Status, Status), Remarks = @Remarks,
        ModifiedBy = @ModifiedBy, ModifiedDate = GETDATE()
    WHERE BatchId = @BatchId;
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultryBatch_Delete')
    DROP PROCEDURE usp_PoultryBatch_Delete;
GO

CREATE PROCEDURE usp_PoultryBatch_Delete
    @BatchId INT
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (SELECT 1 FROM ChickPurchase WHERE BatchId = @BatchId)
        OR EXISTS (SELECT 1 FROM PoultryFeed WHERE BatchId = @BatchId)
        OR EXISTS (SELECT 1 FROM PoultryTreatment WHERE BatchId = @BatchId)
        OR EXISTS (SELECT 1 FROM PoultryMortality WHERE BatchId = @BatchId)
        OR EXISTS (SELECT 1 FROM PoultryGrowth WHERE BatchId = @BatchId)
        OR EXISTS (SELECT 1 FROM EggProduction WHERE BatchId = @BatchId)
        OR EXISTS (SELECT 1 FROM PoultrySales WHERE BatchId = @BatchId)
    BEGIN RAISERROR('Batch has transactions and cannot be deleted. Deactivate it instead.', 16, 1); RETURN; END

    DELETE FROM PoultryBatches WHERE BatchId = @BatchId;
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultryBatch_SetActive')
    DROP PROCEDURE usp_PoultryBatch_SetActive;
GO

CREATE PROCEDURE usp_PoultryBatch_SetActive
    @BatchId INT,
    @IsActive BIT,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE PoultryBatches
    SET Status = CASE WHEN @IsActive = 1 THEN 'Active' ELSE 'Closed' END,
        ModifiedBy = @ModifiedBy, ModifiedDate = GETDATE()
    WHERE BatchId = @BatchId;
END
GO

-- =============================================
-- ChickPurchase: GetPaged / Insert / Update / Delete
-- TotalAmount = Quantity Ã— Rate (always computed).
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_ChickPurchase_GetPaged')
    DROP PROCEDURE usp_ChickPurchase_GetPaged;
GO

CREATE PROCEDURE usp_ChickPurchase_GetPaged
    @ProjectId INT = NULL,
    @BatchId INT = NULL,
    @FromDate DATE = NULL,
    @ToDate DATE = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @SortBy NVARCHAR(50) = 'purchaseDate',
    @SortDir NVARCHAR(4) = 'desc',
    @TotalRecords INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@PageNumber IS NULL OR @PageNumber < 1) SET @PageNumber = 1;
    IF (@PageSize IS NULL OR @PageSize < 1) SET @PageSize = 10;
    IF (@PageSize > 100) SET @PageSize = 100;
    SET @SortBy = LOWER(LTRIM(RTRIM(ISNULL(@SortBy, 'purchasedate'))));
    IF (@SortBy NOT IN ('purchaseid', 'purchasedate', 'batchcode', 'quantity', 'totalamount'))
        SET @SortBy = 'purchasedate';
    SET @SortDir = LOWER(LTRIM(RTRIM(ISNULL(@SortDir, 'desc'))));
    IF (@SortDir NOT IN ('asc', 'desc')) SET @SortDir = 'desc';

    SELECT @TotalRecords = COUNT(*)
    FROM ChickPurchase c
    INNER JOIN PoultryBatches b ON c.BatchId = b.BatchId
    WHERE (@ProjectId IS NULL OR b.ProjectId = @ProjectId)
    AND (@BatchId IS NULL OR c.BatchId = @BatchId)
    AND (@FromDate IS NULL OR c.PurchaseDate >= @FromDate)
    AND (@ToDate IS NULL OR c.PurchaseDate <= @ToDate);

    SELECT c.PurchaseId, c.BatchId, b.BatchCode, b.ProjectId,
        c.PurchaseDate, c.Supplier, c.Quantity, c.Rate, c.TotalAmount,
        c.ReferenceNo, c.Remarks,
        c.CreatedBy, c.CreatedDate, c.ModifiedBy, c.ModifiedDate
    FROM ChickPurchase c
    INNER JOIN PoultryBatches b ON c.BatchId = b.BatchId
    WHERE (@ProjectId IS NULL OR b.ProjectId = @ProjectId)
    AND (@BatchId IS NULL OR c.BatchId = @BatchId)
    AND (@FromDate IS NULL OR c.PurchaseDate >= @FromDate)
    AND (@ToDate IS NULL OR c.PurchaseDate <= @ToDate)
    ORDER BY
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'purchasedate' THEN c.PurchaseDate END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'purchasedate' THEN c.PurchaseDate END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'batchcode' THEN b.BatchCode END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'batchcode' THEN b.BatchCode END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'quantity' THEN c.Quantity END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'quantity' THEN c.Quantity END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'totalamount' THEN c.TotalAmount END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'totalamount' THEN c.TotalAmount END DESC,
        c.PurchaseDate DESC, c.PurchaseId DESC
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_ChickPurchase_Insert')
    DROP PROCEDURE usp_ChickPurchase_Insert;
GO

CREATE PROCEDURE usp_ChickPurchase_Insert
    @BatchId INT,
    @PurchaseDate DATE,
    @Supplier NVARCHAR(200) = NULL,
    @Quantity INT,
    @Rate DECIMAL(18,2) = 0,
    @ReferenceNo NVARCHAR(50) = NULL,
    @Remarks NVARCHAR(500) = NULL,
    @CreatedBy INT,
    @ExpProjectId INT = NULL,
    @ExpBudgetCodeId INT = NULL,
    @ExpResourceId INT = NULL,
    @PurchaseId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@Quantity IS NULL OR @Quantity <= 0)
    BEGIN RAISERROR('Quantity must be greater than zero.', 16, 1); RETURN; END

    DECLARE @Total DECIMAL(18,2) = CAST(@Quantity AS DECIMAL(18,2)) * ISNULL(@Rate, 0);

    INSERT INTO ChickPurchase (BatchId, PurchaseDate, Supplier, Quantity, Rate, TotalAmount, ReferenceNo, Remarks, CreatedBy, CreatedDate)
    VALUES (@BatchId, @PurchaseDate, @Supplier, @Quantity, ISNULL(@Rate, 0), @Total, @ReferenceNo, @Remarks, @CreatedBy, GETDATE());

    SET @PurchaseId = SCOPE_IDENTITY();

    IF (@ExpProjectId IS NOT NULL AND @ExpBudgetCodeId IS NOT NULL AND @ExpResourceId IS NOT NULL AND @Total > 0)
    BEGIN
        INSERT INTO Expenses (ExpenseDate, ProjectId, BudgetCodeId, ResourceId, Amount, Description, ReferenceNo, Remarks, FarmType, FarmEntityType, FarmEntityId, IsDeleted, CreatedBy, CreatedDate)
        VALUES (@PurchaseDate, @ExpProjectId, @ExpBudgetCodeId, @ExpResourceId, @Total,
            'Chick purchase', @ReferenceNo, @Remarks, 'Poultry Farming', 'PoultryBatch', @BatchId, 0, @CreatedBy, GETDATE());
    END
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_ChickPurchase_Update')
    DROP PROCEDURE usp_ChickPurchase_Update;
GO

CREATE PROCEDURE usp_ChickPurchase_Update
    @PurchaseId INT,
    @PurchaseDate DATE,
    @Supplier NVARCHAR(200) = NULL,
    @Quantity INT,
    @Rate DECIMAL(18,2) = 0,
    @ReferenceNo NVARCHAR(50) = NULL,
    @Remarks NVARCHAR(500) = NULL,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@Quantity IS NULL OR @Quantity <= 0)
    BEGIN RAISERROR('Quantity must be greater than zero.', 16, 1); RETURN; END

    UPDATE ChickPurchase
    SET PurchaseDate = @PurchaseDate, Supplier = @Supplier, Quantity = @Quantity,
        Rate = ISNULL(@Rate, 0), TotalAmount = CAST(@Quantity AS DECIMAL(18,2)) * ISNULL(@Rate, 0),
        ReferenceNo = @ReferenceNo, Remarks = @Remarks,
        ModifiedBy = @ModifiedBy, ModifiedDate = GETDATE()
    WHERE PurchaseId = @PurchaseId;
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_ChickPurchase_Delete')
    DROP PROCEDURE usp_ChickPurchase_Delete;
GO

CREATE PROCEDURE usp_ChickPurchase_Delete
    @PurchaseId INT
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM ChickPurchase WHERE PurchaseId = @PurchaseId;
END
GO

-- =============================================
-- PoultryFeed: GetPaged / Insert / Update / Delete
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultryFeed_GetPaged')
    DROP PROCEDURE usp_PoultryFeed_GetPaged;
GO

CREATE PROCEDURE usp_PoultryFeed_GetPaged
    @ProjectId INT = NULL,
    @BatchId INT = NULL,
    @SearchText NVARCHAR(100) = NULL,
    @FromDate DATE = NULL,
    @ToDate DATE = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @SortBy NVARCHAR(50) = 'feedDate',
    @SortDir NVARCHAR(4) = 'desc',
    @TotalRecords INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@PageNumber IS NULL OR @PageNumber < 1) SET @PageNumber = 1;
    IF (@PageSize IS NULL OR @PageSize < 1) SET @PageSize = 10;
    IF (@PageSize > 100) SET @PageSize = 100;
    SET @SortBy = LOWER(LTRIM(RTRIM(ISNULL(@SortBy, 'feeddate'))));
    IF (@SortBy NOT IN ('feedid', 'feeddate', 'batchcode', 'feedtype', 'quantity', 'totalcost'))
        SET @SortBy = 'feeddate';
    SET @SortDir = LOWER(LTRIM(RTRIM(ISNULL(@SortDir, 'desc'))));
    IF (@SortDir NOT IN ('asc', 'desc')) SET @SortDir = 'desc';
    IF (LTRIM(RTRIM(ISNULL(@SearchText, ''))) = '') SET @SearchText = NULL;

    SELECT @TotalRecords = COUNT(*)
    FROM PoultryFeed f
    INNER JOIN PoultryBatches b ON f.BatchId = b.BatchId
    WHERE (@ProjectId IS NULL OR b.ProjectId = @ProjectId)
    AND (@BatchId IS NULL OR f.BatchId = @BatchId)
    AND (@FromDate IS NULL OR f.FeedDate >= @FromDate)
    AND (@ToDate IS NULL OR f.FeedDate <= @ToDate)
    AND (@SearchText IS NULL OR f.FeedType LIKE '%' + @SearchText + '%');

    SELECT f.FeedId, f.BatchId, b.BatchCode, b.ProjectId,
        f.FeedDate, f.FeedType, f.Quantity, f.Unit, f.Rate, f.TotalCost, f.Remarks,
        f.CreatedBy, f.CreatedDate, f.ModifiedBy, f.ModifiedDate
    FROM PoultryFeed f
    INNER JOIN PoultryBatches b ON f.BatchId = b.BatchId
    WHERE (@ProjectId IS NULL OR b.ProjectId = @ProjectId)
    AND (@BatchId IS NULL OR f.BatchId = @BatchId)
    AND (@FromDate IS NULL OR f.FeedDate >= @FromDate)
    AND (@ToDate IS NULL OR f.FeedDate <= @ToDate)
    AND (@SearchText IS NULL OR f.FeedType LIKE '%' + @SearchText + '%')
    ORDER BY
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'feeddate' THEN f.FeedDate END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'feeddate' THEN f.FeedDate END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'batchcode' THEN b.BatchCode END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'batchcode' THEN b.BatchCode END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'feedtype' THEN f.FeedType END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'feedtype' THEN f.FeedType END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'quantity' THEN f.Quantity END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'quantity' THEN f.Quantity END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'totalcost' THEN f.TotalCost END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'totalcost' THEN f.TotalCost END DESC,
        f.FeedDate DESC, f.FeedId DESC
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultryFeed_Insert')
    DROP PROCEDURE usp_PoultryFeed_Insert;
GO

CREATE PROCEDURE usp_PoultryFeed_Insert
    @BatchId INT,
    @FeedDate DATE,
    @FeedType NVARCHAR(50),
    @Quantity DECIMAL(18,2),
    @Unit NVARCHAR(20) = NULL,
    @Rate DECIMAL(18,2) = 0,
    @TotalCost DECIMAL(18,2) = NULL,
    @Remarks NVARCHAR(500) = NULL,
    @CreatedBy INT,
    @ExpProjectId INT = NULL,
    @ExpBudgetCodeId INT = NULL,
    @ExpResourceId INT = NULL,
    @FeedId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@Quantity IS NULL OR @Quantity <= 0)
    BEGIN RAISERROR('Feed quantity must be greater than zero.', 16, 1); RETURN; END
    IF (@TotalCost IS NULL) SET @TotalCost = @Quantity * ISNULL(@Rate, 0);
    IF (@TotalCost < 0)
    BEGIN RAISERROR('Cost must not be negative.', 16, 1); RETURN; END

    INSERT INTO PoultryFeed (BatchId, FeedDate, FeedType, Quantity, Unit, Rate, TotalCost, Remarks, CreatedBy, CreatedDate)
    VALUES (@BatchId, @FeedDate, @FeedType, @Quantity, @Unit, ISNULL(@Rate, 0), @TotalCost, @Remarks, @CreatedBy, GETDATE());

    SET @FeedId = SCOPE_IDENTITY();

    IF (@ExpProjectId IS NOT NULL AND @ExpBudgetCodeId IS NOT NULL AND @ExpResourceId IS NOT NULL AND @TotalCost > 0)
    BEGIN
        INSERT INTO Expenses (ExpenseDate, ProjectId, BudgetCodeId, ResourceId, Amount, Description, ReferenceNo, Remarks, FarmType, FarmEntityType, FarmEntityId, IsDeleted, CreatedBy, CreatedDate)
        VALUES (@FeedDate, @ExpProjectId, @ExpBudgetCodeId, @ExpResourceId, @TotalCost,
            'Poultry feed (' + @FeedType + ')', NULL, @Remarks, 'Poultry Farming', 'PoultryBatch', @BatchId, 0, @CreatedBy, GETDATE());
    END
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultryFeed_Update')
    DROP PROCEDURE usp_PoultryFeed_Update;
GO

CREATE PROCEDURE usp_PoultryFeed_Update
    @FeedId INT,
    @FeedDate DATE,
    @FeedType NVARCHAR(50),
    @Quantity DECIMAL(18,2),
    @Unit NVARCHAR(20) = NULL,
    @Rate DECIMAL(18,2) = 0,
    @TotalCost DECIMAL(18,2) = NULL,
    @Remarks NVARCHAR(500) = NULL,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@Quantity IS NULL OR @Quantity <= 0)
    BEGIN RAISERROR('Feed quantity must be greater than zero.', 16, 1); RETURN; END
    IF (@TotalCost IS NULL) SET @TotalCost = @Quantity * ISNULL(@Rate, 0);
    IF (@TotalCost < 0)
    BEGIN RAISERROR('Cost must not be negative.', 16, 1); RETURN; END

    UPDATE PoultryFeed
    SET FeedDate = @FeedDate, FeedType = @FeedType, Quantity = @Quantity, Unit = @Unit,
        Rate = ISNULL(@Rate, 0), TotalCost = @TotalCost, Remarks = @Remarks,
        ModifiedBy = @ModifiedBy, ModifiedDate = GETDATE()
    WHERE FeedId = @FeedId;
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultryFeed_Delete')
    DROP PROCEDURE usp_PoultryFeed_Delete;
GO

CREATE PROCEDURE usp_PoultryFeed_Delete
    @FeedId INT
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM PoultryFeed WHERE FeedId = @FeedId;
END
GO

-- =============================================
-- PoultryTreatment: GetPaged / Insert / Update / Delete
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultryTreatment_GetPaged')
    DROP PROCEDURE usp_PoultryTreatment_GetPaged;
GO

CREATE PROCEDURE usp_PoultryTreatment_GetPaged
    @ProjectId INT = NULL,
    @BatchId INT = NULL,
    @SearchText NVARCHAR(100) = NULL,
    @FromDate DATE = NULL,
    @ToDate DATE = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @SortBy NVARCHAR(50) = 'treatmentDate',
    @SortDir NVARCHAR(4) = 'desc',
    @TotalRecords INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@PageNumber IS NULL OR @PageNumber < 1) SET @PageNumber = 1;
    IF (@PageSize IS NULL OR @PageSize < 1) SET @PageSize = 10;
    IF (@PageSize > 100) SET @PageSize = 100;
    SET @SortBy = LOWER(LTRIM(RTRIM(ISNULL(@SortBy, 'treatmentdate'))));
    IF (@SortBy NOT IN ('treatmentid', 'treatmentdate', 'batchcode', 'treatmenttype', 'cost'))
        SET @SortBy = 'treatmentdate';
    SET @SortDir = LOWER(LTRIM(RTRIM(ISNULL(@SortDir, 'desc'))));
    IF (@SortDir NOT IN ('asc', 'desc')) SET @SortDir = 'desc';
    IF (LTRIM(RTRIM(ISNULL(@SearchText, ''))) = '') SET @SearchText = NULL;

    SELECT @TotalRecords = COUNT(*)
    FROM PoultryTreatment t
    INNER JOIN PoultryBatches b ON t.BatchId = b.BatchId
    WHERE (@ProjectId IS NULL OR b.ProjectId = @ProjectId)
    AND (@BatchId IS NULL OR t.BatchId = @BatchId)
    AND (@FromDate IS NULL OR t.TreatmentDate >= @FromDate)
    AND (@ToDate IS NULL OR t.TreatmentDate <= @ToDate)
    AND (@SearchText IS NULL OR t.TreatmentType LIKE '%' + @SearchText + '%' OR t.Medicine LIKE '%' + @SearchText + '%');

    SELECT t.TreatmentId, t.BatchId, b.BatchCode, b.ProjectId,
        t.TreatmentDate, t.TreatmentType, t.Medicine, t.Quantity, t.Cost, t.Reason, t.Remarks,
        t.CreatedBy, t.CreatedDate, t.ModifiedBy, t.ModifiedDate
    FROM PoultryTreatment t
    INNER JOIN PoultryBatches b ON t.BatchId = b.BatchId
    WHERE (@ProjectId IS NULL OR b.ProjectId = @ProjectId)
    AND (@BatchId IS NULL OR t.BatchId = @BatchId)
    AND (@FromDate IS NULL OR t.TreatmentDate >= @FromDate)
    AND (@ToDate IS NULL OR t.TreatmentDate <= @ToDate)
    AND (@SearchText IS NULL OR t.TreatmentType LIKE '%' + @SearchText + '%' OR t.Medicine LIKE '%' + @SearchText + '%')
    ORDER BY
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'treatmentdate' THEN t.TreatmentDate END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'treatmentdate' THEN t.TreatmentDate END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'batchcode' THEN b.BatchCode END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'batchcode' THEN b.BatchCode END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'treatmenttype' THEN t.TreatmentType END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'treatmenttype' THEN t.TreatmentType END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'cost' THEN t.Cost END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'cost' THEN t.Cost END DESC,
        t.TreatmentDate DESC, t.TreatmentId DESC
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultryTreatment_Insert')
    DROP PROCEDURE usp_PoultryTreatment_Insert;
GO

CREATE PROCEDURE usp_PoultryTreatment_Insert
    @BatchId INT,
    @TreatmentDate DATE,
    @TreatmentType NVARCHAR(50),
    @Medicine NVARCHAR(200) = NULL,
    @Quantity DECIMAL(18,2) = 0,
    @Cost DECIMAL(18,2) = 0,
    @Reason NVARCHAR(500) = NULL,
    @Remarks NVARCHAR(500) = NULL,
    @CreatedBy INT,
    @ExpProjectId INT = NULL,
    @ExpBudgetCodeId INT = NULL,
    @ExpResourceId INT = NULL,
    @TreatmentId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (ISNULL(@Cost, 0) < 0)
    BEGIN RAISERROR('Cost must not be negative.', 16, 1); RETURN; END

    INSERT INTO PoultryTreatment (BatchId, TreatmentDate, TreatmentType, Medicine, Quantity, Cost, Reason, Remarks, CreatedBy, CreatedDate)
    VALUES (@BatchId, @TreatmentDate, @TreatmentType, @Medicine, ISNULL(@Quantity, 0), ISNULL(@Cost, 0), @Reason, @Remarks, @CreatedBy, GETDATE());

    SET @TreatmentId = SCOPE_IDENTITY();

    IF (@ExpProjectId IS NOT NULL AND @ExpBudgetCodeId IS NOT NULL AND @ExpResourceId IS NOT NULL AND ISNULL(@Cost, 0) > 0)
    BEGIN
        INSERT INTO Expenses (ExpenseDate, ProjectId, BudgetCodeId, ResourceId, Amount, Description, ReferenceNo, Remarks, FarmType, FarmEntityType, FarmEntityId, IsDeleted, CreatedBy, CreatedDate)
        VALUES (@TreatmentDate, @ExpProjectId, @ExpBudgetCodeId, @ExpResourceId, @Cost,
            'Poultry treatment (' + @TreatmentType + ')', NULL, @Reason, 'Poultry Farming', 'PoultryBatch', @BatchId, 0, @CreatedBy, GETDATE());
    END
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultryTreatment_Update')
    DROP PROCEDURE usp_PoultryTreatment_Update;
GO

CREATE PROCEDURE usp_PoultryTreatment_Update
    @TreatmentId INT,
    @TreatmentDate DATE,
    @TreatmentType NVARCHAR(50),
    @Medicine NVARCHAR(200) = NULL,
    @Quantity DECIMAL(18,2) = 0,
    @Cost DECIMAL(18,2) = 0,
    @Reason NVARCHAR(500) = NULL,
    @Remarks NVARCHAR(500) = NULL,
    @ModifiedBy INT
AS
BEGIN
    SET NOCOUNT ON;

    IF (ISNULL(@Cost, 0) < 0)
    BEGIN RAISERROR('Cost must not be negative.', 16, 1); RETURN; END

    UPDATE PoultryTreatment
    SET TreatmentDate = @TreatmentDate, TreatmentType = @TreatmentType, Medicine = @Medicine,
        Quantity = ISNULL(@Quantity, 0), Cost = ISNULL(@Cost, 0),
        Reason = @Reason, Remarks = @Remarks, ModifiedBy = @ModifiedBy, ModifiedDate = GETDATE()
    WHERE TreatmentId = @TreatmentId;
END
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultryTreatment_Delete')
    DROP PROCEDURE usp_PoultryTreatment_Delete;
GO

CREATE PROCEDURE usp_PoultryTreatment_Delete
    @TreatmentId INT
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM PoultryTreatment WHERE TreatmentId = @TreatmentId;
END
GO

-- =============================================
-- PoultryMortality: GetPaged / Insert / Update / Delete
-- Â§108: mortality must not exceed current birds.
-- =============================================
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'usp_PoultryMortality_GetPaged')
    DROP PROCEDURE usp_PoultryMortality_GetPaged;
GO

CREATE PROCEDURE usp_PoultryMortality_GetPaged
    @ProjectId INT = NULL,
    @BatchId INT = NULL,
    @FromDate DATE = NULL,
    @ToDate DATE = NULL,
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @SortBy NVARCHAR(50) = 'mortalityDate',
    @SortDir NVARCHAR(4) = 'desc',
    @TotalRecords INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF (@PageNumber IS NULL OR @PageNumber < 1) SET @PageNumber = 1;
    IF (@PageSize IS NULL OR @PageSize < 1) SET @PageSize = 10;
    IF (@PageSize > 100) SET @PageSize = 100;
    SET @SortBy = LOWER(LTRIM(RTRIM(ISNULL(@SortBy, 'mortalitydate'))));
    IF (@SortBy NOT IN ('mortalityid', 'mortalitydate', 'batchcode', 'quantity'))
        SET @SortBy = 'mortalitydate';
    SET @SortDir = LOWER(LTRIM(RTRIM(ISNULL(@SortDir, 'desc'))));
    IF (@SortDir NOT IN ('asc', 'desc')) SET @SortDir = 'desc';

    SELECT @TotalRecords = COUNT(*)
    FROM PoultryMortality m
    INNER JOIN PoultryBatches b ON m.BatchId = b.BatchId
    WHERE (@ProjectId IS NULL OR b.ProjectId = @ProjectId)
    AND (@BatchId IS NULL OR m.BatchId = @BatchId)
    AND (@FromDate IS NULL OR m.MortalityDate >= @FromDate)
    AND (@ToDate IS NULL OR m.MortalityDate <= @ToDate);

    SELECT m.MortalityId, m.BatchId, b.BatchCode, b.ProjectId,
        m.MortalityDate, m.Quantity, m.Reason, m.Remarks,
        m.CreatedBy, m.CreatedDate, m.ModifiedBy, m.ModifiedDate
    FROM PoultryMortality m
    INNER JOIN PoultryBatches b ON m.BatchId = b.BatchId
    WHERE (@ProjectId IS NULL OR b.ProjectId = @ProjectId)
    AND (@BatchId IS NULL OR m.BatchId = @BatchId)
    AND (@FromDate IS NULL OR m.MortalityDate >= @FromDate)
    AND (@ToDate IS NULL OR m.MortalityDate <= @ToDate)
    ORDER BY
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'mortalitydate' THEN m.MortalityDate END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'mortalitydate' THEN m.MortalityDate END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'batchcode' THEN b.BatchCode END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'batchcode' THEN b.BatchCode END DESC,
        CASE WHEN @SortDir = 'asc' AND @SortBy = 'quantity' THEN m.Quantity END ASC,
        CASE WHEN @SortDir = 'desc' AND @SortBy = 'quantity' THEN m.Quantity END DESC,
        m.MortalityDate DESC, m.MortalityId DESC
    OFFSET ((@PageNumber - 1) * @PageSize) ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END
GO

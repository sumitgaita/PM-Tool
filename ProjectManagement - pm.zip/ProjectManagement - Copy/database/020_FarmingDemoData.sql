USE ProjectManagementDB;
GO

-- =============================================
-- Demo farming data (§111: dashboards/reports verifiable immediately).
-- All blocks idempotent (IF NOT EXISTS on natural keys).
-- =============================================

-- Demo projects
IF NOT EXISTS (SELECT 1 FROM Projects WHERE ProjectCode = 'PRJ-FISH1')
    INSERT INTO Projects (ProjectCode, ProjectName, Description, ClientName, StartDate, EndDate, TotalBudget, Status, FarmType, IsActive, CreatedBy, CreatedDate)
    VALUES ('PRJ-FISH1', 'Fish Farm - Unit 1', 'Demo fish farming project', 'Demo Client', '2026-01-01', '2026-12-31', 500000, 'Active', 'Fish Farming', 1, 1, GETDATE());
IF NOT EXISTS (SELECT 1 FROM Projects WHERE ProjectCode = 'PRJ-POULTRY1')
    INSERT INTO Projects (ProjectCode, ProjectName, Description, ClientName, StartDate, EndDate, TotalBudget, Status, FarmType, IsActive, CreatedBy, CreatedDate)
    VALUES ('PRJ-POULTRY1', 'Poultry Farm - Unit 1', 'Demo poultry farming project', 'Demo Client', '2026-01-01', '2026-12-31', 600000, 'Active', 'Poultry Farming', 1, 1, GETDATE());
GO

-- Demo pond + stocking + feed + mortality + harvest
DECLARE @FishProj INT;
SELECT @FishProj = ProjectId FROM Projects WHERE ProjectCode = 'PRJ-FISH1';
DECLARE @Rohu INT;
SELECT @Rohu = FishTypeId FROM FishTypes WHERE FishCode = 'FISH-ROHU';

IF NOT EXISTS (SELECT 1 FROM Ponds WHERE PondCode = 'POND-01')
    INSERT INTO Ponds (ProjectId, PondCode, PondName, Area, AreaUnit, Depth, PondType, Status, IsActive, CreatedBy, CreatedDate)
    VALUES (@FishProj, 'POND-01', 'Main Pond', 2.5, 'Acre', '6 ft', 'Earthen', 'Active', 1, 1, GETDATE());

DECLARE @Pond INT;
SELECT @Pond = PondId FROM Ponds WHERE PondCode = 'POND-01';

IF NOT EXISTS (SELECT 1 FROM FishStocking WHERE PondId = @Pond AND FishTypeId = @Rohu)
    INSERT INTO FishStocking (PondId, FishTypeId, StockingDate, Quantity, AverageWeight, PurchaseRate, TotalCost, Supplier, ReferenceNo, CreatedBy, CreatedDate)
    VALUES (@Pond, @Rohu, '2026-09-01', 1000, 10, 5, 5000, 'Demo Hatchery', 'DEMO-STOCK-1', 1, GETDATE());

IF NOT EXISTS (SELECT 1 FROM FishFeed WHERE PondId = @Pond AND FeedDate = '2026-09-10')
    INSERT INTO FishFeed (PondId, FeedDate, FeedType, Quantity, Unit, Rate, TotalCost, CreatedBy, CreatedDate)
    VALUES (@Pond, '2026-09-10', 'Grower Feed', 50, 'Kg', 40, 2000, 1, GETDATE());

IF NOT EXISTS (SELECT 1 FROM FishMortality WHERE PondId = @Pond AND MortalityDate = '2026-09-12')
    INSERT INTO FishMortality (PondId, FishTypeId, MortalityDate, Quantity, Reason, CreatedBy, CreatedDate)
    VALUES (@Pond, @Rohu, '2026-09-12', 20, 'Demo data', 1, GETDATE());

IF NOT EXISTS (SELECT 1 FROM FishHarvest WHERE PondId = @Pond AND HarvestDate = '2026-09-25')
    INSERT INTO FishHarvest (PondId, FishTypeId, HarvestDate, Quantity, TotalWeight, AverageWeight, HarvestCost, CreatedBy, CreatedDate)
    VALUES (@Pond, @Rohu, '2026-09-25', 300, 600, 2, 1500, 1, GETDATE());

IF NOT EXISTS (SELECT 1 FROM FishGrowth WHERE PondId = @Pond AND SamplingDate = '2026-09-18')
    INSERT INTO FishGrowth (PondId, FishTypeId, SamplingDate, SampleQuantity, AverageWeight, CreatedBy, CreatedDate)
    VALUES (@Pond, @Rohu, '2026-09-18', 50, 450, 1, GETDATE());

-- Demo fish sale THROUGH the proc so Revenue auto-posts (idempotent by ReferenceNo).
IF NOT EXISTS (SELECT 1 FROM FishSales WHERE ReferenceNo = 'DEMO-FISH-1')
BEGIN
    DECLARE @SaleId INT;
    EXEC usp_FishSales_Insert @ProjectId = @FishProj, @HarvestId = NULL, @FishTypeId = @Rohu,
        @SaleDate = '2026-10-02', @CustomerName = 'Demo Buyer', @Quantity = 200,
        @TotalWeight = 400, @Rate = 120, @TotalAmount = NULL,
        @PaymentStatus = 'Paid', @ReferenceNo = 'DEMO-FISH-1', @CreatedBy = 1, @SaleId = @SaleId OUTPUT;
END
GO

-- Demo shed + batch + chick + feed + mortality + growth + eggs
DECLARE @PoultryProj INT;
SELECT @PoultryProj = ProjectId FROM Projects WHERE ProjectCode = 'PRJ-POULTRY1';

IF NOT EXISTS (SELECT 1 FROM PoultrySheds WHERE ShedCode = 'SHED-01')
    INSERT INTO PoultrySheds (ProjectId, ShedCode, ShedName, Capacity, CapacityUnit, ShedType, Status, IsActive, CreatedBy, CreatedDate)
    VALUES (@PoultryProj, 'SHED-01', 'Broiler Shed 1', 5000, 'Birds', 'Broiler', 'Active', 1, 1, GETDATE());

DECLARE @Shed INT;
SELECT @Shed = ShedId FROM PoultrySheds WHERE ShedCode = 'SHED-01';

IF NOT EXISTS (SELECT 1 FROM PoultryBatches WHERE BatchCode = 'BATCH-01')
    INSERT INTO PoultryBatches (ProjectId, ShedId, BatchCode, BirdType, StartDate, ExpectedSaleDate, InitialQuantity, PurchaseCost, Status, CreatedBy, CreatedDate)
    VALUES (@PoultryProj, @Shed, 'BATCH-01', 'Broiler', '2026-09-01', '2026-10-15', 1000, 12000, 'Active', 1, GETDATE());

DECLARE @Batch INT;
SELECT @Batch = BatchId FROM PoultryBatches WHERE BatchCode = 'BATCH-01';

IF NOT EXISTS (SELECT 1 FROM ChickPurchase WHERE BatchId = @Batch AND ReferenceNo = 'DEMO-CHICK-1')
    INSERT INTO ChickPurchase (BatchId, PurchaseDate, Supplier, Quantity, Rate, TotalAmount, ReferenceNo, CreatedBy, CreatedDate)
    VALUES (@Batch, '2026-09-01', 'Demo Hatchery', 1000, 12, 12000, 'DEMO-CHICK-1', 1, GETDATE());

IF NOT EXISTS (SELECT 1 FROM PoultryFeed WHERE BatchId = @Batch AND FeedDate = '2026-09-10')
    INSERT INTO PoultryFeed (BatchId, FeedDate, FeedType, Quantity, Unit, Rate, TotalCost, CreatedBy, CreatedDate)
    VALUES (@Batch, '2026-09-10', 'Starter', 200, 'Kg', 35, 7000, 1, GETDATE());

IF NOT EXISTS (SELECT 1 FROM PoultryMortality WHERE BatchId = @Batch AND MortalityDate = '2026-09-12')
    INSERT INTO PoultryMortality (BatchId, MortalityDate, Quantity, Reason, CreatedBy, CreatedDate)
    VALUES (@Batch, '2026-09-12', 15, 'Demo data', 1, GETDATE());

IF NOT EXISTS (SELECT 1 FROM PoultryGrowth WHERE BatchId = @Batch AND SampleDate = '2026-09-20')
    INSERT INTO PoultryGrowth (BatchId, SampleDate, SampleQuantity, AverageWeight, CreatedBy, CreatedDate)
    VALUES (@Batch, '2026-09-20', 30, 1.8, 1, GETDATE());

IF NOT EXISTS (SELECT 1 FROM PoultryTreatment WHERE BatchId = @Batch AND TreatmentDate = '2026-09-15')
    INSERT INTO PoultryTreatment (BatchId, TreatmentDate, TreatmentType, Medicine, Quantity, Cost, Reason, CreatedBy, CreatedDate)
    VALUES (@Batch, '2026-09-15', 'Vaccination', 'Ranikhet Vaccine', 2, 800, 'Scheduled vaccination', 1, GETDATE());

IF NOT EXISTS (SELECT 1 FROM EggProduction WHERE BatchId = @Batch AND ProductionDate = '2026-10-02')
    INSERT INTO EggProduction (BatchId, ProductionDate, GoodEggs, BrokenEggs, TotalEggs, CreatedBy, CreatedDate)
    VALUES (@Batch, '2026-10-02', 800, 20, 820, 1, GETDATE());

-- Demo poultry sale THROUGH the proc so Revenue auto-posts.
IF NOT EXISTS (SELECT 1 FROM PoultrySales WHERE ReferenceNo = 'DEMO-POULTRY-1')
BEGIN
    DECLARE @PSaleId INT;
    EXEC usp_PoultrySales_Insert @ProjectId = @PoultryProj, @BatchId = @Batch,
        @SaleDate = '2026-10-03', @CustomerName = 'Demo Buyer', @BirdQuantity = 200,
        @TotalWeight = 360, @Rate = 150, @TotalAmount = NULL,
        @PaymentStatus = 'Paid', @ReferenceNo = 'DEMO-POULTRY-1', @CreatedBy = 1, @SaleId = @PSaleId OUTPUT;
END
GO

-- Demo budgets + linked expenses for the two farm projects.
DECLARE @FishProj2 INT, @PoultryProj2 INT, @FishFeedBc INT, @PoultryFeedBc INT, @Res INT;
SELECT @FishProj2 = ProjectId FROM Projects WHERE ProjectCode = 'PRJ-FISH1';
SELECT @PoultryProj2 = ProjectId FROM Projects WHERE ProjectCode = 'PRJ-POULTRY1';
SELECT @FishFeedBc = BudgetCodeId FROM BudgetCodes WHERE BudgetCode = 'FISH-FEED';
SELECT @PoultryFeedBc = BudgetCodeId FROM BudgetCodes WHERE BudgetCode = 'POULTRY-FEED';
SELECT TOP 1 @Res = ResourceId FROM Resources WHERE IsActive = 1 ORDER BY ResourceId;

IF NOT EXISTS (SELECT 1 FROM ProjectBudgets WHERE ProjectId = @FishProj2 AND BudgetCodeId = @FishFeedBc)
    INSERT INTO ProjectBudgets (ProjectId, BudgetCodeId, BudgetAmount, EffectiveFrom, EffectiveTo, IsActive, CreatedBy, CreatedDate)
    VALUES (@FishProj2, @FishFeedBc, 100000, '2026-01-01', '2026-12-31', 1, 1, GETDATE());
IF NOT EXISTS (SELECT 1 FROM ProjectBudgets WHERE ProjectId = @PoultryProj2 AND BudgetCodeId = @PoultryFeedBc)
    INSERT INTO ProjectBudgets (ProjectId, BudgetCodeId, BudgetAmount, EffectiveFrom, EffectiveTo, IsActive, CreatedBy, CreatedDate)
    VALUES (@PoultryProj2, @PoultryFeedBc, 150000, '2026-01-01', '2026-12-31', 1, 1, GETDATE());

IF NOT EXISTS (SELECT 1 FROM Expenses WHERE ProjectId = @FishProj2 AND ReferenceNo = 'DEMO-EXP-FISH')
    INSERT INTO Expenses (ExpenseDate, ProjectId, BudgetCodeId, ResourceId, Amount, Description, ReferenceNo, FarmType, IsDeleted, CreatedBy, CreatedDate)
    VALUES ('2026-09-10', @FishProj2, @FishFeedBc, @Res, 2000, 'Demo fish feed', 'DEMO-EXP-FISH', 'Fish Farming', 0, 1, GETDATE());
IF NOT EXISTS (SELECT 1 FROM Expenses WHERE ProjectId = @PoultryProj2 AND ReferenceNo = 'DEMO-EXP-POULTRY')
    INSERT INTO Expenses (ExpenseDate, ProjectId, BudgetCodeId, ResourceId, Amount, Description, ReferenceNo, FarmType, IsDeleted, CreatedBy, CreatedDate)
    VALUES ('2026-09-10', @PoultryProj2, @PoultryFeedBc, @Res, 7000, 'Demo poultry feed', 'DEMO-EXP-POULTRY', 'Poultry Farming', 0, 1, GETDATE());
GO

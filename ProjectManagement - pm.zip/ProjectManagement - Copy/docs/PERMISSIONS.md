# Permissions & Roles

## Roles (`Roles` table)

- **Admin** — full access. `RequirePermissionAttribute` bypasses DB checks for Admin.
  No per-page rows required.
- **User** — permission-based. Every protected endpoint checks
  `UserPermissions JOIN Pages` for the page; missing row = deny (`403`).

## Pages (`Pages` table, 11 rows)

Dashboard, Projects, Budget Codes, Project Budgets, Resources, Project Resources,
Expenses, Cost Vs Budget, Reports, Users, Permissions.

List: `GET /api/permission/pages` (auth).

## Granting permissions (Admin only)

Single: `POST /api/user/permissions`
```json
{ "userId": 2, "pageId": 1, "canView": true, "canEdit": false, "canDelete": false }
```
Bulk (used by Permissions UI): `POST /api/permission/user/bulk`
```json
{ "userId": 2, "permissions": [ { "pageId": 1, "canView": true, ... } ] }
```

Read back: `GET /api/user/{id}/permissions` returns all 11 pages with `false`
defaults for ungranted pages. Self: `GET /api/permission/my-permissions`
(Admin gets synthetic full-access rows).

## Enforcement matrix (live-verified 2026-10-02)

| Case | Result |
|---|---|
| No token → `GET /api/project` | `401` |
| User, Dashboard View granted → `GET /api/dashboard/summary` | `200` |
| User, no Projects.Edit → `POST /api/project` | `403` |
| User, no row at all → any protected endpoint | `403` |
| Admin, no rows → everything | `200` (bypass) |

Frontend mirrors this: `PermissionGuard` + `Auth.isAdmin()` gate routes/buttons,
but the backend never trusts it.

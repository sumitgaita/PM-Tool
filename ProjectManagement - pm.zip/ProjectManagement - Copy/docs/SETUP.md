# Setup & Verification

## 1. SQL Server

```
sqlcmd -S "DESKTOP-J3F0UP4\SQLEXPRESS" -E -Q "SELECT @@VERSION"
```

## 2. Database (idempotent — safe to re-run)

```powershell
sqlcmd -S "DESKTOP-J3F0UP4\SQLEXPRESS" -E -i database/001_CreateDatabase.sql
sqlcmd -S "DESKTOP-J3F0UP4\SQLEXPRESS" -E -i database/002_CreateTables.sql
sqlcmd -S "DESKTOP-J3F0UP4\SQLEXPRESS" -E -i database/003_CreateIndexes.sql
sqlcmd -S "DESKTOP-J3F0UP4\SQLEXPRESS" -E -i database/004_CreateViews.sql
sqlcmd -S "DESKTOP-J3F0UP4\SQLEXPRESS" -E -i database/005_CreateFunctions.sql
sqlcmd -S "DESKTOP-J3F0UP4\SQLEXPRESS" -E -i database/006_CreateStoredProcedures.sql
sqlcmd -S "DESKTOP-J3F0UP4\SQLEXPRESS" -E -i database/007_CreateSeedData.sql
sqlcmd -S "DESKTOP-J3F0UP4\SQLEXPRESS" -E -i database/008_CreateAdmin.sql
```

`007` is ID-agnostic (looks up IDs by PRJ/BC/RES codes; expenses keyed by
ReferenceNo). `006` includes `usp_Pages_GetAll`.

## 3. Backend

```powershell
dotnet restore backend/ProjectManagement.Api/ProjectManagement.Api/ProjectManagement.Api.csproj
dotnet build backend/ProjectManagement.Api/ProjectManagement.Api/ProjectManagement.Api.csproj
dotnet run --project backend/ProjectManagement.Api/ProjectManagement.Api/ProjectManagement.Api.csproj --launch-profile https
dotnet test backend/ProjectManagement.Tests/ProjectManagement.Tests.csproj
```

13 unit tests: budget math (remaining/variance/utilization incl. div-by-zero,
over-budget, seed totals), permission matrix (admin bypass, view/edit/delete,
deny-by-default), SHA256 admin hash.

## 4. Frontend

```powershell
cd frontend/project-management-frontend
npm install --legacy-peer-deps
ng serve            # http://localhost:4200
ng build --configuration production
```

## 5. Smoke test (admin/admin123)

```powershell
$tok = (curl.exe -k -s -X POST https://localhost:7284/api/auth/login `
  -H "Content-Type: application/json" -d '{"username":"admin","password":"admin123"}' `
  | ConvertFrom-Json).token
curl.exe -k -s https://localhost:7284/api/project -H "Authorization: Bearer $tok"
curl.exe -k -s https://localhost:7284/api/dashboard/summary -H "Authorization: Bearer $tok"
```

Expected: 3 projects; summary `{ totalProjects: 3, totalBudget: 140000,
totalExpense: 35500 }`. Full E2E log (expense copy, reports, permissions
200/403/401) verified 2026-10-02 — see `docs/API.md`, `docs/PERMISSIONS.md`.

# API Reference

Base URL (HTTPS): `https://localhost:7284/api` — Swagger UI at `https://localhost:7284/swagger`.
All endpoints except `POST /api/auth/login` require JWT Bearer. Permission endpoints
add page-level checks via `[RequirePermission(page, action)]` → `403` on deny, `401` when unauthenticated.

## Auth — `POST /api/auth/login` (public)

```json
{ "username": "admin", "password": "admin123" }
→ { "success": true, "token": "<jwt>", "user": { "userId": 1, "roleName": "Admin", ... } }
```

- `POST /api/auth/change-password` (auth)
- `GET /api/auth/current-user` (auth)

## Page → controller map (View = GET, Edit = POST/PUT, Delete = DELETE)

| Page | Controller | Routes |
|---|---|---|
| Dashboard | `dashboard` | `GET summary, project-wise, budget-code-wise, monthly, year-wise, resource-wise` |
| Projects | `project` | `GET /, GET {id}, POST /, PUT {id}, POST {id}/activate, POST {id}/deactivate, DELETE {id} (soft)` |
| Budget Codes | `budgetcode` | `GET /, POST /, PUT {id}, POST {id}/activate|deactivate, DELETE {id} (soft)` |
| Project Budgets | `projectbudget` | `GET ?projectId&budgetCodeId, POST /, PUT {id}, DELETE {id}` |
| Resources | `resource` | `GET /, POST /, PUT {id}, POST {id}/activate|deactivate, DELETE {id} (soft)` |
| Project Resources | `projectresource` | `GET ?projectId&resourceId, POST /, PUT {id}, DELETE {id}` |
| Expenses | `expense` | `GET {id}, GET by-date/{date}, GET by-date-range?fromDate&toDate&projectId&budgetCodeId&resourceId, POST /, PUT {id}, DELETE {id} (soft), POST copy-from-date` |
| Cost Vs Budget / Reports | `report` | `GET project-wise, GET date-wise/{date}, GET date-range, GET cost-vs-budget` |
| Users | `user` | `GET /, GET {id}, POST /, PUT {id}, POST {id}/activate|deactivate, GET {id}/permissions, POST /permissions` |
| Permissions | `permission` | `GET pages, GET user/{userId}, POST user/bulk (Admin only), GET my-permissions` |

## Copy expense from previous date

```
POST /api/expense/copy-from-date
{ "fromDate": "2026-09-01", "toDate": "2026-10-02", "projectId": null, "resourceId": null }
→ { "success": true, "message": "Expenses copied successfully." }
```

Creates NEW Expense rows dated `toDate` (new ExpenseId). Verified 2026-10-02:
copy 2026-09-01 → October row appears in `dashboard/monthly`.

## Reports (verified 2026-10-02)

- `GET /api/report/project-wise` → per project/budget/resource: `budget, expense, variance, utilizationPercent`
- `GET /api/report/cost-vs-budget` → `budgetAmount, actualCost, remainingBudget, utilizationPercent, variance`
- `GET /api/report/date-range?fromDate&toDate` + `GET /api/report/date-wise/{date}`
- Dashboard: `GET /api/dashboard/summary` → `{ totalProjects: 3, activeProjects: 2, totalBudget: 140000, totalExpense: 35500, activeResources: 3 }`

## Standard response envelope

```json
{ "success": true, "message": "…", "data": {} }
{ "success": false, "message": "Validation failed.", "errors": ["…"] }
```

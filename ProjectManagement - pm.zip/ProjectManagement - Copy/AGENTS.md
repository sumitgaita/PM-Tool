# AGENTS.md — AI Coding Agent Instructions

> Read this file before modifying the project.

## Technology

Angular 21 standalone + ASP.NET Core 9 Web API + SQL Server Express.

## Database

- Instance: `DESKTOP-J3F0UP4\SQLEXPRESS`
- DB: `ProjectManagementDB`
- Auth: Windows Authentication for SQL Server (`Integrated Security=True`). No SQL passwords.
- Access: ADO.NET + Stored Procedures ONLY for CRUD/business ops. Do NOT replace SQL Server with SQLite/PostgreSQL. Do NOT use EF for main flows.

## Key paths (canonical)

- Backend project: `backend/ProjectManagement.Api/ProjectManagement.Api/ProjectManagement.Api.csproj`
  - Sources: `.../ProjectManagement.Api/{Controllers,DTOs,Services,Authorization,Middleware,Program.cs,appsettings.json}`
  - Mirror copies exist one level up (`backend/ProjectManagement.Api/{Controllers,...}`) — keep in sync if editing.
- Frontend: `frontend/project-management-frontend/src/app/{app.routes.ts,app.config.ts,services,core/guards,components}`
- DB scripts: `database/001..008_*.sql` (idempotent, run in order)

## Before modifying

- Database: check existing tables, views (`vw_*`), procedures (`usp_*`). Seed script `007` is ID-agnostic (lookup by code) — keep it that way.
- APIs: check existing DTOs and `IDatabaseService.ExecuteStoredProcedureAsync<T>` (nullable-safe). New endpoints must use stored procs + parameterized `SqlParameter`.
- Angular: check existing routes, `AuthGuard`, `PermissionGuard`, `Api`/`Auth` services. Components must stay `standalone:true` with Material imports. Keep `environment*.ts` apiUrl on `https://localhost:7284/api`.

## Auth model (do not weaken)

- JWT Bearer. Admin bypasses permission checks.
- Page-level View/Edit/Delete in `UserPermissions` + `Pages`. Backend must enforce via `[RequirePermission("Projects","View")]` (403 on deny), not just hide buttons. Bulk save: `POST /api/permission/user/bulk` (Admin only).
- Never store plain-text passwords (SHA256 hex). No password/connection-string logging. Global errors via `GlobalExceptionMiddleware` (no stack traces to client).

## After changes

1. `dotnet build` backend (0 errors).
2. `ng build --configuration production` frontend (0 errors; budgets 5MB initial).
3. Re-run DB scripts if schema changed; verify tables/views/procs/seed/admin.
4. Verify API: login admin/admin123 → GET /api/project, /api/projectbudget, /api/dashboard/summary.
5. `ng serve` + API run; test Admin + Normal User (View/Edit/Delete/No-permission), expense entry, copy-previous-date, reports, Excel export, dashboard.

## Do not

- Remove existing functionality, hard-code IDs/dates/dashboard numbers, fake API responses, mock dashboard data, use LocalStorage-only authorization, or frontend-only security.

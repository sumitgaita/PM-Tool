# 68. Fish Farming & Poultry Farming Integration

Extend the existing Project Management Application to support **Fish Farming and Poultry Farming** as integrated business modules.

Do NOT create separate applications for Fish Farming and Poultry Farming.

The existing architecture must remain the common foundation:

```text
Project
   ↓
Budget
   ↓
Budget Codes
   ↓
Resources
   ↓
Daily Expenses
   ↓
Cost vs Budget
   ↓
Revenue
   ↓
Profitability
   ↓
Reports
   ↓
Dashboard
```

Fish Farming and Poultry Farming will add operational modules on top of this common financial/project-management system.

---

# 69. Farm Type

Add a Farm Type concept.

Supported values:

```text
Fish Farming
Poultry Farming
```

Projects should have a `FarmType` field.

Example:

```text
Project: Fish Farm - Unit 1
FarmType: Fish Farming
```

```text
Project: Poultry Farm - Unit 1
FarmType: Poultry Farming
```

Allow Admin users to create/manage additional farm types in the future if required.

---

# 70. Updated Project Structure

The application navigation should become:

```text
Dashboard

Projects

Farm Management
    Fish Farming
        Ponds
        Fish Types
        Fish Stocking
        Fish Feed
        Fish Treatment
        Fish Mortality
        Fish Growth
        Fish Harvest
        Fish Sales

    Poultry Farming
        Poultry Sheds
        Poultry Batches
        Chick Purchase
        Poultry Feed
        Treatment / Vaccination
        Poultry Mortality
        Poultry Growth
        Egg Production
        Poultry Sales

Budget
    Budget Codes
    Project Budget

Resources
    Project Resources

Expenses
    Daily Expense
    Expense History

Analysis
    Cost vs Budget
    Profitability

Reports
    Project-wise
    Farm-wise
    Fish-wise
    Poultry-wise
    Expense
    Revenue
    Profit/Loss
    Date-wise
    Date-range

Administration
    Users
    Permissions
    Audit Logs
```

Normal users must only see farming pages for which they have View permission.

Admins automatically have full access.

---

# 71. Fish Farming Module

Create a Fish Farming module linked to the existing Project.

A Fish Farming project can contain multiple ponds.

Relationship:

```text
Project
   ↓
Ponds
   ↓
Fish Stocking
   ↓
Feed / Treatment / Mortality / Growth
   ↓
Harvest
   ↓
Sales
```

---

# 72. Pond Management

Create:

```text
Ponds
```

Fields:

```text
PondId
ProjectId
PondCode
PondName
Area
AreaUnit
Depth
WaterCapacity
PondType
Status
IsActive
CreatedBy
CreatedDate
ModifiedBy
ModifiedDate
```

Example:

```text
Pond Code: P001
Pond Name: Main Pond
Area: 2.5
Area Unit: Acre
Depth: 6 ft
Status: Active
```

A Project can have multiple ponds.

---

# 73. Fish Type Master

Create:

```text
FishTypes
```

Fields:

```text
FishTypeId
FishCode
FishName
ScientificName
Description
IsActive
CreatedBy
CreatedDate
ModifiedBy
ModifiedDate
```

Example seed data:

```text
Rohu
Catla
Mrigal
Grass Carp
Common Carp
Tilapia
```

Admins must be able to add additional fish types.

---

# 74. Fish Stocking

Create:

```text
FishStocking
```

Fields:

```text
StockingId
PondId
FishTypeId
StockingDate
Quantity
AverageWeight
PurchaseRate
TotalCost
Supplier
ReferenceNo
Remarks
CreatedBy
CreatedDate
ModifiedBy
ModifiedDate
```

Business rules:

* Pond must be active.
* Fish Type must be active.
* Quantity must be greater than zero.
* Cost must not be negative.
* Stocking must be associated with the selected Project.

---

# 75. Fish Feed Management

Create:

```text
FishFeed
```

Fields:

```text
FishFeedId
PondId
FeedDate
FeedType
Quantity
Unit
Rate
TotalCost
Remarks
CreatedBy
CreatedDate
ModifiedBy
ModifiedDate
```

Examples:

```text
Starter Feed
Grower Feed
Floating Feed
Sinking Feed
```

Fish Feed costs must integrate with the existing Expense system.

---

# 76. Fish Treatment

Create:

```text
FishTreatment
```

Fields:

```text
TreatmentId
PondId
TreatmentDate
TreatmentType
Medicine
Quantity
Unit
Cost
Reason
Remarks
CreatedBy
CreatedDate
ModifiedBy
ModifiedDate
```

Examples:

```text
Water Treatment
Medicine
Lime
Salt
Disinfectant
Disease Treatment
```

---

# 77. Fish Mortality

Create:

```text
FishMortality
```

Fields:

```text
MortalityId
PondId
FishTypeId
MortalityDate
Quantity
Reason
Remarks
CreatedBy
CreatedDate
ModifiedBy
ModifiedDate
```

Calculate estimated stock:

```text
Current Fish Stock =
Opening Stock
+ Stocking
- Mortality
- Harvest Quantity
```

Do not modify historical stocking records when calculating current stock.

---

# 78. Fish Growth / Sampling

Create:

```text
FishGrowth
```

Fields:

```text
GrowthId
PondId
FishTypeId
SamplingDate
SampleQuantity
AverageWeight
Remarks
CreatedBy
CreatedDate
ModifiedBy
ModifiedDate
```

Support growth reports such as:

```text
Date
Fish Type
Sample Quantity
Average Weight
```

---

# 79. Fish Harvest

Create:

```text
FishHarvest
```

Fields:

```text
HarvestId
PondId
FishTypeId
HarvestDate
Quantity
TotalWeight
AverageWeight
HarvestCost
Remarks
CreatedBy
CreatedDate
ModifiedBy
ModifiedDate
```

Calculate:

```text
Average Weight =
Total Weight / Quantity
```

Handle division by zero.

---

# 80. Fish Sales

Create:

```text
FishSales
```

Fields:

```text
SaleId
ProjectId
HarvestId
FishTypeId
SaleDate
CustomerName
Quantity
TotalWeight
Rate
TotalAmount
PaymentStatus
ReferenceNo
Remarks
CreatedBy
CreatedDate
ModifiedBy
ModifiedDate
```

Support:

```text
Paid
Partially Paid
Pending
```

Fish sales must contribute to Project/Farm Revenue.

---

# 81. Poultry Farming Module

Create a Poultry Farming module linked to the existing Project.

Relationship:

```text
Project
   ↓
Poultry Shed
   ↓
Poultry Batch
   ↓
Chick Purchase
   ↓
Feed / Medicine / Vaccination / Mortality / Growth
   ↓
Egg Production / Bird Sales
```

---

# 82. Poultry Shed Management

Create:

```text
PoultrySheds
```

Fields:

```text
ShedId
ProjectId
ShedCode
ShedName
Capacity
CapacityUnit
ShedType
Status
IsActive
CreatedBy
CreatedDate
ModifiedBy
ModifiedDate
```

Example:

```text
Shed Code: S001
Capacity: 5000
Shed Type: Broiler
Status: Active
```

---

# 83. Poultry Batch Management

Create:

```text
PoultryBatches
```

Fields:

```text
BatchId
ProjectId
ShedId
BatchCode
BirdType
StartDate
ExpectedSaleDate
InitialQuantity
PurchaseCost
Status
Remarks
CreatedBy
CreatedDate
ModifiedBy
ModifiedDate
```

Bird types:

```text
Broiler
Layer
Country Chicken
Other
```

A Shed may contain multiple batches over time.

Do not allow overlapping active batches if the configured shed capacity would be exceeded.

---

# 84. Chick Purchase

Create:

```text
ChickPurchase
```

Fields:

```text
PurchaseId
BatchId
PurchaseDate
Supplier
Quantity
Rate
TotalAmount
ReferenceNo
Remarks
CreatedBy
CreatedDate
ModifiedBy
ModifiedDate
```

Calculate:

```text
TotalAmount = Quantity × Rate
```

---

# 85. Poultry Feed Management

Create:

```text
PoultryFeed
```

Fields:

```text
FeedId
BatchId
FeedDate
FeedType
Quantity
Unit
Rate
TotalCost
Remarks
CreatedBy
CreatedDate
ModifiedBy
ModifiedDate
```

Feed types may include:

```text
Starter
Grower
Finisher
Layer Feed
Other
```

Poultry feed costs must integrate with the existing Expense system.

---

# 86. Poultry Treatment / Vaccination

Create:

```text
PoultryTreatment
```

Fields:

```text
TreatmentId
BatchId
TreatmentDate
TreatmentType
Medicine
Quantity
Cost
Reason
Remarks
CreatedBy
CreatedDate
ModifiedBy
ModifiedDate
```

Treatment types:

```text
Vaccination
Medicine
Vitamin
Antibiotic
Disease Treatment
Other
```

---

# 87. Poultry Mortality

Create:

```text
PoultryMortality
```

Fields:

```text
MortalityId
BatchId
MortalityDate
Quantity
Reason
Remarks
CreatedBy
CreatedDate
ModifiedBy
ModifiedDate
```

Calculate:

```text
Current Birds =
Initial Birds
- Mortality
- Sold Birds
```

Do not modify the original batch quantity.

---

# 88. Poultry Growth / Weight

Create:

```text
PoultryGrowth
```

Fields:

```text
GrowthId
BatchId
SampleDate
SampleQuantity
AverageWeight
Remarks
CreatedBy
CreatedDate
ModifiedBy
ModifiedDate
```

Display growth trends:

```text
Week
Average Weight
Sample Quantity
```

---

# 89. Egg Production

For Layer projects, create:

```text
EggProduction
```

Fields:

```text
ProductionId
BatchId
ProductionDate
GoodEggs
BrokenEggs
TotalEggs
Remarks
CreatedBy
CreatedDate
ModifiedBy
ModifiedDate
```

Calculate:

```text
TotalEggs = GoodEggs + BrokenEggs
```

Dashboard metrics:

```text
Today's Eggs
Monthly Eggs
Good Eggs
Broken Eggs
Egg Production %
Average Eggs per Bird
```

---

# 90. Poultry Sales

Create:

```text
PoultrySales
```

Fields:

```text
SaleId
ProjectId
BatchId
SaleDate
CustomerName
BirdQuantity
TotalWeight
Rate
TotalAmount
PaymentStatus
ReferenceNo
Remarks
CreatedBy
CreatedDate
ModifiedBy
ModifiedDate
```

Support:

```text
Paid
Partially Paid
Pending
```

Poultry sales must contribute to Project/Farm Revenue.

---

# 91. Integration With Existing Daily Expense

The existing Daily Expense functionality must support multiple Budget Codes.

Do not create separate expense systems for Fish Farming and Poultry Farming.

Use the existing:

```text
ExpenseHeader
ExpenseDetail
```

structure.

The Expense Header contains common information:

```text
ExpenseId
ExpenseDate
ProjectId
ResourceId
FarmType
ReferenceNo
Remarks
TotalAmount
CreatedBy
CreatedDate
ModifiedBy
ModifiedDate
IsDeleted
```

Expense Detail contains multiple Budget Codes:

```text
ExpenseDetailId
ExpenseId
BudgetCodeId
Description
Amount
Remarks
CreatedBy
CreatedDate
ModifiedBy
ModifiedDate
IsDeleted
```

Example:

```text
Expense Date: 04-Oct-2026
Project: Fish Farm Unit 1
Resource: Farm Manager

Budget Code                 Amount
--------------------------------------
FISH-FEED                   ₹5,000
FISH-MEDICINE               ₹1,500
FISH-LABOUR                 ₹2,000
FISH-TRANSPORT                ₹800
--------------------------------------
Total                       ₹9,300
```

Another example:

```text
Expense Date: 04-Oct-2026
Project: Poultry Farm Unit 1
Resource: Farm Manager

Budget Code                 Amount
--------------------------------------
POULTRY-FEED                ₹8,000
POULTRY-MEDICINE            ₹1,200
POULTRY-LABOUR              ₹2,500
POULTRY-ELECTRICITY         ₹1,000
--------------------------------------
Total                      ₹12,700
```

---

# 92. Farming-Specific Expense Reference

Allow the Expense Header to optionally reference a farming entity.

Add:

```text
FarmEntityType
FarmEntityId
```

Examples:

```text
FarmEntityType = Pond
FarmEntityId = 10
```

or:

```text
FarmEntityType = PoultryBatch
FarmEntityId = 25
```

This allows the system to identify which Pond or Poultry Batch incurred the expense.

Do not make this mandatory for every general project expense.

---

# 93. Farming Budget Codes

Create seed Budget Codes for Fish Farming:

```text
FISH-FEED
FISH-SEED
FISH-MEDICINE
FISH-LABOUR
FISH-WATER
FISH-ELECTRICITY
FISH-MAINTENANCE
FISH-TRANSPORT
FISH-HARVEST
FISH-OTHER
```

Create seed Budget Codes for Poultry Farming:

```text
POULTRY-CHICK
POULTRY-FEED
POULTRY-MEDICINE
POULTRY-VACCINE
POULTRY-LABOUR
POULTRY-ELECTRICITY
POULTRY-MAINTENANCE
POULTRY-TRANSPORT
POULTRY-SALE
POULTRY-OTHER
```

Admins must be able to add additional Budget Codes.

---

# 94. Revenue Management

Add a common Revenue module.

Create:

```text
Revenue
```

Fields:

```text
RevenueId
RevenueDate
ProjectId
FarmType
RevenueType
ReferenceId
CustomerName
Quantity
Weight
Rate
Amount
PaymentStatus
Remarks
CreatedBy
CreatedDate
ModifiedBy
ModifiedDate
IsDeleted
```

Revenue types:

```text
Fish Sale
Poultry Sale
Egg Sale
Other Farm Revenue
```

Fish Sales and Poultry Sales may either write directly to this common Revenue table or be exposed through a unified reporting view.

Avoid duplicate financial amounts.

---

# 95. Profitability

Add a new:

```text
Profitability
```

analysis page.

Calculate:

```text
Revenue
-
Expenses
=
Gross Profit
```

Display:

```text
Total Revenue
Total Expense
Gross Profit
Profit %
```

Formula:

```text
Gross Profit = Total Revenue - Total Expense
```

```text
Profit % = (Gross Profit / Total Revenue) × 100
```

Handle zero revenue safely.

---

# 96. Farming KPIs

For Fish Farming display:

```text
Total Ponds
Active Ponds
Total Fish Stocked
Current Fish Stock
Total Mortality
Total Harvest
Total Harvest Weight
Fish Sales
Fish Revenue
Fish Expense
Fish Profit
```

For Poultry Farming display:

```text
Total Sheds
Active Sheds
Active Batches
Total Birds
Current Birds
Total Mortality
Mortality %
Total Feed
Total Eggs
Bird Sales
Egg Revenue
Poultry Expense
Poultry Revenue
Poultry Profit
```

---

# 97. Unified Dashboard

Update the existing Dashboard.

Add filter:

```text
Farm Type:
All
Fish Farming
Poultry Farming
```

Existing filters remain:

```text
Project
Budget Code
From Date
To Date
```

Quick filters:

```text
Current Month
Previous Month
Last 3 Months
Last 6 Months
Current Year
Previous Year
Custom Range
```

Dashboard must dynamically change based on the selected Farm Type.

---

# 98. Fish Dashboard

When:

```text
Farm Type = Fish Farming
```

show:

```text
Ponds
Fish Stock
Mortality
Harvest
Feed Cost
Treatment Cost
Revenue
Expense
Profit
```

Charts:

```text
Fish Type-wise Stock
Pond-wise Expense
Monthly Feed Consumption
Monthly Expense
Monthly Harvest
Fish Sales
Cost vs Budget
Revenue vs Expense
```

---

# 99. Poultry Dashboard

When:

```text
Farm Type = Poultry Farming
```

show:

```text
Sheds
Active Batches
Birds
Mortality
Feed Consumption
Egg Production
Sales
Revenue
Expense
Profit
```

Charts:

```text
Batch-wise Birds
Batch-wise Mortality
Feed Consumption
Average Weight
Egg Production
Monthly Expense
Monthly Revenue
Cost vs Budget
Revenue vs Expense
```

---

# 100. Farming Reports

Add the following reports.

## Farm-wise Report

Columns:

```text
Farm Type
Project
Budget
Expense
Revenue
Profit
Profit %
```

## Fish Farming Report

Columns:

```text
Project
Pond
Fish Type
Stocked Quantity
Mortality
Current Stock
Harvest Quantity
Harvest Weight
Sales
Expense
Profit
```

## Poultry Farming Report

Columns:

```text
Project
Shed
Batch
Initial Birds
Mortality
Current Birds
Feed
Average Weight
Eggs
Bird Sales
Expense
Revenue
Profit
```

## Feed Consumption Report

Filters:

```text
Farm Type
Project
Pond / Batch
From Date
To Date
Feed Type
```

## Mortality Report

Filters:

```text
Farm Type
Project
Pond / Batch
From Date
To Date
```

## Production Report

For Fish:

```text
Stocking
Growth
Harvest
```

For Poultry:

```text
Birds
Growth
Egg Production
Sales
```

All reports must support:

```text
Pagination
Sorting
Filtering
Excel Export
Date Range
Project Filter
Farm Type Filter
```

---

# 101. Cost vs Budget Enhancement

Update the existing Cost vs Budget module to support:

```text
Farm Type
Project
Budget Code
Pond
Poultry Batch
From Date
To Date
```

Display:

```text
Budget
Actual Expense
Remaining Budget
Variance
Utilization %
```

For farming-specific analysis:

```text
Fish Farm Cost vs Budget
Poultry Farm Cost vs Budget
```

Highlight projects that exceed their budget.

---

# 102. Farming Database Relationships

Use the following logical relationships:

```text
Projects
   |
   +--- Ponds
   |      |
   |      +--- FishStocking
   |      +--- FishFeed
   |      +--- FishTreatment
   |      +--- FishMortality
   |      +--- FishGrowth
   |      +--- FishHarvest
   |
   +--- PoultrySheds
          |
          +--- PoultryBatches
                 |
                 +--- ChickPurchase
                 +--- PoultryFeed
                 +--- PoultryTreatment
                 +--- PoultryMortality
                 +--- PoultryGrowth
                 +--- EggProduction
                 +--- PoultrySales

Projects
   |
   +--- ProjectBudgets
   |
   +--- ExpenseHeader
   |       |
   |       +--- ExpenseDetail
   |
   +--- Revenue
```

Use proper foreign keys.

---

# 103. Farming Stored Procedures

Create stored procedures such as:

## Ponds

```text
usp_Pond_GetAll
usp_Pond_GetById
usp_Pond_Insert
usp_Pond_Update
usp_Pond_Delete
usp_Pond_SetActive
```

## Fish

```text
usp_FishType_GetAll
usp_FishStocking_Get
usp_FishStocking_Insert
usp_FishStocking_Update
usp_FishStocking_Delete

usp_FishFeed_Get
usp_FishFeed_Insert
usp_FishFeed_Update
usp_FishFeed_Delete

usp_FishTreatment_Get
usp_FishTreatment_Insert
usp_FishTreatment_Update
usp_FishTreatment_Delete

usp_FishMortality_Get
usp_FishMortality_Insert
usp_FishMortality_Update
usp_FishMortality_Delete

usp_FishGrowth_Get
usp_FishGrowth_Insert
usp_FishGrowth_Update
usp_FishGrowth_Delete

usp_FishHarvest_Get
usp_FishHarvest_Insert
usp_FishHarvest_Update
usp_FishHarvest_Delete

usp_FishSales_Get
usp_FishSales_Insert
usp_FishSales_Update
usp_FishSales_Delete
```

## Poultry

```text
usp_PoultryShed_GetAll
usp_PoultryShed_GetById
usp_PoultryShed_Insert
usp_PoultryShed_Update
usp_PoultryShed_Delete

usp_PoultryBatch_Get
usp_PoultryBatch_Insert
usp_PoultryBatch_Update
usp_PoultryBatch_Delete

usp_ChickPurchase_Get
usp_ChickPurchase_Insert
usp_ChickPurchase_Update
usp_ChickPurchase_Delete

usp_PoultryFeed_Get
usp_PoultryFeed_Insert
usp_PoultryFeed_Update
usp_PoultryFeed_Delete

usp_PoultryTreatment_Get
usp_PoultryTreatment_Insert
usp_PoultryTreatment_Update
usp_PoultryTreatment_Delete

usp_PoultryMortality_Get
usp_PoultryMortality_Insert
usp_PoultryMortality_Update
usp_PoultryMortality_Delete

usp_PoultryGrowth_Get
usp_PoultryGrowth_Insert
usp_PoultryGrowth_Update
usp_PoultryGrowth_Delete

usp_EggProduction_Get
usp_EggProduction_Insert
usp_EggProduction_Update
usp_EggProduction_Delete

usp_PoultrySales_Get
usp_PoultrySales_Insert
usp_PoultrySales_Update
usp_PoultrySales_Delete
```

---

# 104. Farming Dashboard Stored Procedures

Create:

```text
usp_FarmDashboard_Summary
usp_FishDashboard_Summary
usp_PoultryDashboard_Summary
usp_FishDashboard_PondWise
usp_FishDashboard_FishTypeWise
usp_FishDashboard_Monthly
usp_PoultryDashboard_BatchWise
usp_PoultryDashboard_Monthly
usp_PoultryDashboard_EggProduction
usp_FarmDashboard_RevenueExpense
usp_FarmDashboard_Profitability
```

All dashboard calculations must be performed efficiently in SQL Server.

Do not load all transactional records into Angular just to calculate totals.

---

# 105. Farming Views

Create reporting views:

```text
vw_FishCurrentStock
vw_FishPondSummary
vw_FishHarvestSummary
vw_FishSalesSummary
vw_FishExpenseSummary

vw_PoultryCurrentStock
vw_PoultryBatchSummary
vw_PoultryMortalitySummary
vw_PoultryFeedSummary
vw_PoultryEggProductionSummary
vw_PoultrySalesSummary

vw_FarmRevenueExpense
vw_FarmProfitability
vw_FarmCostVsBudget
```

---

# 106. Farming Permissions

Add the new pages to the existing permission system.

Examples:

```text
Fish Ponds
Fish Types
Fish Stocking
Fish Feed
Fish Treatment
Fish Mortality
Fish Growth
Fish Harvest
Fish Sales

Poultry Sheds
Poultry Batches
Chick Purchase
Poultry Feed
Poultry Treatment
Poultry Mortality
Poultry Growth
Egg Production
Poultry Sales

Revenue
Profitability
Farm Reports
```

Each page must support:

```text
View
Edit
Delete
```

Admins have all permissions.

Normal users receive permissions when the Admin creates or edits their account.

---

# 107. Farming Audit Logging

Log:

```text
Pond Created
Pond Updated
Fish Stocking Added
Fish Feed Added
Fish Mortality Added
Fish Harvest Added
Fish Sale Added

Poultry Shed Created
Poultry Batch Created
Chick Purchase Added
Poultry Feed Added
Poultry Mortality Added
Egg Production Added
Poultry Sale Added
```

Financial changes must also be recorded in the existing AuditLogs table.

---

# 108. Farming Business Rules

Implement these validations.

## Fish

```text
Stocking quantity > 0
Mortality quantity > 0
Harvest quantity > 0
Harvest quantity must not exceed available stock
Fish feed quantity > 0
Sale quantity/weight must be valid
```

## Poultry

```text
Initial birds > 0
Mortality quantity > 0
Mortality must not exceed current birds
Sale quantity must not exceed current birds
Feed quantity > 0
Egg quantity cannot be negative
```

Do not allow negative stock.

Use database transactions for operations that affect multiple tables.

---

# 109. Final Integrated Business Flow

The complete system should support this workflow:

```text
Create Project
      ↓
Select Farm Type
      ↓
Create Farm Structure
      ↓
Assign Resources
      ↓
Create Budget Codes
      ↓
Create Project Budget
      ↓
Start Farming Operations
      ↓
Record Production Activities
      ↓
Record Daily Expenses
      ↓
Record Revenue / Sales
      ↓
Calculate Cost
      ↓
Compare Cost vs Budget
      ↓
Calculate Revenue
      ↓
Calculate Profitability
      ↓
Dashboard
      ↓
Reports
      ↓
Excel Export
```

---

# 110. Important Integration Rule

Do NOT duplicate common functionality.

Use the existing modules for:

```text
Users
Permissions
Projects
Budget Codes
Project Budgets
Resources
Expenses
Cost vs Budget
Reports
Dashboard
Audit Logs
```

Add Fish Farming and Poultry Farming as specialized operational modules.

The final system should therefore be a **single integrated Project + Farm Management application**, not separate Fish Farming and Poultry Farming applications.

---

# 111. Updated Definition of Done

The application is complete only when the following also work:

* Fish Farming project can be created.
* Poultry Farming project can be created.
* Multiple ponds can be created.
* Multiple fish types can be managed.
* Fish stocking can be recorded.
* Fish feed can be recorded.
* Fish treatment can be recorded.
* Fish mortality can be recorded.
* Fish growth can be recorded.
* Fish harvest can be recorded.
* Fish sales can be recorded.
* Multiple poultry sheds can be created.
* Poultry batches can be created.
* Chick purchases can be recorded.
* Poultry feed can be recorded.
* Poultry treatment/vaccination can be recorded.
* Poultry mortality can be recorded.
* Poultry growth can be recorded.
* Egg production can be recorded.
* Poultry sales can be recorded.
* Multiple Budget Codes can be entered within one Daily Expense.
* Farm-specific expenses are linked to the common Expense system.
* Farm revenue is integrated with the financial system.
* Cost vs Budget supports farming projects.
* Profitability calculation works.
* Fish dashboard works.
* Poultry dashboard works.
* Farm-wise reports work.
* Fish reports work.
* Poultry reports work.
* Excel exports work.
* Existing Admin/Normal User permissions work for all new pages.
* Backend authorization protects all new APIs.
* Audit logging works for farming transactions.
* SQL Server tables, views and stored procedures are created automatically.
* Existing Project Management functionality remains fully operational.
